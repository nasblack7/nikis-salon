/* Niki's Grooming Salon — κοινό JS */

(function () {
  "use strict";

  /* ------------------------------------------------------ service worker (PWA) */
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load", function () {
      /* Το /sw.js σερβίρεται από τη ρίζα, αλλιώς το scope θα ήταν /static/
         και ο worker δεν θα έπαιρνε τις πλοηγήσεις των σελίδων. */
      navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(function () {
        /* αν αποτύχει (π.χ. σε HTTP χωρίς HTTPS), η σελίδα δουλεύει κανονικά */
      });
    });
  }

  /* ------------------------------------------------------ εγκατάσταση PWA */
  (function () {
    var bar = document.getElementById("installBar");
    var headerBtn = document.getElementById("headerInstallBtn");
    if (!bar) return;
    var isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    if (!isMobile) return;

    var hint = document.getElementById("installHint");
    var btn = document.getElementById("installBtn");
    var closeBtn = document.getElementById("installClose");
    var dismissed = false;
    try { dismissed = localStorage.getItem("niki_install_dismissed") === "1"; } catch (e) {}
    if (dismissed) return;

    var deferred = null;
    window.addEventListener("beforeinstallprompt", function (e) {
      e.preventDefault();
      deferred = e;
    });

    /* Το Android/Chrome έχει εγκατάσταση σε ένα κλικ. Το iOS χρειάζεται οδηγίες. */
    var isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
    if (isIOS) {
      hint.textContent = "Πατήστε «Μοιράσου» και μετά «Προσθήκη στην αρχική οθόνη».";
      if (btn) btn.style.display = "none";
    } else {
      hint.textContent = "Εγκαταστήστε την εφαρμογή για άμεση πρόσβαση.";
    }

    bar.hidden = false;
    if (headerBtn) headerBtn.hidden = false;

    function doInstall() {
      if (deferred) {
        deferred.prompt();
        deferred.userChoice.finally(function () { deferred = null; });
      } else {
        hint.textContent = "Ανοίξτε το μενού του browser και επιλέξτε «Add to Home Screen».";
      }
    }

    if (btn) {
      btn.addEventListener("click", doInstall);
    }
    if (headerBtn) {
      headerBtn.addEventListener("click", doInstall);
    }

    closeBtn.addEventListener("click", function () {
      bar.hidden = true;
      try { localStorage.setItem("niki_install_dismissed", "1"); } catch (e) {}
    });
  })();


  /* ------------------------------------------------------ αυτόματο κλείσιμο */
  /* Τα μηνύματα έμεναν ανοιχτά μέχρι να τα κλείσει ο χρήστης. Τώρα
     κλείνουν μόνα τους μετά από 5 δευτερόλεπτα.
     Ο χρονόμετρος ΠΑΥΕΙ όσο το ποντίκι είναι επάνω ή το μήνυμα έχει
     εστίαση — αλλιώς το × δεν προλαβαίνει καν να πατηθεί. */
  var FLASH_MS = 5000;
  function armFlash(node) {
    var timer = null;
    function start() {
      if (timer) { clearTimeout(timer); timer = null; }
      timer = setTimeout(function () {
        if (node && node.parentNode) node.parentNode.removeChild(node);
      }, FLASH_MS);
    }
    function stop() {
      if (timer) { clearTimeout(timer); timer = null; }
    }
    node.addEventListener("mouseenter", stop);
    node.addEventListener("mouseleave", start);
    node.addEventListener("focusin", stop);
    node.addEventListener("focusout", start);
    start();
  }

  /* ΟΙ ΔΥΟ ΠΟΡΕΙΕΣ ΠΟΥ ΕΜΦΑΝΙΖΕΤΑΙ ΕΝΑ ΜΗΝΥΜΑ:
     1. ΜΕ ΤΗ ΦΟΡΤΩΣΗ ΤΗΣ ΣΕΛΙΔΑΣ — τα μηνύματα που έφερε ο διακομιστής.
     2. ΜΕΤΑ, ΜΕΣΑ ΑΠΟ AJAX — π.χ. το «αποθηκεύτηκε» στο live calendar.
     Χωρίς τον παρατηρητή, το δεύτερο θα έμενε ανοιχτό για πάντα. */
  function armAllFlashes(root) {
    var nodes = (root || document).querySelectorAll(".flash");
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].dataset.flashArmed) continue;
      nodes[i].dataset.flashArmed = "1";
      armFlash(nodes[i]);
    }
  }
  armAllFlashes(document);

  if (typeof MutationObserver !== "undefined" &&
      document.querySelector(".flash-wrap")) {
    new MutationObserver(function (records) {
      for (var r = 0; r < records.length; r++) {
        for (var n = 0; n < records[r].addedNodes.length; n++) {
          var node = records[r].addedNodes[n];
          if (node.nodeType !== 1) continue;
          if (node.classList && node.classList.contains("flash")) {
            if (node.dataset.flashArmed) continue;
            node.dataset.flashArmed = "1";
            armFlash(node);
          } else {
            armAllFlashes(node);
          }
        }
      }
    }).observe(document.querySelector(".flash-wrap"),
               { childList: true, subtree: true });
  }

  /* ΟΙ ΔΥΟ ΠΟΡΕΙΕΣ ΠΟΥ ΕΜΦΑΝΙΖΕΤΑΙ ΕΝΑ ΜΗΝΥΜΑ:
     1. ΜΕ ΤΗ ΦΟΡΤΩΣΗ ΤΗΣ ΣΕΛΙΔΑΣ — τα μηνύματα που έφερε ο διακομιστής.
     2. ΜΕΤΑ, ΜΕΣΑ ΑΠΟ AJAX — π.χ. το «αποθηκεύτηκε» στο live calendar.
     Χωρίς τον παρατηρητή, το δεύτερο θα έμενε ανοιχτό για πάντα. */
  function armAllFlashes(root) {
    var nodes = (root || document).querySelectorAll(".flash");
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].dataset.flashArmed) continue;
      nodes[i].dataset.flashArmed = "1";
      armFlash(nodes[i]);
    }
  }
  armAllFlashes(document);

  // ΤΟ ΣΩΣΤΟ ΜΕΡΟΣ ΓΙΑ ΠΑΡΑΤΗΡΗΣΗ ΕΙΝΑΙ ΤΟ document.body, ΟΧΙ ΤΟ
  // `.flash-wrap`: το wrap υπάρχει ΜΟΝΟ όταν υπάρχει ήδη μήνυμα
  // ({% if messages %} στο app_base.html). Παρατηρώντας το wrap, σε
  // κάθε σελίδα χωρίς μήνυμα ΔΕΝ ΕΓΚΑΘΙΔΡΟΥΝΑΜΕ ΠΑΡΑΤΗΡΗΤΗ — και τα
  // μηνύματα που έρχονται μετά (AJAX) έμεναν ανοιχτά για πάντα.
  if (typeof MutationObserver !== "undefined" && document.body) {
    new MutationObserver(function (records) {
      for (var r = 0; r < records.length; r++) {
        for (var n = 0; n < records[r].addedNodes.length; n++) {
          var node = records[r].addedNodes[n];
          if (node.nodeType !== 1) continue;
          if (node.classList && node.classList.contains("flash")) {
            if (node.dataset.flashArmed) continue;
            node.dataset.flashArmed = "1";
            armFlash(node);
          } else {
            armAllFlashes(node);
          }
        }
      }
    }).observe(document.body, { childList: true, subtree: true });
  }

  /* ------------------------------------------------------ μενού mobile */
  document.addEventListener("click", function (event) {
    var toggle = event.target.closest("[data-toggle]");
    if (toggle) {
      var target = document.getElementById(toggle.getAttribute("data-toggle"));
      if (target) {
        target.classList.toggle("is-open");
        event.preventDefault();
      }
    }

    /* κλείσιμο μηνύματος */
    var close = event.target.closest(".flash__close");
    if (close) {
      var flash = close.closest(".flash");
      if (flash) flash.remove();
    }

    /* άνοιγμα modal */
    var opener = event.target.closest("[data-modal-open]");
    if (opener) {
      openModal(opener.getAttribute("data-modal-open"));
      event.preventDefault();
    }

    /* κλείσιμο modal */
    if (event.target.closest("[data-modal-close]")) {
      closeModal();
    }
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") closeModal();
  });

  /* ------------------------------------------------------ επιβεβαίωση */
  document.addEventListener("submit", function (event) {
    var message = event.target.getAttribute("data-confirm");
    if (message && !window.confirm(message)) {
      event.preventDefault();
    }
  });

  /* ------------------------------- έτοιμα έξοδα καταστήματος (σύντομα) */
  document.addEventListener("click", function (event) {
    var chip = event.target.closest("[data-expense-preset]");
    if (!chip) return;
    event.preventDefault();
    var item = document.getElementById("item");
    var cat = document.getElementById("category");
    var amount = document.getElementById("amount");
    if (item) item.value = chip.getAttribute("data-expense-preset");
    if (cat) cat.value = chip.getAttribute("data-expense-category") || "";
    /* Το τυπικό ποσό συμπληρώνεται μόνο αν υπάρχει· αλλιώς μένει κενό για
       να το γράψει η ιδιοκτήτρια, γιατί κάθε λογαριασμός διαφέρει. */
    var preset = chip.getAttribute("data-expense-amount");
    if (amount && preset) amount.value = preset;
    if (item) item.focus();
  });

  /* ------------------------------------------------------ modals */
  window.openModal = function (id) {
    var modal = document.getElementById(id);
    if (modal) {
      modal.classList.add("is-open");
      document.body.style.overflow = "hidden";
    }
  };
  function closeModal() {
    document.querySelectorAll(".modal.is-open").forEach(function (modal) {
      modal.classList.remove("is-open");
    });
    document.body.style.overflow = "";
  }

  /* ------------------------------------------------------ μενού: μόνο εικονίδια
     ΖΗΤΗΘΗΚΕ: «να μένουν μόνο τα εικονίδια και το λογότυπο να γίνεται το
     ico του λογοτύπου».

     Η ΚΑΤΑΣΤΑΣΗ ΜΕΝΕΙ ΜΕΤΑ ΑΠΟ ΚΛΕΙΣΙΜΟ ΤΟΥ ΜΕΝΟΥ. Χωρίς αυτό, η ιδιοκτήτρια
     θα έπρεπε να το συμπτύσει κάθε φορά που άνοιγε την εφαρμογή — και ένα
     χαρακτηριστικό που «χάνεται» σε κάθε επανεκκίνηση δεν χρησιμεύει.

     ΜΟΝΟ Ο ΟΝΟΜΑ ΣΤΟ body, ΟΧΙ ΚΑΝΕΝΑ CLASS ΣΤΑ ΣΤΙΛΕ. Έτσι ο κανόνας CSS
     παραμένει ένας, και το JS δεν χρειάζεται να ξέρει πόσα pixel έχει το
     μενού — αλλάζει το όνομα και το CSS κάνει όλα τα υπόλοιπα. */
  (function () {
    var root = document.body;
    var btn = document.getElementById("sidebarToggle");
    if (!root || !btn) return;
    var KEY = "niki_sidebar_collapsed";
    function apply(collapsed) {
      root.classList.toggle("is-collapsed", collapsed);
      btn.setAttribute("aria-expanded", collapsed ? "false" : "true");
      btn.setAttribute("aria-label", collapsed ? "Ανάπτυξη του μενού" : "Συμπτύξη του μενού");
      btn.setAttribute("title", collapsed ? "Ανάπτυξη του μενού" : "Συμπτύξη του μενού");
    }
    var saved = null;
    try { saved = localStorage.getItem(KEY); } catch (e) { /* χωρίς αποθήκευση */ }
    /* ΧΩΡΙΣ ΕΠΙΛΟΓΗ ΑΠΟ ΤΗΝ ΙΔΙΟΚΤΗΤΡΙΑ, ΑΝΑΠΤΥΓΜΕΝΟ. Ένα μενού μόνο
       εικονίδια χωρίς ποτέ να το ζητήσει είναι μπερδεμένο μενού. */
    apply(saved === "1");
    btn.addEventListener("click", function () {
      var next = !root.classList.contains("is-collapsed");
      apply(next);
      try { localStorage.setItem(KEY, next ? "1" : "0"); } catch (e) { /* αδιαφορεί */ }
    });
  })();

  /* ------------------------------------------------------ tabs σε πίνακες */
  document.addEventListener("click", function (event) {
    var trigger = event.target.closest("[data-filter]");
    if (!trigger) return;
    var target = trigger.getAttribute("data-filter");
    document.querySelectorAll("[data-filter]").forEach(function (el) {
      el.classList.toggle("is-active", el.getAttribute("data-filter") === target);
    });
    document.querySelectorAll("[data-filter-panel]").forEach(function (panel) {
      panel.hidden = panel.getAttribute("data-filter-panel") !== target;
    });
  });

  /* ------------------------------------------------------ επιβεβαίωση ακύρωσης */
  window.confirmCancel = function (form) {
    var reason = window.prompt("Αιτία ακύρωσης (προαιρετικό):", "");
    if (reason === null) return false;
    var input = form.querySelector("[name=reason]");
    if (input) input.value = reason;
    return true;
  };

  /* ------------------------------------------------------ auto-submit φίλτρων */
  document.addEventListener("change", function (event) {
    if (event.target.matches("[data-autosubmit]")) {
      var form = event.target.closest("form");
      if (form) form.submit();
    }
  });

  /* ------------------------------------------------------ επισκόπηση ημερομηνίας */
  window.confirmDate = function (input) {
    return window.confirm("Θέλετε να μεταβείτε στις " + input.value + ";");
  };

  /* ------------------------------------------------------ εκτύπωση */
    window.printPage = function () { window.print(); };

    /* ------------------------------------------------------ προεπισκόπηση αρχείου */
    /* Ο χρήστης βλέπει το λογότυπο ΠΡΙΝ πατήσει «Αποθήκευση» — αλλιώς
      πατάει, περιμένει, και μαθαίνει μετά από αρκετή ώρα αν πέτυχε. */

    /* ΟΡΙΑ ΠΟΥ ΘΕΛΕΙ Ο ΔΙΑΚΟΜΙΣΤΗΣ (app/logo.py). Εδώ είναι ενδεικτικά,
       για να μην ξοδεύει η ιδιοκτήτρια χρόνο σε ανέβασμα που θα απορριφθεί. */
    var LOGO_MAX_BYTES = 2 * 1024 * 1024;
    var LOGO_KINDS = /^image\/(png|jpeg|jpg|webp)$/i;
    var LOGO_KIND_TEXT = { "image/png": "PNG", "image/jpeg": "JPG",
                           "image/jpg": "JPG", "image/webp": "WebP" };

    function humanSize(bytes) {
      if (bytes < 1024) return bytes + " B";
      if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + " KB";
      return (bytes / (1024 * 1024)).toFixed(1) + " MB";
    }

    function previewSay(id, text, kind) {
      var box = id ? document.getElementById(id) : null;
      if (!box) return;
      box.textContent = text || "";
      box.hidden = !text;
      box.className = "preview-msg" + (kind ? " preview-msg--" + kind : "");
    }

    document.addEventListener("change", function (event) {
      var input = event.target;
      if (!input.matches || !input.matches("[data-preview]")) return;
      var preview = document.getElementById(input.getAttribute("data-preview"));
      if (!preview) return;
      var msgId = input.getAttribute("data-preview-msg");
      var file = input.files && input.files[0];

      /* ΑΚΥΡΩΣΗ ΤΟΥ ΔΙΑΛΟΓΟΥ. Δεν είναι σφάλμα — απλώς δεν διάλεξε
         αρχείο. Καμία εικόνα, κανένα μήνυμα: το προηγούμενο μήνυμα
         σφάλματος αφαιρείται, όχι όμως η ιδιοκτήτρια τρόμοξε. */
      if (!file) {
        preview.hidden = true;
        preview.removeAttribute("src");
        previewSay(msgId, "");
        return;
      }

      /* ΤΥΠΟΣ. Ο browser μας λέει τι νομίζει ότι είναι· ο διακομιστής
         ελέγχει τα πραγματικά bytes. Εδώ κόβω το ασήμαντο. */
      if (file.type && !LOGO_KINDS.test(file.type)) {
        preview.hidden = true;
        preview.removeAttribute("src");
        previewSay(msgId, "Αυτό το αρχείο δεν είναι PNG, JPG ή WebP — " +
          "η ιδιοκτήτρια δεν θα μπορέσει να το αποθηκεύσει.", "error");
        input.value = "";
        return;
      }

      /* ΜΕΓΕΘΟΣ. */
      if (file.size > LOGO_MAX_BYTES) {
        preview.hidden = true;
        preview.removeAttribute("src");
        previewSay(msgId, "Το αρχείο είναι " + humanSize(file.size) +
          " · το όριο είναι 2 MB. Μίκρηνέ το πριν το ανεβάσεις.", "error");
        input.value = "";
        return;
      }

      /* ΠΡΟΕΠΙΣΚΟΠΗΣΗ. */
      if (preview.dataset.objectUrl) {
        URL.revokeObjectURL(preview.dataset.objectUrl);
      }
      var url = URL.createObjectURL(file);
      preview.dataset.objectUrl = url;

      /* ΤΟ ΚΡΙΣΙΜΟ. ΠΡΙΝ έβριζα το hidden πρώτα και μετά έβριζα το src.
         Αν η φόρτωση αποτύχαινε, έμενε ένα ΣΠΑΣΜΕΝΟ ΣΥΜΒΟΛΟ εικόνας χωρίς
         εξήγηση — και το onload του προτύπου δεν βοηθάει, γιατί δεν
         εκτελείται ποτέ σε αποτυχημένη φόρτωση. Με το error αντι-
         χειρίζομαι την περίπτωση και λέω στην ιδιοκτήτρια τι έγινε. */
      preview.onload = function () {
        preview.hidden = false;
        previewSay(msgId, (LOGO_KIND_TEXT[file.type] || "Εικόνα") +
          " · " + humanSize(file.size) + " · " + file.name +
          " — πατά «Αποθήκευση λογότυπου» για να το οριστικοποιήσει.", "ok");
      };
      preview.onerror = function () {
        preview.hidden = true;
        preview.removeAttribute("src");
        previewSay(msgId, "Το πρόγραμμα δεν μπόρεσε να διαβάσει αυτή την " +
          "εικόνα. Δοκίμασε PNG ή JPG, ή άνοιξε την και αποθήκευσέ τη " +
          "ως PNG από τα Windows.", "error");
        /* Καθαρίζω το input: αλλιώς η επιλογή του ΙΔΙΟΥ αρχείου δεν
           πυροδοτεί νέο change και η ιδιοκτήτρια νομίζει ότι η εφαρμογή
           έχει κολλήσει. */
        input.value = "";
      };
      preview.hidden = true;
      preview.src = url;
    });
})();
