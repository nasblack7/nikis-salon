"""Μηχανή διαθεσιμότητας — Niki's Grooming Salon Appointment Management."""

from __future__ import annotations

from datetime import date as date_cls, datetime, time, timedelta
from typing import Iterable, Optional

from flask import current_app

from .extensions import db
from .models import (
    OPEN_STATUSES,
    Appointment,
    AvailabilityRule,
    Groomer,
    SalonDaySettings,
    TimeOff,
)

REASON_CLOSED = "closed"
REASON_NO_STAFF = "no_staff"
REASON_BOOKED = "booked"
REASON_PAST = "past"
REASON_LEAD = "lead"
REASON_OFF = "off"
REASON_FREE = "free"

REASON_LABELS = {
    REASON_CLOSED: "Κλειστό",
    REASON_NO_STAFF: "Δεν εργάζεται στυλίστρια",
    REASON_BOOKED: "Κλεισμένο",
    REASON_PAST: "Έχει περάσει",
    REASON_LEAD: "Πολύ κοντά στην ώρα αυτή",
    REASON_OFF: "Απουσία",
    REASON_FREE: "Διαθέσιμο",
}


def _minutes(value: time) -> int:
    return value.hour * 60 + value.minute


def _time_from_minutes(total: int) -> time:
    total = max(0, min(24 * 60 - 1, total))
    return time(total // 60, total % 60)


def combine(day: date_cls, minutes: int) -> datetime:
    return datetime.combine(day, _time_from_minutes(minutes))


def parse_hhmm(value: str) -> int:
    try:
        hours, _, mins = str(value).strip().partition(":")
        return int(hours) * 60 + int(mins or 0)
    except (TypeError, ValueError):
        return 0


def slot_step() -> int:
    """Διάστημα μεταξύ διαθέσιμων ωρών, σε λεπτά.

    Προέρχεται από τις Ρυθμίσεις σπα (προεπιλογή 60 = ανά ώρα). Η τιμή
    επιβάλλεται στον έλεγχο ώστε να μην είναι 0 ή μη λογική.
    """
    try:
        from .models import SalonSettings

        value = SalonSettings.get("slot_minutes")
    except Exception:
        value = None
    try:
        step = int(value)
    except (TypeError, ValueError):
        step = 0
    if step < 5:
        step = int(current_app.config.get("SLOT_MINUTES", 60) or 60)
    return step


def horizon_days() -> int:
    return int(current_app.config.get("BOOKING_HORIZON_DAYS", 60))


def min_lead_minutes() -> int:
    return int(current_app.config.get("MIN_LEAD_MINUTES", 120))


def salon_hours_for(day: date_cls) -> tuple[bool, int, int]:
    row = SalonDaySettings.query.filter_by(weekday=day.weekday()).first()
    if row is None:
        if day.weekday() == 6:
            return True, 0, 0
        return False, 9 * 60, 18 * 60
    if row.is_closed:
        return True, 0, 0
    return False, _minutes(row.open_time), _minutes(row.close_time)


def groomer_windows_for(groomer_id: int, day: date_cls) -> list[tuple[int, int]]:
    closed, salon_open, salon_close = salon_hours_for(day)
    if closed:
        return []
    rules = AvailabilityRule.query.filter_by(groomer_id=groomer_id, weekday=day.weekday()).all()
    windows = []
    for rule in rules:
        start = max(_minutes(rule.start_time), salon_open)
        end = min(_minutes(rule.end_time), salon_close)
        if end - start >= slot_step():
            windows.append((start, end))
    return sorted(windows)


def bookable_groomers() -> list[Groomer]:
    return Groomer.query.filter_by(is_bookable=True).order_by(Groomer.sort_order, Groomer.id).all()


def _busy_from_appointments(groomer_ids: Iterable[int], day: date_cls,
                            exclude_appointment_id: Optional[int] = None):
    ids = [g for g in groomer_ids if g]
    if not ids:
        return {}
    day_start = datetime.combine(day, time(0, 0))
    day_end = day_start + timedelta(days=1)

    query = Appointment.query.filter(
        Appointment.groomer_id.in_(ids),
        Appointment.status.in_(OPEN_STATUSES),
        Appointment.start_at < day_end,
        Appointment.end_at > day_start,
    )
    if exclude_appointment_id:
        query = query.filter(Appointment.id != exclude_appointment_id)

    busy: dict[int, list[tuple[int, int]]] = {}
    for appt in query.all():
        start = appt.start_at
        end = appt.end_at
        s = max(_minutes(start.time()), 0) if start.date() == day else 0
        e = min(_minutes(end.time()), 24 * 60) if end.date() == day else 24 * 60
        busy.setdefault(appt.groomer_id, []).append((s, e))
    return busy


def _busy_from_time_off(groomer_ids: Iterable[int], day: date_cls):
    ids = [g for g in groomer_ids if g]
    if not ids:
        return {}
    day_start = datetime.combine(day, time(0, 0))
    day_end = day_start + timedelta(days=1)
    rows = TimeOff.query.filter(
        TimeOff.groomer_id.in_(ids),
        TimeOff.start_at < day_end,
        TimeOff.end_at > day_start,
    ).all()
    busy: dict[int, list[tuple[int, int]]] = {}
    for row in rows:
        s = max(_minutes(row.start_at.time()), 0) if row.start_at.date() == day else 0
        e = min(_minutes(row.end_at.time()), 24 * 60) if row.end_at.date() == day else 24 * 60
        busy.setdefault(row.groomer_id, []).append((s, e))
    return busy


def _merge(busy: dict) -> dict:
    out = {}
    for groomer_id, ranges in busy.items():
        merged: list[list[int]] = []
        for start, end in sorted(ranges):
            if merged and start <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])
        out[groomer_id] = [(s, e) for s, e in merged]
    return out


def busy_map(groomer_ids: Iterable[int], day: date_cls, exclude_appointment_id=None) -> dict:
    merged = _merge(_busy_from_appointments(groomer_ids, day, exclude_appointment_id))
    off = _merge(_busy_from_time_off(groomer_ids, day))
    for groomer_id, ranges in off.items():
        merged.setdefault(groomer_id, []).extend(ranges)
        merged[groomer_id] = sorted(merged[groomer_id])
    return merged


def slots_for_date(
    day: date_cls,
    duration: int,
    groomer_id: Optional[int] = None,
    exclude_appointment_id: Optional[int] = None,
) -> list[dict]:
    step = slot_step()
    # Η διάρκεια των υπηρεσιών ΔΕΝ καθορίζει τα slots: το βήμα είναι σταθερό
    # (ώρες) από το άνοιγμα ως το κλείσιμο. Κρατάμε την παράμετρο για
    # συμβατότητα, αλλά δεν τη χρησιμοποιούμε για να κόψουμε ώρες.
    _ = duration

    closed, salon_open, salon_close = salon_hours_for(day)
    if closed:
        return [
            {
                "start": "—", "end": "—", "start_min": 0, "end_min": 0,
                "groomer_ids": [], "groomer_id": groomer_id, "available": False,
                "reason": REASON_CLOSED, "label": "Κλειστό",
            }
        ]

    groomers = [
        g
        for g in ([db.session.get(Groomer, groomer_id)] if groomer_id else bookable_groomers())
        if g is not None and g.is_bookable
    ]
    if not groomers:
        return [
            {
                "start": "—", "end": "—", "start_min": 0, "end_min": 0,
                "groomer_ids": [], "groomer_id": groomer_id, "available": False,
                "reason": REASON_NO_STAFF, "label": REASON_LABELS[REASON_NO_STAFF],
            }
        ]

    ids = [g.id for g in groomers]
    busy = busy_map(ids, day, exclude_appointment_id)
    now = datetime.now()
    earliest = now + timedelta(minutes=min_lead_minutes())
    latest_bookable = now.date() + timedelta(days=horizon_days())
    too_early = day > latest_bookable

    result: list[dict] = []
    # Κάθε βήμα από το άνοιγμα ως το κλείσιμο. Η τελευταία ώρα δείχνεται
    # μόνο αν χωράει ένα ολόκληρο βήμα πριν το κλείσιμο.
    for start in range(salon_open, max(salon_open - 1, salon_close - step) + 1, step):
        end = start + step
        free_ids: list[int] = []
        # ΠΟΙΕΣ ΕΙΝΑΙ ΑΠΑΣΧΟΛΗΜΕΝΕΣ ΣΕ ΑΥΤΗ ΤΗΝ ΩΡΑ. Χωρίς αυτό το όνομα,
        # η προειδοποίηση θα έλεγε απλώς «η ώρα είναι κατειλημμένη» και η
        # ιδιοκτήτρια δεν θα ήξερε ποιον αφορά — οπότε δεν θα μπορούσε ούτε
        # να αποφασίσει αν το θέλει.
        busy_ids: list[int] = []
        for g in groomers:
            windows = groomer_windows_for(g.id, day)
            # Διαθέσιμος αν η ιδία ώρα έναρξης πέφτει μέσα στο παράθυρό του.
            inside = any(w_start <= start < w_end for w_start, w_end in windows)
            if not inside:
                continue
            clash = any(start < b_end and b_start < end for b_start, b_end in busy.get(g.id, []))
            if clash:
                busy_ids.append(g.id)
            else:
                free_ids.append(g.id)

        slot_start_dt = combine(day, start)
        slot_end_dt = combine(day, end)
        if too_early:
            reason = REASON_LEAD
        elif day < now.date():
            reason = REASON_PAST
        elif free_ids:
            reason = REASON_FREE
        elif slot_start_dt < earliest:
            reason = REASON_LEAD
        else:
            reason = REASON_BOOKED

        result.append(
            {
                "start": f"{start // 60:02d}:{start % 60:02d}",
                "end": f"{end // 60:02d}:{end % 60:02d}",
                "start_min": start,
                "end_min": end,
                "groomer_ids": free_ids,
                "groomer_id": groomer_id if groomer_id in free_ids else (free_ids[0] if free_ids else None),
                "available": bool(free_ids) and reason == REASON_FREE,
                "reason": reason,
                "label": REASON_LABELS.get(reason, ""),
                # Ποιος είναι απασχολημένος. Το διαβάζει η επιβεβαίωση
                # «η ώρα είναι κατειλημμένη — κλείστες όμως;».
                "busy": bool(busy_ids),
                "busy_groomers": [
                    {"id": g.id, "name": g.name}
                    for g in groomers if g.id in busy_ids
                ],
            }
        )
    return result


def next_free_slots(
    count: int = 5,
    duration: int = 60,
    groomer_id: Optional[int] = None,
    exclude_appointment_id: Optional[int] = None,
    from_day: Optional[date_cls] = None,
) -> list[dict]:
    """Οι επόμενες ΔΙΑΘΕΣΙΜΕΣ ώρες — από όλες τις μελλοντικές μέρες.

    ΤΙ ΖΗΤΗΣΕ Η ΙΔΙΟΚΤΗΤΡΙΑ: «να μαθαίνω από το σύστημα πότε είναι η επόμενη
    διαθέσιμη ώρα». Η παλιά φόρμα έδειχνε μόνο τη ΜΕΡΑ πΟΥ ΕΙΧΕ ΕΠΙΛΕΓΘΕΙ, και
    αν ήταν γεμάτη η ιδιοκτήτρια έπρεπε να μυρίζει μέρα-μέρα ποια έχει κενό.

    ΕΔΩ ΨΑΧΝΟΥΜΕ ΜΕΣΑ ΣΤΟ ΟΡΙΖΟΝΤΑ ΤΩΝ ΚΡΑΤΗΣΕΩΝ και επιστρέφουμε τις πρώτες
    `count` που είναι ΠΡΑΓΜΑΤΙΚΑ ΕΛΕΥΘΕΡΕΣ. Σταματάμε στο πρώτο κενό κάθε
    ημέρας, όχι σε όλες τις ώρες της — αλλιώς η λίστα θα γεμιζε με έξι ώρες
    της ίδιας μέρας και η ιδιοκτήτρια δεν θα έβλεπε ποτέ αύριο.
    """
    start_day = from_day or date_cls.today()
    last = start_day + timedelta(days=horizon_days())
    found: list[dict] = []
    day = start_day
    while day <= last and len(found) < count:
        slots = slots_for_date(day, duration, groomer_id,
                               exclude_appointment_id=exclude_appointment_id)
        if not (slots and slots[0].get("start") == "—"):
            for slot in slots:
                if slot.get("available"):
                    found.append({"date": day.isoformat(), "start": slot["start"],
                                  "end": slot["end"]})
                    break        # μία ανά ημέρα αρκεί
        day += timedelta(days=1)
    return found


def week_preview(from_day: date_cls, days: int = 7, duration: int = 60,
                 groomer_id: Optional[int] = None) -> list[dict]:
    preview = []
    for day in [from_day + timedelta(days=i) for i in range(days)]:
        slots = slots_for_date(day, duration, groomer_id)
        closed = bool(slots) and slots[0]["reason"] == REASON_CLOSED
        free = [s for s in slots if s["available"]]
        preview.append(
            {
                "date": day,
                "iso": day.isoformat(),
                "weekday": day.weekday(),
                "weekday_short": ["Δε", "Τρ", "Τε", "Πε", "Πα", "Σα", "Κυ"][day.weekday()],
                "day": day.day,
                "closed": closed,
                "free_count": len(free),
                "first_free": free[0]["start"] if free else None,
                "slots": [] if closed else slots,
            }
        )
    return preview


def first_conflict(start_at: datetime, end_at: datetime, groomer_id: int,
                   exclude_appointment_id: Optional[int] = None):
    day = start_at.date()
    if end_at.date() != day:
        return "Το ραντεβού δεν μπορεί να διασχίσει δύο μέρες."

    # ══ ΠΑΡΕΛΘΟΝΤΙΚΗ ΗΜΕΡΟΜΗΝΙΑ = ΚΑΤΑΓΡΑΦΗ, ΟΧΙ ΠΡΟΓΡΑΜΜΑΤΙΣΜΟΣ ══
    # ΠΡΩΤΟΣ ΕΛΕΓΧΟΣ, ΕΠΙΤΡΕΠΤΟΝΤΑΣ ΟΛΑ ΤΑ ΥΠΟΛΟΙΠΑ ΝΑ ΠΑΡΑΠΕΡΑΣΟΥΝ.
    # Η σειρά έχει νόημα: όταν γράφουμε κάτι που έγινε, το ωράριο του
    # σαλονιού ΣΗΜΕΡΑ δεν έχει καμία σχέση με τότε. Με τον έλεγχο αυτό
    # ΜΕΤΑ τις ώρες, η ιδιοκτήτρια έπαιρνε «Το Salon είναι κλειστό
    # Κυριακή» για μια επίσκεψη που είχε γίνει Κυριακή — και δεν μπορούσε
    # να τη γράψει. Ίδια λογική και με ώρα εκτός του σημερινού ωραρίου.
    if day < datetime.now().date():
        return None

    closed, salon_open, salon_close = salon_hours_for(day)
    if closed:
        return f"Το Salon είναι κλειστό {['Δευτέρα','Τρίτη','Τετάρτη','Πέμπτη','Παρασκευή','Σάββατο','Κυριακή'][day.weekday()]}."
    if _minutes(start_at.time()) < salon_open or _minutes(end_at.time()) > salon_close:
        return f"Εκτός ωρών λειτουργίας ({salon_open // 60:02d}:00 – {salon_close // 60:02d}:00)."

    windows = groomer_windows_for(groomer_id, day)
    if not windows:
        return "Η συγκεκριμένη στυλίστρια δεν εργάζεται αυτή την ημέρα."
    if not any(w_start <= _minutes(start_at.time()) and _minutes(end_at.time()) <= w_end
               for w_start, w_end in windows):
        return "Η ώρα δεν είναι εντός του ωραρίου της στυλίστριας."

    # Μόνο για ώρα που ΔΕΝ έχει περάσει ακόμα. Μια κράτηση για την ώρα που
    # τρέχει τώρα είναι λογική — κάποιος μπαίνει στο κουρίζι τώρα. Μια
    # κράτηση για χθες δεν είναι, και την πιάσαμε ήδη παραπάνω.
    if (start_at > datetime.now()
            and start_at < datetime.now() + timedelta(minutes=min_lead_minutes())):
        return (f"Χρειάζεται τουλάχιστον {min_lead_minutes() // 60} "
                f"ώρες προειδοποίηση.")
    if start_at.date() > datetime.now().date() + timedelta(days=horizon_days()):
        return f"Δεν επιτρέπεται κράτηση πάνω από {horizon_days()} μέρες."

    return None


def slot_taken(start_at: datetime, end_at: datetime, groomer_id: int,
               exclude_appointment_id: Optional[int] = None) -> Optional[str]:
    """ΠΡΟΕΙΔΟΠΟΙΗΣΗ, ΟΧΙ ΕΜΠΟΔΙΟΣ: υπάρχει ήδη ραντεβού σε αυτή την ώρα.

    ΞΕΧΩΡΙΣΤΑ ΑΠΟ ΤΟ first_conflict, και επίτηδες. Η κάλυψη ώρας δεν είναι
    λάθος: η ιδιοκτήτρια μπορεί να έχει δύο πελάτες την ίδια ώρα, ή να
    γράφει αναδρομικά από τη μνήμη της και να ξεχάσει.

    Το ΠΡΟΒΛΗΜΑ ΤΟΥ ΠΡΩΤΟΥ «ΜΠΛΟΚ» ΗΤΑΝ ΠΡΑΓΜΑΤΙΚΟ: σταματούσε ΟΛΗ ΤΗΝ
    ΕΓΓΡΑΦΗ. Η ιδιοκτήτρια έβλεπε «η ώρα είναι κλεισμένη» — χωρίς να
    μάθει ΠΟΙΑ ώρα, χωρίς να μπορεί να αλλάξει εύκολα — και το ραντεβού
    χανόταν. Τώρα προειδοποιεί και αποθηκεύει.

    ΣΕ ΠΑΡΕΛΘΟΝ ΔΕΝ ΠΡΟΕΙΔΟΠΟΙΕΙ: η «κάλυψη» δεν λέει τίποτα όταν
    κάθε ραντεβού είναι στο παρελθόν.
    """
    if groomer_id is None or start_at.date() < datetime.now().date():
        return None
    busy = busy_map([groomer_id], start_at.date(), exclude_appointment_id)
    for b_start, b_end in busy.get(groomer_id, []):
        if _minutes(start_at.time()) < b_end and b_start < _minutes(end_at.time()):
            return ("Υπάρχει ήδη άλλο ραντεβού σε αυτή την ώρα με την ίδια "
                    "στυλίστρια. Αποθηκεύτηκε κανονικά — αν ήταν λάθος, "
                    "διόρθωσέ το μετά.")
    return None


def groomer_is_free(groomer_id: int, start_at: datetime, end_at: datetime,
                    exclude_appointment_id: Optional[int] = None) -> bool:
    return first_conflict(start_at, end_at, groomer_id, exclude_appointment_id) is None


def auto_assign_groomer(start_at: datetime, end_at: datetime,
                        preferred: Optional[int] = None) -> Optional[int]:
    if preferred:
        if groomer_is_free(preferred, start_at, end_at):
            return preferred
    for groomer in bookable_groomers():
        if groomer_is_free(groomer.id, start_at, end_at):
            return groomer.id
    return None
