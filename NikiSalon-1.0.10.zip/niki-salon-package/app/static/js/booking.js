/**
 * Niki's Grooming Salon Appointment Management — φόρμα ραντεβού.
 * Διαχειρίζεται: επιλογή πελάτη → κατοικίδια, υπηρεσίες → διάρκεια,
 * ημερομηνία → διαθέσιμες ώρες.
 */
(function () {
  "use strict";

  var cfg = window.APPT || {};
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };

  var customerSel = $("#customer_id");
  var customerSearch = $("#customerSearch");
  var customerMatch = $("#customerMatch");
  var petList = $("#petList");
  var dateInput = $("#date");
  var timeSel = $("#time");
  var groomerSel = $("#groomer_id");
  var petHint = $("#petHint");
  var timeHint = $("#timeHint");
  var durLabel = $("#durationLabel");
  var countLabel = $("#serviceCountLabel");
  var sumServices = $("#sumServices");
  var sumPrice = $("#sumPrice");
  var finalPrice = $("#finalPrice");
  var discountRow = $("#discountRow");
  var discountValueCell = $("#discountValueCell");
  var discountValue = $("#discountValue");
  var finalRow = $("#finalRow");
  var discountInput = $("[data-discount]");
  var dateStrip = $("#dateStrip");
  var checks = $$('input[name="service_ids"]');
  var customers = [];

  /* ---------------------------------------------------------- helpers */

  var MIN_CHARS = 3;

  /* Ίδιο του fold() στην Python: χωρίς τόνους, πεζά, τελικό ζ -> σ.
     Έτσι το «Παπαδοπουλου» βρίσκει το «Παπαδόπουλος». */
  function fold(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")   // αφαίρεση τόνων
      .toLowerCase()
      .replace(/ς/g, "σ")                 // τελικό ζ
      .replace(/\s+/g, " ")
      .trim();
  }

  function petNames(customer) {
    return (customer.pets || []).map(function (p) { return p.name; }).join(" ");
  }

  /* Η ετικέτα δείχνει και τα κατοικίδια, ώστε να φαίνεται αμέσως
     αν το κατοικίδιο που ζητάει ο πελάτης ανήκει σε αυτόν. */
  function optionLabel(customer) {
    var label = customer.name || "";
    if (customer.phone) label += " — " + customer.phone;
    var pets = (customer.pets || []).map(function (p) { return p.name; });
    if (pets.length) label += "  ·  " + pets.join(", ");
    return label;
  }

  /* Αναζήτηση σε όνομα, τηλέφωνο, email και ονόματα κατοικιδίων.
     Κάθε λέξη του όρου πρέπει να βρεθεί (AND), ώστε να δουλεύει
     και το «Παπαδ Νίκος». */
  function matches(customer, term) {
    var haystack = fold(
      [customer.name, customer.phone, customer.email, petNames(customer)].join(" ")
    );
    var digits = (customer.phone || "").replace(/\D/g, "");
    if (digits) haystack += " " + digits;
    return term.split(" ").every(function (token) {
      return token && haystack.indexOf(token) !== -1;
    });
  }

  /* Γεμίζει το <select> με τους πελάτες που ταιριάζουν, κρατώντας την
     τρέχουσα επιλογή. */
  function renderCustomerOptions(keepValue) {
    if (!customerSel) return 0;
    var term = customerSearch ? fold(customerSearch.value) : "";
    var tokens = term ? term.split(" ").filter(Boolean) : [];
    var filtering = term.length >= MIN_CHARS;
    var previous = keepValue !== undefined ? keepValue : customerSel.value;

    customerSel.innerHTML = '<option value="">— Επιλέξτε πελάτη —</option>';

    var shown = 0, restored = false;
    customers.forEach(function (c) {
      // Με <3 γράμματα δείχνουμε όλους. Με φίλτρο, κρατάμε πάντα και
      // τον ήδη επιλεγμένο ώστε να μη "χαθεί" κατά το πληκτρολόγιο.
      var hit = !filtering || matches(c, term) || String(c.id) === String(previous);
      if (!hit) return;
      var o = document.createElement("option");
      o.value = c.id;
      o.textContent = optionLabel(c);
      if (String(c.id) === String(previous)) { o.selected = true; restored = true; }
      customerSel.appendChild(o);
      shown++;
    });

    if (customerMatch) {
      if (!customers.length) {
        customerMatch.textContent = "Δεν βρέθηκαν πελάτες.";
      } else if (!filtering) {
        customerMatch.textContent = "Εμφανίζονται όλοι οι πελάτες. Γράψτε " +
          "τουλάχιστον " + MIN_CHARS + " γράμματα για να περιορίσετε τη λίστα.";
      } else if (!shown) {
        customerMatch.textContent = "Κανένας πελάτης με «" +
          customerSearch.value.trim() +
          "». Δοκιμάστε μόνο με το επώνυμο ή με το όνομα του κατοικιδίου.";
      } else {
        customerMatch.textContent = shown === 1
          ? "1 πελάτης — επίλεξέ τον από τη λίστα."
          : shown + " πελάτες" + (restored ? " · ο επιλεγμένος παραμένει" : "");
      }
    }
    return shown;
  }

  function minsToLabel(m) {
    var h = Math.floor(m / 60), r = m % 60;
    if (!h) return r + "'";
    return r ? h + " ώ " + r + "'" : h + " ώ";
  }

  function pad2(n) { return String(n).length < 2 ? "0" + n : String(n); }

  /* Μετατρέπει σε Date μόνο αν είναι έγκυρη ημερομηνία· αλλιώς null.
     Προστατεύει από τιμές όπως το κείμενο "null" που έκαναν
     toISOString() να πετάξει RangeError και να μην φορτωθούν οι ώρες. */
  function parseDateOrNull(value) {
    if (!value) return null;
    if (typeof value !== "string" && typeof value !== "number") return null;
    var d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }

  /* YYYY-MM-DD από Date, χωρίς να περνά από toISOString (προσοχή UTC). */
  function isoDay(d) {
    return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate());
  }

  /* Ποσότητα μιας υπηρεσίας (τα πεδία είναι ονόματα qty_<id>). */
  function qtyOf(cb) {
    var id = cb.value;
    var input = document.querySelector('input[data-qty-for="' + id + '"]');
    var n = input ? parseInt(input.value, 10) : 1;
    if (!n || n < 1) n = 1;
    if (n > 20) n = 20;
    return n;
  }

  /* Ενημερωτική διάρκεια (δεν κλείνει slots) και πραγματικό σύνολο τιμής. */
  function selectedDuration() {
    var total = 0, price = 0, names = [];
    checks.forEach(function (cb) {
      if (!cb.checked) return;
      var n = qtyOf(cb);
      total += parseInt(cb.dataset.dur || 30, 10);
      price += (parseFloat(cb.dataset.price) || 0) * n;
      names.push(n > 1 ? (cb.dataset.name + " ×" + n) : cb.dataset.name);
    });
    return { total: total, price: price, names: names };
  }

  function money(v) {
    return (Math.round(v * 100) / 100).toFixed(2).replace(".", ",") + " €";
  }

  /* Το κόστος είναι εσωτερικό: δεν μπαίνει στα email του πελάτη. */
  function updateCost() {
    var d = selectedDuration();
    var none = !d.names.length;
    var discount = discountInput ? parseFloat(discountInput.value) || 0 : 0;
    if (discount < 0) discount = 0;
    if (discount > d.price) discount = d.price;
    var final = Math.max(0, d.price - discount);

    if (sumServices) sumServices.textContent = none ? "—" : d.names.join(", ");
    if (sumPrice) sumPrice.textContent = none ? "—" : money(d.price);

    // Η γραμμή έκπτωσης εμφανίζεται μόνο όταν υπάρχει πραγματική έκπτωση.
    var showDiscount = !none && discount > 0;
    if (discountRow) discountRow.hidden = !showDiscount;
    if (discountValueCell) discountValueCell.hidden = !showDiscount;
    if (showDiscount && discountValue) discountValue.textContent = money(discount);

    if (finalPrice) finalPrice.textContent = none ? "—" : money(final);
    if (finalRow) finalRow.hidden = none;
  }

  /* Μία τιμή ανά υπηρεσία. Εμφανίζει το πεδίο «×ποσότητα» όταν η
     υπηρεσία είναι επιλεγμένη (π.χ. 2 σκύλοι → μπάνιο ×2). */
  function updateServiceRows() {
    checks.forEach(function (cb) {
      var box = cb.closest ? cb.closest(".svc") : null;
      if (!box) return;
      var qty = box.querySelector(".svc__qty");
      if (qty) qty.hidden = !cb.checked;
      var total = box.querySelector(".svc__total");
      if (total) {
        var n = cb.checked ? qtyOf(cb) : 0;
        total.textContent = n > 1 ? "= " + money((parseFloat(cb.dataset.price) || 0) * n) : "";
      }
    });
    // Το τσάκ του κατοικιδίου κάνει την υπηρεσία «διαχωριστή» — οπότε
    // πρέπει να εμφανιστεί ή να κρυφτεί το «μόνο για…» στη συγκεκριμένη
    // γραμμή, όχι μόνο όταν αλλάζουν τα κατοικίδια.
    syncPetAttribution();
  }

  function updateDuration() {
    updateServiceRows();
    var d = selectedDuration();
    var count = d.names.length;
    if (countLabel) {
      countLabel.textContent = count
        ? (count === 1 ? "1 υπηρεσία" : count + " υπηρεσίες")
        : "—";
    }
    if (durLabel) durLabel.textContent = d.total ? minsToLabel(d.total) : "—";
    updateCost();
  }

  /* Τα τσσκ επιλεγμένα κατοικίδια, με τα στοιχεία τους.
     Διαβάζει τη λίστα `customers` (όχι μόνο το preselected), γιατί ο
     πελάτης συνήθως επιλέγεται από το dropdown. */
  function currentCustomer() {
    if (cfg.preselected) return cfg.preselected;
    var v = customerSel && customerSel.value;
    if (!v) return null;
    return customers.filter(function (c) { return String(c.id) === String(v); })[0] || null;
  }

  function selectedPets() {
    if (!petList) return [];
    var pets = (currentCustomer() || {}).pets || [];
    return Array.prototype.slice.call(
      petList.querySelectorAll("input[data-pet-id]:checked")
    ).map(function (cb) {
      return pets.filter(function (p) { return String(p.id) === String(cb.value); })[0] || null;
    }).filter(Boolean);
  }

  function updatePetHint() {
    if (!petHint) return;
    var pets = selectedPets();
    if (!pets.length) { petHint.textContent = ""; return; }
    petHint.textContent = pets.length === 1
      ? "Επιλεγμένο κατοικίδιο: " + (pets[0].name || "χωρίς όνομα")
      : pets.length + " κατοικίδια επιλεγμένα";
  }

  /* ------------------------------------------------- customers → pets */

  function fillPets(customerId, keepPetId) {
    if (!petList) { updatePetHint(); return; }
    var c = customers.filter(function (x) { return x.id == customerId; })[0];
    if (!c) {
      petList.innerHTML = '<p class="link-quiet">Επιλέξτε πρώτα πελάτη.</p>';
      updatePetHint();
      return;
    }
    var pets = c.pets || [];
    if (!pets.length) {
      petList.innerHTML = '<p class="link-quiet">Ο πελάτης δεν έχει κατοικίδια. ' +
        'Προσθέστε ένα από τη σελίδα του πελάτη.</p>';
      updatePetHint();
      return;
    }
    petList.innerHTML = "";
    pets.forEach(function (p) {
      var label = document.createElement("label");
      label.className = "pet-picker__item";
      var cb = document.createElement("input");
      cb.type = "checkbox";
      cb.name = "pet_ids";
      cb.value = p.id;
      cb.dataset.petId = p.id;
      if (keepPetId && String(p.id) === String(keepPetId)) cb.checked = true;
      var txt = document.createElement("span");
      txt.textContent = p.name || "χωρίς όνομα" + (p.breed ? " · " + p.breed : "");
      label.appendChild(cb);
      label.appendChild(txt);
      petList.appendChild(label);
      cb.addEventListener("change", function () {
        updatePetHint();
        // Οι ποσότητες μπορούν να προσαρμοστούν στον αριθμό κατοικιδίων.
        syncQuantityWithPets();
        updateDuration();
      });
    });
    // Μόλις επιλέγεται πελάτης, μπαίνει αυτόματα το πρώτο του κατοικίδιο,
    // ώστε να μην χρειάζεται tick για κάθε κράτηση. Το `pets` είναι τα
    // αντικείμενα από το API, οπότε το checkbox ψάχνεται στο DOM.
    var firstBox = petList.querySelector("input[data-pet-id]");
    if (firstBox && !petList.querySelector("input[data-pet-id]:checked")) {
      firstBox.checked = true;
    }
    // Κρατάμε τον επιλεγμένο πελάτη, ώστε τα κατοικίδια να βρίσκονται
    // και όταν η επιλογή έγινε από το dropdown (όχι μόνο με ?customer=).
    cfg.preselected = c;
    updatePetHint();
    syncQuantityWithPets();
    updateDuration();
  }

  /* Προτείνει ποσότητα = αριθμός κατοικιδίων, χωρίς να πειράζει ό,τι έχει
     πληκτρολογήσει ο χρήστης χειροκίνητα. */
  function syncQuantityWithPets() {
    var n = selectedPets().length;
    if (n < 1) return;
    checks.forEach(function (cb) {
      if (!cb.checked) return;
      var input = document.querySelector('input[data-qty-for="' + cb.value + '"]');
      if (!input || input.dataset.touched) return;
      input.value = n;
    });
    syncPetAttribution();
  }

  /* ΠΟΙΟ ΚΑΤΟΙΚΙΔΙΟ ΠΑΙΡΝΕ ΤΗΝ ΥΠΗΡΕΣΙΑ — ΜΟΝΟ ΟΤΑΝ ΔΙΑΦΕΡΕΙ.

     ΟΡΙΣΜΟΣ: το «μόνο για…» φαίνεται ΜΟΝΟ όταν το ραντεβού έχει 2+ κατοικίδια.
     Με ΈΝΑ κατοικίδιο η ερώτηση δεν υπάρχει — η υπηρεσία είναι εκείνου, και
     ένα κρυφό πεδίο που δεν σημαίνει τίποτα θα ήταν θόρυβος.

     Οι επιλογές γεμίζουν από ΤΑ ΙΔΙΑ ΤΑ ΤΣΑΚΩΜΕΝΑ ΚΑΤΟΙΚΙΔΙΑ. Μια λίστα
     από τον server θα ήταν δεύτερη πηγή αλήθειας και θα πρόσφερε σε
     κατοικίδιο που δεν έρχεται στο ραντεβού. */
  function syncPetAttribution() {
    var pets = selectedPets();
    var many = pets.length > 1;
    $$(".svc").forEach(function (row) {
      var box = row.querySelector(".svc__pet");
      if (!box) return;
      var cb = row.querySelector('input[name="service_ids"]');
      var svcChecked = !!(cb && cb.checked);
      /* ΚΡΥΦΟ ΟΤΑΝ ΔΕΝ ΔΙΑΦΕΡΕΙ, ΟΤΑΝ ΟΧΙ ΥΠΗΡΕΣΙΑ ΕΙΝΑΙ ΕΠΙΛΕΓΜΕΝΗ, Ή
         ΟΤΑΝ ΤΟ ΡΑΝΤΕΒΟΥ ΕΧΕΙ ΕΝΑ ΚΑΤΟΙΚΙΔΙΟ. */
      box.hidden = !(many && svcChecked);
      if (box.hidden) {
        var sel = box.querySelector("select");
        /* Καθαρισμός όταν δεν χρειάζεται πια: αν έμεινε επιλεγμένο κατοικίδιο
           που δεν έρχεται, θα υποβαλλόταν σιωπηλά. */
        if (sel) sel.value = "";
        continue;
      }
      var select = box.querySelector("select");
      if (!select) return;
      var keep = select.value;
      var wanted = pets.map(function (p) { return String(p.id); });
      /* Οι επιλογές ξαναφτιάχνονται κάθε φορά, αλλά η επιλογή κρατιέται αν
         το κατοικίδιο είναι ακόμα επιλεγμένο — αλλιώς η ιδιοκτήτρια θα
         έχανε τη ρύθμισή της μόλις έβρισε ένα άλλο τσακ. */
      select.innerHTML = "";
      var all = document.createElement("option");
      all.value = "";
      all.textContent = "— όλα τα κατοικίδια —";
      select.appendChild(all);
      pets.forEach(function (p) {
        var opt = document.createElement("option");
        opt.value = String(p.id);
        opt.textContent = p.name || "χωρίς όνομα";
        select.appendChild(opt);
      });
      select.value = wanted.indexOf(keep) >= 0 ? keep : "";
    });
  }

  /* ------------------------------------------------- dates & time slots */

  function renderDateStrip() {
    if (!dateStrip) return;
    dateStrip.innerHTML = "";
    var base = new Date();
    for (var i = 0; i < 14; i++) {
      (function (d, off) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "date-chip" + (off === 0 ? " is-active" : "");
        btn.dataset.date = isoDay(d);
        var wd = ["Κυρ", "Δε", "Τρ", "Τε", "Πε", "Πα", "Σα"][d.getDay()];
        btn.innerHTML = "<strong>" + wd + "</strong><span>" + d.getDate() + "</span>";
        btn.addEventListener("click", function () {
          if (dateInput) dateInput.value = btn.dataset.date;
          $$(".date-chip").forEach(function (b) { b.classList.remove("is-active"); });
          btn.classList.add("is-active");
          loadSlots();
        });
        dateStrip.appendChild(btn);
      })(new Date(base.getTime() + i * 86400000), i);
    }
  }

  /* Η ώρα ενός υπάρχοντος ραντεβού πρέπει να εμφανίζεται πάντα. Αν άλλαξαν
     οι ώρες ή το βήμα των slots μετά την κράτηση, η ώρα δεν βρίσκεται στη
     λίστα — χωρίς αυτή την επιλογή, ένα άλλαγμα δεν θα έσωζε ποτέ. */
  function addCurrentTimeOption(hhmm) {
    if (!timeSel || !hhmm) return;
    var found = Array.prototype.some.call(timeSel.options, function (o) {
      return o.value === hhmm;
    });
    if (found) {
      timeSel.value = hhmm;
      return;
    }
    var o = document.createElement("option");
    o.value = hhmm;
    o.textContent = hhmm + " · τρέχουσα ώρα";
    o.selected = true;
    timeSel.appendChild(o);
  }

  /* Η ώρα του ραντεβού που ανοίγουμε, ή κενό για νέο ραντεβού. */
  function currentTime() {
    var d = parseDateOrNull(cfg.startAt);
    return d ? pad2(d.getHours()) + ":" + pad2(d.getMinutes()) : "";
  }

  /* ΠΛΗΡΟΦΟΡΙΕΣ ΚΑΘΕ ΩΡΑΣ, ΓΙΑ ΝΑ ΞΕΡΕΙ Η ΕΠΙΒΕΒΑΙΩΣΗ ΠΟΙΟΣ ΕΙΝΑΙ ΑΠΑΣΧΟΛΗΜΕΝΟΣ.
     Και η επιλογή που «περνάει» μέσα στο modal. */
  var slotInfo = {};
  var pendingTime = "";

  /* Η ΕΠΙΒΕΒΑΙΩΣΗ. Επιλέχθηκε ώρα που είναι ήδη κατειλημμένη: δεν μπλοκάρουμε,
     αλλά ρωτάμε πρώτα. Το «Ναι» θέτει το force_booking, ώστε η υποβολή να μην
     ξαναδείξει το ίδιο μήνυμα σαν απροειδήποτο σφάλμα. */
  function guardOccupied(value) {
    var modal = document.getElementById("doubleBookModal");
    var text = document.getElementById("doubleBookText");
    var info = slotInfo[value];
    if (!modal || !info || !info.busy || !info.busy_groomers || !info.busy_groomers.length) {
      setForce(false);
      return true;
    }
    var names = info.busy_groomers.map(function (g) { return g.name; }).join(", ");
    text.textContent = "Η " + value + " έχει ήδη ραντεβού για " + names + ". "
      + "Θέλεις να κλείσεις και δεύτερο πελάτη την ίδια ώρα;";
    pendingTime = value;
    setForce(false);
    window.openModal && window.openModal("doubleBookModal");
    return false;
  }

  function setForce(on) {
    var box = document.getElementById("forceBooking");
    if (box) box.value = on ? "1" : "";
  }

  function loadNextFree() {
    var box = document.getElementById("nextFree");
    if (!box) return;
    var d = selectedDuration().total || 60;
    var url = "/staff/api/next-slots?duration=" + d + "&count=5";
    if (groomerSel && groomerSel.value) url += "&groomer_id=" + groomerSel.value;
    if (cfg.appointmentId) url += "&exclude=" + cfg.appointmentId;
    fetch(url, { headers: { Accept: "application/json" } })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var slots = data.slots || [];
        box.textContent = "";
        if (!slots.length) {
          var none = document.createElement("span");
          none.className = "link-quiet";
          none.textContent = "Δεν βρέθηκε ελεύθερη ώρα στο προσεχές διάστημα.";
          box.appendChild(none);
          return;
        }
        slots.forEach(function (s) {
          var btn = document.createElement("button");
          btn.type = "button";
          btn.className = "btn btn--soft btn--sm";
          /* «σήμερα» ή «αύριο» αντί για ημερομηνία: η ιδιοκτήτρια σκέφτεται
             σε σχέση με το σήμερα, όχι σε αριθμούς ημερών. */
          btn.textContent = relativeDay(s.date) + " " + s.start;
          btn.addEventListener("click", function () {
            if (dateInput) {
              dateInput.value = s.date;
              dateInput.dispatchEvent(new Event("change", { bubbles: true }));
            }
          });
          box.appendChild(btn);
        });
      })
      .catch(function () {
        box.textContent = "";
        var bad = document.createElement("span");
        bad.className = "link-quiet";
        bad.textContent = "Αδυναμία φόρτωσης των επόμενων διαθέσιμων ωρών.";
        box.appendChild(bad);
      });
  }

  function relativeDay(iso) {
    var today = new Date();
    var d = new Date(iso + "T00:00:00");
    var diff = Math.round((d - new Date(today.getFullYear(), today.getMonth(),
      today.getDate())) / 86400000);
    if (diff === 0) return "Σήμερα";
    if (diff === 1) return "Αύριο";
    var names = ["Κυριακή", "Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη",
      "Παρασκευή", "Σάββατο"];
    return names[d.getDay()] + " " + String(d.getDate()).padStart(2, "0");
  }

  function loadSlots() {
    if (!timeSel) return;
    var prev = timeSel.value;
    timeSel.innerHTML = '<option value="">— Επιλέξτε ώρα —</option>';
    if (timeHint) timeHint.textContent = "";

    var date = dateInput && dateInput.value;
    if (!date) return;

    var d = selectedDuration().total || 60;
    var url = "/staff/api/slots?date=" + encodeURIComponent(date) + "&duration=" + d;
    if (groomerSel && groomerSel.value) url += "&groomer_id=" + groomerSel.value;
    if (cfg.appointmentId) url += "&exclude=" + cfg.appointmentId;

    loadNextFree();

    fetch(url, { headers: { Accept: "application/json" } })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data.closed) {
          if (timeHint) timeHint.textContent = "Το Salon είναι κλειστό αυτή την ημέρα.";
          addCurrentTimeOption(currentTime());
          return;
        }
        var free = 0;
        slotInfo = {};
        (data.slots || []).forEach(function (s) {
          if (s.start === "—") return;
          var o = document.createElement("option");
          o.value = s.start;
          /* Οι κατειλημμένες ώρες ΠΑΡΑΜΕΝΟΥΝ ΕΠΙΛΕΞΙΜΕΣ. Η ιδιοκτήτρια
             ζητήθηκε ρητά να μπορεί να κλείσει δύο πελάτες στην ίδια ώρα — με
             προειδοποίηση. Το παλιο `o.disabled = !s.available` το έκανε
             ΑΔΥΝΑΤΟ, χωρίς ούτε μήνυμα: η ιδιοκτήτρια έβλεπε μια γκριζοποιημένη
             ώρα χωρίς να μάθει γιατί. */
          var occupied = s.reason === "booked" && s.busy;
          o.textContent = s.start + " – " + s.end
            + (s.available ? "" : (occupied ? " · κατειλημμένη" : " · " + s.label));
          o.disabled = !s.available && !occupied;
          if (occupied) o.dataset.occupied = "1";
          slotInfo[s.start] = s;
          if (s.available) free++;
          if (prev && s.start === prev) o.selected = true;
          timeSel.appendChild(o);
        });
        addCurrentTimeOption(currentTime());
        if (timeHint) {
          timeHint.textContent = free
            ? (free === 1 ? "1 διαθέσιμη ώρα για " : free + " διαθέσιμες ώρες για ") + minsToLabel(d)
            : "Δεν υπάρχουν διαθέσιμες ώρες για αυτή τη διάρκεια.";
        }
      })
      .catch(function () { if (timeHint) timeHint.textContent = "Αδυναμία φόρτωσης των διαθέσιμων ωρών."; });
  }

  /* ------------------------------------------------------------- init */

  document.addEventListener("DOMContentLoaded", function () {
    fetch("/staff/api/customers", { headers: { Accept: "application/json" } })
      .then(function (r) { return r.json(); })
      .then(function (list) {
        customers = list || [];
        if (cfg.preselected) {
          cfg.preselected.pets = cfg.preselected.pets || [];
          var already = customers.filter(function (c) { return c.id == cfg.preselected.id; })[0];
          if (already) cfg.preselected = already;
        }
        // Οι επιλογές χτίζονται πλέον από τη λίστα του API, ώστε να έχουν
        // και τα ονόματα των κατοικιδίων.
        var keep = cfg.preselectCustomer || (cfg.preselected && cfg.preselected.id)
                   || (customerSel && customerSel.value);
        renderCustomerOptions(keep);
        if (customerSel && customerSel.value) fillPets(customerSel.value, cfg.preselectPet);
      })
      .catch(function () {
        if (customerMatch) customerMatch.textContent = "Αδυναμία φόρτωσης πελατών.";
      });

    if (customerSearch) {
      var pickIfSingle = function () {
        if (customerSel && customerSel.options.length === 2) {
          customerSel.selectedIndex = 1;
          fillPets(customerSel.value);
        }
      };
      customerSearch.addEventListener("input", function () {
        var before = customerSel && customerSel.value;
        renderCustomerOptions(before);
        pickIfSingle();
      });
      // Το Enter δεν πρέπει να υποβάλλει τη φόρμα όταν απλώς επιλέγουμε.
      customerSearch.addEventListener("keydown", function (ev) {
        if (ev.key !== "Enter") return;
        ev.preventDefault();
        pickIfSingle();
      });
    }

    if (customerSel) customerSel.addEventListener("change", function () { fillPets(this.value); });
    if (dateInput) dateInput.addEventListener("change", loadSlots);
    if (groomerSel) groomerSel.addEventListener("change", loadSlots);
    if (timeSel) timeSel.addEventListener("change", function () {
      if (!guardOccupied(this.value)) {
        /* Απέτυχε η επιβεβαίωση — γυρίζουμε στην κενή επιλογή, ώστε η φόρμα
           να μην υποβληθεί με ώρα που δεν δέχτηκε η ιδιοκτήτρια. */
        this.value = pendingTime && this.value === pendingTime ? "" : this.value;
        pendingTime = "";
      }
    });
    var okBtn = document.getElementById("doubleBookOk");
    if (okBtn) okBtn.addEventListener("click", function () {
      setForce(true);
      if (timeSel && pendingTime) timeSel.value = pendingTime;
      var modal = document.getElementById("doubleBookModal");
      if (modal) modal.classList.remove("is-open");
      document.body.style.overflow = "";
    });
    checks.forEach(function (cb) {
      cb.addEventListener("change", function () {
        // Μόλις επιλεγεί υπηρεσία, προτείνουμε ποσότητα = αριθμός κατοικιδίων.
        syncQuantityWithPets();
        updateDuration();
        loadSlots();
      });
    });
    $$("[data-qty-for]").forEach(function (input) {
      input.addEventListener("input", function () {
        input.dataset.touched = "1";
        updateServiceRows();
        updateCost();
      });
    });
    if (discountInput) {
      discountInput.addEventListener("input", function () {
        // Δεν επιτρέπεται έκπτωση μεγαλύτερη από το άθροισμα.
        var max = selectedDuration().price;
        if ((parseFloat(discountInput.value) || 0) > max) {
          discountInput.value = max ? max.toFixed(2) : "";
        }
        updateCost();
      });
    }

    renderDateStrip();
    updateDuration();

    /* Το loadSlots() πρέπει να τρέξει ΟΠΩΣΔΗΠΟΤΕ. Ένα κακό startAt δεν
       πρέπει να σταματά την αρχικοποίηση και να αφήνει κενές τις ώρες. */
    var startAt = parseDateOrNull(cfg.startAt);
    if (startAt) {
      if (dateInput) dateInput.value = isoDay(startAt);
      var hhmm = pad2(startAt.getHours()) + ":" + pad2(startAt.getMinutes());
      loadSlots();
      setTimeout(function () { if (timeSel) timeSel.value = hhmm; }, 400);
    } else {
      loadSlots();
    }
  });
})();
