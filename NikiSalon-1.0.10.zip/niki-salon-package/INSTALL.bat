@echo off
REM ===========================================================================
REM  Niki's Grooming Salon - INSTALL
REM
REM  ΔΙΠΛΟ ΚΛΙΚ ΣΕ ΑΥΤΟ ΤΟ ΑΡΧΕΙΟ. Μην το ανοίγεις μες στο cmd.
REM
REM  Το αρχείο αυτό ψάχνει την Python, και αν δεν τη βρει σου λέει πού
REM  να τη κατεβάσεις. Δεν απαιτεί δικαιώματα Administrator: το install.py
REM  σηκώνεται μόνος του όταν χρειαστεί.
REM ===========================================================================
setlocal
cd /d "%~dp0"
title Niki's Grooming Salon - Install

echo.
echo   ==========================================================
echo     Niki's Grooming Salon - εγκατάσταση
echo   ==========================================================
echo.

REM --- 1. Ψάξε Python 3.10+ -----------------------------------------------------
set "PY="
for %%C in (
  "%ProgramFiles%\Python313\python.exe"
  "%ProgramFiles%\Python312\python.exe"
  "%ProgramFiles%\Python311\python.exe"
  "%ProgramFiles%\Python310\python.exe"
  "%LocalAppData%\Programs\Python\Python313\python.exe"
  "%LocalAppData%\Programs\Python\Python312\python.exe"
  "%LocalAppData%\Programs\Python\Python311\python.exe"
  "%LocalAppData%\Programs\Python\Python310\python.exe"
) do (
  if exist %%C if not defined PY set "PY=%%~C"
)

if not defined PY (
  for /f "delims=" %%P in ('where python 2^>nul') do (
    if not defined PY set "PY=%%P"
  )
)

if not defined PY (
  echo   [X]  Δεν βρέθηκε Python σε αυτό το μηχάνημα.
  echo.
  echo       Κατέβασέ την από:  https://www.python.org/downloads/
  echo.
  echo       ^(ΣΤΗ ΔΙΑΡΚΕΙΑ ΤΗΣ ΕΓΚΑΤΑΣΤΑΣΗΣ ΑΦΗΣΕ ΤΟ
  echo        "Add Python to PATH" ΤΣΕΚΑΡΙΣΜΕΝΟ.^)
  echo.
  pause
  exit /b 1
)

REM --- 2. Έλεγχος έκδοσης -------------------------------------------------------
"%PY%" -c "import sys; sys.exit(0 if sys.version_info[:2] >= (3, 10) else 1)"
if errorlevel 1 (
  echo   [X]  Η Python που βρέθηκε είναι παλιά.
  "%PY%" --version
  echo       Χρειάζεται Python 3.10 ή νεότερη.
  echo.
  pause
  exit /b 1
)

echo   Βρέθηκε: %PY%
for /f "delims=" %%V in ('"%PY%" --version 2^>^&1') do echo   %%V
echo.

REM --- 3. Εγκατάσταση ----------------------------------------------------------
"%PY%" "%~dp0install.py" %*
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo   ==========================================================
  echo     Ολοκληρώθηκε. Άνοιξε τη διεύθυνση που εμφανίστηκε.
  echo   ==========================================================
) else (
  echo   ==========================================================
  echo     Η εγκατάσταση δεν ολοκληρώθηκε ^(κωδικός %RC%^).
  echo     Διάβασε τα μηνύματα παραπάνω.
  echo   ==========================================================
)
echo.
pause
endlocal
