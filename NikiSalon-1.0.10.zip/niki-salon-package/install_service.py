#!/usr/bin/env python3
"""Εγκατάσταση της εφαρμογής ως μόνιμη εργασία στα Windows (Task Scheduler).

ΓΙΑΤΙ ΟΧΙ IIS
=============
Το HttpPlatformHandler είναι ένα ενδιάμεσο στρώμα ανάμεσα στο IIS και σε
μια διεργασία Python. Βάζει ανάμεσα επτά πιθανά σημεία αστοχίας: app pool,
ταυτότητα, κλειδωμένες config sections, rapid-fail, διαδρομή αρχείου
εξόδου, αντιστοιχίσεις handler, ώρες εκκίνησης. Καθένα από αυτά σταματάει
την εφαρμογή ΜΕ 404 ή 500, χωρίς να εμφανίζει τον πραγματικό λόγο.

Η ίδια η εφαρμογή τρέχει μόνη της μέσω του waitress, που είναι κανονικός
WSGI server. Για μια εφαρμογή σε ένα δίκτυο αυτή η διαφορά δεν έχει
σημασία — και τα Windows ξεκινούν μια εργασία κατά την εκκίνηση χωρίς
καμία εγκατάσταση.

ΤΙ ΚΑΝΕΙ
========
  1. Δημιουργεί τους φακέλους instance\\ και logs\\
  2. Δημιουργεί run_server.cmd που τρέχει την εφαρμογή και γράφει το log
  3. Δημιουργεί εργασία Task Scheduler που ξεκινά σε κάθε εκκίνηση
  4. Ελέγχει ότι η εφαρμογή απαντά πριν τελώσει

ΧΡΗΣΗ
=====
  python install_service.py                      # μόνο στο μηχάνημα
  python install_service.py --port 8080
  python install_service.py --local-only         # μόνο από τον ίδιο υπολογιστή
  python install_service.py --start
  python install_service.py --stop
  python install_service.py --status
  python install_service.py --uninstall
"""
from __future__ import annotations

import argparse
import ipaddress
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

IS_WINDOWS = os.name == "nt"
APP_DIR = Path(__file__).resolve().parent
TASK_NAME = "NikiSalonBooking"
DEFAULT_PORT = 8080
#: Χρώμα κωδικού — μόνο στην έξοδο.
GREEN, YELLOW, RED, DIM, RESET = "\033[32m", "\033[33m", "\033[31m", "\033[2m", "\033[0m"


def _c(text: str, colour: str) -> str:
    return f"{colour}{text}{RESET}" if sys.stdout.isatty() else text


def step(text: str) -> None:
    print()
    print(_c(f"── {text} " + "─" * max(2, 58 - len(text)), DIM))


def ok(text: str) -> None:
    print(f"  {_c('[OK]', GREEN)}  {text}")


def warn(text: str) -> None:
    print(f"  {_c('[!]', YELLOW)}   {text}")


def fail(text: str) -> None:
    print(f"  {_c('[X]', RED)}   {text}")


def info(text: str) -> None:
    print(f"       {text}")


def is_admin() -> bool:
    if not IS_WINDOWS:
        return False
    try:
        return bool(subprocess.run(["net", "session"], capture_output=True,
                                   shell=False, timeout=20).returncode == 0)
    except Exception:                                  # noqa: BLE001
        return False


def schtasks(*args: str, timeout: int = 120) -> subprocess.CompletedProcess:
    return subprocess.run(["schtasks", "/Query", *args][:2] + list(args[2:]),
                          capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout)


def run_task(action: str, task: str) -> subprocess.CompletedProcess:
    """schtasks /create|delete|run|end — χωρίς shell, χωρίς quoting."""
    cmd = {
        "create": ["schtasks", "/Create", "/TN", task],
        "delete": ["schtasks", "/Delete", "/TN", task, "/F"],
        "run": ["schtasks", "/Run", "/TN", task],
        "end": ["schtasks", "/End", "/TN", task],
    }[action]
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=180)


def python_exe() -> Path:
    """Η Python του venv αν υπάρχει, αλλιώς του συστήματος."""
    venv = APP_DIR / ".venv" / "Scripts" / "python.exe"
    if venv.exists():
        return venv
    system = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32/python.exe"
    if system.exists():
        return system
    return Path(sys.executable)


def write_runner(port: int, host: str) -> Path:
    """Γράφει το run_server.cmd — το μόνο σημείο που αλλάζει αν ποτέ η θύρα."""
    cmd = APP_DIR / "run_server.cmd"
    log = APP_DIR / "logs" / "service.log"
    body = f"""@echo off
rem ============================================================
rem  Niki's Grooming Salon - εκτέλεση ως υπηρεσία
rem  Δημιουργήθηκε από install_service.py. Μην το επεξεργάζεσαι
rem  χειροκίνητα· άλλαξε τις παραμέτρους στο install_service.py.
rem ============================================================
cd /d "{APP_DIR}"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONUNBUFFERED=1
if not exist "logs" mkdir "logs"
:run
"{python_exe()}" server.py --host {host} --port {port} >> "logs\\service.log" 2>&1
rem Η διεργασία τερμάτισε: ξαναξεκινάμε σε 5 δευτερόλεπτα.
rem Το μήνυμα είναι ΜΟΝΟ ΑΣΚΙ (ASCII): το cmd.exe έχει δικό του code page
rem και τα ελληνικά θα έβγαιναν αλλοιωμένα στο log.
echo [%DATE% %TIME%] service exited (code %ERRORLEVEL%). Restarting in 5s. >> "logs\\service.log"
timeout /t 5 /nobreak >nul
goto run
"""
    cmd.write_text(body, encoding="utf-8")
    return cmd


def firewall_rule(port: int) -> None:
    """Άνοιγμα θύρας στο τείχος φωτιάς, μόνο αν ζητήθηκε πρόσβαση από δίκτυο."""
    step("Τείχος φωτιάς")
    name = f"NikiSalon {port}"
    try:
        subprocess.run(["netsh", "advfirewall", "firewall", "delete", "rule",
                        "name=" + name], capture_output=True, timeout=60)
    except Exception:                                  # noqa: BLE001
        pass
    try:
        result = subprocess.run(
            ["netsh", "advfirewall", "firewall", "add", "rule", f"name={name}",
             "dir=in", "action=allow", "protocol=TCP", f"localport={port}"],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=60)
        if result.returncode == 0:
            ok(f"Θύρα {port} επιτρέπεται από το δίκτυο.")
        else:
            warn(f"Δεν άνοιξε η θύρα {port}: "
                 f"{(result.stderr or result.stdout or '').strip()[:160]}")
    except Exception as exc:                          # noqa: BLE001
        warn(f"Παράλειψη τείχους φωτιάς: {exc}")


def health(port: int, attempts: int = 15) -> bool:
    """Περιμένει να απαντήσει — η πρώτη εκκίνηση ανοίγει τη βάση."""
    url = f"http://127.0.0.1:{port}/health"
    last = ""
    for i in range(attempts):
        try:
            with urllib.request.urlopen(url, timeout=8) as response:
                if response.status == 200:
                    return True
                last = f"HTTP {response.status}"
        except urllib.error.HTTPError as exc:
            last = f"HTTP {exc.code}"
        except Exception as exc:                      # noqa: BLE001
            last = str(exc)[:120]
        if i < attempts - 1:
            time.sleep(2)
    fail(f"Η εφαρμογή δεν απάντησε στο {url}")
    if last:
        info(f"Τελευταίο σφάλμα: {last}")
    log = APP_DIR / "logs" / "service.log"
    if log.exists():
        info("Πιο κάτω το τέλος του logs/service.log — εκεί είναι ο πραγματικός λόγος:")
        print()
        for line in log.read_text(encoding="utf-8", errors="replace").splitlines()[-30:]:
            print(f"       {line}")
    else:
        warn("Δεν δημιουργήθηκε logs/service.log — η εργασία δεν ξεκίνησε καθόλου.")
    return False


def task_exists() -> bool:
    return run_task("run", TASK_NAME).returncode == 0 or _query() is not None


def _query() -> str | None:
    try:
        result = subprocess.run(["schtasks", "/Query", "/TN", TASK_NAME],
                                capture_output=True, text=True, encoding="utf-8",
                                errors="replace", timeout=60)
        return result.stdout if result.returncode == 0 else None
    except Exception:                                  # noqa: BLE001
        return None


def lan_ips() -> list[str]:
    ips: list[str] = []
    try:
        raw = subprocess.run(["ipconfig"], capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=30).stdout
    except Exception:                                  # noqa: BLE001
        return ips
    for line in raw.splitlines():
        if "IPv4" in line:
            parts = line.split(":")
            if len(parts) > 1:
                candidate = parts[-1].strip()
                try:
                    if ipaddress.ip_address(candidate).is_private:
                        ips.append(candidate)
                except ValueError:
                    pass
    return ips


def is_under_wwwroot() -> Path | None:
    """Επιστρέφει το wwwroot αν η εφαρμογή είναι μέσα του, αλλιώς None.

    ΚΡΙΣΙΜΟ: το IIS έχει πάντα το «Default Web Site» που σερβίρει ΟΛΟ ΤΟ
    wwwroot στο *:80:. Αν η εφαρμογή μένει μέσα στο wwwroot, κάθε υπολογιστής
    του δικτύου μπορεί να κατεβάσει ΤΑ ΔΕΔΟΜΕΝΑ ΣΟΥ:
        http://<IP>/niki-salon/instance/salon.db
        http://<IP>/niki-salon/.env      ← SECRET_KEY + κωδικός SMTP
    Το .env είναι .txt-συμπεριφοράς στο IIS: δεν «δεν βρίσκεται», κατεβάζεται.
    Γι' αυτό προτείνουμε C:/NikiSalon, έξω από το wwwroot.
    """
    try:
        parts = [p.lower() for p in APP_DIR.resolve().parts]
    except Exception:                                  # noqa: BLE001
        return None
    # Χωρίς [:−1]: αν η ίδια η εφαρμογή λέγεται wwwroot, είναι το ΣΥΝΟΛΟ
    # του φακέλου που σερβίρει το IIS — και πάλι πρέπει να προειδοποιήσουμε.
    for i, part in enumerate(parts):
        if part == "wwwroot":
            return Path(*APP_DIR.resolve().parts[:i + 1])
    return None


def warn_wwwroot() -> None:
    root = is_under_wwwroot()
    if root is None:
        return
    step("ΠΡΟΣΟΧΗ — η εφαρμογή είναι μέσα στο wwwroot")
    fail("Το Default Web Site του IIS σερβίρει ΟΛΟ ΤΟ wwwroot στο *:80:.")
    info("Όποιος είναι στο δίκτυο μπορεί να κατεβάσει αυτά, χωρίς κωδικό:")
    info('    http://<IP-ΤΟΥ-PC>/niki-salon/instance/salon.db')
    info('    http://<IP-ΤΟΥ-PC>/niki-salon/.env   ← SECRET_KEY, SMTP κωδικός')
    print()
    target = APP_DIR.drive + "\\NikiSalon"
    ok("Μεταφορά εκτός wwwroot (συνιστάται, διαρκεί 1 λεπτό):")
    print()
    print(f'       powershell -c "Stop-Process -Name w3wp -Force -EA SilentlyContinue; '
          f'robocopy \"{APP_DIR}\" \"{target}\" /MOVE /E"')
    print()
    info("Μετά τη μεταφορά, ξανατρέξε το install_service.py από τη νέα θέση.")
    print()


def lan_hint(local_only: bool, port: int) -> str:
    """Οι διευθύνσεις με τις οποίες προσπελάζεται η εφαρμογή."""
    lines = [f"Στο μηχάνημα αυτό: http://localhost:{port}/"]
    if not local_only:
        ips = lan_ips()
        for ip in ips:
            lines.append(f"Από άλλα μηχάνηματα: http://{ip}:{port}/")
        if not ips:
            lines.append("(Δεν βρέθηκε διεύθυνση δικτύου — "
                         "μπορεί να είναι απενεργοποιημένο το Wi-Fi/LAN.)")
    else:
        lines.append("Μόνο τοπικά — η θύρα δεν άνοιξε στο δίκτυο.")
    return "\n".join("   " + line for line in lines)


#: Οι δύο αυτοματισμοί που τρέχουν στο παρασκήνιο.
REMINDERS_TASK = "NikiSalon-Reminders"
BACKUP_TASK = "NikiSalon-Backup"


#: Επιλογές του schtasks ΠΟΥ ΔΕΝ ΙΣΧΥΟΥΝ για /SC ONSTART. Με οποιαδήποτε
#: από αυτές, το schtasks αποτυγχάνει ΟΛΟΚΛΗΡΑ:
#:   "The options /RI, /DU, /ST, /SD, /ET, /ED and /K are not applicable
#:    for the scheduled types: ONSTART, ONLOGON, ONIDLE, ONEVENT."
#: Ισχύουν μόνο για ONLOGON, DAILY, WEEKLY και MONTHLY.
INVALID_FOR_ONSTART = ("/RI", "/DU", "/ST", "/SD", "/ET", "/ED", "/K")


def task_create_args(cmd_file: Path) -> list[str]:
    """Τα ορίσματα δημιουργίας της εργασίας — μία πηγή αλήθειας.

    Χωρίς επανεκκίνηση εδώ, και αυτό είναι σωστό: το run_server.cmd έχει
    άπειρο βρόχο, οπότε αν πέσει η Python ξαναρχίζει μόνη της σε 5
    δευτερόλεπτα. Το /RI θα ήταν περιττό, και μάλιστα χαμένος χρόνος —
    αν τη σκοτώσει ο scheduler, κανένας χρόνος επανεκκίνησης δεν τη σώζει.

    Χωρίς /IT: σημαίνει «μόνο αν ο χρήστης είναι συνδεδεμένος», που δεν
    ισχύει ποτέ για τον SYSTEM.
    """
    return ["schtasks", "/Create", "/TN", TASK_NAME, "/TR", str(cmd_file),
            "/SC", "ONSTART", "/RU", "SYSTEM", "/RL", "HIGHEST", "/F"]


def setup_automation(python: Path, backup_dir: Path | None = None) -> None:
    """Δημιουργεί τις προγραμματισμένες εργασίες της εφαρμογής.

    Δύο αυτοματισμοί, και ΟΙ ΔΥΟ είναι σημαντικοί:
      · Υπενθυμίσεις ραντεβού κάθε 30 λεπτά (email στον πελάτη το προσού).
        Χωρίς αυτό η υπενθύμιση δεν στέλνεται ποτέ.
      · Αντίγραφο της βάσης κάθε βράδυ 02:00. Χωρίς αυτό, μία μέρα που
        πάει στραβά σημαίνει χαμένα δεδομένα πελατών.
    """
    step("Προγραμματισμένες εργασίες (χωρίς εσένα)")
    if not IS_WINDOWS:
        note("Μη-Windows: παραλείπεται.")
        return

    # --- υπενθυμίσεις: κάθε 30 λεπτά, ξεκινά από 1 λεπτό αργότερα ---
    # ΚΑΝΕΝΑ ΠΑΡΑΘΥΡΟ ΣΤΗΝ ΟΘΟΝΗ. Η εργασία έτρεχε απευθείας την
    # python.exe, που είναι console application: κάθε 30 λεπτά ανοίγε και
    # κλείγε ένα μαύρο παράθυρο στην οθόνη της ιδιοκτήτριας. Τώρα το ίδιο
    # .cmd περνά από VBS με window style 0.
    #
    # ΟΧΙ pythonw ΕΔΩ: η pythonw δεν έχει ούτε stdout, οπότε η έξοδος του
    # send-reminders (πόσα στάλθηκαν, αν λείπει το SMTP) θα χανόταν — και
    # μια εργασία που σταμάτησε να δουλεύει δεν θα το έδειχνε ποτέ.
    reminders_cmd = write_reminders_script(python)
    reminders_vbs = write_hidden_launcher(reminders_cmd)
    script = (
        f"$a = New-ScheduledTaskAction -Execute 'wscript.exe' "
        f"-Argument '//nologo {reminders_vbs}'; "
        # -Hidden κρύβει την εργασία και από τη λίστα του Task Scheduler.
        # Το ExecutionTimeLimit σκοτώνει μια εργασία που κόλλησε στο SMTP.
        f"$s = New-ScheduledTaskSettingsSet -Hidden "
        f"-ExecutionTimeLimit (New-TimeSpan -Minutes 10); "
        f"$t = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) "
        f"-RepetitionInterval (New-TimeSpan -Minutes 30) "
        f"-RepetitionDuration (New-TimeSpan -Days 3650); "
        f"Register-ScheduledTask -TaskName '{REMINDERS_TASK}' -Action $a -Trigger $t -Settings $s "
        f"-Description 'Niki Salon - υπενθυμίσεις ραντεβού' "
        f"-RunLevel Highest -Force | Out-Null"
    )
    result = run_powershell(script)
    if result.returncode == 0:
        ok(f"Υπενθυμίσεις κάθε 30 λεπτά ({REMINDERS_TASK})")
    else:
        warn("Δεν δημιουργήθηκε η εργασία υπενθυμίσεων: "
             f"{(result.stderr or result.stdout or '').strip()[:200]}")

    # --- καθημερινό αντίγραφο ---
    if not backup_dir:
        warn("Χωρίς αυτόματο αντίγραφο. Τα αντίγραφα μένουν στο instance\backups")
        info("και μπορούν να γίνουν χειροκίνητα από Διαχείριση → Αντίγραφα.")
        return
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        warn(f"Ο φάκελος αντιγράφων δεν δημιουργήθηκε: {exc}")
        return
    # Γράφουμε το σενάριο σε αρχείο αντί να το μπλέξουμε σε κείμενο μέσα σε
    # κείμενο: τα Windows έχουν τρία επίπεδα quoting (cmd → PowerShell →
    # παράμετρος) και κάθε λάθος στο ένα σπάει τα άλλα δύο.
    backup_cmd = write_backup_script(backup_dir)
    # Το backup.cmd είναι console εφαρμογή. Το τρέχουμε μέσω VBS με
    # window style 0, αλλιώς στις 02:00 ανοίγει μαύρο παράθυρο — και αν ο
    # υπολογιστής είναι ανοιχτός, η ιδιοκτήτρια το βλέπει.
    launcher = write_hidden_launcher(backup_cmd)
    script = (
        f"$a = New-ScheduledTaskAction -Execute 'wscript.exe' "
        f"-Argument '//nologo {launcher}'; "
        f"$s = New-ScheduledTaskSettingsSet -Hidden "
        f"-ExecutionTimeLimit (New-TimeSpan -Minutes 30); "
        f"$t = New-ScheduledTaskTrigger -Daily -At '02:00'; "
        f"Register-ScheduledTask -TaskName '{BACKUP_TASK}' -Action $a -Trigger $t "
        f"-Settings $s "
        f"-Description 'Niki Salon - antigrrafo vasis' "
        f"-RunLevel Highest -Force | Out-Null"
    )
    result = run_powershell(script)
    if result.returncode == 0:
        ok(f"Antigrrafo vasis ka8e vradu 02:00 -> {backup_dir}")
    else:
        warn("Den diktioithike i ergasia antigragfon: "
             f"{(result.stderr or result.stdout or '').strip()[:200]}")


def write_backup_script(backup_dir: Path) -> Path:
    """backup.cmd: σταματά την εφαρμογή, αντιγράφει τη βάση, την ξαναξεκινά."""
    cmd = APP_DIR / "backup.cmd"
    db = (APP_DIR / "instance" / "salon.db").as_posix()
    dest = backup_dir.as_posix()
    body = f"""@echo off
rem Niki's Grooming Salon - daily database copy.
rem Generated by install_service.py. Do not edit by hand.
rem Stops the app so SQLite is not copied mid-write, copies, then restarts.
rem The timestamp is built by STRIPPING separators, not by slicing
rem (%date:~6,4%): the position of the year depends on the Windows
rem language, so slicing yields 2026-29-09 on an English machine.
chcp 65001 >nul
if not exist "{dest}" mkdir "{dest}"
schtasks /End /TN "{TASK_NAME}" >nul 2>&1
timeout /t 3 /nobreak >nul
set "TS=%DATE%%TIME%"
set "TS=%TS:/=%"
set "TS=%TS::=%"
set "TS=%TS: =%"
set "TS=%TS:,=%"
set "TS=%TS:.=%"
copy /Y "{db}" "{dest}/salon_%TS%.db" >nul
if errorlevel 1 (
  echo [%DATE% %TIME%] BACKUP FAILED - see logs/backup.log>> "{APP_DIR.as_posix()}/logs/backup.log"
) else (
  echo [%DATE% %TIME%] backup ok>> "{APP_DIR.as_posix()}/logs/backup.log"
)
schtasks /Run /TN "{TASK_NAME}" >nul 2>&1
exit /b 0
"""
    cmd.write_text(body, encoding="utf-8")
    return cmd


def write_reminders_script(python: Path) -> Path:
    """Γράφει το run_reminders.cmd — υπενθυμίσεις κάθε 30 λεπτά, με log.

    ΓΙΑΤΙ .cmd ΚΑΙ ΟΧΙ ΜΙΑ pythonw ΑΠΕΥΘΕΙΑΣ: το pythonw.exe δεν έχει
    παράθυρο, αλλά ούτε και stdout — η έξοδος του «send-reminders» (πόσα
    στάλθηκαν, αν λείπει το SMTP) χάνεται. Αν οι υπενθυμίσεις σταματούν να
    φτάνουν στους πελάτες, η ιδιοκτήτρια δεν θα το μάθει ποτέ. Με το .cmd
    κρατάμε την έξοδο στο logs\reminders.log, και το ίδιο το .cmd κρύβεται
    από το VBS.

    Εδώ θέλουμε την python.exe, όχι την pythonw: εδώ θέλουμε την έξοδο.
    """
    cmd = APP_DIR / "run_reminders.cmd"
    log = 'logs\\reminders.log'
    body = f"""@echo off
rem ============================================================
rem  Niki's Grooming Salon - reminders, every 30 minutes
rem  Generated by install_service.py - do not edit by hand.
rem ============================================================
cd /d "{APP_DIR}"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONUNBUFFERED=1
if not exist "logs" mkdir "logs"
rem The messages are ASCII only: cmd.exe has its own code page, so Greek
rem text would come out garbled in the log.
echo [%DATE% %TIME%] --- reminders start --- >> "{log}"
"{python}" -m flask --app wsgi send-reminders >> "{log}" 2>&1
echo [%DATE% %TIME%] --- reminders end (code %ERRORLEVEL%) --- >> "{log}"
"""
    cmd.parent.mkdir(parents=True, exist_ok=True)
    cmd.write_text(body, encoding="utf-8")
    return cmd


def write_hidden_launcher(script: Path, wait: bool = True) -> Path:
    """VBS που τρέχει ένα .cmd ΧΩΡΙΣ να φανεί παράθυρο. Επιστρέφει το VBS.

    ΧΡΕΙΑΖΕΤΑΙ ΓΙΑΤΙ: τα αρχεία .cmd είναι console εφαρμογές. Όταν το Task
    Scheduler τα εκτελεί, ανοίγει μαύρο παράθυρο στην οθόνη της
    ιδιοκτήτριας. Το Task Scheduler δεν έχει «τρέξε το κρυφά» — μόνο το
    -Hidden, που κρύβει την εργασία στη ΛΙΣΤΑ, όχι το παράθυρο. Η μόνη
    εγγυημένη λύση είναι WScript.Shell με window style 0.

    Το αρχεί γράφεται ΜΟΝΟ με χαρακτήρες ASCII: ο VBScript διαβάζει το .vbs
    ως ANSI, και τα ελληνικά σχόλια θα έβγαιναν μπερδεμένα στο log.
    """
    if '"' in str(script):
        raise ValueError("the .cmd path must not contain a quote: " + str(script))
    # wait=True: το Task Scheduler πρέπει να βλέπει την ΠΡΑΓΜΑΤΙΚΗ διάρκεια.
    # Με False η εργασία «τελειώνει» αμέσως και ο επόμενος κύκλος μπορεί να
    # ξεκινήσει ενώ ο προηγούμενος ακόμα τρέχει.
    # Το _hidden στο όνομα ώστε να μην μπερδευτεί με το .cmd του ίδιου
    # stem (run_reminders.cmd + run_reminders_hidden.vbs).
    vbs = APP_DIR / (script.stem + "_hidden.vbs")
    vbs.parent.mkdir(parents=True, exist_ok=True)
    wait_str = "True" if wait else "False"
    vbs.write_text(
        "' Generated by install_service.py - runs a command with NO window.\n"
        "Set sh = CreateObject(\"WScript.Shell\")\n"
        'sh.Run "cmd.exe /c ""' + str(script) + '""", 0, ' + wait_str + '\n',
        encoding="ascii",
    )
    return vbs


def run_powershell(script: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive",
         "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=300)


def do_install(port: int, local_only: bool, quiet: bool) -> int:
    if not IS_WINDOWS:
        fail("Αυτό το σενάριο στοχεύει Windows.")
        return 1
    if not is_admin():
        fail("Χρειάζεται εκτέλεση ως Administrator (για να δημιουργηθεί η εργασία).")
        return 1

    host = "127.0.0.1" if local_only else "0.0.0.0"
    warn_wwwroot()
    step("Προετοιμασία")
    for name in ("instance", "logs"):
        (APP_DIR / name).mkdir(parents=True, exist_ok=True)
    ok("Φάκελοι έτοιμοι: instance\\, logs\\")

    exe = python_exe()
    ok(f"Python: {exe}")
    if not exe.exists():
        fail("Δεν βρέθηκε Python. Τρέξε πρώτα: python -m venv .venv")

    cmd_file = write_runner(port, host)
    ok(f"Δημιουργήθηκε {cmd_file.name}")

    step(f"Εργασία '{TASK_NAME}' (κάθε εκκίνηση)")
    result = subprocess.run(
        # ΧΩΡΙΣ /RI και /DU: το schtasks τα δέχεται ΜΟΝΟ σε ONLOGON, DAILY,
        # WEEKLY και MONTHLY. Με ONSTART αποτυγχάνει ολόκληρη η εντολή:
        #   "The options /RI, /DU, /ST, /SD, /ET, /ED and /K are not
        #    applicable for the scheduled types: ONSTART, ONLOGON..."
        # Χωρίς αυτό δεν χρειάζεται και καμία επανεκκίνηση εδώ: το
        # run_server.cmd έχει ήδη άπειρο βρόχο, οπότε αν πέσει η Python
        # ξαναξεκινά μόνη της σε 5 δευτερόλεπτα. Το /RI θα ήταν και
        # περιττό, και μάλιστα χαμένος χρόνος: αν η Python σκοτωθεί από
        # τον scheduler, κανένας χρόνος επανεκκίνησης δεν τη σώζει.
        # ΧΩΡΙΣ /IT επίσης: το /IT σημαίνει «μόνο αν ο χρήστης είναι
        # συνδεδεμένος», που δεν ισχύει ποτέ για τον SYSTEM.
        task_create_args(cmd_file),
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=180)
    if result.returncode == 0:
        ok("Η εργασία δημιουργήθηκε (ONSTART, ως SYSTEM).")
    else:
        fail("Η εργασία δεν δημιουργήθηκε.")
        info((result.stderr or result.stdout or "").strip()[:400])
        return 1

    if not local_only:
        firewall_rule(port)
    else:
        step("Τείχος φωτιάς")
        ok(f"Μόνο τοπική πρόσβαση — η θύρα {port} δεν άνοιξε στο δίκτυο.")

    step("Εκκίνηση & έλεγχος")
    run_task("run", TASK_NAME)
    if not health(port):
        return 1
    ok("Η εφαρμογή απάντησε.")

    print()
    print(_c("═" * 64, GREEN))
    print("  Η εφαρμογή τρέχει μόνιμα — χωρίς IIS.")
    print(_c("═" * 64, GREEN))
    print(lan_hint(local_only, port))
    print()
    print("   Έλεγχος :  python install_service.py --status")
    print("   Στοίχιο  :  logs\\service.log")
    print("   Σταμάτημα:  python install_service.py --stop")
    return 0


def do_status() -> int:
    step(f"Κατάσταση '{TASK_NAME}'")
    if not IS_WINDOWS:
        fail("Μόνο στα Windows.")
        return 1
    query = _query()
    if query is None:
        warn("Η εργασία δεν υπάρχει.")
        return 1
    for line in query.splitlines():
        if any(k in line for k in ("TaskName", "Status", "Last Run Time",
                                   "Last Result", "Task To Run")):
            print(f"       {line.strip()}")
    for port in (5000, 8080):
        if _alive(port):
            ok(f"Απαντά στο http://127.0.0.1:{port}/health")
            return 0
    warn("Η εφαρμογή δεν απαντά σε κανέναν αναμενόμενο port.")
    log = APP_DIR / "logs" / "service.log"
    if log.exists():
        info("Τέλος του logs/service.log:")
        for line in log.read_text(encoding="utf-8", errors="replace").splitlines()[-15:]:
            print(f"       {line}")
    return 1


def _alive(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=4) as r:
            return r.status == 200
    except Exception:                                  # noqa: BLE001
        return False


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Εγκατάσταση της εφαρμογής ως μόνιμη εργασία στα Windows.")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--local-only", action="store_true",
                        help="Να μην ανοίγει η θύρα στο δίκτυο.")
    parser.add_argument("--start", action="store_true")
    parser.add_argument("--stop", action="store_true")
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--uninstall", action="store_true")
    args = parser.parse_args()

    if args.status:
        return do_status()
    if args.stop:
        step("Διακοπή")
        result = run_task("end", TASK_NAME)
        ok("Σταμάτησε." if result.returncode == 0
           else "Η εργασία δεν εκτελούνταν ήδη.")
        return 0
    if args.start:
        step("Εκκίνηση")
        run_task("run", TASK_NAME)
        return 0 if health(args.port) else 1
    if args.uninstall:
        step("Αφαίρεση")
        run_task("end", TASK_NAME)
        result = run_task("delete", TASK_NAME)
        ok("Η εργασία διαγράφηκε." if result.returncode == 0 else "Δεν υπήρχε.")
        return 0
    return do_install(args.port, args.local_only, False)


if __name__ == "__main__":
    sys.exit(main())
