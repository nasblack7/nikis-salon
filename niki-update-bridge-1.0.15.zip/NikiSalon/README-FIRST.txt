Niki's Grooming Salon - updating to 1.0.15
================================================

WHAT THIS IS
  A one-time helper for salon PCs running an OLD version.
  It repairs the broken database backup in memory, then installs
  1.0.15 from the internet. You do not have to copy any
  Python files by hand.

HOW TO USE
  1. Close the salon program if it is open.
  2. Unzip this file into  C:\NikiSalon
     (so that you get  C:\NikiSalon\UPDATE-NOW.bat)
  3. Double-click  C:\NikiSalon\UPDATE-NOW.bat
  4. Leave the black window alone until it says it is finished.

WHAT YOU WILL SEE
  Two extra lines that were not there before:
    "Διορθώνω το αντίγραφο της βάσης"
    "Άφησα τη βάση ελεύθερη για το αντίγραφο."
  They mean the old bug (the program was holding the database
  open, so the copy failed) is being worked around before the
  real update starts.

IF IT SAYS "404"
  The small description file was found, but the update package
  itself is not where that file says it is. That is not
  something wrong with your computer - it means the developer
  has not uploaded the package yet. Send them the whole line.

AFTER THIS RUNS ONCE
  Every future update happens on its own, from inside the
  salon program: Settings -> Updates. Nobody needs to visit you.
