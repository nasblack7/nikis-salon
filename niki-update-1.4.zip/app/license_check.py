# -*- coding: utf-8 -*-
"""Έλεγχος άδειας χρήσης — License #2 (υπογεγραμμένη, δεσμευμένη στο υλικό).

ΤΙ ΕΙΝΑΙ ΑΥΤΟ
    Κάθε εγκατάσταση έχει ένα `instance/license.json` που υπογράφεται από το
    ΙΔΙΩΤΙΚΟ κλειδί του ιδιοκτήτη. Η εφαρμογή έχει μόνο το ΔΗΜΟΣΙΟ κλειδί και
    ελέγχει την υπογραφή τοπικά, χωρίς internet.

ΤΙ ΔΕΝ ΧΡΕΙΑΖΕΤΑΙ
    Καμία νέα βιβλιοθήκη. Ο έλεγχος Ed25519 γίνεται με το ΥΠΑΡΧΟΝ
    `app/ed25519.py` (καθαρή Python), όπως και για τις υπογραφές των
    ενημερώσεων. Άρα ο υπολογιστής του σαλονιού δεν χρειάζεται pip.

ΑΝΟΧΗ ΣΤΟ ΥΛΙΚΟ
    Το κέντρο του αποτυπώματος (`core`) δεν αλλάζει ποτέ στη ζωή ενός
    υπολογιστή. Ο δίσκος αλλάζει (SSD/HDD), η μνήμη αλλάζει, η κάρτα
    γραφικών αλλάζει. Άρα η ανοχή δίνεται ΜΟΝΟ στον δίσκο: αν το `core`
    ταυτίζεται αλλά το `full` διαφέρει, η άδεια μένει ενεργή με ειδοποίηση.
    Οποιαδήποτε άλλη διαφορά = άδεια για άλλο μηχάνημα, και μπλοκάρει.

Η ΛΗΞΗ ΕΙΝΑΙ ΠΡΑΓΜΑΤΙΚΑ ΑΝΕΝΕΡΓΗ
    Το `expires_at` στην πραγματική άδεια είναι κενό. Ο έλεγχος λήξης υπάρχει,
    αλλά εκτελείται ΜΟΝΟ όταν το πεδίο έχει τιμή. Άρα κάθε άδεια που σας
    εκδώσατε ισχύει μόνιμα, μέχρι να ζητήσετε ρητά λήξη σε επόμενη έκδοση.
"""

from __future__ import annotations

import base64
import json
import os
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Tuple

from . import ed25519

#: Τα ονόματα των καταστάσεων. Χρησιμοποιούνται και στο πρότυπο και στον
#: έλεγχο, οπότε μένουν εδώ και όχι σε δύο αρχεία.
ACTIVE = "Active"
GRACE = "Active (Grace)"
INVALID = "Invalid"
EXPIRED = "Expired"
MISSING = "Missing"
CORRUPT = "Corrupt"

#: Οι δύο παύλες που περικλαίνουν το κοίμητο κοίμενο. Χρησιμοποιούνται
#: και από το `hwid_report.py`, ώστε το μήνυμα του χρήστη και αυτό το
#: κείμενο να μοιάζουν — και ο ιδιοκτήτης να ξέρει πού να κόψει.
BEGIN_MARK = "--- ΛΗΞΕ ΤΟ ΜΠΛΟΚ ΠΡΟΣ ΘΑ ΔΙΑΒΑΣΕΤΕ ---"
END_MARK = "--- ΤΕΛΟΣ ---"

#: Μέγιστο μέγεθος αρχείου άδειας σε bytes. Μια πραγματική άδεια είναι πέντε
#: πεδία — λίγες εκατοντάδες bytes. Το όριο υπάρχει για να μην μπορεί να
#: «ανεβάσει» κάποιος ένα οποιοδήποτε άλλο αρχείο στο όνομά του.
MAX_LICENSE_BYTES = 8 * 1024

#: Καταστάσεις που κλειδώνουν τη λειτουργία. Η `Active (Grace)` ΔΕΝ είναι
#: στη λίστα: η αλλαγή δίσκου είναι προβλεπόμενη, όχι κλοπή.
LOCKED = (INVALID, EXPIRED, MISSING, CORRUPT)


@dataclass
class LicenseState:
    """Η κατάσταση της άδειας, όπως τη χρειάζονται το πρότυπο και ο έλεγχος."""
    status: str = MISSING
    serial: str = ""
    #: Το όνομα του σαλονιού που γράφτηκε στην άδεια. Δεν είναι μόνο
    #: πληροφορία — είναι υπογραμμένο, οπότε ο πελάτης δεν μπορεί να το
    #: αλλάξει στο αρχείο και να κρυφτεί.
    salon: str = ""
    activation_id: str = ""
    core_stored: str = ""
    full_stored: str = ""
    core_current: str = ""
    full_current: str = ""
    issued_at: str = ""
    expires_at: str = ""
    note: str = ""          # ελεγκτική εξήγηση για τον ιδιοκτήτη/χρήστη

    @property
    def locked(self) -> bool:
        return self.status in LOCKED

    @property
    def usable(self) -> bool:
        return self.status in (ACTIVE, GRACE)

    @property
    def badge(self) -> str:
        """Η κλάση χρώματος του σήματος κατάστασης — διαλεγμένη ΕΔΩ.

        Όχι στο πρότυπο. Ένα πρότυπο με `{% if status == 'Active' %}` μπροστά
        σε «κλειδωμένη» κατάσταση θα έδειχνε πράσινο. Το μόνο πράγμα που
        κρατάει ένα πρότυπο από το να λέψει είναι να μην του δίνεις τη
        λογική της απόφασης — μόνο το αποτέλεσμα.
        """
        return BADGE_CLASS.get(self.status, "badge--red")

    @property
    def status_label(self) -> str:
        """Η κατάσταση στα ΕΛΛΗΝΙΚΑ — αυτό που διαβάζει η ιδιοκτήτρια.

        Το `status` μένει αγγλικό επίτηδες: το συγκρίνει ο κώδικας και το
        γράφει στο αρχείο άδειας. Αλλά στην οθόνη έβγαινε «Η εφαρμογή δεν έχει
        ενεργή άδεια (Missing)» — μισό αγγλικό μέσα σε ελληνική πρόταση. Η
        αντιστοίχιση μένει ΕΔΩ, όπως και το χρώμα, για τον ίδιο λόγο: το
        πρότυπο δεν κρατάει λογική απόφασης.
        """
        return STATUS_LABEL.get(self.status, self.status)


def license_path() -> str:
    try:
        from pathlib import Path
        from config import INSTANCE_DIR
        return str(Path(INSTANCE_DIR) / "license.json")
    except Exception:
        return "instance/license.json"


def _public_key() -> bytes:
    """Το ΔΗΜΟΣΙΟ κλειδί, ως 32 bytes.

    Προέρχεται από το ΙΔΙΟΤΙΚΟ κλειδί που υπογράφει τις ενημερώσεις: ένα
    κλειδί για τα πάντα, ώστε να μην υπάρχουν δύο μυστικά να φυλάγονται.
    Κενό => καμία άδεια δεν γίνεται ποτέ δεκτή (ασφαλής συμπεριφορά).
    """
    from .version import UPDATE_PUBLIC_KEY
    raw = (UPDATE_PUBLIC_KEY or "").strip()
    if len(raw) != 64:
        return b""
    try:
        return bytes.fromhex(raw)
    except ValueError:
        return b""


def _decode_b64(text: str) -> bytes:
    """Δεκτό base64, και ως εναλλακτικά url-safe (το .lic μπορεί να έχει `-_`)."""
    raw = str(text or "").strip()
    if not raw:
        return b""
    padded = raw + "=" * (-len(raw) % 4)
    for decoder in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            return decoder(padded)
        except Exception:
            continue
    return b""


def _canonical(payload: dict) -> bytes:
    """Τα bytes που υπογράφονται.

    Τα κλειδιά ταξινομούνται και δεν μπαίνουν κενά, ώστε ο υπογράφων και ο
    επαληθευτής να παράγουν ΠΑΝΤΑ τα ίδια bytes.

    ΤΟ `salon` ΜΠΑΙΝΕΙ ΜΟΝΟ ΟΤΑΝ ΥΠΑΡΧΕΙ. Δεν είναι πρόχειρο. Οι άδειες που
    έχουν ήδη δοθεί σε πελάτες ΔΕΝ έχουν το πεδίο· αν το προσθέταμε πάντα,
    τα κανονικοποιημένα bytes τους θα άλλαζαν, η υπογραφή τους δεν θα
    επαληθευόταν ποτέ ξανά, και ΚΑΘΕ υπάρχουσα εγκατάσταση θα ξεκλειδόταν
    μετά την ενημέρωση. Με τη συνθήκη, μια παλιά άδεια παράγει ακριβώς τα
    ίδια bytes με πριν — και μια νέα με όνομα σαλονιού υπογράφεται κανονικά.
    """
    body = {
        "serial": payload.get("serial", ""),
        "hwid": payload.get("hwid", ""),
        "issued_at": payload.get("issued_at", ""),
        "expires_at": payload.get("expires_at", ""),
    }
    # ΜΟΝΟ ΟΤΑΝ ΥΠΑΡΧΕΙ: βλ. το σχόλιο παραπάνω για τις παλιές άδειες.
    salon = payload.get("salon") or ""
    if salon:
        body["salon"] = salon
    return json.dumps(body, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")


def _parse_dt(text: str) -> Optional[datetime]:
    raw = str(text or "").strip()
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


def load_file() -> Tuple[Optional[dict], str]:
    """Διαβάζει το license αρχείο. Επιστρέφει (δεδομένα, λόγος_αποτυχίας)."""
    path = license_path()
    if not os.path.exists(path):
        return None, ""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            return None, "Το αρχείο άδειας δεν περιέχει αντικείμενο."
        return data, ""
    except Exception as exc:
        return None, f"Το αρχείο άδειας δεν διαβάστηκε ({exc.__class__.__name__})."


def save_file(payload: dict) -> Tuple[bool, str]:
    """Γράφει το license αρχείο. Επιστρέφει (επιτυχία, λόγος_αποτυχίας).

    Γίνεται ΜΕΤΑ το πέρασμα της υπογραφής, ώστε ένα άσχημο αρχείο να μην
    παραμείνει ποτέ στον δίσκο και να μη χρειαστεί χειροκίνητη διόρθωση.
    """
    path = license_path()
    try:
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, path)          # ατομική αντικατάσταση
        return True, ""
    except Exception as exc:
        return False, f"Η άδεια δεν αποθηκεύτηκε ({exc.__class__.__name__})."


def _current() -> Tuple[str, str]:
    """Το αποτύπωμα ΑΥΤΟΥ του υπολογιστή, όπως το βλέπει η ίδια η εφαρμογή."""
    from . import hwid
    return hwid.compute()


def check() -> LicenseState:
    """Ο έλεγχος της άδειας. Καλείται σε κάθε σελίδα — είναι φθηνός."""
    from . import hwid

    core_now, full_now = _current()
    data, broken = load_file()
    data_note_missing = "Δεν βρέθηκε άδεια σε αυτόν τον υπολογιστή."

    # Το Activation ID υπάρχει σε ΚΑΘΕ κατάσταση — και στην «Missing».
    # Είναι το πρώτο πράγμα που ζητά ο χρήστης όταν δεν έχει άδεια, οπότε
    # το πεδίο πρέπει να γεμίζει πάντα. Μια κενή τιμή εδώ θα έκανε τη σελίδα
    # άχρηστη ακριβώς στη στιγμή που τη χρειάζεται.
    act = hwid.activation_id(core_now)

    if data is None and broken:
        return LicenseState(status=CORRUPT, activation_id=act,
                            core_current=core_now, full_current=full_now,
                            note=broken)
    if data is None:
        return LicenseState(status=MISSING, activation_id=act,
                            core_current=core_now, full_current=full_now,
                            note=data_note_missing)

    serial = str(data.get("serial") or "")
    stored = str(data.get("hwid") or "")
    core_stored, _, full_stored = stored.partition(":")
    if not full_stored:
        # Μοναδικό hash χωρίς διπλό: αγνοούμε την ανοχή, ταυτίζεται μόνο αν
        # ταυτίζει και το «μόνο core».
        full_stored = core_stored

    state = LicenseState(
        serial=serial,
        salon=str(data.get("salon") or ""),
        activation_id=act,
        core_stored=core_stored, full_stored=full_stored,
        core_current=core_now, full_current=full_now,
        issued_at=str(data.get("issued_at") or ""),
        expires_at=str(data.get("expires_at") or ""),
    )

    # 1) Υπογραφή. Χωρίς αυτήν τίποτα δεν έχει αξία — ούτε το serial.
    key = _public_key()
    if not key:
        state.status = CORRUPT
        state.note = "Η εφαρμογή δεν έχει δημόσιο κλειδί άδειας."
        return state
    signature = _decode_b64(data.get("signature"))
    if not signature:
        state.status = CORRUPT
        state.note = "Το αρχείο άδειας δεν έχει υπογραφή."
        return state
    if not ed25519.verify(_canonical(data), signature, key):
        state.status = CORRUPT
        state.note = ("Η υπογραφή της άδειας δεν επαληθεύεται. Το αρχείο "
                      "είναι αλλοιωμένο ή δεν προέρχεται από εσάς.")
        return state

    # 2) Λήξη — ΕΝΕΡΓΟΠΟΙΕΙΤΑΙ ΜΟΝΟ ΑΝ ΥΠΑΡΧΕΙ ΤΙΜΗ. Η πραγματική άδεια έχει
    #    κενό, άρα ποτέ δεν μπλοκάρει λόγω λήξης.
    expiry = _parse_dt(state.expires_at)
    if expiry is not None:
        import datetime as _dt
        now = _dt.datetime.now(expiry.tzinfo) if expiry.tzinfo else _dt.datetime.now()
        if now > expiry:
            state.status = EXPIRED
            state.note = "Η άδεια έληξε. Χρειάζεται νέα από τον ιδιοκτήτη."
            return state

    # 3) Σύνδεση με το υλικό.
    if core_stored and core_stored == core_now and full_stored == full_now:
        state.status = ACTIVE
        return state
    if core_stored and core_stored == core_now:
        state.status = GRACE
        state.note = ("Αλλάξε ο δίσκος ή η μνήμη. Η άδεια συνεχίζει να "
                      "ισχύει· αν αλλάξει κι η κάρτα μητρέας, χρειάζεται νέα.")
        return state

    state.status = INVALID
    state.note = ("Η άδεια δεν αντιστοιχεί σε αυτόν τον υπολογιστή. "
                  "Έχει εκδοθεί για άλλο μηχάνημα.")
    return state


def verify_upload(payload: dict) -> Tuple[bool, str, str]:
    """Ελέγχει ένα αρχείο πριν το γράψει. Επιστρέφει (έγκυρο, λόγος, serial).

    Γράφεται ΜΟΝΟ όταν επιστρέφει έγκυρο. Έτσι η εφαρμογή δεν κρατάει ποτέ
    αρχείο που δεν περνάει, και ο χρήστης μπορεί να δοκιμάζει ξανά.
    """
    if not isinstance(payload, dict):
        return False, "Το αρχείο δεν είναι έγκυρη άδεια.", ""

    serial = str(payload.get("serial") or "").strip()
    if not serial:
        return False, "Λείπει ο αριθμός άδειας (serial).", ""
    if not serial.upper().startswith("KI-"):
        return False, ("Ο αριθμός άδειας πρέπει να αρχίζει με «KI-». "
                       "Έλεγξτε ότι στέλνετε το σωστό αρχείο."), serial
    hwid_value = str(payload.get("hwid") or "").strip()
    if ":" not in hwid_value:
        return False, ("Λείπει το αποτύπωμα υλικού (hwid). Η άδεια πρέπει να "
                       "περιέχει core και full, χωρισμένα με άνω-κάτω τελεία."), serial

    key = _public_key()
    if not key:
        return False, "Η εφαρμογή δεν έχει δημόσιο κλειδί άδειας.", serial
    signature = _decode_b64(payload.get("signature"))
    if not signature:
        return False, "Το αρχείο δεν έχει υπογραφή.", serial
    if not ed25519.verify(_canonical(payload), signature, key):
        return False, ("Η υπογραφή δεν επαληθεύεται. Το αρχείο δεν έχει "
                       "εκδοθεί από εσάς ή έχει αλλοιωθεί."), serial

    # Έλεγχος του υλικού ΕΔΩ, ώστε να μην αποθηκεύεται άδεια άλλου μηχανήματος.
    core_now, full_now = _current()
    core_given, _, full_given = hwid_value.partition(":")
    if core_given != core_now:
        return False, ("Η άδεια έχει εκδοθεί για άλλον υπολογιστή. "
                       "Δεν αποθηκεύεται."), serial
    if full_given != full_now:
        # Δεκτό, αλλά ο χρήστης πρέπει να το ξέρει: το αποτυπώμα του
        # δίσκου άλλαξε από την έκδοση. Η άδεια μπαίνει σε κατάσταση
        # «Active (Grace)» — όχι σφάλμα.
        pass
    return True, "", serial


def activate(payload: dict) -> Tuple[bool, str]:
    """Εγκαθιστά άδεια αφού περάσει τον έλεγχο. Επιστρέφει (επιτυχία, λόγος)."""
    ok, reason, _serial = verify_upload(payload)
    if not ok:
        return False, reason
    wrote, why = save_file(payload)
    if not wrote:
        return False, why
    return True, ""


def salon_name() -> str:
    """Το όνομα του σαλονιού ΑΥΤΟΥ του υπολογιστή.

    Διαβάζεται από τις ρυθμίσεις, που στήθηκαν στη σελίδα πρώτης εγκατάστασης.
    Χωρίς επιστροφή σφάλματος: η σελίδα άδειας είναι ΑΝΟΙΧΤΗ, χωρίς σύνδεση,
    και δεν πρέπει να πέσει με 500 επειδή λείπει ένας πίνακας.
    """
    try:
        from .models import SalonSettings

        return str(SalonSettings.get("name") or "").strip()
    except Exception:                                   # noqa: BLE001
        return ""


def copy_block(state: "LicenseState", machine: str = "") -> str:
    """Το ακριβές κείμενο που αντιγράφει ο χρήστης και στέλνει στον ιδιοκτήτη.

    Μία μόνη πηγή αλήθειας: και η σελίδα στον browser και το `/license/block.txt`
    χρησιμοποιούν ΑΥΤΗ τη λειτουργία. Άρα το μήνυμα που έστειλε ο πελάτης
    είναι γραμμένο ακριβώς όπως το βλέπει ο ιδιοκτήτης στο δικό του εργαλείο —
    και όχι δύο διαφορετικά κείμενα που πρέπει να ταιριάζουν σε χαρτί.

    ΤΟ ΟΝΟΜΑ ΤΟΥ SALON ΕΙΝΑΙ Η ΠΡΩΤΗ ΓΡΑΜΜΗ ΕΔΩ, ΓΙΑ ΜΙΑ ΠΡΑΓΜΑΤΙΚΗ ΑΙΤΙΑ:
    ο ιδιοκτήτης δέχεται μπλοκ από πολλά σαλόνια και τα HWID είναι
    αδιάκριτα. Χωρίς το όνομα, «ποιο μπλοκ ανήκει σε ποιον» είναι μια
    πρόβλεψη. Με αυτό, το `make_license.py` μπορεί να το πάρει από εδώ και
    να ονομάσει το .lic με το όνομα του σαλονιού.
    """
    lines = [
        "=== Niki's Grooming Salon — στοιχεία ενεργοποίησης ===",
        "",
        "Salon:  %s" % (salon_name() or "—"),
        "Activation ID:  %s" % (state.activation_id or "—"),
        "Serial (υπάρχει ήδη):  %s" % (state.serial or "—"),
        "Κατάσταση:  %s" % (state.status or "—"),
    ]
    if machine:
        lines.append("Υπολογιστής:  %s" % machine)
    lines += [
        "",
        "Αν η κατάσταση δεν είναι «Active», στείλτε τα παρακάτω:",
        "",
        # ΔΥΟ παύλες και στις δύο άκρες, για να ξέρει ο ιδιοκτής πού
        # ακριβώς τελειώνει το κοίμητο κομμάτι. Ίδια μορφή με το
        # `hwid_report.py`, ώστε να μην αναρωτηθεί ποιο από τα δύο
        # χρειάζεται.
        BEGIN_MARK,
        "HWID core:  %s" % (state.core_current or "—"),
        "HWID full:  %s" % (state.full_current or "—"),
        END_MARK,
    ]
    return "\n".join(lines)


def describe_status(state: "LicenseState") -> str:
    """Μία πρόταση στα ελληνικά για τον χρήστη, ανάλογα με την κατάσταση.

    Το πρότυπο δεν αποφασίζει τίποτα· απλώς δείχνει. Η απόφαση έγινε στο
    `check()`, που είναι το backend.
    """
    if state.status == ACTIVE:
        return "Η άδεια ισχύει για αυτόν τον υπολογιστή."
    if state.status == GRACE:
        return ("Αλλάξε ο δίσκος ή η μνήμη. Η άδεια ισχύει κανονικά — "
                "χρειάζεται νέα μόνο αν αλλάξει η μητρέας.")
    if state.status == MISSING:
        return "Δεν έχει ενεργοποιηθεί ακόμα. Στείλτε τα στοιχεία στον ιδιοκτήτη."
    if state.status == EXPIRED:
        return "Η άδεια έληξε. Χρειάζεται νέα από τον ιδιοκτήτη."
    if state.status == INVALID:
        return ("Η άδεια έχει εκδοθεί για άλλον υπολογιστή. "
                "Στείλτε τα στοιχεία στον ιδιοκτήτη για νέα.")
    return ("Το αρχείο άδειας δεν επαληθεύεται. Ζητήστε νέο από τον ιδιοκτήτη.")


#: Η κατάσταση που δείχνει το χρώμα σήματος. Το χρώμα το διαλέγει το
#: ΜΟΝΟ το backend και όχι το πρότυπο: έτσι δεν υπάρχει «πράσινο ενεργή» σε
#: σελίδα που το backend είπε ότι δεν είναι ενεργή. Οι τιμές είναι τα
#: όνομα των κλάσεων του `app.css`.
BADGE_CLASS = {
    ACTIVE: "badge--sage",
    GRACE: "badge--amber",
    EXPIRED: "badge--red",
    INVALID: "badge--red",
    MISSING: "badge--red",
    CORRUPT: "badge--red",
}

#: Η ίδια κατάσταση στα ελληνικά, για τις τρεις σελίδες που τη δείχνουν στην
#: ιδιοκτήτρια (σύνδεση, ρυθμίσεις ενημερώσεων, ενεργοποίηση). Χωρίς αυτό το
#: πρότυπο έπρεπε να κάνει `{% if status == 'Active' %}` για να πει «Ενεργή»
#: — δηλαδή λογική απόφασης μέσα στο πρότυπο, που είναι ακριβώς το πράγμα
#: που το `badge` υπάρχει για να αποτρέψει.
STATUS_LABEL = {
    ACTIVE: "Ενεργή",
    GRACE: "Ενεργή (περίοδος χάρης)",
    EXPIRED: "Ληγμένη",
    INVALID: "Μη έγκυρη",
    MISSING: "Δεν έχει εισαχθεί ακόμη",
    CORRUPT: "Μη αναγνώσιμο αρχείο",
}
