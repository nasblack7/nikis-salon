# -*- coding: utf-8 -*-
"""Αποτύπωμα υλικού (HWID) για την άδεια χρήσης.

ΤΙ ΜΕΤΡΑΕΙ ΚΑΙ ΤΙ ΟΧΙ
    Μετράνε ΤΡΙΑ πράγματα, και μόνο αυτά, γιατί πρέπει να είναι σταθερά
    όσο ζει ο υπολογιστής:

        1. MachineGuid        — εγγραφή των Windows για τη μηχανή
        2. UUID μητρέας      — το ίδιο το πλακέτι
        3. MAC της κάρτας    — το ίδιο το τυπικό δίκτυο

    ΔΕΝ μετράνε ο δίσκος και η μνήμη: αλλάζουν. Γι' αυτό υπάρχουν ΔΥΟ
    hashes — το `core` (τα τρία παραπάνω, αμετάβλητα) και το `full`
    (core + σειρά δίσκου). Όταν αλλάζει δίσκος, το core παραμένει ίδιο και
    η άδεια μέναι ενεργή με ειδοποίηση. Όταν αλλάζει κάρτα ή μητρέας,
    το core αλλάζει και η άδεια δεν ταιριάζει πλέον — πράγμα που θέλουμε,
    γιατί τότε μπορεί να είναι άλλο μηχάνημα.

ΜΟΝΟ ΚΑΘΑΡΗ PYTHON
    Καμία βιβλιοθήκη τρίτου μέρους, καμία εγκατάσταση, καμία άδεια. Ο
    υπολογιστής του σαλονιού δεν χρειάζεται να μπει στο internet για να
    τρέξει αυτό το αρχείο.

ΕΜΠΙΣΤΟΣΥΝΗ
    Οι συγκρίσεις γίνονται ΜΟΝΟ μέσα στο backend. Η σελίδα δείχνει τις
    τιμές, αλλά καμία απόφαση δεν παίρνεται από το πρότυπο ή το JS.
"""

from __future__ import annotations

import hashlib
import os
import re
import threading
import time as _time
import uuid as _uuid
from typing import Optional, Tuple

#: Το μήκος του hash που κρατάμε στην άδεια. Το SHA-256 αρκεί εδώ: δεν
#: κρυπτογραφούμε κάτι, απλώς δεν θέλουμε δύο διαφορετικές μηχανές να
#: παράγουν το ίδιο αποτύπωμα κατά λάθος.
HASH_LEN = 64

#: Πόσα πρώτα ψηφία του core γίνονται το σύντομο Activation ID. Οκτώ
#: ψηφία (32 εκατομμύρια πιθανότητες) αρκούν για ανθρώπινο χειρισμό: το
#: ID δεν προστατεύει τίποτα μόνο του, απλών εντοπίζει γρήγορα ποιος
#: υπολογιστής είναι ποιος όταν σας στέλνουν ένα μήνυμα.
ACTIVATION_ID_LEN = 8


# ── δεξιά παραμέτρος για το μηχάνημα ─────────────────────────────────────────

def _machine_guid() -> str:
    """Το MachineGuid των Windows.

    Η εγγραφή είναι η πιο σταθερή ταυτότητα μηχανής που υπάρχει στα
    Windows. Διαβάζεται απευθείας από το registry με το `winreg` — χωρίς
    `wmic`, που αφαιρέθηκε από τα Windows 11, και χωρίς PowerShell.
    """
    if os.name != "nt":
        return ""
    try:
        import winreg  # type: ignore

        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
            0,
            winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
        ) as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
        return str(value)
    except Exception:
        return ""


def _board_uuid() -> str:
    """Το UUID της μητρέας (το ίδιο το πλακέτι).

    Στα Windows το δίνει το `Win32_BaseBoard` μέσω WMI. Δοκιμάζουμε το
    PowerShell (παρόν σε κάθε Windows) και μετά το αρχείο `/sys` στο
    Linux. Η μέθοδος του `uuid` σε Windows βασίζεται στο ίδιο UUID, οπότε
    σε επείγοντα χρησιμοποιείται ως εφεδρική.
    """
    if os.name == "nt":
        try:
            import subprocess

            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "(Get-CimInstance -ClassName Win32_BaseBoard).SerialNumber"],
                capture_output=True, text=True, timeout=4.0, check=False,
            )
            value = (out.stdout or "").strip().splitlines()
            if value:
                return value[0].strip()
        except Exception:
            pass
        try:
            return str(_uuid.getnode())          # όχι ιδανικό, αλλά σταθερό
        except Exception:
            return ""

    # macOS: το IOPlatformUUID. Έρχεται μαζί με το ίδιο UUID που βλέπει το
    # `uuid.getnode()` σε Mac, άρα είναι συμβατό με τη δική μας διαβάσμενη πηγή.
    if os.name == "posix" and not os.path.exists("/sys/class/dmi/id"):
        try:
            import subprocess

            out = subprocess.run(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                capture_output=True, text=True, timeout=4.0, check=False)
            for line in (out.stdout or "").splitlines():
                if "IOPlatformUUID" in line and '"' in line:
                    value = line.split('"')[-2].strip()
                    if value:
                        return value
        except Exception:
            pass
        return ""

    # Linux: το ίδιο UUID διαβάζεται από το DMI, χωρίς δικαιώματα root.
    for path in ("/sys/class/dmi/id/product_uuid",
                 "/sys/devices/virtual/dmi/id/product_uuid"):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                value = fh.read().strip()
            if value and value.lower() != "none":
                return value
        except Exception:
            continue
    return ""


def _mac_address() -> str:
    """Η MAC του τυπικού δίκτυου.

    Διαβάζεται απευθείας από το `uuid.getnode()`, που επιστρέφει τη MAC
    του πρώτου φυσικού διασύνδελου και αποθηκεύεται από το Λειτουργικό στο
    registry μεταξύ των επανεκκινήσεων. Έτσι δεν εξαρτάται από
    εργαλεία γραμμής εντολών και λειτουργεί και σε Windows και σε Linux.
    """
    try:
        node = _uuid.getnode()
    except Exception:
        return ""
    # 0x010000000000 σημαίνει «δεν ξέρω / εφεδρική διεύθυνση» — μη χρήσιμο
    if node in (0, 0x010000000000):
        return ""
    text = "%012X" % node
    return ":".join(text[i:i + 2] for i in range(0, 12, 2))


def _disk_serial() -> str:
    """Η σειρά του δίσκου — ΜΟΝΟ για την ανοχή, ποτέ για την ταυτότητα.

    Στα Windows διαβάζεται με PowerShell από το `Win32_DiskDrive`· σε
    Linux/macOS από το `lsblk`. Αν δεν βρεθεί, μένει κενό και η ανοχή
    απλώς δεν χρειάζεται — ο έλεγχος γίνεται μόνο από το core.
    """
    if os.name == "nt":
        try:
            import subprocess

            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "(Get-CimInstance -ClassName Win32_DiskDrive | "
                 "Select-Object -First 1).SerialNumber"],
                capture_output=True, text=True, timeout=4.0, check=False,
            )
            return (out.stdout or "").strip().splitlines()[0].strip()
        except Exception:
            return ""
    try:
        import subprocess

        out = subprocess.run(["lsblk", "-no", "SERIAL"],
                             capture_output=True, text=True, timeout=4.0,
                             check=False)
        for line in (out.stdout or "").splitlines():
            value = line.strip()
            if value:
                return value
    except Exception:
        pass
    return ""


# ── κανονικοποίηση και κατανομή ─────────────────────────────────────────────

def _clean(value: str) -> str:
    """Καθαρίζει μια τιμή ώστε να είναι η ίδια κάθε φορά που διαβάζεται.

    Τα Windows δίνουν τα ίδια δεδομένα με διαφορετική γραφή κάθε φορά
    (κεφαλαία/πεζά, μοναδικά, κενά). Χωρίς αυτό το βήμα, ο ίδιος
    υπολογιστής θα έδινε διαφορετικό hash σε διαφορετική εκκίνηση και η
    άδεια θα έσπαγε μόνη της. Είναι το πιο σημαντικό σημείο όλης της
    υλοποίησης.
    """
    text = str(value or "").strip()
    if not text:
        return ""
    text = re.sub(r"[^0-9A-Za-z]", "", text)     # παύλες, κενά, άνω-κάτω τελεία
    return text.upper()


#: Πόσα δευτερόλεπτα ισχύει η μέτρηση πριν μετρηθεί ξανά. ΜΗΔΕΝ σημαίνει
#: «μετράω σε κάθε κλήση». Ο λόγος υπάρχει: το UUID της μητρέας και η σειρά
#: του δίσκου διαβάζονται στα Windows με μια κλήση PowerShell, που κάνει
#: 0,3–1 δευτερόλεπτα. Χωρίς προσωρινή αποθήκευση, ΚΑΘΕ σελίδα του σαλονιού
#: θα περίμενε δευτερόλεπτα — και αυτό είναι το χειρότερο πράγμα που μπορεί
#: να γίνει σε μια εφαρμογή κρατήσεων.
HWID_TTL_SECONDS = 600

_cache: dict = {}
_cache_lock = threading.Lock()
_cache_time: float = 0.0


def _ttl() -> float:
    """Η ισχύοντα TTL — οι δοκιμές το κάνουν 0 για να μετράτε φρέσκα."""
    try:
        from flask import current_app, has_app_context

        if has_app_context():
            value = current_app.config.get("HWID_TTL_SECONDS")
            if value is not None:
                return float(value)
    except Exception:
        pass
    return float(HWID_TTL_SECONDS)


def forget() -> None:
    """Ξεχνάει τη μέτρηση· η επόμενη κλήση την ξανακάνει.

    Χρησιμοποιείται μετά από αλλαγή υλικού, ή στις δοκιμές.
    """
    global _cache_time
    with _cache_lock:
        _cache.clear()
        _cache_time = 0.0


def _measure() -> Tuple[str, str]:
    """Η πραγματική μέτρηση — χωρίς προσωρινή αποθήκευση."""
    guid = _clean(_machine_guid())
    board = _clean(_board_uuid())
    mac = _clean(_mac_address())
    disk = _clean(_disk_serial())

    # Χωρίς MAC η ταυτότητα είναι ασθενές: σε ορισμένα VMs το getnode
    # επιστρέφει εφεδρική διεύθυνση. Τότε μένει το UUID του host, κι αν
    # κι αυτό λείπει το αποτύπωμα θεωρείται κενό και η άδεια δεν
    # ταιριάζει ποτέ — δηλαδή «κλειστή πόρτα» αντί για «κλειστή σε όλους».
    core_parts = [guid, board, mac]
    if not any(core_parts):
        return "", ""

    core_raw = "|".join(p or "-" for p in core_parts)
    full_raw = core_raw + "|" + (disk or "-")

    core = hashlib.sha256(core_raw.encode("utf-8")).hexdigest()
    full = hashlib.sha256(full_raw.encode("utf-8")).hexdigest()
    return core, full


def compute() -> Tuple[str, str]:
    """Επιστρέφει (core, full) — δύο SHA-256 σε hex.

    Το `core` είναι η ταυτότητα του μηχανήματος. Το `full` προσθέτει τον
    δίσκο και χρησιμοποιείται ΜΟΝΟ για την ανοχή.

    Η μέτρηση κρατιέται προσωρινά για `HWID_TTL_SECONDS` δευτερόλεπτα. Άρα η
    εγκατάσταση ενός νέου δίσκου ενδέχεται να μη φανεί αμέσως: το αντιλαμβάνεται
    ο έλεγχος στην επόμενη μέτρηση, το αργότερο δέκα λεπτά αργότερα. Είναι
    μικρό κόστος για σταθερότητα σε κάθε σελίδα.
    """
    global _cache_time
    with _cache_lock:
        age = _time.monotonic() - _cache_time
        if _cache and age < _ttl():
            return _cache["core"], _cache["full"]
    core, full = _measure()
    with _cache_lock:
        _cache["core"], _cache["full"] = core, full
        _cache_time = _time.monotonic()
    return core, full


def activation_id(core: str) -> str:
    """Το σύντομο ID που στέλνει ο χρήστης όταν ζητά άδεια.

    Προέρχεται από το `core` μόνο, ώστε να παραμένει ίδιο αν αλλάξει ο
    δίσκος — αλλιώς ο χρήστης θα έπρεπε να σας πει «άλλο ID», ενώ το μόνο
    που άλλαξε ήταν ο δίσκος, και εσείς δεν θα τον αναγνωρίσατε.
    """
    text = (core or "").strip().upper()
    if len(text) < ACTIVATION_ID_LEN:
        return text or "—"
    return "%s-%s" % (text[:4], text[4:ACTIVATION_ID_LEN])


def fingerprint() -> str:
    """Η τιμή που μπαίνει στην άδεια και στο μήνυμα προς τον ιδιοκτήτη."""
    core, full = compute()
    if not core:
        return ""
    return "%s:%s" % (core, full)


def describe() -> str:
    """Μία γραμμή με το τι είδους μηχάνημα είναι — για διαγνωστικό."""
    import platform
    return "%s %s" % (platform.system() or "?", platform.machine() or "?")
