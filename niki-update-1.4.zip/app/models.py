"""Μοντέλα βάσης δεδομένων — Niki's Grooming Salon Appointment Management."""

from __future__ import annotations

from datetime import datetime, time, timedelta, date as date_cls

from flask_login import UserMixin
from sqlalchemy import func, or_
from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db, login_manager

# ----------------------------------------------------------------- σταθερές
# Το μέγεθος του κατοικιδίου καταργήθηκε: η τιμή και η διάρκεια κάθε
# υπηρεσίας είναι πλέον μία για όλα. Οι παλιές στήλες size/price_large κ.λπ.
# παραμένουν στη βάση αλλά δεν διαβάζονται πουθενά.

# Κατηγορίες εξόδων. Οι «Έξοδα καταστήματος» είναι τα σταθερά του μαγαζιού
# (ρεύμα, νερό, ενοικίαση…) σε αντίθεση με τα υλικά που καταναλώνονται
# στις υπηρεσίες (σαμπουάν, μάσκες…).
EXPENSE_STORE = "Έξοδα καταστήματος"
EXPENSE_SUPPLIES = "Υλικά επίστρωσης"
EXPENSE_GENERAL = "Γενικά"
EXPENSE_CATEGORIES = (EXPENSE_STORE, EXPENSE_SUPPLIES, EXPENSE_GENERAL)


ROLE_OWNER = "owner"
ROLE_STAFF = "staff"
# Ο ΥΠΕΥΘΥΝΟΣ ΕΙΝΑΙ ΙΔΙΟΚΤΗΤΗΣ ΧΩΡΙΣ ΤΟΝ ΤΙΤΛΟ. Ζητήθηκε ρητά «ίδια
# δικαιώματα με τον ιδιοκτήτη», γι' αυτό και το όνομα του ελέγχου δεν είναι
# «ιδιοκτήτης» αλλά «διοίκηση»: διαφορετικά, ο επόπτης βλέπει μια
# δικλίδα που δεν κλειδώνει ποτέ, και κανείς δεν καταλαβαίνει ποιος έχει
# δικαιώματα στα οικονομικά μέχρι να τη χαλάσει.
ROLE_MANAGER = "manager"
ROLE_LABELS = {ROLE_OWNER: "Ιδιοκτήτης", ROLE_MANAGER: "Υπεύθυνος",
               ROLE_STAFF: "Βοηθός"}
STAFF_ROLES = (ROLE_OWNER, ROLE_MANAGER, ROLE_STAFF)
# ΟΠΟΙ ΜΠΑΙΝΕΙ ΣΤΗ ΔΙΟΙΚΗΣΗ. Ο ΥΠΕΥΘΥΝΟΣ ΜΠΑΙΝΕΙ, Ο ΒΟΗΘΟΣ ΟΧΙ.
ADMIN_ROLES = (ROLE_OWNER, ROLE_MANAGER)

STATUS_PENDING = "pending"
STATUS_CONFIRMED = "confirmed"
STATUS_IN_PROGRESS = "in_progress"
STATUS_COMPLETED = "completed"
STATUS_CANCELLED = "cancelled"
STATUS_NO_SHOW = "no_show"

STATUS_LABELS = {
    STATUS_PENDING: "Σε αναμονή",
    STATUS_CONFIRMED: "Επιβεβαιωμένο",
    STATUS_IN_PROGRESS: "Σε εξέλιξη",
    STATUS_COMPLETED: "Ολοκληρώθηκε",
    STATUS_CANCELLED: "Ακυρώθηκε",
    STATUS_NO_SHOW: "Δεν προήλθε",
}
OPEN_STATUSES = (STATUS_PENDING, STATUS_CONFIRMED, STATUS_IN_PROGRESS)

SOURCE_PHONE = "phone"
SOURCE_EMAIL = "email"
SOURCE_WALK_IN = "walk_in"
#: Η σειρά των παρακάτω είναι και η σειρά που εμφανίζονται στο dropdown.
#: Οι ΤΙΜΕΣ παραμένουν στα αγγλικά (αυτές αποθηκεύονται στη βάση και
#: φαίνονται στα φίλτρα/αποθηκευμένα φίλτρα), τα ΚΕΙΜΕΝΑ είναι ελληνικά.
#: Το walk_in κρατά την παλιά του τιμή επίτηδες, για να μη χαλάσουν τα
#: ραντεβού που έχουν ήδη αποθηκευτεί με αυτήν.
SOURCE_LABELS = {
    SOURCE_PHONE: "Τηλεφωνικά",
    SOURCE_EMAIL: "Μέσω email",
    SOURCE_WALK_IN: "Στο κατάστημα",
}

SPECIES = {
    "dog": "Σκύλος",
    "cat": "Γάτα",
    "other": "Άλλο",
}
GENDERS = {"male": "Αρσενικό", "female": "Θηλυκό", "unknown": "—"}

WEEKDAYS = ["Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο", "Κυριακή"]


def daterange(start: date_cls, end: date_cls):
    current = start
    while current <= end:
        yield current
        current += timedelta(days=1)


# --------------------------------------------------------------------- χρήστης
class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(180), unique=True, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default=ROLE_STAFF, index=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    phone = db.Column(db.String(40))
    is_active_flag = db.Column(db.Boolean, default=True, nullable=False)
    is_archived = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)
    last_login_at = db.Column(db.DateTime)

    groomer = db.relationship(
        "Groomer", back_populates="user", uselist=False, cascade="all, delete-orphan"
    )

    @property
    def is_active(self) -> bool:
        return self.is_active_flag

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()

    @property
    def initials(self) -> str:
        return (self.first_name[:1] + self.last_name[:1]).upper()

    @property
    def is_staff(self) -> bool:
        return self.role in STAFF_ROLES

    @property
    def is_owner(self) -> bool:
        """Αληθινός ιδιοκτήτης — ταυτότητα, όχι δικαιώματα."""
        return self.role == ROLE_OWNER

    @property
    def is_admin(self) -> bool:
        """Έχει δικαιώματα διοίκησης: ιδιοκτήτης Ή υπεύθυνος.

        ΞΕΧΩΡΙΣΤΟ ΑΠΟ ΤΟ is_owner ΕΠΕΙΔΗ: η ταυτότητα και η άδεια δεν
        είναι το ίδιο πράγμα. Το is_owner χρησιμοποιείται όπου ρωτάμε «ποιος
        είναι ο ιδιοκτήτης» (π.χ. το όνομα στα email). Όπου ρωτάμε «μπορεί να
        δει τα οικονομικά;» χρειάζεται το is_admin, αλλιώς ο υπεύθυνος
        κοίταξε την άδεια του ιδιοκτήτη και δεν έβλεπε τα νούμερα."""
        return self.role in ADMIN_ROLES

    def set_password(self, raw: str) -> None:
        self.password_hash = generate_password_hash(raw)

    def check_password(self, raw: str) -> bool:
        return check_password_hash(self.password_hash, raw)

    @classmethod
    def find_by_identifier(cls, identifier: str | None):
        """Βρίσκει χρήστη από όνομα χρήστη ή email (χωρίς διάκριση πεζών/κεφαλαίων)."""
        value = (identifier or "").strip().lower()
        if not value:
            return None
        return cls.query.filter(
            or_(
                func.lower(cls.username) == value,
                func.lower(cls.email) == value,
            )
        ).first()

    @staticmethod
    def normalize_username(value: str | None) -> str:
        return (value or "").strip()

    @staticmethod
    def normalize_email(value: str | None) -> str | None:
        value = (value or "").strip().lower()
        return value or None


@login_manager.user_loader
def load_user(user_id: str):
    return db.session.get(User, int(user_id))


# ------------------------------------------------------------------- προσωπικό
class Groomer(db.Model):
    __tablename__ = "groomers"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    title = db.Column(db.String(120))
    bio = db.Column(db.Text)
    photo_path = db.Column(db.String(255))
    color = db.Column(db.String(9), default="#B0567A")
    specialties = db.Column(db.String(255))
    is_bookable = db.Column(db.Boolean, default=True, nullable=False)
    sort_order = db.Column(db.Integer, default=0, nullable=False)

    user = db.relationship("User", back_populates="groomer")
    appointments = db.relationship("Appointment", back_populates="groomer")
    rules = db.relationship(
        "AvailabilityRule",
        back_populates="groomer",
        cascade="all, delete-orphan",
        order_by="AvailabilityRule.start_time",
    )
    time_off = db.relationship("TimeOff", back_populates="groomer", cascade="all, delete-orphan")

    @property
    def name(self) -> str:
        return self.user.full_name if self.user else "—"

    @property
    def display(self) -> str:
        return self.title or self.name


# ------------------------------------------------------------------- πελάτης
class Customer(db.Model):
    __tablename__ = "customers"

    id = db.Column(db.Integer, primary_key=True)
    # Ονοματεπώνυμο σε ένα πεδίο. Το τηλέφωνο και το email είναι προαιρετικά:
    # πολλοί πελάτες έρχονται με το σκύλο τους και τίποτα άλλο.
    name = db.Column(db.String(160), nullable=False)
    phone = db.Column(db.String(40))
    email = db.Column(db.String(180))
    address = db.Column(db.String(255))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    # ΑΡΧΕΙΟΘΕΤΗΣΗ, ΟΧΙ ΣΒΗΣΙΜΟ. Ζητήθηκε ρητά: «να αρχειοθετείται ο πελάτης,
    # αλλά να σβήνεται οριστικά μόνο αν δεν έχει ιστορικό». Το ιστορικό είναι
    # αμετάκλητο: ένα σβημένο ραντεβού δεν ξαναγίνεται, και τα οικονομικά
    # στοιχεία του καταστήματος πρέπει να μένουν συνεπή. Η ίδια σήμα υπάρχει
    # ήδη στον χρήστη και στο κατοικίδιο — επιστρέφουμε στο ίδιο μοτίβο.
    is_active_flag = db.Column(db.Boolean, default=True, nullable=False)
    archived_at = db.Column(db.DateTime)

    pets = db.relationship(
        "Pet", back_populates="customer", cascade="all, delete-orphan", order_by="Pet.name"
    )
    appointments = db.relationship("Appointment", back_populates="customer")

    @property
    def active_pets(self) -> list["Pet"]:
        return [p for p in self.pets if p.is_active_flag and not p.is_archived]

    @property
    def has_history(self) -> bool:
        """Έχει κάτι που δεν επιτρέπεται να χαθεί;

        ΟΧΙ ΜΟΝΟ ΟΙ ΣΥΝΟΛΕΣ ΑΝΑΜΝΗΣΤΙΚΕΣ ΕΠΙΣΚΕΨΕΙΣ. Και ένα κατοικίδιο
        χωρίς ποτέ ραντεβού είναι ιστορικό: δεν είναι λόγος να χαθεί, γιατί
        θα έπρεπε να το ξαναγράψει η ιδιοκτήτρια από την αρχή. Χωρίς
        κατοικίδια και χωρίς ραντεβού, ο πελάτης είναι ένα αχρησία
        στοιχείο που μπήκε κατά λάθος — και τότε η διαγραφή είναι σωστή.
        """
        return bool(self.pets or self.appointments)

    @property
    def is_archived(self) -> bool:
        return not self.is_active_flag

    @property
    def has_upcoming(self) -> bool:
        return any(a.is_upcoming for a in self.appointments)


# ---------------------------------------------------------------------- κατοικίδια
class Pet(db.Model):
    __tablename__ = "pets"

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(
        db.Integer, db.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True
    )
    # Το όνομα είναι προαιρετικό: μπορεί το σπα να ξέρει τον πελάτη αλλά
    # όχι το όνομα του σκύλου.
    name = db.Column(db.String(80))
    species = db.Column(db.String(20), default="dog", nullable=False)
    breed = db.Column(db.String(120))
    gender = db.Column(db.String(10), default="unknown", nullable=False)
    birth_date = db.Column(db.Date)
    weight_kg = db.Column(db.Float)
    color = db.Column(db.String(80))
    is_neutered = db.Column(db.Boolean, default=False)
    allergies = db.Column(db.Text)
    temperament = db.Column(db.Text)
    health_notes = db.Column(db.Text)
    coat_notes = db.Column(db.Text)
    photo_path = db.Column(db.String(255))
    is_active_flag = db.Column(db.Boolean, default=True, nullable=False)
    is_archived = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    customer = db.relationship("Customer", back_populates="pets")
    appointments = db.relationship("Appointment", back_populates="pet")

    @property
    def is_active(self) -> bool:
        return self.is_active_flag

    @property
    def display_name(self) -> str:
        """Το όνομα όπως πρέπει να εμφανίζεται παντού.

        Το όνομα είναι προαιρετικό. Ένα κατοικίδιο μπορεί να μην έχει όνομα, και τότε το
        παλιό φίλτρο «άφησε έξω τα κενά» έκανε το κατοικίδιο να εξαφανίζεται από την κάρτα
        του πελάτη, χωρίς να το πει κανείς. Εδώ το κενό όνομα γίνεται «χωρίς όνομα» — ίδια
        λέξη με την `Appointment.pets_label`, ώστε να μην λέει η εφαρμογή δύο διαφορετικά
        πράγματα για το ίδιο πράγμα.

        Κόβει και τα λευκά κενά. Το «   » είναι αληθινή τιμή στη βάση και ισχύει και για
        το Python, οπότε ένα φίλτρο βασισμένο στο truthiness το κρατά και εμφανίζει ένα
        κενό όνομα στην οθόνη."""
        return (self.name or "").strip() or "χωρίς όνομα"

    @property
    def species_label(self) -> str:
        return SPECIES.get(self.species, self.species or "—")

    @property
    def gender_label(self) -> str:
        return GENDERS.get(self.gender, "—")

    @property
    def age_label(self) -> str:
        if not self.birth_date:
            return "—"
        months = (date_cls.today().year - self.birth_date.year) * 12 + (
            date_cls.today().month - self.birth_date.month
        )
        if months < 0:
            return "—"
        if months == 1:
            return "1 μήνα"
        if months < 24:
            return f"{months} μην."
        years = months // 12
        return "1 έτος" if years == 1 else f"{years} έτη"

    @staticmethod
    def appointments_for(pet_ids) -> dict[int, list["Appointment"]]:
        """Ραντεβού που αφορούν καθένα από τα δοθέντα κατοικίδια.

        ΕΝΩΝΕΙ ΤΙΣ ΔΥΟ ΠΗΓΕΣ: το appointment.pet_id (κύριο κατοικίδιο) και
        τον πίνακα appointment_pets (συμμετέχοντα). Χωρίς τη δεύτερη
        πηγή, ένα δεύτερο κατοικίδιο σε ραντεβού έμενε «0 επισκέψεις»
        και «Πρώτη φορά» ενώ είχε πάει.

        ΜΙΑ ΕΡΩΤΗΣΗ ΓΙΑ ΟΛΑ ΤΑ ΚΑΤΟΙΚΙΔΙΑ. Το αντίθετο — ένα ερώτημα ανά
        κατοικίδιο — σε λίστα 200 κατοικίδιων είναι 200 ερωτήματα, και η
        σελίδα που το κάνει είναι αυτή που ανοίγει ο ιδιοκτήτης το πρωί.
        """
        if not pet_ids:
            return {}
        # ΟΙ ΔΥΟ ΕΠΙΛΟΓΕΣ ΠΡΕΠΕΙ ΝΑ ΕΧΟΥΝ ΤΟ ΙΔΙΟ ΟΝΟΜΑ ΣΤΗΝ ΕΝΩΣΗ.
        # Χωρίς .label(), το union κρατά το όνομα της πρώτης στήλης και το
        # union.c.id δεν υπάρχει — AttributeError: id. Το πρόβλημα το έπιασε
        # η δοκιμή με πραγματικά δεδομένα, όχι κανένα static check.
        primary = db.session.query(
            Appointment.id.label("id")).filter(
                Appointment.pet_id.in_(pet_ids))
        secondary = db.session.query(
            appointment_pets.c.appointment_id.label("id")).filter(
                appointment_pets.c.pet_id.in_(pet_ids))
        union = primary.union_all(secondary).subquery()
        rows = db.session.query(Appointment).filter(
            Appointment.id.in_(db.session.query(union.c.id))).all()

        # Χαρτογράφηση: ποιο κατοικίδιο συμμετείχε σε ποιο ραντεβού, ώστε να
        # διαβάσω το id του ραντεβού χωρίς δεύτερο ερώτημα ανά κατοικίδιο.
        pairs = db.session.query(
            appointment_pets.c.pet_id,
            appointment_pets.c.appointment_id).filter(
                appointment_pets.c.pet_id.in_(pet_ids)).all()

        out: dict[int, list[Appointment]] = {pid: [] for pid in pet_ids}
        by_id = {a.id: a for a in rows}

        # ── ΠΗΓΗ 1: το κατοικίδιο είναι το ΚΥΡΙΟ (appointment.pet_id) ──
        # ΜΟΝΟ για κατοικίδια που ζητήθηκαν. Χωρίς τον έλεγχο, ένα ραντεβού
        # όπου το ζητημένο είναι το δεύτερο κατοικίδιο θα επέστρεφε και το
        # πρώτο — μια λίστα με κατοικίδια που κανείς δεν ζήτησε.
        for appt in rows:
            if appt.pet_id in out:
                out[appt.pet_id].append(appt)

        # ── ΠΗΓΗ 2: το κατοικίδιο είναι ΣΥΜΜΕΤΕΧΟΝ (appointment_pets) ──
        # ΕΔΩ ΗΤΑΝ ΤΟ ΛΑΘΟΣ. Το παρακάτω έμπαινε μέσα σε `if appt_id ==
        # appt.id`, όπου το appt_id ήταν το ΣΥΝΟΛΟ των id του κατοικιδίου.
        # Σύγκριση συνόλου με ακέραιο είναι ΨΕΥΔΟΣ ΠΑΝΤΑ — άρα το δεύτερο
        # κατοικίδιο έπαιρνε μηδέν, δηλαδή ΑΥΤΟΣ Ο ΒΡΟΧΟΣ. Ο κώδικας ήταν
        # έγκυρος· απλώς δεν έκανε τίποτα. Μόνο η δοκιμή με πραγματικά
        # δεδομένα το έπιασε.
        #
        # Το «δύο φορές» δεν επαναλαμβάνεται: ένα ραντεβού με δύο κατοικίδια
        # είναι ΜΙΑ ΕΝΤΥΠΗ ΓΡΑΜΜΗ, όχι δύο.
        for pet_id, appt_id in pairs:
            target = out.get(pet_id)
            appt = by_id.get(appt_id)
            if target is not None and appt is not None and appt not in target:
                target.append(appt)

        for lst in out.values():
            lst.sort(key=lambda a: a.start_at or a.id)
        return out

    def appointments_including_shared(self) -> list["Appointment"]:
        """Τα ραντεβού του κατοικίδιου, από ΟΛΕΣ τις πηγές (για ένα)."""
        return type(self).appointments_for([self.id]).get(self.id, [])

    @property
    def completed_appointments(self) -> list["Appointment"]:
        return [a for a in self.appointments_including_shared()
                if a.status == STATUS_COMPLETED]

    @property
    def last_visit(self):
        # ΟΛΑ ΤΑ ΡΑΝΤΕΒΟΥ, όχι μόνο αυτά που το έχουν ως κύριο. Ένα
        # κατοικίδιο που μπήκε δεύτερο σε ραντεβού έμενε «Πρώτη φορά»
        # για μήνες — και το «Επείγον» ανέβαινε μόνο του.
        past = [
            a
            for a in self.appointments_including_shared()
            if a.status == STATUS_COMPLETED and a.start_at and a.start_at <= datetime.now()
        ]
        if not past:
            return None
        return max(past, key=lambda a: a.start_at)

    def days_since_last_visit(self):
        last = self.last_visit
        if not last:
            return None
        return (datetime.now() - last.start_at).days

# ---------------------------------------------------------------------- υπηρεσίες
class Service(db.Model):
    __tablename__ = "services"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(60), default="Βασικές")
    is_addon = db.Column(db.Boolean, default=False, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    sort_order = db.Column(db.Integer, default=0, nullable=False)

    # Μία τιμή και μία διάρκεια για όλα τα κατοικίδια. Οι διάρκειες
    # επεξεργάζονται από την ιδιοκτήτρια (Ρυθμίσεις → Υπηρεσίες) και είναι
    # ενημερωτικές: δεν καθορίζουν τα διαθέσιμα slots.
    price = db.Column(db.Float, default=0, nullable=False)
    duration_minutes = db.Column(db.Integer, default=30, nullable=False)

    appointments = db.relationship(
        "Appointment",
        secondary="appointment_services",
        back_populates="services",
        viewonly=True,
    )
    service_links = db.relationship("AppointmentService", back_populates="service")

    @property
    def duration_label(self) -> str:
        return minutes_to_label(self.duration_minutes)


def minutes_to_label(minutes: int) -> str:
    minutes = int(minutes or 0)
    if minutes < 60:
        return f"{minutes}'"
    hours, rest = divmod(minutes, 60)
    return f"{hours} ώ" if not rest else f"{hours} ώ {rest}'"


def fmt_money(value) -> str:
    """€ με ελληνικό δεκαδικό σύμβολο: 1234.5 -> «1.234,50 €»."""
    return f"{float(value or 0):.2f} €".replace(".", ",")


# ------------------------------------------------------------------ διαθεσιμότητα
class AvailabilityRule(db.Model):
    __tablename__ = "availability_rules"

    id = db.Column(db.Integer, primary_key=True)
    groomer_id = db.Column(
        db.Integer, db.ForeignKey("groomers.id", ondelete="CASCADE"), nullable=False, index=True
    )
    weekday = db.Column(db.Integer, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)

    groomer = db.relationship("Groomer", back_populates="rules")

    @property
    def weekday_label(self) -> str:
        return WEEKDAYS[self.weekday]

    @property
    def label(self) -> str:
        return f"{self.weekday_label} {self.start_time.strftime('%H:%M')} - {self.end_time.strftime('%H:%M')}"


class TimeOff(db.Model):
    __tablename__ = "time_off"

    id = db.Column(db.Integer, primary_key=True)
    groomer_id = db.Column(
        db.Integer, db.ForeignKey("groomers.id", ondelete="CASCADE"), nullable=False, index=True
    )
    start_at = db.Column(db.DateTime, nullable=False)
    end_at = db.Column(db.DateTime, nullable=False)
    reason = db.Column(db.String(160))

    groomer = db.relationship("Groomer", back_populates="time_off")

    @property
    def label(self) -> str:
        if self.start_at.date() == self.end_at.date():
            return f"{fmt_date(self.start_at.date())} · {self.start_at:%H:%M}–{self.end_at:%H:%M}"
        return f"{fmt_date(self.start_at.date())} → {fmt_date(self.end_at.date())}"


class SalonDaySettings(db.Model):
    __tablename__ = "salon_day_settings"

    id = db.Column(db.Integer, primary_key=True)
    weekday = db.Column(db.Integer, nullable=False, unique=True)
    is_closed = db.Column(db.Boolean, default=False, nullable=False)
    open_time = db.Column(db.Time, default=time(9, 0))
    close_time = db.Column(db.Time, default=time(18, 0))
    note = db.Column(db.String(160))

    @property
    def weekday_label(self) -> str:
        return WEEKDAYS[self.weekday]


# -------------------------------------------------------------------- ραντεβού
# Πολλά κατοικίδια στο ίδιο ραντεβού (μια πελάτρια με 2 σκύλους).
appointment_pets = db.Table(
    "appointment_pets",
    db.Column("appointment_id", db.Integer, db.ForeignKey("appointments.id", ondelete="CASCADE"), primary_key=True),
    db.Column("pet_id", db.Integer, db.ForeignKey("pets.id", ondelete="CASCADE"), primary_key=True),
)


class AppointmentService(db.Model):
    """Γραμμή υπηρεσίας σε ραντεβού: ποσότητα + στιγμιότυπο διάρκειας.

    Είναι association object (όχι απλό Table) επειδή χρειάζονται και οι
    διπλές στήλες ποσότητας/διάρκειας μαζί με τη σχέση.
    """
    __tablename__ = "appointment_services"

    appointment_id = db.Column(
        db.Integer, db.ForeignKey("appointments.id", ondelete="CASCADE"), primary_key=True
    )
    service_id = db.Column(db.Integer, db.ForeignKey("services.id"), primary_key=True)
    # Πόσες φορές γίνεται η υπηρεσία στο ίδιο ραντεβού (π.χ. 2 σκύλοι → ×2).
    quantity = db.Column(db.Integer, default=1, nullable=False)
    # Στιγμιότυπο διάρκειας, όπως ακριβώς και η τιμή στο total_price.
    duration = db.Column(db.Integer, default=30, nullable=False)
    # ΠΟΙΟ ΚΑΤΟΙΚΙΔΙΟ ΠΑΙΡΝΕΙ ΑΥΤΗ ΤΗ ΥΠΗΡΕΣΙΑ. ΚΕΝΟ = ΟΛΑ ΤΑ ΚΑΤΟΙΚΙΔΙΑ
    # ΤΟΥ ΡΑΝΤΕΒΟΥ (η συνηθισμένη περίπτωση, και ό,τι ισχύει στα παλιά
    # ραντεβού). Πριν αυτή τη στήλη, η εφαρμογή ΗΞΕΡΕ ΠΟΙΑ ΚΑΤΟΙΚΙΔΙΑ ΕΙΧΑΝ
    # ΤΟ ΡΑΝΤΕΒΟΥ ΚΑΙ ΠΟΙΕΣ ΥΠΗΡΕΣΙΕΣ ΕΙΧΕ — ΑΛΛΑ ΟΧΙ ΠΟΙΟΣ ΤΙ: δεν
    # υπήρχε σύνδεση. Με δύο κατοικίδια ήταν αδύνατο να γραφτεί «ο ένας
    # πλυντρείται, η άλλη κουρεμένη».
    pet_id = db.Column(db.Integer, db.ForeignKey("pets.id", ondelete="SET NULL"),
                       nullable=True, index=True)

    appointment = db.relationship("Appointment", back_populates="service_links")
    service = db.relationship("Service", back_populates="service_links")
    pet = db.relationship("Pet", foreign_keys=[pet_id])


class Appointment(db.Model):
    __tablename__ = "appointments"

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(
        db.Integer, db.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True
    )
    pet_id = db.Column(db.Integer, db.ForeignKey("pets.id", ondelete="CASCADE"), nullable=False, index=True)
    groomer_id = db.Column(db.Integer, db.ForeignKey("groomers.id", ondelete="RESTRICT"), index=True)

    start_at = db.Column(db.DateTime, nullable=False, index=True)
    end_at = db.Column(db.DateTime, nullable=False)

    status = db.Column(db.String(20), default=STATUS_CONFIRMED, nullable=False, index=True)
    source = db.Column(db.String(20), default=SOURCE_PHONE, nullable=False)
    # Στιγμιότυπο των τιμών τη στιγμή του ραντεβού, ώστε μια αλλαγή
    # τιμοκαταλόγου να μην ξαναγράφει τα ιστορικά έσοδα.
    total_price = db.Column(db.Float, default=0.0, nullable=False)
    # Χειροκίνητη τελική τιμή (π.χ. έκπτωση καταστήματος). None = χωρίς έκπτωση.
    price_override = db.Column(db.Float)
    # Παραλαβή από άλλο άτομο. Κενά => παραλαμβάνει ο ίδιος ο πελάτης.
    pickup_name = db.Column(db.String(120))
    pickup_phone = db.Column(db.String(40))
    customer_note = db.Column(db.Text)
    staff_note = db.Column(db.Text)
    cancel_reason = db.Column(db.String(200))

    reminder_sent_at = db.Column(db.DateTime)
    confirmation_sent_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

    customer = db.relationship("Customer", back_populates="appointments")
    pet = db.relationship("Pet", back_populates="appointments")
    groomer = db.relationship("Groomer", back_populates="appointments")
    services = db.relationship(
        "Service", secondary="appointment_services", back_populates="appointments", viewonly=True
    )
    service_links = db.relationship(
        "AppointmentService",
        back_populates="appointment",
        cascade="all, delete-orphan",
        order_by="AppointmentService.service_id",
    )
    created_by = db.relationship("User", foreign_keys=[created_by_id])
    # Ένα ραντεβού μπορεί να αφορά περισσότερα από ένα κατοικίδιο.
    pets = db.relationship("Pet", secondary=appointment_pets, order_by="Pet.name", lazy="joined")

    @property
    def service_lines(self) -> list[dict]:
        """Υπηρεσίες με ποσότητα, μονάδια τιμή και άθροισμα ανά γραμμή."""
        lines = []
        for link in self.service_links:
            service = link.service
            unit = float(service.price or 0.0)
            quantity = max(1, int(link.quantity or 1))
            lines.append({
                "service": service,
                "quantity": quantity,
                "unit_price": unit,
                "total": round(unit * quantity, 2),
                "duration": int(link.duration or 0),
                # Ποιο κατοικίδιο παίρνει την υπηρεσία· None = όλα του
                # ραντεβού. Χωρίς αυτό, η σύνοψη μπορεί να τα δείξνει μόνο
                # συγκεντρωμένα — δηλαδή ακριβώς όπως ήταν πριν.
                "pet": link.pet,
            })
        return lines

    @property
    def service_pets(self) -> dict[int, int]:
        """{service_id: pet_id} — για προσυμπλήρωση της φόρμας επεξεργασίας."""
        return {
            link.service_id: link.pet_id
            for link in self.service_links
            if link.pet_id
        }

    @property
    def service_quantities(self) -> dict[int, int]:
        """{service_id: ποσότητα} — για προσυμπλήρωση της φόρμας επεξεργασίας."""
        return {
            link.service_id: max(1, int(link.quantity or 1))
            for link in self.service_links
        }

    @property
    def services_duration_total(self) -> int:
        """Συνολική εκτίμηση χρόνου υπηρεσιών — ενημερωτική, δεν κλείνει slots."""
        return sum(line["duration"] for line in self.service_lines)

    @property
    def services_by_pet(self) -> list[dict]:   # ιδιότητα, όπως το service_lines
        """Οι υπηρεσίες του ραντεβού, ομαδοποιημένες ανά κατοικίδιο.

        ΕΠΙΣΤΡΕΦΕΙ [{pet, links, unrecorded, all_pets}]:
          · pet       — το κατοικίδιο, ή None για τις υπηρεσίες που
                        αφορούν ΟΛΑ ΤΑ ΚΑΤΟΙΚΙΔΙΑ ΤΟΥ ΡΑΝΤΕΒΟΥ
          · links     — οι γραμμές υπηρεσιών εκείνου του κατοικιδίου
          · unrecorded— αληθινό μόνο για ΠΑΛΙΑ ραντεβού: πολλά κατοικίδια,
                        μία υπηρεσία, κανένα καταχωρισμένο κατοικίδιο. Είναι
                        η μοναδική περίπτωση που η αλήθεια δεν μπορεί να
                        εξαχθεί από τα δεδομένα — και λέμε ακριβώς ότι δεν
                        ξέρουμε, αντί να δείξουμε μια επιλογή που μπορεί να
                        είναι λάθος.
          · all_pets  — True αν υπάρχουν υπηρεσίες κοινές σε όλα
        """
        pets = list(self.pets)
        by_pet: dict = {}
        shared: list = []
        for line in self.service_lines:
            pet = line.get("pet")
            if pet is not None:
                by_pet.setdefault(pet.id, []).append(line)
            else:
                shared.append(line)
        out: list[dict] = []
        for pet in pets:
            out.append({"pet": pet, "links": by_pet.get(pet.id, []),
                        "unrecorded": False, "all_pets": False})
        if shared:
            # ΚΕΝΟ pet_id = όλα τα κατοικίδια. Με ένα κατοικίδιο δεν υπάρχει
            # αμφιβολία. Με ΠΟΛΛΑ και ποσότητα μικρότερη από τα κατοικίδια,
            # όμως, «μία φορά» δεν σημαίνει «όλα» — σημαίνει ότι κάποιο
            # κατοικίδιο δεν έχει καταχωριστεί, και δεν μπορούμε να μαντέψουμε
            # ποιο.
            ambiguous = len(pets) > 1 and any(
                (l["quantity"] or 1) < len(pets) for l in shared)
            out.append({"pet": None, "links": shared, "unrecorded": ambiguous,
                        "all_pets": not ambiguous})
        return out

    @property
    def pets_label(self) -> str:
        """Ονόματα κατοικιδίων για εμφάνιση· τα χωρίς όνομα μένουν «χωρίς όνομα»."""
        names = [(p.name or "").strip() for p in self.pets]
        if not names:
            return "—"
        return ", ".join(n if n else "χωρίς όνομα" for n in names)

    @property
    def date(self) -> date_cls:
        return self.start_at.date()

    @property
    def weekday_label(self) -> str:
        return WEEKDAYS[self.start_at.weekday()]

    @property
    def start_label(self) -> str:
        return self.start_at.strftime("%H:%M")

    @property
    def end_label(self) -> str:
        return self.end_at.strftime("%H:%M")

    @property
    def time_range(self) -> str:
        return f"{self.start_label} – {self.end_label}"

    @property
    def duration_minutes(self) -> int:
        return int((self.end_at - self.start_at).total_seconds() // 60)

    @property
    def duration_label(self) -> str:
        return minutes_to_label(self.duration_minutes)

    @property
    def price_effective(self) -> float:
        """Τελικό ποσό: η χειροκίνητη τιμή αν υπάρχει, αλλιώς το άθροισμα."""
        return float(self.price_override if self.price_override is not None else self.total_price)

    @property
    def price_label(self) -> str:
        return fmt_money(self.price_effective)

    @property
    def has_discount(self) -> bool:
        return self.price_override is not None and self.price_override < self.total_price

    @property
    def has_pickup_person(self) -> bool:
        """True όταν το κατοικίδιο το παραλαμβάνει κάποιος άλλος από τον πελάτη."""
        return bool((self.pickup_name or "").strip())

    @property
    def pickup_label(self) -> str:
        if not self.has_pickup_person:
            return ""
        if self.pickup_phone:
            return f"{self.pickup_name} · {self.pickup_phone}"
        return f"{self.pickup_name} · χωρίς τηλέφωνο"

    @property
    def discount_amount(self) -> float:
        return max(0.0, self.total_price - self.price_effective)

    @property
    def discount_label(self) -> str:
        return fmt_money(self.discount_amount)

    @property
    def status_label(self) -> str:
        return STATUS_LABELS.get(self.status, self.status)

    @property
    def source_label(self) -> str:
        return SOURCE_LABELS.get(self.source, self.source)

    @property
    def is_open(self) -> bool:
        return self.status in OPEN_STATUSES

    @property
    def is_upcoming(self) -> bool:
        return self.is_open and self.start_at >= datetime.now()

    @property
    def is_past(self) -> bool:
        return self.start_at < datetime.now()

    @property
    def services_label(self) -> str:
        """Ονόματα υπηρεσιών με ποσότητα, π.χ. «Μπάνιο ×2, Κόψιμο νυχιών»."""
        parts = []
        for line in self.service_lines:
            name = line["service"].name
            qty = line["quantity"]
            parts.append(f"{name} ×{qty}" if qty > 1 else name)
        return ", ".join(parts) or "—"

    def overlaps(self, start_at: datetime, end_at: datetime) -> bool:
        return self.start_at < end_at and start_at < self.end_at


# ---------------------------------------------------------------- ανάκτηση κωδικού
class PasswordResetToken(db.Model):
    """Σύνδεσμος επαναφοράς κωδικού — προσωρινός και μοναδικός.

    Αποθηκεύεται ΜΟΝΟ το hash του token, όχι το ίδιο το token. Μετά τη
    χρήση ή μετά τη λήξη μένει ανενεργό, ώστε ένας παλιός σύνδεσμος στο
    ιστορικό του email να μην ανοίγει την εφαρμογή.
    """

    __tablename__ = "password_reset_tokens"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"),
                        nullable=False, index=True)
    #: SHA-256 του token. Ο ίδιος ο κωδικός δεν αποθηκεύεται ποτέ.
    token_hash = db.Column(db.String(64), nullable=False, unique=True, index=True)
    expires_at = db.Column(db.DateTime, nullable=False)
    used_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    user = db.relationship("User", backref=db.backref("reset_tokens",
                                                       cascade="all, delete-orphan"))

    @property
    def is_usable(self) -> bool:
        return self.used_at is None and self.expires_at > datetime.now()


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey("appointments.id", ondelete="CASCADE"), index=True)
    kind = db.Column(db.String(30), nullable=False)
    channel = db.Column(db.String(20), default="log")
    recipient = db.Column(db.String(180))
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)
    sent = db.Column(db.Boolean, default=False, nullable=False)

    appointment = db.relationship("Appointment")


class ExpenseItem(db.Model):
    """Προκαθορισμένο έξοδο καταστήματος (ρεύμα, νερό, ενοικίαση…).

    Ο ιδιοκτήτρία τα διαχειρίζεται από τις Ρυθμίσεις και μετά τα επιλέγει
    γρήγορα στη σελίδα Εξόδων, χωρίς να γράφει κάθε φορά από την αρχή.
    """

    __tablename__ = "expense_items"

    id = db.Column(db.Integer, primary_key=True)
    label = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(60), default=EXPENSE_STORE, nullable=False)
    # Τυπικό ποσό, για να συμπληρώνεται μόνο του. Μηδενικό = χωρίς προτυπο.
    default_amount = db.Column(db.Float, default=0.0, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    sort_order = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    @property
    def has_default(self) -> bool:
        return float(self.default_amount or 0) > 0

    @property
    def default_label(self) -> str:
        return fmt_money(self.default_amount) if self.has_default else "—"

    def __repr__(self) -> str:  # pragma: no cover - βοηθητικό για debugging
        return f"<ExpenseItem {self.label} ({self.category})>"


class Expense(db.Model):
    """Έξοδα καταστήματος — υλικά και σταθερά λειτουργίας."""

    __tablename__ = "expenses"

    id = db.Column(db.Integer, primary_key=True)
    item = db.Column(db.String(160), nullable=False)
    category = db.Column(db.String(60), default=EXPENSE_GENERAL)
    amount = db.Column(db.Float, nullable=False, default=0.0)
    spent_on = db.Column(db.Date, nullable=False, index=True, default=date_cls.today)
    note = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    created_by = db.relationship("User", foreign_keys=[created_by_id])

    @property
    def amount_label(self) -> str:
        return fmt_money(self.amount)

    @property
    def category_label(self) -> str:
        return self.category or EXPENSE_GENERAL

    @property
    def is_store_expense(self) -> bool:
        """Έξοδο σταθερού καταστήματος (ρεύμα, νερό, ενοικίαση…)."""
        return (self.category or "") == EXPENSE_STORE

    def __repr__(self) -> str:  # pragma: no cover - βοηθητικό για debugging
        return f"<Expense {self.spent_on} {self.item} {self.amount}>"


def expenses_between(start: date_cls, end: date_cls) -> float:
    """Σύνολο εξόδων στο κλειστό διάστημα [start, end)."""
    total = db.session.query(func.coalesce(func.sum(Expense.amount), 0.0)).filter(
        Expense.spent_on >= start, Expense.spent_on < end
    ).scalar()
    return float(total or 0.0)


class SalonSettings(db.Model):
    __tablename__ = "salon_settings"

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(60), unique=True, nullable=False, index=True)
    value = db.Column(db.Text)

    DEFAULTS = {
        "name": "Niki's Grooming Salon",
        "tagline": "Κομμωτήριο σκύλων στο Παλαιό Φάληρο",
        "logo_path": "/static/img/site/logo-transparent.png",
        "phone": "210 985 0914",
        "email": "nikis.grooming@gmail.com",
        "address": "Τερψιθέας 14, Π. Φάληρο, Τ.Κ. 175 63",
        "instagram": "@nikisgroomingsalon",
        "facebook": "https://www.facebook.com/profile.php?id=100063285247809",
        "tiktok": "https://www.tiktok.com/@nikis.groomingsalon",
        # Βήμα διαθέσιμων ωρών σε λεπτά. 60 = ανά ώρα, από άνοιγμα ως κλείσιμο.
        "slot_minutes": "60",
        # Σλόγκαν του σπα. Η ιδιοκτήτρια το αλλάζει από τις Ρυθμίσεις.
        "slogan": (
            "Το να μπορείς να εκφράζεις τη δημιουργικότητά σου, "
            "παρέα με ότι αγαπάς.. Για μένα σημαίνει τα πάντα..!"
        ),
    }

    @classmethod
    def get(cls, key: str, default: str = "") -> str:
        row = cls.query.filter_by(key=key).first()
        if row and row.value is not None:
            return row.value
        return cls.DEFAULTS.get(key, default)

    @classmethod
    def set(cls, key: str, value: str) -> None:
        row = cls.query.filter_by(key=key).first()
        if row is None:
            row = cls(key=key)
            db.session.add(row)
        row.value = value

    @classmethod
    def as_dict(cls) -> dict:
        data = dict(cls.DEFAULTS)
        for row in cls.query.all():
            if row.value is not None:
                data[row.key] = row.value
        return data


# ------------------------------------------------------------------ φίλτρα Jinja
def fmt_date(value) -> str:
    if not value:
        return "—"
    if isinstance(value, datetime):
        value = value.date()
    return value.strftime("%d/%m/%Y")


def fmt_datetime(value) -> str:
    if not value:
        return "—"
    if isinstance(value, datetime):
        return value.strftime("%d/%m/%Y · %H:%M")
    return value.strftime("%d/%m/%Y")


def relative_days(value) -> str:
    if not value:
        return "—"
    days = (value.date() - date_cls.today()).days
    if days == 0:
        return "σήμερα"
    if days == 1:
        return "αύριο"
    if days == -1:
        return "χθες"
    if days == 2:
        return "σε δύο μέρες"
    if days == -2:
        return "πριν δύο μέρες"
    if days > 0:
        return f"σε {days} μέρες"
    return f"πριν {abs(days)} μέρες"
