"""
Εκκίνηση Niki's Grooming Salon Appointment Management.

Τρέχει με Waitress WSGI server — κατάλληλο για:
  · Windows IIS intranet (μέσω HttpPlatformHandler)
  · PyInstaller exe (standalone)

Χρήση:
  python server.py                    # http://0.0.0.0:5000
  python server.py --port 8080        # custom port
  python server.py --host 127.0.0.1   # localhost only
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


# ---------------------------------------------------------------------------
# ΦΟΡΤΩΣΗ ΤΗΣ ΕΝΕΡΓΗΣ ΕΚΔΟΣΗΣ
#
# Οι ενημερώσεις δεν γράφουν πάνω σε αυτό το αρχείο. Κάθε ενημέρωση μπαίνει
# σε δικό της φάκελο (instance/releases/...) και το instance/current.txt
# δείχνει ποια τρέχει. Έτσι η επιστροφή σε προηγούμενη έκδοση είναι αλλαγή
# ενός αρχείου, όχι επανεγκατάσταση.
#
# Το αρχείο αυτό μένει μικρό και σταθερό επίτηδες: το web.config των IIS και
# τα Windows Services έχουν τη διαδρομή του, άρα δεν αλλάζει ποτέ.
# ---------------------------------------------------------------------------
def _active_release_dir() -> Path:
    """Φάκελος της ενεργής έκδοσης (ή η ρίζα, στην πρώτη εγκατάσταση)."""
    try:
        current = (ROOT / "instance" / "current.txt").read_text(
            encoding="utf-8").strip()
    except OSError:
        return ROOT
    if not current or current == "." or current.startswith("/") or ".." in current:
        return ROOT
    # Οι ενημερώσεις ζουν μέσα στο instance/, οπότε η διαδρομή στο
    # current.txt μετράται από εκεί και όχι από τη ρίζα του project.
    candidate = (ROOT / "instance" / current).resolve()
    return candidate if candidate.is_dir() else ROOT


RELEASE = _active_release_dir()
# Η ενεργή έκδοση μπαίνει πρώτη, ώστε να έχει προτεραιότητα από τη ρίζα.
sys.path.insert(0, str(RELEASE))
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from app import create_app, force_utf8_stdio
from app.extensions import db
from app.models import Groomer, User, ROLE_OWNER

# Νωρίς, γιατί τα print() παρακάτω περιέχουν ελληνικά και στα Windows
# η κονσόλα χρησιμοποιεί cp1252 -> UnicodeEncodeError.
force_utf8_stdio()


def ensure_schema():
    """Δημιουργεί τους πίνακες και εφαρμόζει τις μετατροπές, αν χρειάζονται.

    Χρειάζεται για την έκδοση exe: ο χρήστης κάνει διπλό κλικ στο πρόγραμμα
    χωρίς να έχει τρέξει ποτέ `python server.py --init-db`. Χωρίς αυτό το βήμα
    η εφαρμογή έπεφτε με «no such table: users».

    Είναι ασφαλής να εκτελείται σε κάθε εκκίνηση: το create_all() δεν
    αγγίζει υπάρχοντες πίνακες, και οι μετατροπές είναι idempotent.
    """
    app = create_app()
    with app.app_context():
        db.create_all()
        try:
            import migrate

            migrate.add_username_column()
            migrate.add_pricing_columns()
            migrate.add_customer_archive_column()
        except Exception as exc:  # ποτέ να μην κρυφτεί ένα πρόβλημα σχήματος
            print(f"  Προσοχή: οι μετατροπές βάσης δεν ολοκληρώθηκαν ({exc}).")

        # Ώρες λειτουργίας: χωρίς αυτές μια καθαρή εγκατάσταση ξεκινά χωρίς
        # πότες ανοίγει το σπα και ο νέος λογαριασμός δεν έχει διαθεσιμότητα.
        try:
            import migrate as _migrate

            days = _migrate.seed_salon_hours()
            if days:
                print(f"  Δημιουργήθηκαν οι ώρες λειτουργίας του Salon ({days} ημέρες).")
        except Exception as exc:
            print(f"  Προσοχή: οι ώρες λειτουργίας δεν δημιουργήθηκαν ({exc}).")

        # Σε καθαρή εγκατάσταση (exe) δεν υπάρχει τίποτα να κλείσει ο πελάτης
        # χωρίς κατάλογο υπηρεσιών· τον δημιουργούμε. Χωρίς επιδειγματικά δεδομένα.
        try:
            from seed import seed_services

            created = seed_services()
            if created:
                print(f"  Δημιουργήθηκε ο κατάλογος υπηρεσιών ({created}).")
        except Exception as exc:
            print(f"  Προσοχή: ο κατάλογος υπηρεσιών δεν δημιουργήθηκε ({exc}).")

        # ΤΟ ΙΔΙΟ ΚΑΙ ΓΙΑ ΤΑ ΕΞΟΔΑ ΚΑΤΑΣΤΗΜΑΤΟΣ. Αυτά τα προκαθορισμένα
        # είδη (ρεύμα, νερό, ενοίκιο, καθαριστικά…) μπαίνουν ΜΟΝΟ από το
        # migrate.py. Το migrate τρέχει μια φορά, με το χέρι — άρα σε
        # καθαρή εγκατάσμα (exe) το «Προτυπικά έξοδα» ήταν ΚΕΝΟ, και η
        # ιδιοκτήτρια έβλεπε «μην υπάρχουν στοιχεία» σε μια λίστα που
        # ποτέ δεν γεμίστηκε. Το ίδιο συμβαίνει και σε υπάρχουσα
        # εγκατάσταση που της προστέθηκαν νέα είδη μετά την εγκατάσταση:
        # το seed «αν υπάρχει ένα, μην κάνεις τίποτα» δεν τα έβαζε ποτέ.
        # Ο backfill γράφει ΜΟΝΟ όσα λείπουν· τα δικά της δεδομένα
        # δεν αγγίζονται.
        try:
            _migrate.seed_store_expenses()
            added = _migrate.backfill_store_expenses()
            if added:
                print(f"  Προστέθηκαν {added} προκαθορισμένα έξοδα καταστήματος.")
        except Exception as exc:
            print(f"  Προσοχή: τα προκαθορισμένα έξοδα δεν δημιουργήθηκαν ({exc}).")
    return app


def report_missing_owner(app) -> bool:
    """Ελέγχει αν υπάρχει ιδιοκτήτρια. Επιστρέφει True αν ΔΕΝ υπάρχει.

    ΔΕΝ δημιουργούμε αυτόματα προεπιλεγμένο χρήστη (π.χ. «salon1234»): ένας
    τέτοιος κωδικός είναι γνωστός σε όλους, οπότε μια εγκατάσταση δεν πρέπει
    να ξεκινά με αυτόν. Ο λογαριασμός δημιουργείται από τη σελίδα /setup.
    """
    with app.app_context():
        from app.models import ROLE_OWNER, User

        try:
            owner = User.query.filter_by(role=ROLE_OWNER).first()
        except Exception:
            # Χωρίς πίνακες δεν μπορούμε να κρίνουμε τίποτα — δεν μπλοκάρουμε την εκκίνηση.
            return False
        if owner is not None:
            return False

    print("=" * 62)
    print("  Δεν υπάρχει λογαριασμός ιδιοκτήτριας.")
    print("  Κανείς δεν μπορεί να συνδεθεί μέχρι να δημιουργηθεί.")
    print("  Θα ανοίξει ο browser στη σελίδα πρώτης εγκατάστασης (/setup).")
    print("=" * 62)
    return True


def open_setup_page_in_browser(app, port: int = 5000) -> None:
    """Στο .exe ανοίγει τον browser στη σελίδα πρώτης εγκατάστασης.

    Το .exe γίνεται --windowed (χωρίς κονσόλα), οπότε ο χρήστης δεν μπορεί να
    δει τον κωδικό εγκατάστασης. Του τον δίνουμε έτοιμο στη διεύθυνση, ώστε
    να μην χρειάζεται να τον πληκτρολογήσει.
    """
    import webbrowser

    from app.blueprints.setup import ensure_token, owner_exists

    with app.app_context():
        # Δική άμυνα: αν έχει ήδη δημιουργηθεί ιδιοκτήτρια, δεν ανοίγουμε τίποτα.
        if owner_exists():
            return
        token = ensure_token()

    url = f"http://127.0.0.1:{port}/setup/?token={token}"
    print(f"  Άνοιξε στον browser για την πρώτη εγκατάσταση: {url}")
    try:
        webbrowser.open(url, new=2)
    except Exception:
        # Αν δεν ανοίξει ο browser, μπαίνει χειροκίνητα στο /setup — ο κωδικός
        # υπάρχει στο instance/setup_token.txt.
        pass




def main():
    parser = argparse.ArgumentParser(description="Niki's Grooming Salon Appointment Management")
    parser.add_argument("--host", default="0.0.0.0", help="Host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=5000, help="Port (default: 5000)")
    parser.add_argument("--init-db", action="store_true", help="Δημιουργεί τους πίνακες")
    parser.add_argument("--seed", action="store_true", help="Εισάγει επιδειγματικά δεδομένα")
    args = parser.parse_args()

    if args.init_db:
        with create_app().app_context():
            db.create_all()
            print("Οι πίνακες δημιουργήθηκαν.")
        return

    # Η εκκίνηση πρέπει να είναι ασφαλής και σε καθαρή εγκατάσταση (exe).
    app = ensure_schema()

    if args.seed:
        from seed import seed_all
        with app.app_context():
            seed_all(force=True)
            print("Τα επιδειγματικά δεδομένα εισήχθησαν.")
        return

    if report_missing_owner(app):
        open_setup_page_in_browser(app, args.port)

    from app.version import APP_VERSION
    from app.updates import active_release, background_check

    print(f"  Niki's Grooming Salon Appointment Management")
    print(f"  http://{args.host}:{args.port}")
    print(f"  Έκδοση {APP_VERSION}  ({active_release()})")
    print("  Πάτητα Ctrl+C για έξοδο")
    print()

    # Περιοδικός έλεγχος για ενημέρωση. Ποτέ δεν εγκαθιστά μόνος του — μόνο
    # ενημερώνει την ιδιοκτήτρια ότι υπάρχει. Το νήμα είναι daemon, οπότε
    # δεν κρατά τη διεργασία ζωντανή.
    try:
        background_check(app, int(app.config.get("UPDATE_CHECK_HOURS", 0)))
    except Exception as exc:
        print(f"  (Ο έλεγχος ενημερώσεων δεν ξεκίνησε: {exc})")

    from waitress import serve
    serve(app, host=args.host, port=args.port, threads=4)


if __name__ == "__main__":
    main()
