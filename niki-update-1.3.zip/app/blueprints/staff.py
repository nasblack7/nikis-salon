"""Εφαρμογή προσωπικού: dashboard, ημερολόγιο, πελάτες, κατοικίδια — Niki's Grooming Salon."""

from __future__ import annotations

from collections import defaultdict
from datetime import date as date_cls, datetime, time, timedelta

from flask import (Blueprint, current_app, flash, redirect, render_template,
                   request, send_file, url_for)
from flask_login import current_user
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import joinedload

from ..availability import (
    REASON_LABELS,
    auto_assign_groomer,
    combine,
    first_conflict,
    slot_taken,
    parse_hhmm,
    salon_hours_for,
    slot_step,
    next_free_slots,
    slots_for_date,
)
from ..extensions import db
from ..helpers import (
    MIN_SEARCH_CHARS,
    active_services,
    clean,
    form_bool,
    form_float,
    form_int,
    get_or_404,
    is_searchable,
    matches,
    admin_required,
    parse_date,
    plural,
    pet_ids_from_form,
    pricing_for,
    service_ids_from_form,
    service_pets_from_form,
    service_quantities_from_form,
    staff_required,
)
from ..importexport import (HEADERS, TEMPLATE_COLUMNS,
                            export_customers, import_customers,
                            template_bytes)
from ..version import APP_VERSION
from ..models import (
    EXPENSE_CATEGORIES,
    EXPENSE_GENERAL,
    EXPENSE_STORE,
    OPEN_STATUSES,
    SOURCE_LABELS,
    SOURCE_PHONE,
    SPECIES,
    GENDERS,
    STATUS_CANCELLED,
    STATUS_COMPLETED,
    STATUS_CONFIRMED,
    STATUS_IN_PROGRESS,
    STATUS_NO_SHOW,
    STATUS_PENDING,
    WEEKDAYS,
    Appointment,
    AppointmentService,
    AvailabilityRule,
    Customer,
    Expense,
    ExpenseItem,
    Groomer,
    Notification,
    Pet,
    Service,
    TimeOff,
    User,
    expenses_between,
    fmt_money,
)
from ..reminders import (KIND_REMINDER, appointments_between,
                           due_reminders, send, upcoming_for_day)

bp = Blueprint("staff", __name__, url_prefix="/staff")


@bp.before_request
@staff_required
def require_staff():
    return None


def promote_started_appointments(now=None) -> int:
    """«Επιβεβαιωμένο» που ξεκίνησε τώρα → «Σε εκτέλεση». ΜΟΝΑ του.

    ΖΗΤΗΘΗΚΕ ΑΠΟ ΤΗΝ ΙΔΙΟΚΤΗΤΡΙΑ: μόλις έφτανε η ώρα του ραντεβού να
    γίνεται μόνο του «σε εκτέλεση», και μετά εκείνη να το περνάει μόνη σε
    ολοκληρώθηκε / δεν προήλθε / ακυρώθηκε.

    ΤΙ ΔΕΝ ΓΙΝΕΤΑΙ, ΚΑΙ ΓΙΑΤΙ:
    · ΜΟΝΟ «επιβεβαιωμένο» → «σε εκτέλεση». Αν η ίδια άφησε ένα σε
      «αναμονή», το σεβόμαστε — μπορεί να το ήθελε για αργότερα. Ένα
      αυτόματο σύστημα που παραβλέπει τις επιλογές της ιδιοκτήτριας
      χάνει το νόημά του.
    · ΠΟΤΕ «ολοκληρώθηκε» αυτόματα. Το τελείωσε η ίδια — αλλιώς ένα
      ραντεβού που ακυρώθηκε τηλεφωνικά θα μετρούνε σαν εσόδου.
    · ΤΙΠΟΤΑ ΣΤΟ ΠΑΡΕΛΘΟΝ. Η συνθήκη έχει άνω και κάτω όριο στη ΣΗΜΕΡΑ, άρα
      ένα ραντεβού της 15:00 δεν «ξεκινά» το βράδυ. Η ιδιοκτήτρια θα
      έβλεπε χθες και σήμερα «σε εκτέλεση» ταυτόχρονα.

    ΕΙΣΟΔΟ: ΤΑ ΜΕΤΡΑΕΙ ΜΟΝΟ ΤΟ «ΟΛΟΚΛΗΡΩΘΗΚΕ», ΆΡΑ Η ΑΛΛΑΓΗ ΕΙΝΑΙ
    ΟΥΔΕΤΕΡΗ ΣΤΑ ΝΟΜΙΣΜΑΤΑ. Το «επιβεβαιωμένο» και το «σε εκτέλεση» δεν
    μετρούν κανένα από τα δύο — το άλλαξα επειδή το ενδεχόμενο «μείωσε το
    έσοδα της ημέρας μόλις άρχισε το ραντεβού» θα ήταν απώλεια εμπιστοσύνης
    στους αριθμούς, όχι χαρακτηριστικό.
    """
    now = now or datetime.now()
    started = (
        db.session.query(Appointment)
        .filter(
            Appointment.status == STATUS_CONFIRMED,
            Appointment.start_at <= now,
            Appointment.end_at > now,
        )
        .all()
    )
    if not started:
        return 0
    for appt in started:
        appt.status = STATUS_IN_PROGRESS
    db.session.commit()
    return len(started)


@bp.before_request
def advance_started_status():
    """Τρέχει σε ΚΑΘΕ σελίδα του staff, ώστε η αλλαγή να μένει πάντα
    σωστή — και όχι μόνο όταν πατηθεί «αποθήκευση».

    Το κόστος είναι μία ερώτημα με δείκτες (status και start_at είναι
    στη στήλη), και το commit γίνεται ΜΟΝΟ όταν πράγματι άλλαξε κάτι — τις
    περισσότερες φορές είναι απλώς ένα «δεν βρήκα τίποτα».

    ΜΕ ΤΟ ΖΩΝΤΑΝΟ ΗΜΕΡΟΛΟΓΙΟ ΔΟΥΛΕΥΕΙ ΜΟΝΟ ΤΟΥ: η αλλαγή αλλάζει το
    updated_at, άρα αλλάζει και το token του /api/calendar-version, και η
    σελίδα ανανεώνεται μόνη της. Χωρίς νέο μηχανισμό.
    """
    try:
        promote_started_appointments()
    except SQLAlchemyError:
        # Μια αποτυχία εδώ ΔΕΝ πρέπει να ρίξει 500 σε ολόκληρη τη σελίδα
        # του σαλονιού. Η ιδιοκτήτρία χρειάζεται το ημερολόγιο, όχι αυτή
        # την αυτοματοποίηση — και το rollback αφήνει τα δεδομένα όπως
        # ήταν, χωρίς μισή αλλαγή.
        db.session.rollback()
    return None


# ------------------------------------------------------------------ helpers
MONTH_NAMES = ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος",
               "Μάιος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος",
               "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"]


def _day_counts(first_day: date_cls, last_day: date_cls) -> dict:
    """{ημερομηνία: πλήθος ραντεβού} για ένα κλειστό διάστημα.

    ΜΙΑ ΕΡΩΤΗΣΗ ΓΙΑ ΟΛΟ ΤΟ ΔΙΑΣΤΗΜΑ. Το εναλλακτικό — μία ερώτηση ανά ημέρα —
    για τον μηνιαίο ημερολόγιο είναι 42 και για τον ετήσιο 372. Σε σκληρό
    δίσκο αυτό ένιωθε ως «το πρόγραμμα κολλάει».
    """
    counts: dict = defaultdict(int)
    for appt in appointments_between(first_day, last_day):
        counts[appt.start_at.date()] += 1
    return counts


def _year_month_counts(year: int) -> list[dict]:
    """[{month, name, count, past}] για τους 12 μήνες του χρόνου."""
    per_day = _day_counts(date_cls(year, 1, 1), date_cls(year, 12, 31))
    out = []
    for m in range(1, 13):
        count = sum(n for d, n in per_day.items()
                    if d.year == year and d.month == m)
        out.append({"month": m, "name": MONTH_NAMES[m - 1], "count": count,
                    "past": year < date_cls.today().year
                    or (year == date_cls.today().year
                        and m < date_cls.today().month)})
    return out


def _view_date() -> date_cls:
    return parse_date(request.args.get("date"), date_cls.today()) or date_cls.today()


def _final_price(subtotal: float) -> float | None:
    """Η τελική τιμή μετά την έκπτωση του καταστήματος.

    Επιστρέφει None όταν δεν υπάρχει έκπτωση, ώστε το price_override να
    παραμένει κενό και το άθροισμα των υπηρεσιών να είναι το τελικό ποσό.
    """
    discount = form_float("discount", 0.0)
    if discount <= 0:
        return None
    # Δεν επιτρέπεται αρνητικό τελικό ποσό ούτε έκπτωση μεγαλύτερη από το άθροισμα.
    return max(0.0, round(subtotal - discount, 2))


def _source_from_form() -> str:
    """Η πηγή του ραντεβού, μόνο αν είναι μία από τις γνωστές.

    ΠΡΙΝ ΑΥΤΟ Η ΠΗΓΗ ΔΕΝ ΕΛΕΓΧΟΤΑΝ: οποιοσδήποτε κείμενο έμπαινε στη βάση και
    εμφανιζόταν ακριβώς όπως ήταν στην κάρτα του ραντεβού. Το dropdown προσφέρει
    μόνο τρεις τιμές, αλλά το form στέλνεται από τον browser και μπορεί να
    περιέχει οτιδήποτε. Άγνωστη τιμή => προεπιλογή (τηλεφωνικά), όχι σφάλμα:
    η ιδιοκτήτρια δεν πρέπει να μένει χωρίς ραντεβού επειδή πέταξε ένα
    ασύνημο πεδίο στη φόρμα.
    """
    value = clean(request.form.get("source"))
    return value if value in SOURCE_LABELS else SOURCE_PHONE


def _pickup_details() -> tuple[str | None, str | None]:
    """(όνομα, τηλέφωνο) του ατόμου που παραλαμβάνει το κατοικίδιο.

    Κενά => παραλαμβάνει ο ίδιος ο πελάτης. Αν υπάρχει όνομα αλλά όχι
    τηλέφωνο, επιστρέφεται (όνομα, None) και ο χρήστης ενημερώνεται —
    δεν μπλοκάρουμε το ραντεβού, αλλά το τονίζουμε.
    """
    name = clean(request.form.get("pickup_name"))
    phone = clean(request.form.get("pickup_phone"))
    if not name:
        # Όνομα χωρίς άτομο δεν σημαίνει τίποτα — καθαρίζουμε και το τηλέφωνο.
        return None, None
    return name[:120], (phone[:40] or None)


def _warn_missing_pickup_phone(name: str | None, phone: str | None) -> None:
    """Υπενθύμιση (όχι σφάλμα) αν το άτομο παραλαβής δεν έχει τηλέφωνο.

    Δεν μπλοκάρουμε το ραντεβού — απλώς τονίζουμε ότι το σπα χρειάζεται
    ένα νούμερρο για να επικοινωνήσει αν κάτι πάει στραβά.
    """
    if name and not phone:
        flash(
            f"Προσοχή: ο «{name}» έχει οριστεί για την παραλαβή χωρίς τηλέφωνο.",
            "warning",
        )


MONTH_LABELS = ["Ιαν", "Φεβ", "Μαρ", "Απρ", "Μαΐ", "Ιουν", "Ιουλ", "Αυγ", "Σεπ", "Οκτ", "Νοέ", "Δεκ"]


def _month_name(day: date_cls) -> str:
    return MONTH_LABELS[day.month - 1]


def _groomers() -> list[Groomer]:
    return db.session.query(Groomer).join(Groomer.user).order_by(Groomer.sort_order, Groomer.id).all()


def default_groomer_id(groomers: list[Groomer]) -> int | None:
    """Ποια στυλίστρια προτείνεται στη φόρμα ραντεβού.

    Η πρώτη στη σειρά (sort_order) είναι η κύρια του Salon, οπότε επιλέγεται
    αυτόματα· αν χρειαστεί άλλη, την αλλάζει η ιδιοκτήτρια.

    Εξαίρεση: αν η πρώτη δεν έχει καθόλου διαθεσιμότητα δεν προτείνεται — η
    φόρμα θα έδειχνε μηδέν διαθέσιμες ώρες. Τότε μένει η «Αυτόματη επιλογή».
    """
    bookable = [g for g in groomers if g.is_bookable]
    if not bookable:
        return None
    if db.session.query(AvailabilityRule.id).filter_by(groomer_id=bookable[0].id).first():
        return bookable[0].id
    return None


# ----------------------------------------------------------------- dashboard
#: Πόσες μέρες μπροστά βλέπει η κάρτα «Επόμενα ραντεβού». Μία εβδομάδα
#: αρκεί για να δει η ιδιοκτήτρια τι έρχεται, χωρίς να γεμίσει η κάρτα με
#: ραντεβού από μήνες που έχουν ήδη κλειστεί.
NEXT_UP_DAYS = 7


@bp.route("/")
def dashboard():
    today = date_cls.today()
    now = datetime.now()
    todays = upcoming_for_day(today)
    open_today = [a for a in todays if a.status in OPEN_STATUSES]

    week_start = today - timedelta(days=today.weekday())
    week_end = week_start + timedelta(days=6)
    week_appointments = (
        Appointment.query.filter(
            Appointment.start_at >= datetime.combine(week_start, time(0, 0)),
            Appointment.start_at < datetime.combine(week_end + timedelta(days=1), time(0, 0)),
        )
        .order_by(Appointment.start_at)
        .all()
    )

    # ΤΟ «ΕΠΟΜΕΝΑ ΡΑΝΤΕΒΟΥ» ΔΕΝ ΠΡΕΠΕΙ ΝΑ ΤΕΛΕΙΩΝΕΙ ΜΕ ΤΗ ΜΕΡΑ.
    #
    # ΤΟ ΠΡΟΒΛΗΜΑ ΠΟΥ ΑΝΑΦΕΡΕ Η ΙΔΙΟΚΤΗΤΡΙΑ: μόλις τελείωνε η μέρα, η κάρτα
    # έλεγε «Δεν υπάρχουν επερχόμενα» — ενώ υπήρχε ραντεβού ΑΥΡΙΟ ΤΟ ΠΡΩΙ.
    #
    # Η ΑΙΤΙΑ ΗΤΑΝ ΜΙΑ ΛΕΞΗ: η λίστα έπαιρνε ΜΟΝΟ τη σημερινή μέρα
    # (`upcoming_for_day(today)`). Ό,τι και αν έγινε, η λίστα δεν μπορούσε να
    # δει ποτέ αύριο. Δεν ήταν «κανένα επερχόμενο»· ήταν «κανένα σήμερα».
    #
    # ΤΟ ΔΙΟΡΘΩΝΟΥΜΕ ΣΤΗΝ ΠΗΓΗ: ρωτάμε τις ΕΠΟΜΕΝΕΣ ΕΝΕΡΓΕΣ ΡΑΝΤΕΒΟΥ σε
    # όλο το μέλλον, με σειρά χρονική. Έτσι το αύριο το πρωί εμφανίζεται
    # μόνο του του — και η κάρτα κάνει αυτό που λέει το όνομά της.
    #
    # Το ΟΡΙΖΟΝΤΑΣ ΠΑΡΑΜΕΝΕΙ ΜΙΑ ΕΒΔΟΜΑΔΑ. Χωρίς όριο, ένα ραντεβού σε δύο
    # χρόνια θα γέμιζε την κάρτα και θα έκρυβε το αύριο που είναι το
    # πραγματικά χρήσιμο.
    next_up = (
        Appointment.query.filter(
            Appointment.status.in_(OPEN_STATUSES),
            Appointment.start_at >= now,
            Appointment.start_at < now + timedelta(days=NEXT_UP_DAYS),
        )
        .order_by(Appointment.start_at)
        .limit(6)
        .all()
    )
    pending_reminders = due_reminders()
    # due_for_grooming removed (Επείγον badge removed)
    due_pets = []

    month_start = today.replace(day=1)
    month_count = Appointment.query.filter(
        Appointment.status == STATUS_COMPLETED,
        Appointment.start_at >= datetime.combine(month_start, time(0, 0)),
    ).count()

    no_shows = Appointment.query.filter(
        Appointment.status == STATUS_NO_SHOW,
        Appointment.start_at >= datetime.combine(month_start, time(0, 0)),
    ).count()

    # Οικονομικά: τα έξοδα τα βλέπουν όλοι (τα καταχωρούν), τα έσοδα και το
    # καθαρό εισόδημα μόνο η ιδιοκτήτρια.
    month_end = (month_start + timedelta(days=32)).replace(day=1)
    today_expenses = expenses_between(today, today + timedelta(days=1))
    month_expenses = expenses_between(month_start, month_end)

    month_revenue = month_net = 0.0
    if current_user.is_admin:
        month_completed = Appointment.query.filter(
            Appointment.status == STATUS_COMPLETED,
            Appointment.start_at >= datetime.combine(month_start, time(0, 0)),
        ).all()
        month_revenue = sum(a.price_effective for a in month_completed)
        month_net = month_revenue - month_expenses

    week_bars = []
    peak = max(
        (len([a for a in week_appointments if a.start_at.date() == week_start + timedelta(days=i)])
         for i in range(7)),
        default=0,
    ) or 1
    for i in range(7):
        day = week_start + timedelta(days=i)
        items = [a for a in week_appointments if a.start_at.date() == day]
        week_bars.append(
            {
                "date": day,
                "iso": day.isoformat(),
                "label": day.strftime("%a %d/%m"),
                "count": len(items),
                "pct": round(len(items) / peak * 100),
                "is_today": day == today,
            }
        )

    return render_template(
        "staff/dashboard.html",
        today=today,
        todays=todays,
        open_today=open_today,
        next_up=next_up,
        week_appointments=week_appointments,
        week_bars=week_bars,
        week_start=week_start,
        week_end=week_end,
        month_count=month_count,
        no_shows=no_shows,
        pending_reminders=pending_reminders,
        due_pets=due_pets,
        today_expenses=today_expenses,
        month_expenses=month_expenses,
        month_revenue=month_revenue,
        month_net=month_net,
    )


# ----------------------------------------------------------------- calendar
@bp.route("/calendar")
def calendar():
    view = request.args.get("view", "day")
    day = _view_date()

    groomers = _groomers()
    if not groomers:
        # Χωρίς στυλίστρια δεν υπάρχει ποιος να εμφανιστεί, αλλά η γραμμή
        # εργαλείων (prev/next/«Σήμερα») χρειάζεται τις ίδιες μεταβλητές με την
        # κανονική διαδρομή — αλλιώς η σελίδα σπάει με σφάλμα 500.
        return render_template(
            "staff/calendar.html",
            view=view,
            day=day,
            today=date_cls.today(),
            is_today=True,
            groomers=[],
            columns=[],
            hours=[],
            total_slots=1,
            prev_day=day - timedelta(days=1),
            next_day=day + timedelta(days=1),
            empty=True,
        )

    # ΟΙ ΤΕΣΣΕΡΙΣ ΠΕΡΙΟΔΟΙ. Οι δύο νέες (μήνας, χρόνος) είναι ΣΥΝΟΨΕΙΣ: λένε
    # πόσα ραντεβού έχει κάθε μέρα/μήνα, όχι ποια. Η ιδιοκτήτρια θέλει να
    # δει «πόσο γεμάτο είναι το Νίκη Salon» χωρίς να πατά 12 φορές το ←.
    if view == "year":
        year = day.year
        months = _year_month_counts(year)
        total = sum(m["count"] for m in months)
        return render_template(
            "staff/calendar_year.html",
            view=view, day=day, year=year, months=months, total=total,
            prev_year=(day.replace(year=year - 1)).isoformat(),
            next_year=(day.replace(year=year + 1)).isoformat(),
        )

    if view == "month":
        first = day.replace(day=1)
        # Ξεκινάμε τη ΔΕΥΤΕΡΑ πριν την 1η, ώστε οι εβδομάδες της μηνιαίας
        # λωρίδας να είναι επτά ημέρες. Μια μήνα που ξεκινά Κυριακή θα έπρεπε
        # να έχει μια ανύπαρκτη Κυριακή μπροστά — που θα έδειχνε έναν «μήνα»
        # 31 ημερών με κενή πρώτη στήλη.
        grid_start = first - timedelta(days=first.weekday())
        grid_end = grid_start + timedelta(days=41)      # 6 εβδομάδες
        per_day = _day_counts(grid_start, grid_end)
        weeks = []
        cursor = grid_start
        while cursor <= grid_end:
            week = []
            for i in range(7):
                d = cursor + timedelta(days=i)
                week.append({
                    "date": d,
                    "in_month": d.month == day.month,
                    "is_today": d == date_cls.today(),
                    "count": per_day.get(d, 0),
                })
            weeks.append(week)
            cursor += timedelta(days=7)
        nxt = (first + timedelta(days=32)).replace(day=1)
        prv = (first - timedelta(days=1))
        return render_template(
            "staff/calendar_month.html",
            view=view, day=day, weeks=weeks, today=date_cls.today(),
            MONTHS=MONTH_NAMES,
            total=sum(per_day.get(d, 0) for d in per_day
                      if d.month == day.month and d.year == day.year),
            prev_month=prv.isoformat(), next_month=nxt.isoformat(),
        )

    if view == "week":
        days = [day - timedelta(days=day.weekday()) + timedelta(days=i) for i in range(7)]
        by_day = defaultdict(list)
        for d in days:
            by_day[d] = upcoming_for_day(d)
        grid = []
        for d in days:
            grid.append(
                {
                    "date": d,
                    "is_today": d == date_cls.today(),
                    "weekday": WEEKDAYS[d.weekday()],
                    "appointments": sorted(by_day[d], key=lambda a: a.start_at),
                }
            )
        return render_template(
            "staff/calendar_week.html",
            view=view,
            day=day,
            days=grid,
            groomers=groomers,
            total=sum(len(g["appointments"]) for g in grid),
            prev_week=(days[0] - timedelta(days=7)).isoformat(),
            next_week=(days[0] + timedelta(days=7)).isoformat(),
        )

    closed, salon_open, salon_close = salon_hours_for(day)
    step = slot_step()
    if closed:
        salon_open, salon_close = 9 * 60, 18 * 60

    appointments = upcoming_for_day(day)
    by_groomer = defaultdict(list)
    for appt in appointments:
        by_groomer[appt.groomer_id].append(appt)

    hours = []
    for m in range(salon_open, salon_close + step, step):
        hours.append({"minutes": m, "label": f"{m // 60:02d}:{m % 60:02d}", "hour": m % 60 == 0})

    # Η λωρίδα του ημερολογίου έχει μία γραμμή ανά slot και ύψος len(hours) * 30px.
    # Τα top/height των μπλοκ είναι ποσοστά επί του ύψους της λωρίδας, άρα ο
    # παρονομαστής είναι τα λεπτά που καλύπτει ολόκληρη η λωρίδα.
    lane_span = salon_close - salon_open + step

    def lane_pct(minutes: float) -> float:
        """Θέση σε λεπτά μέσα στη λωρίδα, ως ποσοστό του ύψους της."""
        return round(max(0.0, min(minutes, lane_span)) / lane_span * 100, 3)

    columns = []
    for groomer in groomers:
        items = sorted(by_groomer.get(groomer.id, []), key=lambda a: a.start_at)
        blocks = []
        for appt in items:
            start_min = appt.start_at.hour * 60 + appt.start_at.minute
            end_min = appt.end_at.hour * 60 + appt.end_at.minute
            top = lane_pct(start_min - salon_open)
            height = lane_pct(end_min - salon_open) - top
            blocks.append(
                {
                    "appointment": appt,
                    "top": top,
                    # ποτέ κάτω από 2.2% ώστε να φαίνεται πάντα ο τίτλος
                    "height": round(max(height, 2.2), 3),
                }
            )
        columns.append({"groomer": groomer, "blocks": blocks, "count": len(items)})

    prev_day = day - timedelta(days=1)
    next_day = day + timedelta(days=1)

    return render_template(
        "staff/calendar.html",
        view=view,
        day=day,
        today=date_cls.today(),
        now_parts=datetime.now(),
        is_today=day == date_cls.today(),
        salon_open=salon_open,
        salon_close=salon_close,
        salon_closed=closed,
        step=step,
        columns=columns,
        hours=hours,
        total_slots=max(1, len(hours)),
        lane_span=lane_span,
        prev_day=prev_day,
        next_day=next_day,
        empty=False,
        slot_labels=REASON_LABELS,
    )


@bp.route("/new-appointment", methods=["GET", "POST"])
def new_appointment():
    groomers = [g for g in _groomers() if g.is_bookable]
    # Ο ΑΡΧΕΙΟΘΕΤΗΜΕΝΟΣ ΔΕΝ ΠΡΟΣΦΕΡΕΤΑΙ ΓΙΑ ΝΕΟ ΡΑΝΤΕΒΟΥ. Υπάρχει μόνο για
    # το ιστορικό· αν επιστρέψει, θα τον βρει ξανά εδώ.
    customers = (
        db.session.query(Customer)
        .filter(Customer.is_active_flag.is_(True))
        .order_by(Customer.name).all()
    )
    services = active_services()

    if request.method == "POST":
        customer = db.session.get(Customer, form_int("customer_id"))
        if customer is None:
            flash("Επιλέξτε πελάτη.", "error")
            return redirect(url_for("staff.new_appointment"))

        # Ένας πελάτης μπορεί να φέρει περισσότερα από ένα κατοικίδια.
        pet_ids = pet_ids_from_form() or ([form_int("pet_id")] if form_int("pet_id") else [])
        pets = [p for p in (db.session.get(Pet, i) for i in pet_ids if i) if p is not None]
        if not pets:
            flash("Επιλέξτε τουλάχιστον ένα κατοικίδιο.", "error")
            return redirect(url_for("staff.new_appointment"))

        service_ids = service_ids_from_form()
        chosen = db.session.query(Service).filter(Service.id.in_(service_ids)).all() if service_ids else []
        if not chosen:
            flash("Επιλέξτε τουλάχιστον μία υπηρεσία.", "error")
            return redirect(request.referrer or url_for("staff.new_appointment"))

        # Στιγμιότυπο τιμής: κρατά τη λιανική τιμή, ακόμη κι αν αλλάξει ο τιμοκατάλογος.
        quantities = service_quantities_from_form()
        total_price, total_duration = pricing_for(
            chosen, quantities, service_pets_from_form())
        final_price = _final_price(total_price)
        # Η ώρα λήξης ακολουθεί το βήμα των slots, όχι τη διάρκεια των
        # υπηρεσιών: ένα slot είναι μία «μονάδα χρόνου» του σπα.
        slot_minutes = slot_step()
        pickup_name, pickup_phone = _pickup_details()

        day = parse_date(request.form.get("date"))
        start_min = parse_hhmm(request.form.get("time"))
        if day is None or start_min is None:
            flash("Συμπληρώστε ημερομηνία και ώρα.", "error")
            return redirect(request.referrer or url_for("staff.new_appointment"))

        start_at = combine(day, start_min)
        end_at = combine(day, start_min + slot_minutes)

        # Ο χρήστης επέλεξε συγκεκριμένη στυλίστρια; την τηρούμε. Πριν
        # γινόταν σιωπηρή ανάθεση σε άλλη όταν η επιλεγμένη ήταν απασχολημένη,
        # κι έτσι το ραντεβού έμπαινε σε λάθος άτομο χωρίς προειδοποίηση.
        # Η ιδιοκτήτρια επιβεβαίωσε στο modal ότι ΘΕΛΕΙ διπλό ραντεβού.
        # Χωρίς αυτή τη σημαία, το ραντεβού σε κατειλημμένη ώρα σταματά όπως
        # πάντα με μήνυμα — η μόνη διαφορά είναι ΠΟΤΕ το βλέπει.
        force_booking = str(request.form.get("force_booking", "")).strip() in {
            "1", "true", "on", "yes"}
        chosen_groomer_id = form_int("groomer_id")
        if chosen_groomer_id:
            # ΤΟ ΟΝΟΜΑ ΣΕ ΙΔΙΑ ΜΕΤΑΒΛΗΤΗ. Το παλιό `chosen = next(...)` έπεφτε
            # πάνω στη λίστα των ΥΠΗΡΕΣΙΩΝ (γραμμή 410). Δεν έβλαπτε μόνο
            # επειδή εκεί ακολουθούσε return — αλλά η προειδοποίηση για την
            # κάλυψη ώρας διαβάζει το `chosen` σε ΔΙΑΦΟΡΕΤΙΚΗ ΣΕΙΡΑ, όπου δεν
            # έχει σκιαστεί, και έδειχνε στην ιδιοκτήτρια «([<Service 1>],
            # 01/10 15:00)» αντί για όνομα. Πλέον οι δύο χρήσεις είναι
            # ξεχωριστές μεταβλητές και δεν μπορούν να συγκρούσουν.
            groomer_name = next(
                (g.name for g in groomers if g.id == chosen_groomer_id),
                "Η επιλεγμένη στυλίστρια",
            )
            conflict = first_conflict(start_at, end_at, chosen_groomer_id)
            if conflict:
                # Δείχνουμε τον ΠΡΑΓΜΑΤΙΚΟ ΛΟΓΟ. Το «είναι απασχολημένη»
                # ήταν ψευδίσμα για όλα τα υπόλοιπα: αν δεν εργάζεται εκείνη
                # τη μέρα ή η ώρα είναι εκτός ωραρίου, η ιδιοκτήτρια έψαγνε
                # λάθος πρόβλημα (να αλλάξει ώρα ενώ το πρόβλημα ήταν το
                # ωράριο).
                flash(f"{conflict} ({groomer_name}, {start_at:%d/%m %H:%M})",
                      "error")
                return redirect(request.referrer or url_for("staff.new_appointment"))
            # ΠΡΟΕΙΔΟΠΟΙΗΣΗ, ΟΧΙ ΜΠΛΟΚ. Δύο πελάτες στην ίδια ώρα είναι
            # πιθανόν (ή η ιδιοκτήτρια γράφει αναδρομικά από τη μνήμη της).
            # Πριν το μπλοκαρμε, χανόταν ΟΛΗ ΤΗΝ ΕΓΓΡΑΦΗ: η ιδιοκτήτρια
            # έβλεπε σφάλμα χωρίς να μάθει ποια ώρα, και το ραντεβού χανόταν.
            warn = slot_taken(start_at, end_at, chosen_groomer_id)
            if warn:
                flash(f"{warn} ({groomer_name}, {start_at:%d/%m %H:%M})",
                      "warning")
            groomer_id = chosen_groomer_id
        else:
            # «Αυτόματη επιλογή»: παίρνει όποια είναι ελεύθερη εκείνη την ώρα.
            groomer_id = auto_assign_groomer(start_at, end_at)
            if groomer_id is None:
                # ΚΑΝΕΝΑΣ ΔΙΑΘΕΣΙΜΟΣ — ΑΛΛΑ Η ΙΔΙΟΚΤΗΤΡΙΑ ΤΟ ΔΕΧΘΗΚΕ.
                # Χωρίς το force_booking, η παλιά συμπεριφορά: μήνυμα σφάλματος
                # και καμία εγγραφή. Με το force_booking, δίνουμε στην πρώτη
                # που μπορεί να δουλέψει — είναι η πρόθεσή της, και το modal
                # την ενημέρωσε ήδη.
                if not force_booking:
                    flash("Δεν βρέθηκε διαθέσιμη στυλίστρια για αυτή την ώρα.",
                          "error")
                    return redirect(request.referrer
                                    or url_for("staff.new_appointment"))
                groomer_id = next((g.id for g in groomers if g.is_bookable), None)
                if groomer_id is None:
                    flash("Δεν υπάρχει διαθέσιμη στυλίστρια για εγγραφή.", "error")
                    return redirect(request.referrer
                                    or url_for("staff.new_appointment"))
            # Η ΠΡΟΕΙΔΟΠΟΙΗΣΗ ΤΗΣ ΔΙΠΛΟΥ ΡΑΝΤΕΒΟΥ, ΟΧΙ ΜΟΝΟ ΣΤΗΝ ΕΠΙΛΕΓΜΕΝΗ
            # ΣΤΥΛΙΣΤΡΙΑ.
            #
            # ΒΡΗΚΑ ΤΟ ΚΕΝΟ ΤΟΥΤΟ ΣΤΟ ΤΕΣΤ: στην «αυτόματη επιλογή» η
            # προειδοποίηση ΔΕΝ ΕΜΦΑΝΙΖΟΤΑΝ ΠΟΤΕ. Ο `auto_assign_groomer` δεν
            # κοιτάζει αν απασχολημένη — μόνο αν δουλεύει εκείνη τη μέρα — και
            # το `slot_taken` καλούνταν ΜΟΝΟ στο κλάδο με επιλεγμένη στυλίστρια.
            # Άρα η ιδιοκτήτρια με «Αυτόματη επιλογή» έκανε διπλό ραντεβού
            # ΣΤΗ ΣΙΩΠΗ, χωρίς ποτέ να δει προειδοποίηση. Ένα ραντεβού που
            # «εμφανίζεται» χωρίς να το ζητήσει κανείς είναι το χειρότερο
            # είδος λάθους: η ιδιοκτήτρια δεν το ξέρει για να το διορθώσει.
            warn = slot_taken(start_at, end_at, groomer_id)
            if warn and not force_booking:
                flash(f"{warn} ({start_at:%d/%m %H:%M})", "warning")

        appointment = Appointment(
            customer_id=customer.id,
            pet_id=pets[0].id,          # παλιά στήλη: το πρώτο κατοικίδιο
            groomer_id=groomer_id,
            start_at=start_at,
            end_at=end_at,
            status=clean(request.form.get("status")) or STATUS_CONFIRMED,
            # Μόνο τιμές από το allowlist: αλλιώς οποιοσδήποτε κείμενο
            # αποθηκευόταν και εμφανιζόταν στην κάρτα του ραντεβού.
            source=_source_from_form(),
            total_price=total_price,
            price_override=final_price,
            pickup_name=pickup_name,
            pickup_phone=pickup_phone,
            customer_note=clean(request.form.get("note")) or None,
            staff_note=clean(request.form.get("staff_note")) or None,
            created_by_id=current_user.id,
        )
        appointment.pets = pets
        db.session.add(appointment)
        _set_service_links(appointment, chosen, quantities)
        db.session.commit()
        who = ", ".join((p.name or "χωρίς όνομα") for p in pets)
        flash(
            f"Επιβεβαιώθηκε ραντεβού για {who} στις {start_at:%d/%m %H:%M}.",
            "success",
        )
        _warn_missing_pickup_phone(pickup_name, pickup_phone)
        return redirect(url_for("staff.appointment_detail", appointment_id=appointment.id))

    selected_customer_id = request.args.get("customer", type=int)
    selected_pet_id = request.args.get("pet", type=int)
    preselected = db.session.get(Customer, selected_customer_id) if selected_customer_id else None
    initial_customer_json = (
        {
            "id": preselected.id,
            "pets": [
                {
                    "id": p.id,
                    "name": p.name,
                    "breed": p.breed or "",
                }
                for p in preselected.active_pets
            ],
        }
        if preselected
        else None
    )
    return render_template(
        "staff/appointment_form.html",
        groomers=groomers,
        default_groomer_id=default_groomer_id(groomers),
        customers=customers,
        services=services,
        today=date_cls.today(),
        selected_customer_id=selected_customer_id,
        selected_pet_id=selected_pet_id,
        preselected=preselected,
        initial_customer_json=initial_customer_json,
    )


# --------------------------------------------------------- appointment CRUD
@bp.route("/appointments/<int:appointment_id>")
def appointment_detail(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    # Ιστορικό του πελάτη (όχι ενός κατοικιδίου): το ραντεβού μπορεί να
    # αφορά περισσότερα από ένα κατοικίδιο ή κανένα με όνομα.
    all_appointments = sorted(appointment.customer.appointments, key=lambda a: a.start_at)
    index = next((i for i, a in enumerate(all_appointments) if a.id == appointment.id), None)
    history = all_appointments[max(0, index - 4): index + 1] if index is not None else []
    return render_template(
        "staff/appointment_detail.html",
        appointment=appointment,
        history=history,
    )


@bp.route("/appointments/<int:appointment_id>/edit", methods=["GET", "POST"])
def appointment_edit(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    services = active_services()
    groomers = _groomers()

    if request.method == "POST":
        chosen_ids = service_ids_from_form()
        chosen = db.session.query(Service).filter(Service.id.in_(chosen_ids)).all() if chosen_ids else []
        if not chosen:
            flash("Επιλέξτε τουλάχιστον μία υπηρεσία.", "error")
            return redirect(request.referrer or url_for("staff.appointment_edit", appointment_id=appointment.id))

        # Κάθε αποθήκευση ξανακρατά τις τιμές της στιγμής του ραντεβού.
        quantities = service_quantities_from_form()
        total_price, _total_duration = pricing_for(
            chosen, quantities, service_pets_from_form())
        final_price = _final_price(total_price)
        pickup_name, pickup_phone = _pickup_details()

        day = parse_date(request.form.get("date")) or appointment.start_at.date()
        start_min = parse_hhmm(request.form.get("time")) or appointment.start_at.hour * 60 + appointment.start_at.minute
        start_at = combine(day, start_min)
        end_at = combine(day, start_min + slot_step())
        groomer_id = form_int("groomer_id") or appointment.groomer_id

        conflict = first_conflict(start_at, end_at, groomer_id, exclude_appointment_id=appointment.id)
        if conflict:
            flash(f"Δεν είναι δυνατή η αλλαγή: {conflict}", "error")
            return redirect(request.referrer or url_for("staff.appointment_edit", appointment_id=appointment.id))

        # Η ΙΔΙΑ ΠΡΟΕΙΔΟΠΟΙΗΣΗ ΚΑΙ ΣΤΗΝ ΑΛΛΑΓΗ, ΑΛΛΑ ΕΔΩ. Μετακινώ το
        # ραντεβού επάνω σε ώρα που έχει ήδη κάτι: συμβαίνει, είτε από
        # λάθος επιλογή είτε επειδή έχει δύο πελάτες εκείνη την ώρα.
        # Πριν το μπλοκαρμε, η αλλαγή χανόταν ολόκληρη.
        #
        # ΕΔΩ ΚΑΙ ΟΧΙ ΜΕΣΑ ΣΤΟ `if conflict:`. Μέσα, ο κώδικας είναι
        # νεκρός (ακολουθεί return) και η μεταβλητή δεν ορίζεται στην
        # κανονική πορεία — UnboundLocalError στο `if edit_warn:` και 500
        # ΣΕ ΚΑΘΕ ΕΠΙΤΥΧΗΜΕΝΗ ΑΛΛΑΓΗ, αφού το ραντεβού είχε ήδη
        # αποθηκευτεί. Η ιδιοκτήτρια έβλεπε «Κάτι πήγε στραβά» ενώ η
        # αλλαγή είχε γίνει.

        pet_ids = pet_ids_from_form() or ([form_int("pet_id")] if form_int("pet_id") else [])
        new_pets = [x for x in (db.session.get(Pet, i) for i in pet_ids if i) if x is not None]
        if new_pets:
            appointment.pets = new_pets
            appointment.pet_id = new_pets[0].id
        # ΙΔΙΑ ΛΟΓΙΚΗ ΜΕ ΤΟ ΝΕΟ ΡΑΝΤΕΒΟΥ: αν η ιδιοκτήτρια επιβεβαίωσε στο
        # modal ότι θέλει δύο πελάτες την ίδια ώρα, δεν ξαναδείχνουμε την ίδια
        # προειδοποίηση για την ίδια απόφαση. Αν κάτι πήγε στραβά και ΔΕΝ
        # επιβεβαιώθηκε, η προειδοποίηση εμφανίζεται κανονικά.
        force_booking = str(request.form.get("force_booking", "")).strip() in {
            "1", "true", "on", "yes"}
        edit_warn = slot_taken(start_at, end_at, groomer_id,
            exclude_appointment_id=appointment.id)
        if edit_warn and force_booking:
            edit_warn = None
        appointment.groomer_id = groomer_id
        appointment.start_at = start_at
        appointment.end_at = end_at
        appointment.status = clean(request.form.get("status")) or appointment.status
        appointment.total_price = total_price
        appointment.price_override = final_price
        appointment.pickup_name = pickup_name
        appointment.pickup_phone = pickup_phone
        appointment.customer_note = clean(request.form.get("note")) or None
        appointment.staff_note = clean(request.form.get("staff_note")) or None
        _set_service_links(appointment, chosen, quantities)
        db.session.commit()
        flash("Το ραντεβού ενημερώθηκε.", "success")
        # Η ΠΡΟΕΙΔΟΠΟΙΗΣΗ ΜΕΤΑ ΤΗΝ ΕΠΙΤΥΧΙΑ, ώστε να μην την κρύβει
        # το μήνυμα «ενημερώθηκε». Η αλλαγή έγινε — απλώς να το ξέρει.
        if edit_warn:
            flash(edit_warn, "warning")
        _warn_missing_pickup_phone(pickup_name, pickup_phone)
        return redirect(url_for("staff.appointment_detail", appointment_id=appointment.id))

    # Ο επεξεργαστής χρειάζεται τη λίστα πελατών και το preselect JSON,
    # ώστε το form να δουλεύει και χωρίς JavaScript.
    owner_customer = appointment.customer
    initial_customer_json = {
        "id": owner_customer.id,
        "pets": [
            {
                "id": p.id,
                "name": p.name,
                "breed": p.breed or "",
            }
            for p in owner_customer.pets
        ],
    }
    return render_template(
        "staff/appointment_form.html",
        appointment=appointment,
        groomers=groomers,
        # Στην επεξεργασία κρατάμε τη στυλίστρια του ραντεβού· αν δεν υπάρχει
        # πια, προτείνεται η πρώτη.
        default_groomer_id=appointment.groomer_id or default_groomer_id(groomers),
        customers=[owner_customer],
        services=services,
        today=date_cls.today(),
        selected_customer_id=appointment.customer_id,
        selected_pet_id=appointment.pet_id,
        preselected=owner_customer,
        initial_customer_json=initial_customer_json,
    )


@bp.route("/appointments/<int:appointment_id>/status", methods=["POST"])
def appointment_status(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    status = clean(request.form.get("status")) or appointment.status
    valid = {STATUS_PENDING, STATUS_CONFIRMED, STATUS_IN_PROGRESS, STATUS_COMPLETED,
             STATUS_CANCELLED, STATUS_NO_SHOW}
    if status not in valid:
        flash("Μη έγκυρη κατάσταση.", "error")
        return redirect(request.referrer or url_for("staff.calendar"))
    appointment.status = status
    if status == STATUS_CANCELLED:
        appointment.cancel_reason = clean(request.form.get("reason")) or None
    db.session.commit()
    flash(f"Κατάσταση: {appointment.status_label}", "success")
    return redirect(request.referrer or url_for("staff.appointment_detail", appointment_id=appointment.id))


@bp.route("/appointments/<int:appointment_id>/notes", methods=["POST"])
def appointment_notes(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    appointment.staff_note = clean(request.form.get("staff_note")) or None
    db.session.commit()
    flash("Η σημείωση αποθηκεύτηκε.", "success")
    return redirect(request.referrer or url_for("staff.appointment_detail", appointment_id=appointment.id))


@bp.route("/appointments/<int:appointment_id>/remind", methods=["POST"])
def appointment_remind(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    send(KIND_REMINDER, appointment)
    db.session.commit()
    flash("Στάλθηκε υπενθύμιση στον πελάτη (βλ. logs/notifications.log).", "success")
    return redirect(request.referrer or url_for("staff.appointment_detail", appointment_id=appointment.id))


@bp.route("/appointments/<int:appointment_id>/delete", methods=["POST"])
def appointment_delete(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    label = appointment.pets_label
    db.session.delete(appointment)
    db.session.commit()
    flash(f"Το ραντεβού για {label} διαγράφηκε.", "info")
    return redirect(url_for("staff.calendar"))


# -------------------------------------------------------------- πελάτες
@bp.route("/clients")
def clients():
    search = clean(request.args.get("q"))
    # Κάτω από 3 γράμματα δεν φιλτράρουμε: δείχνουμε όλους και
    # υπενθυμίζουμε πόσα γράμματα χρειάζεται η αναζήτηση.
    filtering = is_searchable(search)
    # Οι αρχειοθετημένοι κρύβονται από την καθημερινή λίστα — αλλιώς η
    # ιδιοκτήτρια τους έβλεπε σε κάθε αναζήτηση. Με `?archived=1`
    # εμφανίζονται ΜΟΝΟ αυτοί, για να τους επαναφέρει.
    archived_only = request.args.get("archived") == "1"
    query = db.session.query(Customer).filter(
        Customer.is_active_flag.is_(not archived_only))
    if filtering:
        query = query.options(joinedload(Customer.pets))
    rows = query.order_by(Customer.name).all()

    if filtering:
        rows = [
            c for c in rows
            if matches(
                search, c.name, c.email, c.phone,
                c.address, c.notes, *[(pet.name or '') for pet in c.pets],
            )
        ]

    enriched = []
    for customer in rows:
        visits = db.session.query(func.count(Appointment.id)).filter(
            Appointment.customer_id == customer.id,
            Appointment.status == STATUS_COMPLETED,
        ).scalar()
        last = (
            db.session.query(func.max(Appointment.start_at))
            .filter(Appointment.customer_id == customer.id,
                    Appointment.status == STATUS_COMPLETED)
            .scalar()
        )
        upcoming = db.session.query(func.count(Appointment.id)).filter(
            Appointment.customer_id == customer.id,
            Appointment.status.in_(OPEN_STATUSES),
            Appointment.start_at >= datetime.now(),
        ).scalar()
        enriched.append(
            {
                "customer": customer,
                "visits": visits or 0,
                "last_visit": last,
                "upcoming": upcoming or 0,
                "pets": customer.active_pets,
            }
        )

    return render_template(
        "staff/clients.html",
        rows=enriched,
        search=search,
        filtering=filtering,
        min_chars=MIN_SEARCH_CHARS,
        archived_only=archived_only,
        archived_count=db.session.query(Customer)
        .filter(Customer.is_active_flag.is_(False)).count(),
    )


# ──────────────────────────────────────────────── εισαγωγή / εξαγωγή Excel
# ΜΟΝΟ Η ΙΔΙΟΚΤΗΤΡΙΑ. Ο @admin_required ελέγχει τη διαδρομή στον δι��κομιστή,
# όχι μόνο το κουμπί: αλλιώς η εισαγωγή 3.000 πελατών γίνεται με ένα URL.
import io
import re


#: Όριο μεγέθους αρχείου. Το config έχει MAX_CONTENT_LENGTH στα 4 MB για
#: όλα· εδώ θέλουμε κάτι πολύ μικρότερο, γιατί ένα πρότυπο με χιλιάδες
#: πελάτες είναι 200–400 KB. Τα 4 MB θα ήταν ανεξέλεγκτα για κάτι που
#: δεν χρειάζεται ποτέ.
MAX_IMPORT_BYTES = 2 * 1024 * 1024

ALLOWED_EXT = {".xlsx", ".xlsm", ".csv", ".xls", ".txt"}


#: Ελληνικά → λατινικά, ΓΙΑ ΜΟΝΟ ΤΟ ΟΝΟΜΑ ΤΟΥ ΑΡΧΕΙΟΥ. Το περιεχόμενο
#: παραμένει ελληνικό· αλλάζει μόνο η ετικέτα στη λήψη.
#: Κτίζεται ΑΥΤΟΜΑΤΑ και για τα κεφαλαία. Με χέρι, τα «Πελάτες» έβγαιναν
#: «Πelates» — μισό ελληνικό, μισό λατινικό, και μπερδεμένα. Ο κανόνας
#: «κεφαλαίο προς κεφαλαίο, πεζό προς πεζό» δεν πρέπει να ξεχνιέται.
_GREEK_PAIRS = {
    "α": "a", "β": "v", "γ": "g", "δ": "d", "ε": "e", "ζ": "z", "η": "i",
    "θ": "th", "ι": "i", "κ": "k", "λ": "l", "μ": "m", "ν": "n", "ξ": "x",
    "ο": "o", "π": "p", "ρ": "r", "ς": "s", "σ": "s", "τ": "t", "υ": "y",
    "φ": "f", "χ": "ch", "ψ": "ps", "ω": "o",
    "ά": "a", "έ": "e", "ή": "i", "ί": "i", "ό": "o", "ύ": "y", "ώ": "o",
    "ϊ": "i", "ϋ": "y", "ΐ": "i", "ΰ": "y",
}
_GREEK_LATIN: dict[int, str] = {}
for _greek, _latin in _GREEK_PAIRS.items():
    _GREEK_LATIN[ord(_greek)] = _latin
    # Το «ΐ».upper() δίνει «Ϊ́» — δύο χαρακτήρες, τον Ϊ και έναν τονισμό
    # που έμπασε μαζί. Χωρίς το [0], ο ord() πέφτει με TypeError.
    _GREEK_LATIN[ord(_greek.upper()[0])] = _latin.capitalize()


def download_name(raw: str, fallback: str = "pelates.xlsx") -> str:
    """Καθαρίζει το όνομα αρχείου για την κεφαλίδα Content-Disposition.

    ΧΩΡΙΣ ΑΥΤΟ ΥΠΑΡΧΕΙ ΠΡΟΒΛΗΜΑ: ένα όνομα με αλλαγή γραμμής ή κωδικούς
    ελέγχου μπαίνει στην επικεφαλίδα απάντησης και σε κάποιους browsers
    κάνει header injection. Το όνομα προέρχεται από τον χρήστη, άρα το
    θεωρούμε εχθρικό.

    ΚΑΙ ΛΑΤΙΝΙΚΑ ΓΙΑΤΙ: το Werkzeug βγάζει δύο εκδόσεις — το κανονικό
    filename= και το filename*=UTF-8. Στο πρώτο κόβει ό,τι δεν είναι
    ASCII, και έτσι το «πρότυπο-πελατών-1.0.2.xlsx» έφτανε ως
    «--1.0.2.xlsx». Οι σύγχρονοι browsers χρησιμοποιούν το filename*, αλλά
    ένα αρχείο που αποθηκεύτηκε με κενό όνομα είναι μπέχα για την ιδιοκτήτρια.
    Άρα: λατινικά, ώστε να διαβάζεται και στις δύο εκδόσεις."""
    import unicodedata
    name = (raw or "").strip().split("/")[-1].split("\\")[-1]
    # Οι τόνοι φεύγουν πρώτοι· μετά η μεταγραφή σε λατινικά.
    name = "".join(c for c in unicodedata.normalize("NFD", name)
                   if not unicodedata.combining(c))
    name = name.translate(_GREEK_LATIN)
    name = "".join(ch for ch in name if ch.isalnum() or ch in " ._-()")
    name = re.sub(r"\s+", " ", name).strip(" .-")
    return name[:80] or fallback


def _send_xlsx(payload: bytes, name: str):
    return send_file(
        io.BytesIO(payload),
        mimetype="application/vnd.openxmlformats-officedocument."
                 "spreadsheetml.sheet",
        as_attachment=True,
        download_name=download_name(name),
    )


@bp.route("/clients/import", methods=["GET", "POST"])
@admin_required
def clients_import():
    """Η σελίδα εισαγωγής και η ίδια η διαδικασία — owner only."""
    if request.method == "GET":
        return render_template("staff/clients_import.html",
                               columns=TEMPLATE_COLUMNS, headers=HEADERS)

    upload = request.files.get("file")
    if upload is None or not (upload.filename or "").strip():
        flash("Δεν επιλέχθηκε αρχείο.", "error")
        return redirect(url_for("staff.clients_import"))

    filename = upload.filename or ""
    ext = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    if ext and ext not in ALLOWED_EXT:
        flash(f"Ο τύπος «{ext}» δεν υποστηρίζεται. Χρησιμοποίησε .xlsx ή .csv.",
              "error")
        return redirect(url_for("staff.clients_import"))

    # Ανάγνωση ΣΤΗ ΜΝΗΜΗ. Κανένα αρχείο δεν ακουμπά τον δίσκο.
    data = upload.read(MAX_IMPORT_BYTES + 1)
    if len(data) > MAX_IMPORT_BYTES:
        flash("Το αρχείο είναι πολύ μεγάλο (πάνω από 2 MB). "
              "Χωρίσε το σε δύο αρχεία.", "error")
        return redirect(url_for("staff.clients_import"))
    if not data.strip():
        flash("Το αρχείο είναι κενό.", "error")
        return redirect(url_for("staff.clients_import"))

    try:
        result = import_customers(data, filename)
    except ValueError as exc:
        # Μορφοποίηση/κεφαλίδες λάθος — δεν μπήκε τίποτα, δεν χρειάζεται rollback.
        flash(str(exc), "error")
        return redirect(url_for("staff.clients_import"))
    except Exception as exc:                                   # noqa: BLE001
        db.session.rollback()
        current_app.logger.exception("Αποτυχία εισαγωγής πελατών")
        flash(f"Η εισαγωγή απέτυχε ({type(exc).__name__}). "
              "Δεν μπήκε τίποτα — τα δεδομένα είναι ανέπαφα.", "error")
        return redirect(url_for("staff.clients_import"))

    if result.inserted:
        db.session.commit()
    else:
        # Κανένας επιτυχής γραμμή → δεν αφήνουμε ανοιχτή συναλλαγή.
        db.session.rollback()

    _flash_import_result(result)
    return redirect(url_for("staff.clients"))


def _flash_import_result(result) -> None:
    """Το μήνυμα της ιδιοκτήτριας: πόσοι μπήκαν, πόσοι όχι, και ΓΙΑΤΙ.
    Ο λόγος είναι το σημαντικότερο κομμάτι — χωρίς αυτόν, ένας αριθμός
    απορρίψεων είναι ανεξήγητος."""
    if result.inserted:
        flash(result.summary(), "success")
    else:
        flash("Δεν μπήκε κανένας πελάτης — διόρθωσε τα παρακάτω "
              "και δοκίμασε ξανά.", "error")

    if result.skipped_blank:
        flash(f"{result.skipped_blank} κενές γραμμές παραλείφθηκαν.", "info")

    if result.unknown_columns:
        flash("Στήλες που δεν αναγνωρίστηκαν και αγνοήθηκαν: "
              + ", ".join(result.unknown_columns[:6]) + ".", "info")

    # Μέχρι 8 λόγους. Με 200 απορρίψεις το μήνυμα γίνεται ανάγνωστο
    # δυσπαθές — λέμε πόσοι είναι και δείχνουμε τους πρώτους, με τον
    # αριθμό γραμμής ώστε να τους βρει στο αρχείο.
    for rej in result.rejected[:8]:
        flash(f"Γραμμή {rej.row_no} — {rej.name}: {rej.reason}", "error")
    if len(result.rejected) > 8:
        flash(f"…και {len(result.rejected) - 8} ακόμα απορρίψεις. "
              "Διόρθωσε τις παραπάνω και δοκίμασε ξανά.", "info")


@bp.route("/clients/export")
@admin_required
def clients_export():
    """Κατεβάζει .xlsx — owner only.

    ?template=1  → το κενό ΠΡΟΤΥΠΟ, με οδηγίες στη 2η σειρά
    ?export=1    → τους πελάτες που φιλτράρει η σελίδα (?q=…)

    ΔΥΟ ΞΕΧΩΡΙΣΤΑ ΜΠΟΥΤΟΝΙΑ, ΟΧΙ ΕΝΑ ΜΕ ΠΑΡΑΜΕΤΡΟΥΣ. Το «κατέβασε πρότυπο»
    και το «κατέβασε τους πελάτες μου» είναι διαφορετικές πράξεις με
    διαφορετικό αποτέλεσμα· το ένα γράφει, το άλλο διαβάζει. Ένα κουμπί
    που «μιλάει» ανάλογα με ένα αόρατο ?q είναι πηγή λαθών."""
    if request.args.get("template"):
        return _send_xlsx(template_bytes(),
                          f"πρότυπο-πελατών-{APP_VERSION}.xlsx")

    search = (request.args.get("q") or "").strip()
    active = is_searchable(search)
    # ΟΙ ΑΡΧΕΙΟΘΕΤΗΜΕΝΟΙ ΜΕΝΟΥΝ ΣΤΗΝ ΕΞΑΓΩΓΗ. Μια εξαγωγή που σβήνει
    # σειρές χωρίς να το λέει είναι μη αναστρέψιμη απώλεια δεδομένων μέσα
    # σε ένα αρχείο. Οι ενεργοί είναι η καθημερινή λίστα· η εξαγωγή είναι
    # αρχείο, όχι λίστα.
    rows = Customer.query.options(
        joinedload(Customer.pets)).order_by(Customer.name).all()
    if active:
        rows = [c for c in rows
                if matches(search, c.name, c.email, c.phone, c.address,
                           c.notes, *[(p.name or "") for p in c.pets])]
    if not rows:
        flash("Δεν βρέθηκαν πελάτες για εξαγωγή.", "info")
        return redirect(url_for("staff.clients"))
    return _send_xlsx(export_customers(rows),
                      f"πελάτες-{len(rows)}-{APP_VERSION}.xlsx")


@bp.route("/clients/new", methods=["GET", "POST"])
def client_new():
    if request.method == "POST":
        # Ονοματεπώνυμο σε ένα πεδίο. Τηλέφωνο/email/διεύθυνση προαιρετικά.
        name = clean(request.form.get("name"))
        phone = clean(request.form.get("phone"))
        email = clean(request.form.get("email"))
        address = clean(request.form.get("address"))
        notes = clean(request.form.get("notes"))

        if not name:
            flash("Συμπληρώστε το ονοματεπώνυμο.", "error")
        else:
            customer = Customer(
                name=name,
                phone=phone or None,
                email=email or None,
                address=address or None,
                notes=notes or None,
            )
            db.session.add(customer)
            db.session.commit()
            flash(f"Ο πελάτης {name} προστέθηκε.", "success")
            return redirect(url_for("staff.client_detail", customer_id=customer.id))
    return render_template("staff/client_form.html", customer=None)


@bp.route("/clients/<int:customer_id>")
def client_detail(customer_id: int):
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    now = datetime.now()
    appointments = sorted(customer.appointments, key=lambda a: a.start_at, reverse=True)
    completed = [a for a in appointments if a.status == STATUS_COMPLETED]
    # GROOMING_INTERVAL_DAYS was removed (Επείγον badge removed)
    return render_template(
        "staff/client_detail.html",
        customer=customer,
        appointments=appointments,
        upcoming=[a for a in appointments if a.is_upcoming],
        completed_count=len(completed),
        no_shows=len([a for a in appointments if a.status == STATUS_NO_SHOW]),
        last_visit=completed[0] if completed else None,
        today=now.date(),
    )


@bp.route("/clients/<int:customer_id>/delete", methods=["POST"])
def client_delete(customer_id: int):
    """Αρχειοθέτηση — ή οριστική διαγραφή, αν δεν υπάρχει ιστορικό.

    Ζητήθηκε ρητά: «να γίνεται αρχειοθέτηση, αλλά να σβήνεται οριστικά όταν δεν έχει
    ιστορικό». Η διάταξη είναι σκόπιμα αυτή: η διαγραφή χωρίς ιστορικό δεν χάνει τίποτα —
    δεν υπάρχει τίποτα να χαθεί — και καθαρίζει μια καταχώρηση που μπήκε κατά λάθος, ενώ
    η αρχειοθέτηση αφήνει ανέπαφο το οικονομικό ιστορικό του καταστήματος.
    """
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    name = customer.name

    # Επερχόμενα ραντεβού = όχι. Η αρχειοθέτηση κάνει τον πελάτη αόρατο στις λίστες,
    # άρα ένα κρυφό επερχόμενο ραντεβού θα έμενε στο ημερολόγιο χωρίς πελάτη — και η
    # ιδιοκτήτρια θα το αναζητούσε στο ημερολόγιο χωρίς αποτέλεσμα.
    if customer.has_upcoming:
        flash("Δεν είναι δυνατή η αρχειοθέτηση — υπάρχουν επερχόμενα "
              "ραντεβού. Ακυρώστε τα πρώτα και επαναλάβετε.", "error")
        return redirect(url_for("staff.client_detail", customer_id=customer_id))

    if not customer.has_history:
        # Οριστική διαγραφή μόνο εδώ. Το διαγραφικό αλυσίδωμα σβήνει και τα κατοικίδια, αλλά
        # δεν υπάρχει κανένα — αλλιώς δεν θα φτάναμε εδώ.
        db.session.delete(customer)
        db.session.commit()
        flash(f"Ο πελάτης «{name}» διαγράφηκε οριστικά — δεν είχε ούτε ραντεβού "
              "ούτε κατοικίδια.", "info")
        return redirect(url_for("staff.clients"))

    customer.is_active_flag = False
    customer.archived_at = datetime.now()
    db.session.commit()
    flash(f"Ο πελάτης «{name}» αρχειοθετήθηκε. Τα ραντεβού και τα κατοικίδια "
          "παραμένουν διαθέσιμα.", "info")
    return redirect(url_for("staff.client_detail", customer_id=customer_id))


@bp.route("/clients/<int:customer_id>/restore", methods=["POST"])
def client_restore(customer_id: int):
    """Επαναφορά αρχειοθετημένου πελάτη.

    Υπάρχει επειδή διαφορετικά η αρχειοθέτηση θα ήταν μονόδρομη. Μια διαδρομή που μόνο
    σβήνει δεν είναι «διαγραφή με ανάκληση», είναι απώλεια.
    """
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    customer.is_active_flag = True
    customer.archived_at = None
    db.session.commit()
    flash(f"Ο πελάτης «{customer.name}» επανήλθε στους ενεργούς πελάτες.", "info")
    return redirect(url_for("staff.client_detail", customer_id=customer_id))


@bp.route("/clients/<int:customer_id>/edit", methods=["GET", "POST"])
def client_edit(customer_id: int):
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    if request.method == "POST":
        name = clean(request.form.get("name"))
        if not name:
            flash("Συμπληρώστε το ονοματεπώνυμο.", "error")
        else:
            customer.name = name
            customer.phone = clean(request.form.get("phone")) or None
            customer.email = clean(request.form.get("email")) or None
            customer.address = clean(request.form.get("address")) or None
            customer.notes = clean(request.form.get("notes")) or None
            db.session.commit()
            flash("Τα στοιχεία ενημερώθηκαν.", "success")
            return redirect(url_for("staff.client_detail", customer_id=customer.id))
    return render_template("staff/client_form.html", customer=customer)


@bp.route("/clients/<int:customer_id>/notes", methods=["POST"])
def client_notes(customer_id: int):
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    customer.notes = clean(request.form.get("notes")) or None
    db.session.commit()
    flash("Η σημείωση αποθηκεύτηκε.", "success")
    return redirect(url_for("staff.client_detail", customer_id=customer.id))


# -------------------------------------------------------- κατοικίδια
@bp.route("/clients/<int:customer_id>/pets/new", methods=["GET", "POST"])
def pet_new(customer_id: int):
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    if request.method == "POST":
        # Το όνομα είναι προαιρετικό· χωρίς όνομα εμφανίζεται «χωρίς όνομα».
        name = clean(request.form.get("name")) or None
        birth = parse_date(request.form.get("birth_date"))
        if request.form.get("birth_date") and birth is None:
            flash("Ημερομηνία γέννησης μη έγκυρη (μορφή ΗΗ/ΜΜ/ΕΕΕΕ).", "error")
        elif birth and birth > date_cls.today():
            flash("Η ημερομηνία γέννησης δεν μπορεί να είναι στο μέλλον.", "error")
        else:
            pet = Pet(
                customer_id=customer.id,
                # Το όνομα παραμένει προαιρετικό· χωρίς όνομα εμφανίζεται
                # ως «χωρίς όνομα» στο ραντεβού.
                name=name,
                species=clean(request.form.get("species")) or "dog",
                breed=clean(request.form.get("breed")) or None,
                gender=clean(request.form.get("gender")) or "unknown",
                birth_date=birth,
                weight_kg=form_float("weight_kg") or None,
                is_neutered=form_bool("is_neutered"),
                allergies=clean(request.form.get("allergies")) or None,
                temperament=clean(request.form.get("temperament")) or None,
                health_notes=clean(request.form.get("health_notes")) or None,
                coat_notes=clean(request.form.get("coat_notes")) or None,
            )
            db.session.add(pet)
            db.session.commit()
            flash(f"Το κατοικίδιο «{name or 'χωρίς όνομα'}» προστέθηκε!", "success")
            return redirect(url_for("staff.client_detail", customer_id=customer.id))
    return render_template("staff/pet_form.html", customer=customer, pet=None,
                       species=SPECIES, genders=GENDERS)


@bp.route("/pets/<int:pet_id>/edit", methods=["GET", "POST"])
def pet_edit(pet_id: int):
    pet = get_or_404(Pet, pet_id, "Το κατοικίδιο δεν βρέθηκε.")
    customer = pet.customer
    if request.method == "POST":
        # Το όνομα είναι προαιρετικό.
        name = clean(request.form.get("name")) or None
        birth = parse_date(request.form.get("birth_date"))
        pet.name = name
        pet.species = clean(request.form.get("species")) or "dog"
        pet.breed = clean(request.form.get("breed")) or None
        pet.gender = clean(request.form.get("gender")) or "unknown"
        pet.birth_date = birth
        pet.weight_kg = form_float("weight_kg") or None
        pet.is_neutered = form_bool("is_neutered")
        pet.allergies = clean(request.form.get("allergies")) or None
        pet.temperament = clean(request.form.get("temperament")) or None
        pet.health_notes = clean(request.form.get("health_notes")) or None
        pet.coat_notes = clean(request.form.get("coat_notes")) or None
        db.session.commit()
        flash("Τα στοιχεία ενημερώθηκαν.", "success")
        return redirect(url_for("staff.client_detail", customer_id=customer.id))
    return render_template("staff/pet_form.html", customer=customer, pet=pet,
                           species=SPECIES, genders=GENDERS)


@bp.route("/pets/<int:pet_id>/delete", methods=["POST"])
def pet_delete(pet_id: int):
    pet = get_or_404(Pet, pet_id, "Το κατοικίδιο δεν βρέθηκε.")
    customer_id = pet.customer_id
    # ΟΛΑ ΤΑ ΡΑΝΤΕΒΟΥ, όχι μόνο αυτά που το έχει ως κύριο.
    has_future = any(a.is_upcoming for a in pet.appointments_including_shared())
    if has_future:
        flash("Δεν είναι δυνατή η διαγραφή — υπάρχουν επερχόμενα ραντεβού.", "error")
        return redirect(url_for("staff.client_detail", customer_id=customer_id))
    # ΑΡΧΕΙΟΘΕΤΗΣΗ ΟΤΑΝ ΥΠΑΡΧΕΙ ΙΣΤΟΡΙΚΟ. Ο ΚΑΝΟΝΑΣ ΕΙΝΑΙ «ΑΝ ΥΠΑΡΧΕΙ
    # ΙΣΤΟΡΙΚΟ, ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ» — και «ιστορικό» σημαίνει ΟΠΟΙΟΔΗΠΟΤΕ
    # ραντεβού, όχι μόνο τα ολοκληρωμένα. Το παλιό έλεγε μόνο τα
    # ολοκληρωμένα, οπότε ένα κατοικίδιο με ένα ΑΚΥΡΩΜΕΝΟ ή
    # «δεν ήρθε» ραντεβού σβηνόταν οριστικά — και μαζί του το ιστορικό
    # και τα οικονομικά του. Ζητήθηκε ρητά: να αρχειοθετείται όταν έχει
    # έσοδα/ραντεβού, όπως οι πελάτες.
    appts = pet.appointments_including_shared()
    name = pet.name or "χωρίς όνομα"
    if appts:
        pet.is_archived = True
        db.session.commit()
        flash(f"Το κατοικίδιο «{name}» αρχειοθετήθηκε — έχει "
              f"{len(appts)} ραντεβού, δεν θα διγραφεί. Μπορεί να "
              f"επανέλθει αν χρειαστεί.", "info")
    else:
        db.session.delete(pet)
        db.session.commit()
        flash(f"Το κατοικίδιο «{name}» διαγράφηκε οριστικά (δεν είχε "
              f"κανένα ραντεβού).", "info")
    return redirect(url_for("staff.client_detail", customer_id=customer_id))


@bp.route("/pets/<int:pet_id>/restore", methods=["POST"])
def pet_restore(pet_id: int):
    pet = get_or_404(Pet, pet_id, "Το κατοικίδιο δεν βρέθηκε.")
    customer_id = pet.customer_id
    if not pet.is_archived:
        flash("Το κατοικίδιο δεν είναι αρχειοθετημένο.", "error")
        return redirect(url_for("staff.client_detail", customer_id=customer_id))
    pet.is_archived = False
    db.session.commit()
    flash(f"Το κατοικίδιο «{pet.name or 'χωρίς όνομα'}» επαναφέρθηκε.", "success")
    return redirect(url_for("staff.client_detail", customer_id=customer_id))


@bp.route("/pets")
def all_pets():
    # By default exclude archived pets; use ?archived=1 to show them
    show_archived = request.args.get("archived") == "1"
    query = (
        db.session.query(Pet)
        .join(Pet.customer)
        .order_by(Customer.name, Pet.name)
    )
    if not show_archived:
        query = query.filter(Pet.is_archived == False)
    pets = query.all()
    show_due_only = request.args.get("due") == "1"
    search = clean(request.args.get("q"))
    filtering = is_searchable(search)

    if show_due_only:
        # due_for_grooming removed (Επείγον badge removed)
        pets = []

    if filtering:
        pets = [
            pet for pet in pets
            if matches(
                search, pet.name, pet.breed, pet.color, pet.species,
                pet.allergies, pet.temperament, pet.health_notes, pet.coat_notes,
                pet.customer.name,
                pet.customer.phone, pet.customer.email,
            )
        ]

    # ΟΙ ΕΠΙΣΚΕΨΕΙΣ, ΜΙΑ ΦΟΡΑ ΓΙΑ ΟΛΗ ΤΗ ΛΙΣΤΑ. Ένα ερώτημα ενώνει το
    # κύριο κατοικίδιο με τους συμμετέχοντες — αλλιώς το δεύτερο
    # κατοικίδιο σε ραντεβού με δύο κατοικίδια έμενε μηδέν επισκέψεις.
    visits_by_pet: dict[int, int] = {}
    for _pid, _appts in Pet.appointments_for([x.id for x in pets]).items():
        visits_by_pet[_pid] = sum(
            1 for a in _appts if a.status == STATUS_COMPLETED)


    return render_template(

        "staff/pets.html",

        pets=pets,
        visits_by_pet=visits_by_pet,
        show_due_only=show_due_only,
        search=search,
        filtering=filtering,
        min_chars=MIN_SEARCH_CHARS,
    )


# ------------------------------------------------------------ ειδοποιήσεις
@bp.route("/notifications")
def notifications():
    rows = (
        Notification.query.order_by(Notification.created_at.desc()).limit(120).all()
    )
    return render_template("staff/notifications.html", rows=rows,
                           pending=due_reminders())


@bp.route("/api/calendar-version")
def api_calendar_version():
    """«Έκδοση» του ημερολογίου μιας μέρας, για έλεγχο αλλαγών.

    Πολύ ελαφρύ endpoint: μία συγκέντρωση πάνω σε χρονικό διάστημα. Ο
    πελάτης το ζητά κάθε λίγα δευτερόλεπτα και ανανεώνεται μόνο όταν αλλάξει
    το token — δηλαδή όταν μπήκε, διεγράφη ή άλλαξε κάτι.

    Το token πιάνει και τις τρεις περιπτώσεις: νέα κράση (μεγαλύτερο id),
    αλλαγή ώρας/κατάστασης (μεγαλύτερο updated_at) και διαγραφή (πλήθος).
    """
    from flask import jsonify

    day = parse_date(request.args.get("date")) or date_cls.today()
    start_dt = datetime.combine(day, time(0, 0))
    end_dt = datetime.combine(day + timedelta(days=1), time(0, 0))
    row = (
        db.session.query(
            func.count(Appointment.id),
            func.max(Appointment.id),
            func.max(Appointment.updated_at),
        )
        .filter(Appointment.start_at >= start_dt, Appointment.start_at < end_dt)
        .one()
    )
    count, max_id, updated = row
    token = "%s|%s|%s" % (count or 0, max_id or 0, updated or "")
    return jsonify({
        "date": day.isoformat(),
        "token": token,
        "count": int(count or 0),
        "updated_at": updated.isoformat() if updated else None,
    })


@bp.route("/notifications/send-reminders", methods=["POST"])
def send_pending_reminders():
    items = due_reminders()
    for appointment in items:
        send(KIND_REMINDER, appointment)
    db.session.commit()
    flash(plural(len(items), "υπενθύμιση", "υπενθυμίσεις") + " στάλθηκαν.", "success")
    return redirect(url_for("staff.notifications"))


# ------------------------------------------------------- API για JS φόρμες
@bp.route("/api/customers")
def api_customers():
    from flask import jsonify

    results = []
    for customer in (db.session.query(Customer)
                     .filter(Customer.is_active_flag.is_(True))
                     .order_by(Customer.name).all()):
        results.append(
            {
                "id": customer.id,
                "name": customer.name,
                "phone": customer.phone or "",
                "email": customer.email or "",
                "pets": [
                    {"id": p.id, "name": p.name,
                     "breed": p.breed or ""}
                    for p in customer.active_pets
                ],
            }
        )
    return jsonify(results)


@bp.route("/api/slots")
def api_slots():
    from flask import jsonify

    day = parse_date(request.args.get("date")) or date_cls.today()
    duration = int(request.args.get("duration", 60) or 60)
    groomer_id = request.args.get("groomer_id", type=int)
    exclude = request.args.get("exclude", type=int)
    slots = slots_for_date(day, duration, groomer_id, exclude_appointment_id=exclude)
    return jsonify(
        {
            "date": day.isoformat(),
            "closed": bool(slots) and slots[0]["start"] == "—",
            "duration": duration,
            "slots": [
                {"start": s["start"], "end": s["end"], "available": s["available"],
                 "reason": s["reason"], "label": s["label"], "groomer_id": s["groomer_id"],
                 "busy": s.get("busy", False),
                 "busy_groomers": s.get("busy_groomers", [])}
                for s in slots
            ],
        }
    )


@bp.route("/api/next-slots")
def api_next_slots():
    """Οι επόμενες ώρες του ημερολογίου: ελεύθερες και κλεισμένες.

    Απαντά στο «πότε θα γεμίσει;» — την ερώτηση που έμενε αναπάντητη όταν η μέρα που
    είχε επιλέξει ήταν γεμάτη. Είναι συμβουλευτική: δεν κλείνει τίποτα, απλώς δείχνει
    πού υπάρχει χώρος. Η ιδιοκτήτρια μπορεί να το αγγίξει και να μεταφέρει την ημερομηνία
    εκεί.

    Ζητήθηκε ρητά να συμπεριλαμβάνονται και οι κλεισμένες. Χωρίς αυτές η απάντηση ήταν
    ασυνεπής: η ίδια ώρα εμφανιζόταν πέντε φορές και η λίστα δεν έλεγε ποτέ πού υπάρχει
    ήδη κόσμος. Κάθε εγγραφή φέρει το `booked` (true για κατειλημμένη) και το `label`,
    τα οποία εμφανίζει το JS: μια κλεισμένη ώρα που φαίνεται ίδια με ελεύθερη είναι
    ψευτική εικόνα που σπαταλά χρόνο."""
    from flask import jsonify

    duration = int(request.args.get("duration", 60) or 60)
    groomer_id = request.args.get("groomer_id", type=int)
    exclude = request.args.get("exclude", type=int)
    try:
        count = max(1, min(10, int(request.args.get("count", 5) or 5)))
    except ValueError:
        count = 5
    return jsonify({
        "slots": next_free_slots(count, duration, groomer_id, exclude),
    })


def _set_service_links(appointment, services, quantities) -> None:
    """Γράφει τις γραμμές υπηρεσιών με ποσότητα και στιγμιότυπο διάρκειας.

    ΜΕ ΤΟ ΠΟΙΟ ΚΑΤΟΙΚΙΔΙΟ, ΟΤΑΝ Η ΙΔΙΟΚΤΗΤΡΙΑ ΤΟ ΕΙΠΕ. Το `svc_pet` έρχεται
    από το κρυφό πεδίο που γεμίζει ΜΟΝΟ η επιλογή «μόνο για…», άρα στη
    συνηθισμένη κλήση είναι κενό και η υπηρεσία αφορά όλα τα κατοικίδια —
    χωρίς ένα μόνο κλικ παραπάνω.

    ΕΛΕΓΧΟΥΜΕ ΟΤΙ ΤΟ ΚΑΤΟΙΚΙΔΙΟ ΑΝΗΚΕΙ ΣΤΟ ΡΑΝΤΕΒΟΥ. Χωρίς τον έλεγχο, μια
    τροποποιημένη φόρμα θα μπορούσε να δηλώσει υπηρεσία για κατοικίδιο που δεν
    έρχεται ποτέ — και η σύνοψη θα έλεγε «για τον Rex», ενώ ο Rex δεν έρχεται.
    """
    wanted = service_pets_from_form()
    own_pets = {pet.id for pet in appointment.pets}

    def _link(service):
        pet_id = wanted.get(service.id) if wanted.get(service.id) in own_pets else None
        qty = max(1, int(quantities.get(service.id, 1)))
        # «ΜΟΝΟ ΓΙΑ…» = ΜΙΑ ΦΟΡΑ. Η γραμμή της βάσης είναι η ΑΛΗΘΕΙΑ που
        # διαβάζουν μετά η αναφορά εξόδων και η κάρτα του ραντεβού. Αν
        # γράψουμε 2 για υπηρεσία ενός κατοικιδίου, τότε η ιδιοκτήτρια βλέπει
        # «2 × 25 € = 50 €» για ένα πλυντρείο που έκανε ΜΙΟ ζώο, και το
        # «ποιος πήρε τι» συνοψίζεται λάθος. Ίδιος κανόνας με pricing_for.
        if pet_id:
            qty = 1
        return AppointmentService(
            service_id=service.id,
            quantity=qty,
            duration=int(service.duration_minutes or 0),
            pet_id=pet_id,
        )

    appointment.service_links = [_link(service) for service in services]


# ------------------------------------------------------------------ expenses
@bp.route("/expenses", methods=["GET", "POST"])
def expenses():
    """Καταγραφή εξόδων υλικών (π.χ. σαμπουάν, μάσκες) από την ιδιοκτήτρια ή τους βοηθούς."""
    today = date_cls.today()

    if request.method == "POST":
        action = request.form.get("action") or "create"
        if action == "create":
            item = clean(request.form.get("item"))
            if not item:
                flash("Συμπληρώστε τι αγοράστηκε, χρησιμοποιήθηκε ή πληρώθηκε.", "error")
                return redirect(url_for("staff.expenses"))
            amount = form_float("amount", 0.0)
            if amount <= 0:
                flash("Το ποσό πρέπει να είναι μεγαλύτερο από μηδέν.", "error")
                return redirect(url_for("staff.expenses"))
            spent_on = parse_date(request.form.get("spent_on"), default=today) or today
            db.session.add(
                Expense(
                    item=item[:160],
                    category=clean(request.form.get("category"))[:60] or EXPENSE_GENERAL,
                    amount=round(amount, 2),
                    spent_on=spent_on,
                    note=clean(request.form.get("note"))[:200] or None,
                    created_by_id=current_user.id,
                )
            )
            db.session.commit()
            flash(f"Καταχωρίστηκαν έξοδα: {item} — {fmt_money(amount)}.", "success")
        elif action == "delete":
            expense = db.session.get(Expense, form_int("expense_id"))
            if expense is None:
                flash("Δεν βρέθηκε αυτή η καταχώρηση.", "error")
            else:
                item = expense.item
                db.session.delete(expense)
                db.session.commit()
                flash(f"Τα έξοδα «{item}» διαγράφηκαν.", "info")
        return redirect(url_for("staff.expenses"))

    # Παράμετροι περιόδου (προεπιλογή: τρέχων μήνας)
    today = date_cls.today()
    month_start = today.replace(day=1)
    next_month = (month_start + timedelta(days=32)).replace(day=1)
    view_month = request.args.get("month", "")  # YYYY-MM

    if view_month:
        try:
            year_s, month_s = view_month.split("-")
            view_start = date_cls(int(year_s), int(month_s), 1)
        except (ValueError, TypeError):
            view_month = ""
            view_start = month_start
    if not view_month:
        view_start = month_start
    view_end = (view_start + timedelta(days=32)).replace(day=1)

    rows = (
        Expense.query.filter(Expense.spent_on >= view_start, Expense.spent_on < view_end)
        .order_by(Expense.spent_on.desc(), Expense.id.desc())
        .all()
    )

    day_totals: dict = {}
    for row in rows:
        day_totals.setdefault(row.spent_on, 0.0)
        day_totals[row.spent_on] += row.amount

    month_expenses = sum(r.amount for r in rows)

    # Τα οικονομικά του καταστήματος (έσοδα/καθαρό εισόδημα) είναι για την
    # ιδιοκτήτρια μόνο. Οι βοηθοί βλέπουν έξοδα — που καταχωρούν — όχι έσοδα.
    show_financials = current_user.is_admin
    revenue = revenue_gross = discounts = net = 0.0
    if show_financials:
        window = (
            Appointment.status == STATUS_COMPLETED,
            Appointment.start_at >= datetime.combine(view_start, time(0, 0)),
            Appointment.start_at < datetime.combine(view_end, time(0, 0)),
        )
        # ΜΙΑ ΕΡΩΤΗΣΗ ΓΙΑ ΟΛΑ ΤΑ ΠΟΣΑ, ΟΧΙ ΔΥΟ.
        #
        # ΤΙ ΖΗΤΗΣΕ Η ΙΔΙΟΚΤΗΤΡΙΑ ΚΑΙ ΤΙ ΕΔΕΙΧΝΕ Η ΟΘΟΝΗ. Έδειχνε 168,00 € και
        # από κάτω «−18,00 € εκπτώσεις». Δηλαδή το ΜΕΓΑΛΟ ΝΟΜΙΣΜΑ ήταν αυτό
        # που δεν μπήκε στο ταμείο. Τα πραγματικά χρήματα ήταν 150,00 €, και
        # αυτό είναι που θέλει να βλέπει πρώτο.
        #
        # Δεν το άλλαξα μόνο στην οθόνη: άλλαξα το ίδιο το ΜΕΤΡΗΜΑ, ώστε ο
        # αριθμός στην οθόνη και αυτός στο Excel να είναι το ίδιο πράγμα.
        # Μια επιφάνεια που διαφωνεί με την αναφορά είναι χειρότερη από το
        # παλιό.
        row = db.session.query(
            func.coalesce(func.sum(Appointment.total_price), 0.0),
            func.coalesce(
                func.sum(
                    func.coalesce(Appointment.price_override, Appointment.total_price)
                ), 0.0),
        ).filter(*window).one()
        revenue_gross = float(row[0] or 0.0)
        revenue = float(row[1] or 0.0)
        discounts = revenue_gross - revenue
        net = revenue - month_expenses

    categories = sorted({r.category_label for r in rows} | set(EXPENSE_CATEGORIES))

    # Ανάλυση ανά κατηγορία, ώστε να φαίνεται πόσα ήταν τα έξοδα του
    # καταστήματος (ρεύμα, νερό…) από τα υλικά που καταναλώθηκαν.
    by_category: dict = {}
    for row in rows:
        by_category.setdefault(row.category_label, 0.0)
        by_category[row.category_label] += row.amount
    category_totals = sorted(by_category.items(), key=lambda kv: -kv[1])
    store_total = by_category.get(EXPENSE_STORE, 0.0)

    # Ο κατάλογος των σταθερών εξόδων, για γρήγορη καταχώριση.
    store_items = (
        ExpenseItem.query.filter_by(is_active=True)
        .order_by(ExpenseItem.sort_order, ExpenseItem.label)
        .all()
    )

    # ΤΙ ΠΡΟΤΕΙΝΕΤΑΙ ΣΤΟ ΠΛΑΤΙ «Αγοράστηκε…» για αυτόματη συμπλήρωση.
    #
    # ΤΟ ΠΑΛΙΟ ΠΡΟΣΟΧΙΟ ΗΤΑΝ ΛΑΘΟΣ: το πλατίο είχε το id «expenseItems»,
    # ΑΛΛΑ ΤΟ ΠΑΡΕΜΠΑΖΕ ΤΙΣ ΚΑΤΗΓΟΡΙΕΣ. Άρα η ιδιοκτήτρια που έγραφε
    # «Σαμπουάν 5L» έβλεπε να της προτείνεται «Γενικά» — μια κατηγορία, όχι
    # αυτό που έγραφε. Ο κατάλογος των ειδών υπήρχε ΉΔΗ στη βάση και φορτωνόταν
    # στη σελίδα (store_items), αλλά δεν πηγαίνε ΠΟΤΕ στο πλαίσιο.
    item_suggestions: list[str] = []
    for item in store_items:
        if item.label and item.label not in item_suggestions:
            item_suggestions.append(item.label)
    # ΚΑΙ ΟΤΙ ΕΓΡΑΨΕ Η ΙΔΙΑ ΠΡΟΗΓΟΥΜΕΝΑ. Ο ιδιοκτήτρια έγραψε «μαύρες μάσκες»
    # τον Ιούλιο και το ίδιο τον Αύγουστο δεν το πρόσφερε η εφαρμογή.
    for row in rows:
        label = (row.item or "").strip()
        if label and label not in item_suggestions:
            item_suggestions.append(label)

    return render_template(
        "staff/expenses.html",
        item_suggestions=item_suggestions,
        rows=rows,
        day_totals=day_totals,
        month_expenses=month_expenses,
        revenue=revenue,
        revenue_gross=revenue_gross,
        discounts=discounts,
        net=net,
        view_start=view_start,
        view_end=view_end,
        view_label=f"{_month_name(view_start)} {view_start.year}",
        today=today,
        categories=categories,
        category_totals=category_totals,
        store_total=store_total,
        store_items=store_items,
        show_financials=show_financials,
    )

