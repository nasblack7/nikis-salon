"""Πίνακας διαχείρισης (μόνο ιδιοκτήτρια): χρήστες, δικαιώματα, ρυθμίσεις."""

from __future__ import annotations

from datetime import time

from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for
from flask_login import current_user
from sqlalchemy import func

import config

from .. import logo
from ..envfile import apply_to_runtime, env_file_path, set_env_values
from ..mailer import is_configured, missing_settings, status
from ..backup import (
    BackupError,
    backups_dir,
    create_backup as create_sql_backup,
    list_backups,
    peek_backup,
    restore_backup as restore_sql_backup,
    safe_backup_path,
)
from ..extensions import db
from ..helpers import (
    MIN_PASSWORD_LENGTH,
    clean,
    form_bool,
    form_float,
    form_int,
    form_time,
    admin_required,
)
from ..updates import maintenance_off, maintenance_on, request_restart
from ..models import (
    EXPENSE_STORE,
    ADMIN_ROLES,
    ROLE_MANAGER,
    ROLE_OWNER,
    ROLE_STAFF,
    Appointment,
    Customer,
    ExpenseItem,
    Groomer,
    Pet,
    SalonDaySettings,
    SalonSettings,
    Service,
    User,
)

bp = Blueprint("admin", __name__, url_prefix="/admin")

GROOMER_COLORS = ["#B0567A", "#5F8A72", "#4E7E9C", "#C98A2E", "#7C6BA0", "#A0576B"]


@bp.before_request
@admin_required
def require_owner():
    return None


# ------------------------------------------------------------------ dashboard
@bp.route("/")
def dashboard():
    services = Service.query.order_by(Service.category, Service.sort_order, Service.name).all()
    groomers = db.session.query(Groomer).join(Groomer.user).order_by(Groomer.sort_order).all()
    days = SalonDaySettings.query.order_by(SalonDaySettings.weekday).all()
    if not days:
        # Οι προεπιλογές της στήλης (`default=time(9,0)`) μπαίνουν στη βάση
        # ΜΟΝΟ στο flush. Ένα αντικείμενο που δεν γράφτηκε ποτέ στη βάση έχει
        # open_time = None, και το {{ d.open_time.strftime(...) }} σκάζει με
        # UndefinedError — δηλαδή το dashboard έπεφτε 500 σε ΚΑΘΕ ΚΑΙΝΟΥΡΙΟ
        # σαλόνι, πριν προλάβει η ιδιοκτήτρια να πατήσει «ώρες λειτουργίας».
        # Οι τιμές είναι ίδιες με αυτές που σπέρνει η σελίδα salon_hours(), ώστε
        # το «τι θα δεις» και το «τι θα αποθηκευτεί» να είναι το ίδιο πράγμα.
        days = [SalonDaySettings(weekday=i, is_closed=(i == 6),
                                 open_time=time(9, 0), close_time=time(18, 0))
                for i in range(7)]

    stats = {
        "services": len(services),
        "active_services": len([s for s in services if s.is_active]),
        "groomers": len(groomers),
        "users": User.query.count(),
        "customers": Customer.query.count(),
        "pets": Pet.query.count(),
        "appointments": Appointment.query.count(),
        "closed_days": len([d for d in days if d.is_closed]),
    }
    return render_template(
        "admin/dashboard.html",
        services=services,
        groomers=groomers,
        days=days,
        stats=stats,
    )


# ------------------------------------------------------------------ χρήστες
def _any_admin_left(exclude_id: int) -> bool:
    """Υπάρχει άλλος χρήστης με δικαιώματα διοίκησης εκτός από αυτόν;

    Το παλιό φύλαγμα μετρούσε ιδιοκτήτες. Με τον υπεύθυνο, ο μετρητής
    έπρεπε να γίνει «έχει δικαιώματα διοίκησης» — αλλιώς η εφαρμογή θα
    έσβηνε τον τελευταίο υπεύθυνο και θα έμενε χωρίς πρόσβαση στη Διοίκηση."""
    return User.query.filter(
        User.role.in_(ADMIN_ROLES), User.id != exclude_id).count() > 0


@bp.route("/users", methods=["GET", "POST"])
def users():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "create":
            username = User.normalize_username(request.form.get("username"))
            email = User.normalize_email(request.form.get("email"))
            first_name = clean(request.form.get("first_name"))
            last_name = clean(request.form.get("last_name"))
            password = request.form.get("password") or ""
            role = clean(request.form.get("role")) or ROLE_STAFF
            if role not in (ROLE_OWNER, ROLE_MANAGER, ROLE_STAFF):
                role = ROLE_STAFF
            if not username:
                flash("Το όνομα χρήστη είναι υποχρεωτικό.", "error")
            elif len(username) < 3:
                flash("Το όνομα χρήστη πρέπει να έχει τουλάχιστον 3 χαρακτήρες.", "error")
            elif " " in username:
                flash("Το όνομα χρήστη δεν πρέπει να έχει κενά.", "error")
            elif User.query.filter(func.lower(User.username) == username.lower()).first():
                flash("Υπάρχει ήδη χρήστης με αυτό το όνομα χρήστη.", "error")
            elif email and User.query.filter(func.lower(User.email) == email).first():
                flash("Υπάρχει ήδη χρήστης με αυτό το email.", "error")
            elif email and ("@" not in email or "." not in email.split("@")[-1]):
                flash("Μη έγκυρο email.", "error")
            elif len(password) < MIN_PASSWORD_LENGTH:
                flash(
                    f"Ο κωδικός πρέπει να έχει τουλάχιστον {MIN_PASSWORD_LENGTH} χαρακτήρες.",
                    "error",
                )
            elif not first_name or not last_name:
                flash("Συμπληρώστε όνομα και επώνυμο.", "error")
            else:
                user = User(
                    username=username, email=email, role=role, first_name=first_name,
                    last_name=last_name, phone=clean(request.form.get("phone")) or None,
                )
                user.set_password(password)
                db.session.add(user)
                db.session.flush()
                if role == ROLE_OWNER:
                    db.session.add(Groomer(user_id=user.id, sort_order=user.id, color="#B0567A"))
                # Ο ΥΠΕΥΘΥΝΟΣ ΔΕΝ ΓΙΝΕΤΑΙ ΑΥΤΟΜΑΤΑ ΣΤΥΛΙΣΤΡΙΑ. Ο ιδιοκτήτης
                # γίνεται γιατί κουρίζει. Δικαιώματα ≠ δουλειά: αν ο
                # υπεύθυνος δεν κουρίζει, του σφήνουμε μια κενή στυλίστρια
                # που δεν βλέπει ποτέ ελεύθερο ραντεβού και μπερδεύει το
                # ημερολόγιο. Τη δίνει η ιδιοκτήτρια αν χρειαστεί.
                db.session.commit()
                flash(f"Ο χρήστης {first_name} {last_name} προστέθηκε.", "success")
        elif action == "toggle":
            user = db.session.get(User, form_int("user_id"))
            if user and user.id != current_user.id:
                user.is_active_flag = not user.is_active_flag
                db.session.commit()
                flash(
                    f"Ο λογαριασμός του {user.full_name} είναι "
                    f"{'ενεργός' if user.is_active_flag else 'απενεργοποιημένος'}.",
                    "info",
                )
        elif action == "change_password":
            user = db.session.get(User, form_int("user_id"))
            new_pass = request.form.get("new_password") or ""
            if user and len(new_pass) >= 6:
                user.set_password(new_pass)
                db.session.commit()
                flash(f"Ο κωδικός του χρήστη {user.full_name} άλλαξε.", "success")
            else:
                flash(
                    f"Ο κωδικός πρέπει να έχει τουλάχιστον {MIN_PASSWORD_LENGTH} χαρακτήρες.",
                    "error",
                )
        elif action == "delete":
            user = db.session.get(User, form_int("user_id"))
            if user is None:
                flash("Ο χρήστης δεν βρέθηκε.", "error")
            elif user.id == current_user.id:
                flash("Δεν μπορείτε να διαγράψετε τον εαυτό σας.", "error")
            elif user.is_admin and not _any_admin_left(user.id):
                flash("Πρέπει να υπάρχει τουλάχιστον ένας με δικαιώματα διοίκησης.",
                      "error")
            else:
                name = user.full_name
                db.session.delete(user)
                db.session.commit()
                flash(f"Ο χρήστης {name} διαγράφηκε.", "info")
        return redirect(url_for("admin.users"))

    rows = User.query.order_by(User.role, User.last_name, User.first_name).all()
    return render_template("admin/users.html", users=rows)


# ------------------------------------------------------------------ υπηρεσίες
@bp.route("/services", methods=["GET", "POST"])
def services():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "create":
            name = clean(request.form.get("name"))
            if not name:
                flash("Το όνομα της υπηρεσίας είναι υποχρεωτικό.", "error")
            else:
                db.session.add(
                    Service(
                        name=name,
                        description=clean(request.form.get("description")) or None,
                        category=clean(request.form.get("category")) or "Βασικές",
                        is_addon=form_bool("is_addon"),
                        sort_order=form_int("sort_order", 99),
                        price=max(0.0, form_float("price", 0) or 0.0),
                        duration_minutes=max(5, form_int("duration_minutes", 30) or 30),
                    )
                )
                db.session.commit()
                flash(f"Προστέθηκε η υπηρεσία «{name}».", "success")
        elif action == "update":
            service = db.session.get(Service, form_int("service_id"))
            if service:
                service.name = clean(request.form.get("name")) or service.name
                service.description = clean(request.form.get("description")) or None
                service.category = clean(request.form.get("category")) or service.category
                service.is_addon = form_bool("is_addon")
                service.is_active = form_bool("is_active")
                service.sort_order = form_int("sort_order", service.sort_order)
                service.price = max(0.0, form_float("price", service.price))
                service.duration_minutes = max(
                    5, form_int("duration_minutes", service.duration_minutes) or 30
                )
                db.session.commit()
                flash("Η υπηρεσία ενημερώθηκε.", "success")
        return redirect(url_for("admin.services"))

    items = Service.query.order_by(Service.category, Service.sort_order, Service.name).all()
    categories = sorted({s.category or "Λοιπά" for s in items})
    return render_template("admin/services.html", services=items, categories=categories)


@bp.route("/services/<int:service_id>/delete", methods=["POST"])
def service_delete(service_id: int):
    service = db.session.get(Service, service_id)
    if service is None:
        flash("Η υπηρεσία δεν βρέθηκε.", "error")
    else:
        name = service.name
        db.session.delete(service)
        db.session.commit()
        flash(f"Η υπηρεσία «{name}» διαγράφηκε.", "info")
    return redirect(url_for("admin.services"))


@bp.route("/services/<int:service_id>/toggle", methods=["POST"])
def service_toggle(service_id: int):
    service = db.session.get(Service, service_id)
    if service is None:
        flash("Η υπηρεσία δεν βρέθηκε.", "error")
    else:
        service.is_active = not service.is_active
        db.session.commit()
        flash(
            f"Η υπηρεσία «{service.name}» είναι {'ενεργή' if service.is_active else 'ανενεργή'}.",
            "info",
        )
    return redirect(url_for("admin.services"))


# ------------------------------------------------------------- ώρες λειτουργίας
@bp.route("/salon-hours", methods=["GET", "POST"])
def salon_hours():
    if request.method == "POST":
        for row in SalonDaySettings.query.all():
            row.is_closed = form_bool(f"closed_{row.weekday}")
            row.open_time = form_time(f"open_{row.weekday}") or row.open_time
            row.close_time = form_time(f"close_{row.weekday}") or row.close_time
            row.note = clean(request.form.get(f"note_{row.weekday}")) or None
        db.session.commit()
        flash("Οι ώρες λειτουργίας του Salon ενημερώθηκαν.", "success")
        return redirect(url_for("admin.salon_hours"))

    for wd in range(7):
        if not SalonDaySettings.query.filter_by(weekday=wd).first():
            db.session.add(
                SalonDaySettings(weekday=wd, is_closed=(wd == 6), open_time=time(9, 0),
                                 close_time=time(18, 0))
            )
    db.session.commit()
    days = SalonDaySettings.query.order_by(SalonDaySettings.weekday).all()
    return render_template("admin/salon_hours.html", days=days)


# ------------------------------------------------- κατάλογος εξόδων καταστήματος
@bp.route("/expense-items", methods=["GET", "POST"])
def expense_items():
    """Τα σταθερά έξοδα του μαγαζιού (ρεύμα, νερό, ενοικίαση…).

    Μετά τα επιλέγει η ιδιοκτήτρια γρήγορα από τη σελίδα Εξόδων, αντί να τα
    γράφει κάθε φορά από την αρχή.
    """
    if request.method == "POST":
        action = request.form.get("action")
        label = clean(request.form.get("label"))
        if action == "create":
            if not label:
                flash("Δώστε μια ονομασία για το έξοδο.", "error")
            else:
                db.session.add(
                    ExpenseItem(
                        label=label[:120],
                        category=clean(request.form.get("category")) or EXPENSE_STORE,
                        default_amount=max(0.0, form_float("default_amount", 0) or 0.0),
                        sort_order=form_int("sort_order", 99),
                    )
                )
                db.session.commit()
                flash(f"Προστέθηκε το έξοδο «{label}».", "success")
        elif action == "update":
            item = db.session.get(ExpenseItem, form_int("item_id"))
            if item is None:
                flash("Το έξοδο δεν βρέθηκε.", "error")
            else:
                item.label = clean(request.form.get("label")) or item.label
                item.category = clean(request.form.get("category")) or item.category
                item.default_amount = max(0.0, form_float("default_amount", 0) or 0.0)
                item.is_active = form_bool("is_active")
                item.sort_order = form_int("sort_order", item.sort_order)
                db.session.commit()
                flash("Το έξοδο ενημερώθηκε.", "success")
        return redirect(url_for("admin.expense_items"))

    items = ExpenseItem.query.order_by(
        ExpenseItem.category, ExpenseItem.sort_order, ExpenseItem.label
    ).all()
    return render_template("admin/expense_items.html", items=items)


@bp.route("/expense-items/<int:item_id>/delete", methods=["POST"])
def expense_item_delete(item_id: int):
    item = db.session.get(ExpenseItem, item_id)
    if item is None:
        flash("Το έξοδο δεν βρέθηκε.", "error")
    else:
        # Οι καταχωρημένες κινήσεις μένουν· απλώς χάνεται η συντόμευση.
        name = item.label
        db.session.delete(item)
        db.session.commit()
        flash(
            f"Το έξοδο «{name}» αφαιρέθηκε από τον κατάλογο. "
            "Οι καταχωρημένες κινήσεις παραμένουν.",
            "info",
        )
    return redirect(url_for("admin.expense_items"))


@bp.route("/expense-items/<int:item_id>/toggle", methods=["POST"])
def expense_item_toggle(item_id: int):
    item = db.session.get(ExpenseItem, item_id)
    if item is None:
        flash("Το έξοδο δεν βρέθηκε.", "error")
    else:
        item.is_active = not item.is_active
        db.session.commit()
        flash(
            f"Το έξοδο «{item.label}» είναι "
            f"{'διαθέσιμο' if item.is_active else 'κρυφό'}.",
            "info",
        )
    return redirect(url_for("admin.expense_items"))


# ----------------------------------------------------------------- ρυθμίσεις
@bp.route("/settings", methods=["GET", "POST"])
def settings():
    if request.method == "POST":
        keys = ["name", "tagline", "slogan", "logo_path", "icon_path",
                "phone", "email",
                  "address", "instagram", "slot_minutes"]
        for key in keys:
            if key in request.form:
                SalonSettings.set(key, clean(request.form.get(key)))
        db.session.commit()
        flash("Οι ρυθμίσεις αποθηκεύτηκαν.", "success")
        return redirect(url_for("admin.settings"))

    return render_template(
        "admin/settings.html",
        values=SalonSettings.as_dict(),
        backups=list_backups(),
        backups_folder=str(backups_dir()),
        mail=_mail_settings_view(),
    )


# ------------------------------------------------- email / υπενθυμίσεις (SMTP)

#: ΤΙ ΣΗΜΑΙΝΕ «ΚΕΝΟ» ΣΤΟ ΠΕΔΙΟ ΤΟΥ ΚΩΔΙΚΟΥ. Δεν το λέμε «κενό = κανένας
#: κωδικός», γιατί τότε η ιδιοκτήτρια θα έβλεπε το password να εξαφανίζεται με
#: ένα κενό πάτημα. Το κενό σημαίνει «άφησε ό,τι έχει ήδη αποθηκευτεί».
PW_KEEP = "__keep__"

#: Οι επιλογές ασφαλείας, όπως τις δέχεται ο mailer (app/mailer.py _connect).
#: Με την κενή επιλογή το port 465 χρειάζεται SSL, το 587 STARTTLS — και το
#: λάθος εδώ είναι ο #1 λόγος που ένα σωστό server/user/password δεν στέλνει.
_MAIL_SECURITY = (("starttls", "STARTTLS (συνηθισμένο, θύρα 587)"),
                  ("ssl", "SSL / TLS (θύρα 465)"),
                  ("none", "Καμία ασφάλεια (χωρίς κρυπτογράφηση)"))


def _mail_form_values() -> dict:
    """Τι ζητάει η φόρμα, ΣΤΗ ΣΙΓΜΑΤΙΚΗ ΜΟΡΦΗ ΤΟΥ .env. Χωρίς άγνωστα κλειδιά."""
    # ΤΑ ΟΝΟΜΑΤΑ ΤΩΝ ΠΕΔΙΩΝ, ΟΧΙ ΟΙ ΤΙΜΕΣ ΤΟΥΣ. Το form_bool()/form_int()
    # δέχονται το `name` και ψάχνουν μέσα στο request.form. Με το
    # request.form.get("mail_port") μέσα τους, ένα γέμισμα «587» ή «1»
    # έψαχνε ένα πεδίο που λέγεται «587» — δεν το βρίσκει, επιστρέφει την
    # προκαθορισμένη τιμή, και η ιδιοκτήτρια βλέπει «αποθηκεύτηκε» ενώ η
    # θύρα και το on/off ΔΕΝ άλλαξαν. Χωρίς σφάλμα, χωρίς ειδοποίηση.
    values = {
        "MAIL_ENABLED": "1" if form_bool("mail_enabled") else "0",
        "MAIL_SERVER": clean(request.form.get("mail_server")),
        "MAIL_PORT": str(form_int("mail_port", 587) or 587),
        "MAIL_SECURITY": clean(request.form.get("mail_security")) or "starttls",
        "MAIL_USER": clean(request.form.get("mail_user")),
        "MAIL_FROM": clean(request.form.get("mail_from")),
        "MAIL_FROM_NAME": clean(request.form.get("mail_from_name")),
    }
    if values["MAIL_SECURITY"] not in {v for v, _ in _MAIL_SECURITY}:
        values["MAIL_SECURITY"] = "starttls"
    # ΤΟ ΚΕΝΟ ΠΕΔΙΟ ΔΕΝ ΕΙΝΑΙ «ΚΑΝΕΝΑΣ ΚΩΔΙΚΟΣ». Χωρίς αυτό, ένα κενό
    # πάτημα στο Αποθήκευση θα έσβηνε τον κωδικό που μόλις δούλεψε.
    #
    # Γι' αυτό το «κενό = κράτα τον παλιό» είναι ΑΣΦΑΦΗΣ ΑΠΟΦΑΣΗ ΚΑΙ ΤΟ
    # ΠΡΩΤΟ ΑΠΟ ΤΑ ΔΥΟ ΣΗΜΕΙΑ. ΤΟ ΔΕΥΤΕΡΟ ΕΙΝΑΙ ΤΟ ΚΟΥΜΠΙ «διέγραψε τον»:
    # χωρίς αυτό, αν γραφτεί λάθος κωδικός (ή το σαλόνι περάσει σε relay
    # χωρίς authentication) ΔΕΝ υπάρχει τρόπος να φύγει — το πεδίο μένει
    # κενό πάντα, και η μόνη λύση θα ήταν να κάσει κάποιος με το χέρι το .env.
    password = request.form.get("mail_password") or ""
    if form_bool("mail_password_clear"):
        values["MAIL_PASSWORD"] = ""
    elif password:
        values["MAIL_PASSWORD"] = password
    if not values["MAIL_FROM"]:
        values["MAIL_FROM"] = values["MAIL_USER"]
    return values


def _mail_settings_view() -> dict:
    """Τι βλέπει η φόρμα. Ο ΚΩΔΙΚΟΣ ΔΕΝ ΕΠΙΣΤΡΕΦΕΤΑ ΠΟΤΕ.

    Ο κωδικός του SMTP μπαίνει στο .env, όχι στη βάση. Δεν υπάρχει λόγος να
    μπει στη σελίδα — και να μπει «μια φορά για να τον δει η ιδιοκτήτρια» σημαίνει
    ότι κάθε browser, κάθε browser-cache και κάθε screenshot της οθόνης κρατά
    το κωδικό του ταχυδρομείου της. Δείχνουμε μόνο ΑΝ υπάρχει.
    """
    cfg = current_app.config
    return {
        "enabled": bool(cfg.get("MAIL_ENABLED", True)),
        "server": cfg.get("MAIL_SERVER") or "",
        "port": cfg.get("MAIL_PORT") or 587,
        "security": (cfg.get("MAIL_SECURITY") or "starttls").lower(),
        "user": cfg.get("MAIL_USER") or "",
        "from": cfg.get("MAIL_FROM") or "",
        "from_name": cfg.get("MAIL_FROM_NAME") or "",
        "has_password": bool(cfg.get("MAIL_PASSWORD")),
        "ready": is_configured(),
        "missing": missing_settings(),
        "status": status(),
        "options": _MAIL_SECURITY,
    }


def _mail_error_hint(exc_type: str, detail: str) -> str:
    """Μεταφράζει ένα σφάλμα SMTP σε «τι να κάνω τώρα».

    Το ακριβές μήνυμα του smtplib («SMTPServerDisconnected») δεν λέει τίποτα
    σε κάποιον που προσπαθεί να στείλει το πρώτο του email. Τα κοινά
    αίτια είναι λίγα και συγκεκριμένα, και δίνουν τη σωστή ενέργεια.
    """
    text = (detail or "").lower()
    if "authentication" in text or "auth" in exc_type.lower() or "535" in text:
        return ("Τα διαπιστευτήρια δεν έγιναν δεκτά. Στο Gmail και στο Outlook "
                "χρειάζεται ΚΩΔΙΚΟΣ ΕΦΑΡΜΟΓΗΣ (app password), όχι ο κωδικός "
                "του λογαριασμού.")
    if "certificate" in text or "ssl" in exc_type.lower():
        return ("Το πιστοποιητικό απέτυχε. Δοκίμασε STARTTLS στη θύρα 587 "
                "αντί για SSL στη 465 — ή, για γεγονότα που είναι self-signed, "
                "το ζητούμενο είναι να μπει το πιστοποιητικό του διακομιστή.")
    if "name or service not known" in text or "getaddrinfo" in text \
            or "resolve" in text:
        return ("Δεν βρέθηκε ο διακομιστής. Ο τύπος του λάθους είναι «δεν "
                "υπάρχει αυτό το όνομα» — συνήθως είναι λάθος υλογραφήμενο, "
                "π.χ. smtp.gmail. com αντί για smtp.gmail.com.")
    if "connection refused" in text:
        return ("Η σύνδεση απορρίφθηκε. Σχεδόν πάντα είναι λάθος θύρα: το 587 "
                "θέλει STARTTLS, το 465 θέλει SSL.")
    if "timeout" in exc_type.lower() or "timed out" in text:
        return ("Ο διακομιστής δεν απάντησε. Μπορεί να είναι πρόβλημα δικτύου ή "
                "το τείχος προστασίας του σπατιού να κόβει τις εξερχόμενες "
                "θύρες 465/587.")
    return ("Η σύνδεση με τον διακομιστή απέτυχε. Ελέγξτε διακομιστή, θύρα και "
            "επιλογή ασφαλείας — και ότι ο κωδικός είναι κωδικός ΕΦΑΡΜΟΓΗΣ.")


@bp.route("/settings/mail", methods=["POST"])
@admin_required
def settings_mail():
    """Αποθήκευση SMTP στο .env, ή δοκιμαστική αποστολή με ΟΤΙ ΕΙΝΑΙ ΣΤΗ ΦΟΡΜΑ.

    ΔΥΟ ΚΟΥΜΠΙΑ, ΜΙΑ ΦΟΡΜΑ. Το κουμπί «Δοκιμή» ΔΕΝ αποθηκεύει πρώτα — στέλνει
    με ό,τι έχει γράψει η ιδιοκτήτρια αυτή τη στιγμή. Διαφορετικά θα έπρεπε να
    αποθηκεύσεις ρυθμίσεις που δεν ξέρεις αν δουλεύουν, και μετά να τις
    διορθώσεις — και αν έκανες λάθος στο αποθηκευμένο .env, το κακό έχει
    ήδη γραφτεί.
    """
    values = _mail_form_values()
    action = clean(request.form.get("action")) or "save"

    if action == "test":
        return _mail_test(values)

    # ── Αποθήκευση ────────────────────────────────────────────────────────
    path = env_file_path(config.BASE_DIR)
    try:
        changed = set_env_values(path, values)
    except OSError as exc:
        flash(f"Το αρχείο .env δεν μπήκε στο σωστό μέρος ({exc}). "
              "Οι ρυθμίσεις ΔΕΝ αποθηκεύτηκαν.", "error")
        return redirect(url_for("admin.settings") + "#mail")
    # ΠΡΙΝ το μήνυμα. Αν το os.replace πέτυχε αλλά κάτι έσκασε στο config,
    # η ιδιοκτήτρια πρέπει να ξέρει ότι το αρχείο ΓΡΑΦΤΗΚΕ — αλλιώς θα το
    # ξαναπατήσει και θα νομίσει ότι δεν αποθηκεύτηκε τίποτα.
    apply_to_runtime(current_app._get_current_object(), values)

    if changed:
        flash(f"Οι ρυθμίσεις email αποθηκεύτηκαν ({len(changed)} πεδία) και "
              "ισχύουν αμέσως.", "success")
    else:
        flash("Οι ρυθμίσεις email ήταν ήδη έτσι — τίποτα δεν άλλαξε.", "info")
    if not is_configured():
        flash("Ακόμα λείπουν: " + ", ".join(missing_settings())
              + ". Χωρίς αυτά δεν στέλνονται email υπενθυμίσεων.", "warning")
    return redirect(url_for("admin.settings") + "#mail")


def _mail_test(values: dict) -> redirect:
    """Στέλνει ένα δοκιμαστικό email με τις ΤΙΜΕΣ ΤΗΣ ΦΟΡΜΑΣ, όχι με τις
    αποθηκευμένες — και επιστρέφει τη φόρμα στην κατάσταση που ήταν.

    Η ΠΡΟΣΩΡΙΝΗ ΕΦΑΡΜΟΓΗ ΤΩΝ ΤΙΜΩΝ. Βάζουμε τις νέες τιμές στο config, στέλνουμε,
    και επαναφέρουμε τις παλιές. Χωρίς την επαναφορά, ένα «Δοκιμή» θα άφηνε
    τις μη-αποθηκευμένες τιμές στη μνήμη και η εφαρμογή θα συνέχιζε να στέλνει
    με αυτές μετά από restart που δεν έγινε ποτέ.
    """
    from .. import mailer

    app = current_app._get_current_object()
    to = clean(request.form.get("test_to")) or (
        current_user.email or SalonSettings.get("email") or "")

    saved: dict = {}
    for key, value in values.items():
        saved[key] = app.config.get(key)
        if key in {"MAIL_PORT", "MAIL_TIMEOUT"}:
            app.config[key] = int(value)
        elif key == "MAIL_ENABLED":
            app.config[key] = value == "1"
        else:
            app.config[key] = value

    try:
        if not is_configured():
            missing = ", ".join(missing_settings())
            flash(f"Δεν στάλθηκε: λείπουν {missing}. Για το Gmail και το "
                  "Outlook χρειάζεται κωδικός εφαρμογής, όχι ο κωδικός του "
                  "λογαριασμού.", "error")
            return redirect(url_for("admin.settings") + "#mail")

        if not to or "@" not in to:
            flash("Δεν στάλθηκε: η διεύθυνση παραλήπτη δεν είναι έγκυρη. "
                  "Γράψτε σε ποιον να πάει η δοκιμή.", "error")
            return redirect(url_for("admin.settings") + "#mail")

        result = mailer.send_email(
            to,
            f"Δοκιμή email — {SalonSettings.get('name') or 'Niki’s Grooming Salon'}",
            "Αυτό είναι ένα δοκιμαστικό email.\n\nΑν το διαβάζετε, ο διακομιστής "
            "email του σαλονιού λειτουργεί και οι υπενθυμίσεις θα φτάνουν.\n\n"
            "— Μπορείτε να το αγνοήσετε άνετα.",
        )
        if result.ok:
            flash(f"Στάλθηκε επιτυχώς στο {to}. Οι υπενθυμίσεις email θα "
                  "λειτουργούν.", "success")
        else:
            flash(f"Δεν στάλθηκε. {result.reason} "
                  + _mail_error_hint(mailer.status(), result.reason),
                  "error")
    except Exception as exc:                              # noqa: BLE001
        current_app.logger.exception("Η δοκιμή email απέτυχε")
        flash(f"Η δοκιμή απέτυχε ({type(exc).__name__}). Δες το "
              "logs/notifications.log για αναλυτικά.", "error")
    finally:
        for key, value in saved.items():
            app.config[key] = value
    return redirect(url_for("admin.settings") + "#mail")


# ------------------------------------------------------------- αντίγραφα βάσης

@bp.route("/settings/backup", methods=["POST"])
def create_backup():
    """Γράφει τη βάση σε αρχείο SQL μέσα στο instance/backups/."""
    try:
        info = create_sql_backup(clean(request.form.get("note", "")))
    except BackupError as exc:
        flash(str(exc), "error")
    else:
        flash(f"Δημιουργήθηκε αντίγραφο «{info['name']}» ({info['human_size']}).",
              "success")
    return redirect(url_for("admin.settings"))


@bp.route("/settings/backup/restore", methods=["POST"])
def restore_backup():
    """Επαναφέρει τη βάση από αρχείο SQL.

    Η εφαρμογή κλειδώνει σε λειτουργία συντήρησης και επανεκκινεί, γιατί
    αντικαθίσταται ολόκληρη η βάση ενώ η εφαρμογά κρατάει συνδέσεις.
    """
    name = request.form.get("name", "")
    try:
        peek_backup(name)              # επιβεβαίωση πριν κάνουμε οτιδήποτε
    except BackupError as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin.settings"))

    maintenance_on("Επαναφορά αντιγράφου βάσης")
    try:
        result = restore_sql_backup(name)
    except BackupError as exc:
        maintenance_off()
        flash(str(exc), "error")
        return redirect(url_for("admin.settings"))
    except Exception as exc:           # απροσδόκητο: κλειδώνουμε, μην αφήσουμε
        maintenance_off()
        flash(f"Η επαναφορά απέτυχε: {exc}", "error")
        return redirect(url_for("admin.settings"))

    flash(f"Η βάση επαναφέρθηκε από το «{result['name']}». "
          f"Η εφαρμογή επανεκκινεί τώρα.", "success")
    request_restart(reason="restore")
    return redirect(url_for("admin.settings"))


@bp.route("/settings/backup/delete", methods=["POST"])
def delete_backup():
    name = request.form.get("name", "")
    try:
        path = safe_backup_path(name)
    except BackupError as exc:
        flash(str(exc), "error")
        return redirect(url_for("admin.settings"))
    try:
        path.unlink()
        flash(f"Το αντίγραφο «{name}» διαγράφηκε.", "success")
    except OSError as exc:
        flash(f"Δεν ήταν δυνατή η διαγραφή: {exc}", "error")
    return redirect(url_for("admin.settings"))


@bp.route("/settings/backup/peek", methods=["POST"])
def peek_backup_view():
    """Πληροφορίες για ένα αντίγραφο, για επιβεβαίωση πριν την επαναφορά."""
    try:
        info = peek_backup(request.form.get("name", ""))
    except BackupError as exc:
        flash(str(exc), "error")
    else:
        flash(f"Το «{info['name']}» έχει {info['tables']} πίνακες και "
              f"περίπου {info['rows']} εγγραφές ({info['human_size']}).",
              "info")
    return redirect(url_for("admin.settings"))


@bp.route("/settings/logo", methods=["POST"])
def upload_logo():
    """Ανεβασμός λογότυπου μέσω διαλόγου επιλογής αρχείου.

    Παλιά ήταν πεδίο κειμένου με διαδρομή, και ο χρήστης έπρεπε να
    τοποθετεί μόνος το αρχείο στο app/static/ — αδύνατο, αφού ο φάκελος
    της εφαρμογής είναι μόνο για ανάγνωση. Τώρα το αρχείο ανεβαίνει από
    τον ίδιο τον browser και πάει στο instance/, που είναι εγγράψιμο και
    δεν αγγίζεται από τις ενημερώσεις.
    """
    # Το form_bool δέχεται το ΟΝΟΜΑ του πεδίου, όχι την τιμή — με την
    # τιμή ψάχνει ένα πεδίο που λέγεται "1" και επιστρέφει πάντα False.
    if form_bool("remove_logo"):
      logo.delete_logo()
      SalonSettings.set("logo_path", "")
      db.session.commit()
      flash("Το λογότυπο αφαιρέθηκε.", "success")
      return redirect(url_for("admin.settings"))

    upload = request.files.get("logo")
    if upload is None or not upload.filename:
      flash("Δεν επιλέχθηκε αρχείο λογότυπου.", "error")
      return redirect(url_for("admin.settings"))

    try:
      path = logo.save_logo(upload.read())
    except logo.LogoError as exc:
      flash(str(exc), "error")
    else:
      SalonSettings.set("logo_path", path)
      db.session.commit()
      flash("Το λογότυπο αντικαταστάθηκε.", "success")
    return redirect(url_for("admin.settings"))

@bp.route("/settings/icon", methods=["POST"])
@admin_required
def upload_icon():
    """Αποθήκευση ή αφαίρεση του ICO του σαλονιού.

    ΞΕΧΩΡΙΣΤΟ ΑΠΟ ΤΟ ΛΟΓΟΤΥΠΟ. Το ίδιο αρχείο δεν μπορεί να είναι και τα
    δύο: το λογότυπο είναι συνήθως οριζόντιο και στα 32px του συμπτυγμένου
    μενού θα διαβαζόταν σαν μπάρα. Και τα δύο κρατούνται χωριστά, ώστε η
    αλλαγή του ενός να μην σβήνει το άλλο — πράγμα που με μόνο «ένα αρχείο»
    θα συνέβαινε σιωπηλά.
    """
    if request.method != "POST":
        return redirect(url_for("admin.settings"))

    if form_bool("remove_icon"):
        logo.delete_icon()
        SalonSettings.set("icon_path", "")
        db.session.commit()
        flash("Το εικονίδιο αφαιρέθηκε.", "success")
        return redirect(url_for("admin.settings"))

    upload = request.files.get("icon")
    if upload is None or not upload.filename:
        flash("Δεν επιλέχθηκε αρχείο εικονιδίου.", "error")
        return redirect(url_for("admin.settings"))

    try:
        path = logo.save_icon(upload.read())
    except logo.LogoError as exc:
        flash(str(exc), "error")
    else:
        SalonSettings.set("icon_path", path)
        db.session.commit()
        flash("Το εικονίδιο αντικαταστάθηκε.", "success")
    return redirect(url_for("admin.settings"))
