#!/usr/bin/env python3
"""Εγκατάσταση της εφαρμογής ως μόνιμη εργασία στα Windows (Task Scheduler).

ΓΙΑΤΙ ΟΧΙ IIS
=============
Το HttpPlatformHandler είναι ένα ενδιάμεσο στρώμα ανάμεσα στο IIS και σε
μια διεργασία Python. Βάζει ανάμεσα επτά πιθανά σημεία αστοχίας: app pool,
ταυτότητα, κλειδωμένες config sections, rapid-fail, διαδρομή αρχείου
εξόδου, αντιστοιχίσεις handler, ώρες εκκίνησης. Καθένα από αυτά σταματάει
την εφαρμογή ΜΕ 404 ή 500, χωρίς να εμφανίζει τον πραγματικό λόγο.

Η ίδια η εφαρμογή τρέχει μόνη της μέσω του waitress, που είναι κανονικός
WSGI server. Για μια εφαρμογή σε ένα δίκτυο αυτή η διαφορά δεν έχει
σημασία — και τα Windows ξεκινούν μια εργασία κατά την εκκίνηση χωρίς
καμία εγκατάσταση.

ΤΙ ΚΑΝΕΙ
========
  1. Δημιουργεί τους φακέλους instance\\ και logs\\
  2. Δημιουργεί run_server.cmd που τρέχει την εφαρμογή και γράφει το log
  3. Δημιουργεί εργασία Task Scheduler που ξεκινά σε κάθε εκκίνηση
  4. Ελέγχει ότι η εφαρμογή απαντά πριν τελώσει

ΧΡΗΣΗ
=====
  python install_service.py                      # μόνο στο μηχάνημα
  python install_service.py --port 8080
  python install_service.py --local-only         # μόνο από τον ίδιο υπολογιστή
  python install_service.py --start
  python install_service.py --stop
  python install_service.py --status
  python install_service.py --uninstall
"""
from __future__ import annotations

import argparse
import ipaddress
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

IS_WINDOWS = os.name == "nt"
APP_DIR = Path(__file__).resolve().parent
TASK_NAME = "NikiSalonBooking"
DEFAULT_PORT = 8080
#: Χρώμα κωδικού — μόνο στην έξοδο.
GREEN, YELLOW, RED, DIM, RESET = "\033[32m", "\033[33m", "\033[31m", "\033[2m", "\033[0m"


def _enable_vt() -> bool:
    r"""Ενεργοποιεί τα ANSI escape sequences στην console των Windows.

    Τα Windows 10+ υποστηρίζουν χρώματα ANSI, αλλά ΜΟΝΟ όταν η console έχει
    ενεργό το ENABLE_VIRTUAL_TERMINAL_PROCESSING. Χωρίς αυτό, το cmd.exe
    τυπώνει τα escape codes ως κείμενο — «\033[32m[OK]\033[0m» — που είναι
    ακριβώς αυτό που έβλεπε ο χρήστης. Το Windows Terminal το έχει ενεργό
    από προεπιλογή· το παλιό conhost όχι.
    """
    if os.name != "nt":
        return True
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)          # STD_OUTPUT_HANDLE
        if not handle:
            return False
        mode = ctypes.c_uint32()
        if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        return bool(kernel32.SetConsoleMode(
            handle, mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING))
    except Exception:                                # noqa: BLE001
        return False


#: Χρώμα μόνο όταν ΚΑΙ είμαστε σε τερματικό ΚΑΙ η τερματική το καταλαβαίνει.
#: Ο συνδυασμός είναι απαραίτητος: το isatty() μόνο του επιστρέφει True στο
#: cmd.exe και το χρώμα τύπωνε σκουπίδια. Ο έλεγχος γίνεται μία φορά, στο
#: import, ώστε κάθε κλήση της _c να μην πληρώνει syscalls.
_HAS_COLOR = sys.stdout.isatty() and _enable_vt()


def _c(text: str, colour: str) -> str:
    return f"{colour}{text}{RESET}" if _HAS_COLOR else text


def step(text: str) -> None:
    print()
    print(_c(f"── {text} " + "─" * max(2, 58 - len(text)), DIM))


def ok(text: str) -> None:
    print(f"  {_c('[OK]', GREEN)}  {text}")


def warn(text: str) -> None:
    print(f"  {_c('[!]', YELLOW)}   {text}")


def fail(text: str) -> None:
    print(f"  {_c('[X]', RED)}   {text}")


def info(text: str) -> None:
    print(f"       {text}")


def is_admin() -> bool:
    if not IS_WINDOWS:
        return False
    try:
        return bool(subprocess.run(["net", "session"], capture_output=True,
                                   shell=False, timeout=20).returncode == 0)
    except Exception:                                  # noqa: BLE001
        return False


def schtasks(*args: str, timeout: int = 120) -> subprocess.CompletedProcess:
    return subprocess.run(["schtasks", "/Query", *args][:2] + list(args[2:]),
                          capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout)


def run_task(action: str, task: str) -> subprocess.CompletedProcess:
    """schtasks /create|delete|run|end — χωρίς shell, χωρίς quoting."""
    cmd = {
        "create": ["schtasks", "/Create", "/TN", task],
        "delete": ["schtasks", "/Delete", "/TN", task, "/F"],
        "run": ["schtasks", "/Run", "/TN", task],
        "end": ["schtasks", "/End", "/TN", task],
    }[action]
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=180)


def _python_works(exe: Path) -> bool:
    """Εκτελείται ΑΥΤΟΣ Ο ΠΡΑΓΜΑΤΙΚΑ Ο EXE; Όχι μόνο «υπάρχει».

    Το `C:\\Windows\\System32\\python.exe` ΥΠΑΡΧΕΙ ΣΕ ΚΑΘΕ Windows 10/11,
    αλλά είναι το άδειο alias του Microsoft Store: χωρίς Python εκεί, το
    άνοιγμά του σημαίνει «εγκατέστησε την Python από το Store» ή έξοδο
    χωρίς να τυπώσει τίποτα. Ο έλεγχος `exe.exists()` το έβλεπε ως εντάξει
    και η υπηρεσία πέθαινε στο ξεκίνημα, χωρίς να γράψει μία γραμμή.
    """
    if not exe.exists():
        return False
    try:
        r = subprocess.run([str(exe), "-c", "import sys; print(sys.version_info[0])"],
                           capture_output=True, text=True, timeout=120)
        return r.returncode == 0 and r.stdout.strip().isdigit()
    except Exception:                                  # noqa: BLE001
        return False


def python_exe() -> Path:
    """Η Python του venv αν υπάρχει, αλλιώς του συστήματος.

    Ο ΚΑΝΟΝΑΣ: μόνο Python που ΤΡΕΧΕΙ. Το ύπαρξη δεν αρκεί — βλ. _python_works.
    """
    venv = APP_DIR / ".venv" / "Scripts" / "python.exe"
    if _python_works(venv):
        return venv
    system = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "python.exe"
    if _python_works(system):
        return system
    # Τελευταία λύση: η Python που τρέχει ΑΥΤΗ ΤΗ ΣΤΙΓΜΗ το εργαλείο.
    # Ξέρουμε ότι δουλεύει, γιατί μόλις της τρέξαμε.
    return Path(sys.executable)


def write_runner(port: int, host: str) -> Path:
    """Γράφει το run_server.cmd — το μόνο σημείο που αλλάζει αν ποτέ η θύρα."""
    cmd = APP_DIR / "run_server.cmd"
    log = APP_DIR / "logs" / "service.log"
    # Ο ΚΩΔΙΚΟΣ ΕΞΟΔΟΥ ΤΗΣ ΕΦΑΡΜΟΓΗΣ. Όταν τον βλέπει το cmd, η εφαρμογή έχει
    # ήδη ξεκινήσει μόνη της τη νέα διαδικασία (app/updates.py:
    # RESTART_HANDOFF_EXIT) και πρέπει να ΣΤΑΜΑΤΗΣΕΙ. Χωρίς τη γραμμή με το 90,
    # το cmd ξαναφέρνει και την Python στα 5 δευτερόλεπτα: δύο διεργασίες για τη
    # θύρα {port}, η μία σκοτώνεται με "address already in use", και ο ατέρμονος
    # βρόχος ξαναφέρνει τη χαμένη για ώρες.
    #
    # ΤΟ ping ΑΝΤΙ ΓΙΑ ΤΟ timeout ΔΕΝ ΕΙΝΑΙ ΘΕΩΡΗΤΙΚΟ. Το `timeout` αποτυγχάνει με
    # «Input redirection is not supported» όταν τρέχει από προγραμματισμένη
    # εργασία, επειδή δεν έχει κονσόλα να διαβάσει. Ο βρόχος τότε γύριζε χωρίς
    # καθυστέρηση — όποτε η Python έπεφτε, ξαναξεκινούσε αμέσως και γέμιζε το
    # log. Το ping δεν διαβάζει stdin, δουλεύει πάντα, και το `-n 6` δίνει τα
    # ίδια περίπου 5 δευτερόλεπτα.
    body = f"""@echo off
chcp 65001 >nul
rem ============================================================
rem  Salon booking - service runner
rem  Generated by install_service.py - do not edit by hand.
rem ============================================================
cd /d "{APP_DIR}"
if errorlevel 1 exit /b 2
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONUNBUFFERED=1
if not exist "{log.parent}" mkdir "{log.parent}"
:run
"{python_exe()}" server.py --host {host} --port {port} >> "{log}" 2>&1
set "RC=%ERRORLEVEL%"
rem Exit code 90 means the app already started its own replacement.
rem Stop here, or two processes fight for the port.
if "%RC%"=="90" exit /b 0
echo [%DATE% %TIME%] service exited (code %RC%). Restarting in 5s. >> "{log}"
ping -n 6 127.0.0.1 >nul
goto run
"""


    # ΤΟ `chcp 65001` ΠΑΡΑΠΑΝΩ ΚΑΝΕΙ ΤΟ cmd.exe ΝΑ ΔΙΑΒΑΖΕΙ ΟΛΟ ΤΟ ΑΡΧΕΙΟ ΩΣ
    # UTF-8. Χωρίς αυτό, ένας δρόμος εγκατάστασης με ελληνικούς χαρακτήρες
    # («C:\Users\Γιάννης\...») μπερδεύεται, το `cd` αποτυγχάνει ΣΙΩΠΗΛΑ και η
    # εφαρμογή δεν ξεκινά ποτέ — χωρίς ούτε μία γραμμή στο log. Το ίδιο το
    # UTF-8 ταιριάζει με το PYTHONIOENCODING=utf-8, άρα το log δεν μπερδεύεται.
    #
    # ΚΑΙ Ο ΔΡΟΜΟΣ ΤΟΥ LOG ΕΙΝΑΙ ΑΠΟΛΥΤΟΣ. Με σχετικό «logs\service.log», αν
    # το `cd` αποτύχει ο redirect γράφει ΑΛΛΟΥ (π.χ. στο System32) και ο
    # ιδιοκτήτης βλέπει «το service.log δεν δημιουργήθηκε» ενώ το πρόβλημα
    # είναι άλλο. Έτσι «δεν υπάρχει log» σημαίνει πάντα «το cmd δεν έφτασε
    # ποτέ να τρέξει την εφαρμογή» — και τίποτα άλλο.
    cmd.write_text(body, encoding="utf-8", newline="\r\n")
    return cmd


def firewall_rule(port: int) -> None:
    """Άνοιγμα θύρας στο τείχος φωτιάς, μόνο αν ζητήθηκε πρόσβαση από δίκτυο."""
    step("Τείχος φωτιάς")
    name = f"NikiSalon {port}"
    try:
        subprocess.run(["netsh", "advfirewall", "firewall", "delete", "rule",
                        "name=" + name], capture_output=True, timeout=60)
    except Exception:                                  # noqa: BLE001
        pass
    try:
        result = subprocess.run(
            ["netsh", "advfirewall", "firewall", "add", "rule", f"name={name}",
             "dir=in", "action=allow", "protocol=TCP", f"localport={port}"],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=60)
        if result.returncode == 0:
            ok(f"Θύρα {port} επιτρέπεται από το δίκτυο.")
        else:
            warn(f"Δεν άνοιξε η θύρα {port}: "
                 f"{(result.stderr or result.stdout or '').strip()[:160]}")
    except Exception as exc:                          # noqa: BLE001
        warn(f"Παράλειψη τείχους φωτιάς: {exc}")


def _local_opener() -> "urllib.request.OpenerDirector":
    """Opener που ΔΕΝ περνά από proxy — για έλεγχο του 127.0.0.1.

    Το `urllib.request.urlopen` χρησιμοποιεί τις μεταβλητές HTTP_PROXY /
    http_proxy από το περιβάλλον. Σε μηχάνημα με proxy (εταιρείας, ή σπίτι
    με VPN) ο έλεγχος για το 127.0.0.1 πήγαινε στον proxy, εκεί δεν υπάρχει
    τίποτα να απαντήσει, και η εγκατάσταση έλεγε «η εφαρμογή δεν απάντησε»
    ενώ η εφαρμογή ήταν εντελώς υγιής. Ο proxy δεν έχει να κάνει με το
    localhost — και ο έλεγχος είναι του localhost.
    """
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def health(port: int, attempts: int = 40, delay: float = 2.0) -> bool:
    """Περιμένει να απαντήσει — η πρώτη εκκίνηση ανοίγει τη βάση.

    ΤΟ ΠΡΟΫΠΟΝ ΗΤΑΝ ΜΙΑ ΜΙΑ ΜΕ ΑΥΤΌ ΤΟ ΠΡΟΒΛΗΜΑ. Στα Windows 11 η εγκατάσταση
    άνοιγε τη θύρα 8080 στο τείχος φωτιάς κανονικά και μετά έλεγε ότι το
    /health δεν απάντησε. Δύο λόγοι, και οι δύο εδώ:

      · ΤΟ PROXY (παραπάνω) — το urlopen πήγαινε στον proxy.
      · Ο ΧΡΟΝΟΣ. 15 προσπάθειες × 2 δευτερόλεπτα = 30 δευτερόλεπτα. Μετά
        το pip install, το πρώτο ξεκίνημα κάνει import του Flask, τρέχει
        τις μετατροπές και σπέρνει τον κατάλογο — σε αργό δίσκο τα 30
        δευτερόλεπτα δεν προλαβαίνουν. Και το πραγματικό σύμπτωμα ήταν
        «μην κλείσετε το παράθυρο, η εγκατάσταση συνεχίζεται» σε μια
        εφαρμογή που εδώ έκανε 80 δευτερόλεπτα να σηκωθεί.
    """
    url = f"http://127.0.0.1:{port}/health"
    opener = _local_opener()
    last = ""
    for i in range(attempts):
        try:
            with opener.open(url, timeout=8) as response:
                if response.status == 200:
                    return True
                last = f"HTTP {response.status}"
        except urllib.error.HTTPError as exc:
            last = f"HTTP {exc.code}"
        except Exception as exc:                      # noqa: BLE001
            last = str(exc)[:120]
        if i < attempts - 1:
            time.sleep(delay)
    fail(f"Η εφαρμογή δεν απάντησε στο {url}")
    info(f"Περίμενα {int(attempts * delay)} δευτερόλεπτα. Τελευταίο σφάλμα: "
         f"{last or 'κανένα'}")
    diagnose(port)
    return False


def _binds(port: int, host: str, reuse: bool) -> bool:
    """Μπορώ να πάρω τη θύρα; Με ή χωρίς SO_REUSEADDR."""
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        if reuse:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            probe.bind((host, port))
            return True
        except OSError:
            return False


def _someone_answers(port: int) -> bool:
    """Απαντάει ΚΑΝΕΙΣ σε αυτή τη θύρα τώρα; Η οριστική ερώτηση."""
    import socket
    for loop in ("127.0.0.1", "localhost"):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                probe.settimeout(1.5)
                if probe.connect_ex((loop, port)) == 0:
                    return True
        except OSError:
            continue
    return False


def port_is_free(port: int, host: str = "0.0.0.0") -> bool:
    """Ελέγχει ΠΡΙΝ την εγκατάσταση αν κάτι άλλο κρατάει τη θύρα.

    Αν η 8080 είναι κατειλημμένη από άλλο πρόγραμμα, η εφαρμογή δεν
    ξεκινά, και το /health χτυπάει ΑΛΛΟ ΣΥΣΤΗΜΑ. Το σύμπτωμα ήταν «δεν
    απάντησε» χωρίς να υπάρχει λόγος — και η πρώτη σκέψη ήταν πάντα «κάτι με
    το τείχος φωτιάς». Εδώ λέμε την αλήθεια πριν.

    ΧΩΡΙΣ SO_REUSEADDR, ΕΠΙΔΕΜΕΛΩΣ. Δεν είναι μικρολεπτομέρεια: στα Windows
    αυτή η σημαία επιτρέπει σε ΔΥΟ διαδικασίες να δεσμεύσουν την ΙΔΙΑ θύρα και
    η δεύτερη να κλέψει τις συνδέσεις της πρώτης. Ο έλεγχός μας θα έλεγε
    «ελεύθερη» ενώ κάτι την κρατάει — χρήσιμος μόνο για να μας δώσει
    ψευδαισθημασία. Ο έλεγχος πρέπει να βλέπει αυτό που θα δει η εφαρμογή.
    """
    # 1. Απαντάει κάτι τώρα; Αν ναι, τελώνουμε — είναι οριστικό.
    if _someone_answers(port):
        return False
    # 2. Μπορώ να την πάρω με τον ίδιο τρόπο που θα τη δεσμεύσει η εφαρμογή;
    if _binds(port, host, reuse=False):
        return True
    # 3. Κολλάει, ΑΛΛΑ με SO_REUSEADDR δεσμεύεται. Άρα δεν την κρατάει
    #    κανείς «ζωντανά» — είναι απομόνωμα από μια πρόσφατη σύνδεση
    #    (TIME_WAIT), που σβήνει μόνη της. Δεν είναι σύγκρουση, και το
    #    wait_for_port του server.py θα ξαναδοκιμάσει. Να το πούμε αυτό,
    #    κι όχι να κολλήσουμε την εγκατάσταση σε λάθος συμπέρασμα.
    return _binds(port, host, reuse=True)


def _task_query(verbose: bool = True) -> tuple[str, str]:
    """(έξοδος, σφάλμα) του schtasks /Query. ΠΟΤΕ δεν σκάει."""
    args = ["schtasks", "/Query", "/TN", TASK_NAME]
    if verbose:
        args += ["/V", "/FO", "LIST"]
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=60)
        err = (r.stderr or "").strip()
        return (r.stdout or ""), (err if r.returncode else "")
    except Exception as exc:                           # noqa: BLE001
        return "", str(exc)


def _last_task_result() -> tuple[str, str]:
    """Το «Last Result» του scheduler, και το σφάλμα αν δεν το δώσανε.

    Χωρίς αυτό, η εγκατάσταση έφτανε στο «δεν απάντησε» και σταματούσε. Ο
    κωδικός του scheduler είναι το ΕΝΑ ΣΗΜΕΙΟ που λέει τον λόγο: 267009 =
    «η διαδρομή δεν βρέθηκε», 1 = η διεργασία τερμάτισε αμέσως, 2147942401 =
    «η εκτέλεση απέτυχε».

    ΕΠΙΣΤΡΕΦΕΙ ΚΑΙ ΤΟ ΣΦΑΛΜΑ, ΕΠΕΙΔΗ ΤΟ «Access denied» ΕΙΝΑΙ ΑΠΑΝΤΗΣΗ. Η
    ερώτηση σε εργασία που ανήκει στο SYSTEM θέλει δικαιώματα. Χωρίς αυτά,
    το εργαλείο έπρεπε να το πει ανοιχτά — αλλιώς ο ιδιοκτήτης έπρεπε να το
    μαντέψει από το ότι δεν εμφανίστηκε τίποτα.
    """
    out, err = _task_query(verbose=True)
    if not out:
        out, err = _task_query(verbose=False)
    for line in (out or "").splitlines():
        if "Last Result" in line or "Τελευταίο αποτέλεσμα" in line:
            return line.split(":", 1)[-1].strip(), ""
    return "", err


def diagnose(port: int) -> None:
    """Γιατί δεν σηκώθηκε η εφαρμογή — με συγκεκριμένο λόγο, όχι «ξαναπροσπάθησε».

    Το παλιό `health()` έκανε ένα πράγμα μόνο: έδινε το log, και αν δεν
    υπήρχε, έκανε μια πρόταση και σταματούσε. Χωρίς log, χωρίς διαγνωστική.
    Μετά από μια αποτυχημένη εγκατάσταση σε Windows με Python 3.13, ο
    ιδιοκτήτης είχε ένα σφάλμα 10061 και τίποτα άλλο — 30 λεπτά κυνήγι χωρίς
    να πει γιατί. Εδώ ρωτάμε τον scheduler και τρέχουμε το ίδιο αρχείο στο
    προσκήνιο, όπου το σφάλμα εμφανίζεται στην οθόνη αντί να χαθεί.
    """
    step("Διάγνωση")
    code, qerr = _last_task_result()
    if code:
        info(f"Scheduler «Last Result»: {code}")
        explained = {
            "267009": "δεν βρήκε το αρχείο .cmd (μήπως άλλαξε φάκελο η εγκατάσταση;)",
            "2147942401": "η διεργασία απέτυχε να εκτελεστεί (συνήθως: μη σωστή Python ή δικαιώματα).",
            "2147942650": "η διαδρομή δεν βρέθηκε ή δεν είναι προσβάσιμη.",
            "1": "η διεργασία τερμάτισε αμέσως χωρίς να γράψει τίποτα.",
            "2": "το αρχείο .cmd δεν μπόρεσε να εκτελεστεί.",
            "267011": "δεν ξεκίνησε ποτέ η εκτέλεση.",
        }
        for k, v in explained.items():
            if code.lstrip("0") == k.lstrip("0") or code == k:
                info(f"  → σημαίνει: {v}")
                break
    elif qerr:
        warn(f"Ο scheduler δεν απάντησε: {qerr[:160]}")
        info("Αυτό συνήθως σημαίνει ότι το παράθυρο δεν έχει δικαιώματα")
        info("Administrator. Το «Last Result» είναι ΑΚΡΙΒΩΣ η πληροφορία")
        info("που λείπει — και λέει τον λόγο με έναν αριθμό.")

    log = APP_DIR / "logs" / "service.log"
    if log.exists():
        info("Το τέλος του logs/service.log — εκεί είναι ο πραγματικός λόγος:")
        print()
        for line in log.read_text(encoding="utf-8", errors="replace").splitlines()[-30:]:
            print(f"       {line}")
        return

    warn("Δεν δημιουργήθηκε logs/service.log.")
    info("Αυτό σημαίνει ότι το run_server.cmd δεν έφτασε ποτέ να τρέξει την")
    info("εφαρμογή — το πρόβλημα είναι πριν την Python, όχι στην εφαρμογή.")
    print()
    info("Τρέχω το ίδιο αρχείο στο προσκήνιο, για να δούμε το πραγματικό σφάλμα:")
    print()
    runner = APP_DIR / "run_server.cmd"
    try:
        r = subprocess.run(["cmd.exe", "/c", str(runner)], cwd=str(APP_DIR),
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=25)
        out = ((r.stdout or "") + (r.stderr or "")).strip()
        if out:
            for line in out.splitlines()[-25:]:
                print(f"       {line}")
        else:
            info("  (δεν έγραψε τίποτα — μάλλον σκοτώθηκε αμέσως)")
    except subprocess.TimeoutExpired:
        info("  (συνέχισε να τρέχει και το σκότωσα μετά από 25s — ΑΥΤΟ ΕΙΝΑΙ")
        info("   το σωστό: σημαίνει ότι η εφαρμογή ξεκινά μόνη της, και το")
        info("   πρόβλημα είναι μόνο στο scheduler.)")
    except Exception as exc:                           # noqa: BLE001
        warn(f"  Δεν έτρεξε: {exc}")

    print()
    # Η ΕΦΑΡΜΟΓΗ ΔΟΥΛΕΥΕΙ ΧΕΙΡΟΚΙΝΑ. Αν το παραπάνω τρέξει και σταματήσει
    # αμέσως, ξέρουμε ότι το μόνο σπασμένο είναι ο scheduler — και η
    # εγκατάσταση δεν πρέπει να αφήνει τον ιδιοκτήτη χωρίς εφαρμογή.
    info("Αν η εφαρμογή ΣΗΚΩΘΕΚΕ μόλις την τρέξαμε, το πρόβλημα είναι μόνο")
    info("ο scheduler. Δουλεύει με αυτά τα δύο, χωρίς να ξαναεγκαταστήσεις:")
    print()
    print(f"     {APP_DIR / 'run_server.cmd'}          (το τρέχεις και στέλνεις)")
    print(f"     python {Path(__file__).name} --start      (ξαναπροσπαθεί ο scheduler)")
    print()
    info(f"Χειροκίνητα, χωρίς δικαιώματα, αν θέλεις να το δοκιμάσεις:")
    print(f"     cd /d {APP_DIR}")
    print(f"     {python_exe()} server.py --host 127.0.0.1 --port {port}")


def task_exists() -> bool:
    return run_task("run", TASK_NAME).returncode == 0 or _query() is not None


def _query() -> str | None:
    try:
        result = subprocess.run(["schtasks", "/Query", "/TN", TASK_NAME],
                                capture_output=True, text=True, encoding="utf-8",
                                errors="replace", timeout=60)
        return result.stdout if result.returncode == 0 else None
    except Exception:                                  # noqa: BLE001
        return None


def lan_ips() -> list[str]:
    ips: list[str] = []
    try:
        raw = subprocess.run(["ipconfig"], capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=30).stdout
    except Exception:                                  # noqa: BLE001
        return ips
    for line in raw.splitlines():
        if "IPv4" in line:
            parts = line.split(":")
            if len(parts) > 1:
                candidate = parts[-1].strip()
                try:
                    if ipaddress.ip_address(candidate).is_private:
                        ips.append(candidate)
                except ValueError:
                    pass
    return ips


def is_under_wwwroot() -> Path | None:
    """Επιστρέφει το wwwroot αν η εφαρμογή είναι μέσα του, αλλιώς None.

    ΚΡΙΣΙΜΟ: το IIS έχει πάντα το «Default Web Site» που σερβίρει ΟΛΟ ΤΟ
    wwwroot στο *:80:. Αν η εφαρμογή μένει μέσα στο wwwroot, κάθε υπολογιστής
    του δικτύου μπορεί να κατεβάσει ΤΑ ΔΕΔΟΜΕΝΑ ΣΟΥ:
        http://<IP>/niki-salon/instance/salon.db
        http://<IP>/niki-salon/.env      ← SECRET_KEY + κωδικός SMTP
    Το .env είναι .txt-συμπεριφοράς στο IIS: δεν «δεν βρίσκεται», κατεβάζεται.
    Γι' αυτό προτείνουμε C:/NikiSalon, έξω από το wwwroot.
    """
    try:
        parts = [p.lower() for p in APP_DIR.resolve().parts]
    except Exception:                                  # noqa: BLE001
        return None
    # Χωρίς [:−1]: αν η ίδια η εφαρμογή λέγεται wwwroot, είναι το ΣΥΝΟΛΟ
    # του φακέλου που σερβίρει το IIS — και πάλι πρέπει να προειδοποιήσουμε.
    for i, part in enumerate(parts):
        if part == "wwwroot":
            return Path(*APP_DIR.resolve().parts[:i + 1])
    return None


def warn_wwwroot() -> None:
    root = is_under_wwwroot()
    if root is None:
        return
    step("ΠΡΟΣΟΧΗ — η εφαρμογή είναι μέσα στο wwwroot")
    fail("Το Default Web Site του IIS σερβίρει ΟΛΟ ΤΟ wwwroot στο *:80:.")
    info("Όποιος είναι στο δίκτυο μπορεί να κατεβάσει αυτά, χωρίς κωδικό:")
    info('    http://<IP-ΤΟΥ-PC>/niki-salon/instance/salon.db')
    info('    http://<IP-ΤΟΥ-PC>/niki-salon/.env   ← SECRET_KEY, SMTP κωδικός')
    print()
    target = APP_DIR.drive + "\\NikiSalon"
    ok("Μεταφορά εκτός wwwroot (συνιστάται, διαρκεί 1 λεπτό):")
    print()
    print(f'       powershell -c "Stop-Process -Name w3wp -Force -EA SilentlyContinue; '
          f'robocopy \"{APP_DIR}\" \"{target}\" /MOVE /E"')
    print()
    info("Μετά τη μεταφορά, ξανατρέξε το install_service.py από τη νέα θέση.")
    print()


def lan_hint(local_only: bool, port: int) -> str:
    """Οι διευθύνσεις με τις οποίες προσπελάζεται η εφαρμογή."""
    lines = [f"Στο μηχάνημα αυτό: http://localhost:{port}/"]
    if not local_only:
        ips = lan_ips()
        for ip in ips:
            lines.append(f"Από άλλα μηχάνηματα: http://{ip}:{port}/")
        if not ips:
            lines.append("(Δεν βρέθηκε διεύθυνση δικτύου — "
                         "μπορεί να είναι απενεργοποιημένο το Wi-Fi/LAN.)")
    else:
        lines.append("Μόνο τοπικά — η θύρα δεν άνοιξε στο δίκτυο.")
    return "\n".join("   " + line for line in lines)


#: Οι δύο αυτοματισμοί που τρέχουν στο παρασκήνιο.
REMINDERS_TASK = "NikiSalon-Reminders"
BACKUP_TASK = "NikiSalon-Backup"


#: Επιλογές του schtasks ΠΟΥ ΔΕΝ ΙΣΧΥΟΥΝ για /SC ONSTART. Με οποιαδήποτε
#: από αυτές, το schtasks αποτυγχάνει ΟΛΟΚΛΗΡΑ:
#:   "The options /RI, /DU, /ST, /SD, /ET, /ED and /K are not applicable
#:    for the scheduled types: ONSTART, ONLOGON, ONIDLE, ONEVENT."
#: Ισχύουν μόνο για ONLOGON, DAILY, WEEKLY και MONTHLY.
INVALID_FOR_ONSTART = ("/RI", "/DU", "/ST", "/SD", "/ET", "/ED", "/K")


def task_create_args(cmd_file: Path) -> list[str]:
    """Τα ορίσματα δημιουργίας της εργασίας — μία πηγή αλήθειας.

    Χωρίς επανεκκίνηση εδώ, και αυτό είναι σωστό: το run_server.cmd έχει
    άπειρο βρόχο, οπότε αν πέσει η Python ξαναρχίζει μόνη της σε 5
    δευτερόλεπτα. Το /RI θα ήταν περιττό, και μάλιστα χαμένος χρόνος —
    αν τη σκοτώσει ο scheduler, κανένας χρόνος επανεκκίνησης δεν τη σώζει.

    Χωρίς /IT: σημαίνει «μόνο αν ο χρήστης είναι συνδεδεμένος», που δεν
    ισχύει ποτέ για τον SYSTEM.
    """
    return ["schtasks", "/Create", "/TN", TASK_NAME, "/TR", str(cmd_file),
            "/SC", "ONSTART", "/RU", "SYSTEM", "/RL", "HIGHEST", "/F"]


def setup_automation(python: Path, backup_dir: Path | None = None) -> None:
    """Δημιουργεί τις προγραμματισμένες εργασίες της εφαρμογής.

    Δύο αυτοματισμοί, και ΟΙ ΔΥΟ είναι σημαντικοί:
      · Υπενθυμίσεις ραντεβού κάθε 30 λεπτά (email στον πελάτη το προσού).
        Χωρίς αυτό η υπενθύμιση δεν στέλνεται ποτέ.
      · Αντίγραφο της βάσης κάθε βράδυ 02:00. Χωρίς αυτό, μία μέρα που
        πάει στραβά σημαίνει χαμένα δεδομένα πελατών.
    """
    step("Προγραμματισμένες εργασίες (χωρίς εσένα)")
    if not IS_WINDOWS:
        note("Μη-Windows: παραλείπεται.")
        return

    # --- υπενθυμίσεις: κάθε 30 λεπτά, ξεκινά από 1 λεπτό αργότερα ---
    # ΚΑΝΕΝΑ ΠΑΡΑΘΥΡΟ ΣΤΗΝ ΟΘΟΝΗ. Η εργασία έτρεχε απευθείας την
    # python.exe, που είναι console application: κάθε 30 λεπτά ανοίγε και
    # κλείγε ένα μαύρο παράθυρο στην οθόνη της ιδιοκτήτριας. Τώρα το ίδιο
    # .cmd περνά από VBS με window style 0.
    #
    # ΟΧΙ pythonw ΕΔΩ: η pythonw δεν έχει ούτε stdout, οπότε η έξοδος του
    # send-reminders (πόσα στάλθηκαν, αν λείπει το SMTP) θα χανόταν — και
    # μια εργασία που σταμάτησε να δουλεύει δεν θα το έδειχνε ποτέ.
    reminders_cmd = write_reminders_script(python)
    reminders_vbs = write_hidden_launcher(reminders_cmd)
    script = (
        f"$a = New-ScheduledTaskAction -Execute 'wscript.exe' "
        f"-Argument '//nologo {reminders_vbs}'; "
        # -Hidden κρύβει την εργασία και από τη λίστα του Task Scheduler.
        # Το ExecutionTimeLimit σκοτώνει μια εργασία που κόλλησε στο SMTP.
        f"$s = New-ScheduledTaskSettingsSet -Hidden "
        f"-ExecutionTimeLimit (New-TimeSpan -Minutes 10); "
        f"$t = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) "
        f"-RepetitionInterval (New-TimeSpan -Minutes 30) "
        f"-RepetitionDuration (New-TimeSpan -Days 3650); "
        f"Register-ScheduledTask -TaskName '{REMINDERS_TASK}' -Action $a -Trigger $t -Settings $s "
        f"-Description 'Salon booking - υπενθυμίσεις ραντεβού' "
        f"-RunLevel Highest -Force | Out-Null"
    )
    result = run_powershell(script)
    if result.returncode == 0:
        ok(f"Υπενθυμίσεις κάθε 30 λεπτά ({REMINDERS_TASK})")
    else:
        warn("Δεν δημιουργήθηκε η εργασία υπενθυμίσεων: "
             f"{(result.stderr or result.stdout or '').strip()[:200]}")

    # --- καθημερινό αντίγραφο ---
    if not backup_dir:
        warn("Χωρίς αυτόματο αντίγραφο. Τα αντίγραφα μένουν στο instance\backups")
        info("και μπορούν να γίνουν χειροκίνητα από Διαχείριση → Αντίγραφα.")
        return
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        warn(f"Ο φάκελος αντιγράφων δεν δημιουργήθηκε: {exc}")
        return
    # Γράφουμε το σενάριο σε αρχείο αντί να το μπλέξουμε σε κείμενο μέσα σε
    # κείμενο: τα Windows έχουν τρία επίπεδα quoting (cmd → PowerShell →
    # παράμετρος) και κάθε λάθος στο ένα σπάει τα άλλα δύο.
    backup_cmd = write_backup_script(backup_dir)
    # Το backup.cmd είναι console εφαρμογή. Το τρέχουμε μέσω VBS με
    # window style 0, αλλιώς στις 02:00 ανοίγει μαύρο παράθυρο — και αν ο
    # υπολογιστής είναι ανοιχτός, η ιδιοκτήτρια το βλέπει.
    launcher = write_hidden_launcher(backup_cmd)
    script = (
        f"$a = New-ScheduledTaskAction -Execute 'wscript.exe' "
        f"-Argument '//nologo {launcher}'; "
        f"$s = New-ScheduledTaskSettingsSet -Hidden "
        f"-ExecutionTimeLimit (New-TimeSpan -Minutes 30); "
        f"$t = New-ScheduledTaskTrigger -Daily -At '02:00'; "
        f"Register-ScheduledTask -TaskName '{BACKUP_TASK}' -Action $a -Trigger $t "
        f"-Settings $s "
        f"-Description 'Salon booking - antigrrafo vasis' "
        f"-RunLevel Highest -Force | Out-Null"
    )
    result = run_powershell(script)
    if result.returncode == 0:
        ok(f"Antigrrafo vasis ka8e vradu 02:00 -> {backup_dir}")
    else:
        warn("Den diktioithike i ergasia antigragfon: "
             f"{(result.stderr or result.stdout or '').strip()[:200]}")


def write_backup_script(backup_dir: Path) -> Path:
    """backup.cmd: σταματά την εφαρμογή, αντιγράφει τη βάση, την ξαναξεκινά."""
    cmd = APP_DIR / "backup.cmd"
    db = (APP_DIR / "instance" / "salon.db").as_posix()
    dest = backup_dir.as_posix()
    #
    # ΤΟ `ping` ΑΝΤΙ ΓΙΑ ΤΟ `timeout` ΔΕΝ ΕΙΝΑΙ ΘΕΩΡΗΤΙΚΟ. Το `timeout`
    # αποτυγχάνει με «Input redirection is not supported» όταν τρέχει από
    # προγραμματισμένη εργασία, επειδή δεν έχει κονσόλα να διαβάσει — και
    # ΑΥΤΟ ΤΟ ΑΡΧΕΙΟ ΤΡΕΧΕΙ ΑΠΟ ΠΡΟΓΡΑΜΜΑΤΙΣΜΕΝΗ ΕΡΓΑΣΙΑ, κάθε βράδυ
    # στις 02:00. Χωρίς την παύση, το `copy` έτριβε τη SQLite στη μέση της
    # εγγραφής. Ήταν το ίδιο μάθημα που είχαμε ήδη πληρώσει στο
    # run_server.cmd, ξεχασμένο στο δεύτερο αρχείο.
    #
    # ΤΟ CRLF ΓΡΑΦΕΤΑΙ ΡΗΤΑ. Το `newline=None` του write_text βασίζεται στο
    # os.linesep, άρα το αρχείο είναι σωστό μόνο όταν το γράφει Windows.
    # Ένα .cmd με LF τελώνει σε .cmd με LF, πάντα, ανεξάρτητα από το πού
    # γράφτηκε.
    body = f"""@echo off
rem Salon booking - daily database copy.
rem Generated by install_service.py. Do not edit by hand.
rem Stops the app so SQLite is not copied mid-write, copies, then restarts.
rem The timestamp is built by STRIPPING separators, not by slicing a
rem substring out of %date%: the position of the year depends on the
rem Windows language, so slicing yields 2026-29-09 on an English
rem machine. These comment lines carry no brackets or quote marks,
rem because cmd.exe parses rem lines too.
rem ASCII only: cmd.exe has its own code page, so Greek in a rem
rem line comes out garbled and can break the parser.
chcp 65001 >nul
if not exist "{dest}" mkdir "{dest}"
schtasks /End /TN "{TASK_NAME}" >nul 2>&1
rem ping, not timeout: timeout fails from a scheduled task (no console
rem to read), which would leave SQLite being copied mid-write.
ping -n 4 127.0.0.1 >nul
set "TS=%DATE%%TIME%"
set "TS=%TS:/=%"
set "TS=%TS::=%"
set "TS=%TS: =%"
set "TS=%TS:,=%"
set "TS=%TS:.=%"
copy /Y "{db}" "{dest}/salon_%TS%.db" >nul
if errorlevel 1 (
  echo [%DATE% %TIME%] BACKUP FAILED - see logs/backup.log >> "{APP_DIR.as_posix()}/logs/backup.log"
) else (
  echo [%DATE% %TIME%] backup ok >> "{APP_DIR.as_posix()}/logs/backup.log"
)
schtasks /Run /TN "{TASK_NAME}" >nul 2>&1
exit /b 0
"""
    cmd.write_text(body, encoding="utf-8", newline="\r\n")
    return cmd


def write_reminders_script(python: Path) -> Path:
    """Γράφει το run_reminders.cmd — υπενθυμίσεις κάθε 30 λεπτά, με log.

    ΓΙΑΤΙ .cmd ΚΑΙ ΟΧΙ ΜΙΑ pythonw ΑΠΕΥΘΕΙΑΣ: το pythonw.exe δεν έχει
    παράθυρο, αλλά ούτε και stdout — η έξοδος του «send-reminders» (πόσα
    στάλθηκαν, αν λείπει το SMTP) χάνεται. Αν οι υπενθυμίσεις σταματούν να
    φτάνουν στους πελάτες, η ιδιοκτήτρια δεν θα το μάθει ποτέ. Με το .cmd
    κρατάμε την έξοδο στο logs\reminders.log, και το ίδιο το .cmd κρύβεται
    από το VBS.

    Εδώ θέλουμε την python.exe, όχι την pythonw: εδώ θέλουμε την έξοδο.
    """
    cmd = APP_DIR / "run_reminders.cmd"
    logdir = APP_DIR / "logs"
    log = logdir / "reminders.log"
    #
    # Ο ΔΡΟΜΟΣ ΤΟΥ LOG ΕΙΝΑΙ ΑΠΟΛΥΤΟΣ, ΟΧΙ ΣΧΕΤΙΚΟΣ. Αν το `cd` αποτύχει
    # ποτέ, ένα `logs\reminders.log` γράφεται στο System32 και η ιδιοκτήτρια
    # λέει «οι υπενθυμίσεις έσπασαν» για λόγο που δεν είναι ο λόγος. Με
    # απόλυτο δρόμο, το «δεν υπάρχει log» σημαίνει πάντα «το cmd δεν
    # έφτασε ποτέ να τρέξει» - όπως ακριβώς στο run_server.cmd.
    #
    # ΚΑΙ ΤΟ `chcp 65001` ΠΡΕΠΕΙ ΝΑ ΠΡΟΗΓΕΙΤΑΙ ΤΟΥ `cd`. Χωρίς το, ένας
    # ελληνικός δρόμος («C:\Users\Γιάννης\...») κάνει το `cd` να αποτύχει
    # ΣΙΩΠΗΛΑ, και το `if errorlevel 1` παρακάτω δεν το πιάνει επειδή
    # δεν έχει εκτελεστεί καν.
    #
    # ΤΟ `if errorlevel 1 exit /b 2` ΜΕΤΑ ΤΟ `cd` ΜΕΤΑΦΡΑΖΕΙ ΤΟ ΙΔΙΟ ΠΡΑΓΜΑ
    # ΣΕ ΘΟΡΥΒΟ ΔΥΝΑΤΟ: αντί να συνεχίσει, σταματά.
    body = f"""@echo off
rem ============================================================
rem  Salon booking - reminders, every 30 minutes
rem  Generated by install_service.py - do not edit by hand.
rem
rem  ASCII only, and the log path is ABSOLUTE. Both are deliberate:
rem  cmd.exe has its own code page, so Greek here comes out garbled
rem  and can confuse the parser; and a relative log path silently
rem  writes to the wrong directory whenever the cd fails.
rem ============================================================
chcp 65001 >nul
cd /d "{APP_DIR}"
if errorlevel 1 exit /b 2
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set PYTHONUNBUFFERED=1
if not exist "{logdir}" mkdir "{logdir}"
echo [%DATE% %TIME%] --- reminders start --- >> "{log}"
"{python}" -m flask --app wsgi send-reminders >> "{log}" 2>&1
echo [%DATE% %TIME%] --- reminders end (code %ERRORLEVEL%) --- >> "{log}"
"""
    cmd.parent.mkdir(parents=True, exist_ok=True)
    cmd.write_text(body, encoding="utf-8", newline="\r\n")
    return cmd


def write_hidden_launcher(script: Path, wait: bool = True) -> Path:
    """VBS που τρέχει ένα .cmd ΧΩΡΙΣ να φανεί παράθυρο. Επιστρέφει το VBS.

    ΧΡΕΙΑΖΕΤΑΙ ΓΙΑΤΙ: τα αρχεία .cmd είναι console εφαρμογές. Όταν το Task
    Scheduler τα εκτελεί, ανοίγει μαύρο παράθυρο στην οθόνη της
    ιδιοκτήτριας. Το Task Scheduler δεν έχει «τρέξε το κρυφά» — μόνο το
    -Hidden, που κρύβει την εργασία στη ΛΙΣΤΑ, όχι το παράθυρο. Η μόνη
    εγγυημένη λύση είναι WScript.Shell με window style 0.

    Το αρχεί γράφεται ΜΟΝΟ με χαρακτήρες ASCII: ο VBScript διαβάζει το .vbs
    ως ANSI, και τα ελληνικά σχόλια θα έβγαιναν μπερδεμένα στο log.
    """
    if '"' in str(script):
        raise ValueError("the .cmd path must not contain a quote: " + str(script))
    # wait=True: το Task Scheduler πρέπει να βλέπει την ΠΡΑΓΜΑΤΙΚΗ διάρκεια.
    # Με False η εργασία «τελειώνει» αμέσως και ο επόμενος κύκλος μπορεί να
    # ξεκινήσει ενώ ο προηγούμενος ακόμα τρέχει.
    # Το _hidden στο όνομα ώστε να μην μπερδευτεί με το .cmd του ίδιου
    # stem (run_reminders.cmd + run_reminders_hidden.vbs).
    vbs = APP_DIR / (script.stem + "_hidden.vbs")
    vbs.parent.mkdir(parents=True, exist_ok=True)
    wait_str = "True" if wait else "False"
    vbs.write_text(
        "' Generated by install_service.py - runs a command with NO window.\n"
        "Set sh = CreateObject(\"WScript.Shell\")\n"
        'sh.Run "cmd.exe /c ""' + str(script) + '""", 0, ' + wait_str + '\n',
        encoding="ascii",
    )
    return vbs


def run_powershell(script: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive",
         "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=300)


def do_install(port: int, local_only: bool, quiet: bool) -> int:
    if not IS_WINDOWS:
        fail("Αυτό το σενάριο στοχεύει Windows.")
        return 1
    if not is_admin():
        fail("Χρειάζεται εκτέλεση ως Administrator (για να δημιουργηθεί η εργασία).")
        return 1

    host = "127.0.0.1" if local_only else "0.0.0.0"
    warn_wwwroot()
    step("Προετοιμασία")
    for name in ("instance", "logs"):
        (APP_DIR / name).mkdir(parents=True, exist_ok=True)
    ok("Φάκελοι έτοιμοι: instance\\, logs\\")

    exe = python_exe()
    ok(f"Python: {exe}")
    if not exe.exists():
        fail("Δεν βρέθηκε Python. Τρέξε πρώτα: python -m venv .venv")

    cmd_file = write_runner(port, host)
    ok(f"Δημιουργήθηκε {cmd_file.name}")

    # Η ΘΥΡΑ ΕΙΝΑΙ ΕΛΕΥΘΕΡΗ; ΤΟ ΕΛΕΓΧΟΥΜΕ ΠΡΙΝ ΑΠΟ ΟΤΙΔΗΠΟΤΕ ΑΛΛΟ.
    #
    # Αν η θύρα είναι κατειλημμένη, η εφαρμογή δεν ξεκινά και το `/health`
    # χτυπάει ΑΛΛΟ ΠΡΟΓΡΑΜΜΑ. Η εγκατάσταση έλεγε τότε «η εφαρμογή δεν
    # απάντησε στο /health» — και η πρώτη σκέψη ήταν πάντα «κάτι με το τείχος
    # φωτιάς». Στα Windows 11 η εγκατάσταση άνοιγε κανονικά τη θύρα στο δίκτυο
    # και μετά έλεγε αυτό. Τώρα λέμε ποιος την κρατάει.
    if not port_is_free(port):
        step(f"Θύρα {port}")
        fail(f"Η θύρα {port} χρησιμοποιείται ήδη από άλλο πρόγραμμα.")
        info("Η εφαρμογή δεν θα μπορέσει να σηκωθεί. Κλείσε ό,τι την")
        info("χρησιμοποιεί, ή εγκατέστησέ την σε άλλη θύρα:")
        info(f"    python install.py --port {port + 1}")
        info("")
        info(f"Να βεις τι την κρατάει:  netstat -ano | findstr :{port}")
        return 1

    step(f"Εργασία '{TASK_NAME}' (κάθε εκκίνηση)")
    result = subprocess.run(
        # ΧΩΡΙΣ /RI και /DU: το schtasks τα δέχεται ΜΟΝΟ σε ONLOGON, DAILY,
        # WEEKLY και MONTHLY. Με ONSTART αποτυγχάνει ολόκληρη η εντολή:
        #   "The options /RI, /DU, /ST, /SD, /ET, /ED and /K are not
        #    applicable for the scheduled types: ONSTART, ONLOGON..."
        # Χωρίς αυτό δεν χρειάζεται και καμία επανεκκίνηση εδώ: το
        # run_server.cmd έχει ήδη άπειρο βρόχο, οπότε αν πέσει η Python
        # ξαναξεκινά μόνη της σε 5 δευτερόλεπτα. Το /RI θα ήταν και
        # περιττό, και μάλιστα χαμένος χρόνος: αν η Python σκοτωθεί από
        # τον scheduler, κανένας χρόνος επανεκκίνησης δεν τη σώζει.
        # ΧΩΡΙΣ /IT επίσης: το /IT σημαίνει «μόνο αν ο χρήστης είναι
        # συνδεδεμένος», που δεν ισχύει ποτέ για τον SYSTEM.
        task_create_args(cmd_file),
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=180)
    if result.returncode == 0:
        ok("Η εργασία δημιουργήθηκε (ONSTART, ως SYSTEM).")
    else:
        fail("Η εργασία δεν δημιουργήθηκε.")
        info((result.stderr or result.stdout or "").strip()[:400])
        return 1

    if not local_only:
        firewall_rule(port)
    else:
        step("Τείχος φωτιάς")
        ok(f"Μόνο τοπική πρόσβαση — η θύρα {port} δεν άνοιξε στο δίκτυο.")

    step("Εκκίνηση & έλεγχος")
    run_task("run", TASK_NAME)
    if not health(port):
        return 1
    ok("Η εφαρμογή απάντησε.")

    print()
    print(_c("═" * 64, GREEN))
    print("  Η εφαρμογή τρέχει μόνιμα — χωρίς IIS.")
    print(_c("═" * 64, GREEN))
    print(lan_hint(local_only, port))
    print()
    print("   Έλεγχος :  python install_service.py --status")
    print("   Στοίχιο  :  logs\\service.log")
    print("   Σταμάτημα:  python install_service.py --stop")
    return 0


def do_status() -> int:
    step(f"Κατάσταση '{TASK_NAME}'")
    if not IS_WINDOWS:
        fail("Μόνο στα Windows.")
        return 1
    query = _query()
    if query is None:
        warn("Η εργασία δεν υπάρχει.")
        return 1
    for line in query.splitlines():
        if any(k in line for k in ("TaskName", "Status", "Last Run Time",
                                   "Last Result", "Task To Run")):
            print(f"       {line.strip()}")
    for port in (5000, 8080):
        if _alive(port):
            ok(f"Απαντά στο http://127.0.0.1:{port}/health")
            return 0
    warn("Η εφαρμογή δεν απαντά σε κανέναν αναμενόμενο port.")
    log = APP_DIR / "logs" / "service.log"
    if log.exists():
        info("Τέλος του logs/service.log:")
        for line in log.read_text(encoding="utf-8", errors="replace").splitlines()[-15:]:
            print(f"       {line}")
    return 1


def _alive(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=4) as r:
            return r.status == 200
    except Exception:                                  # noqa: BLE001
        return False


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Εγκατάσταση της εφαρμογής ως μόνιμη εργασία στα Windows.")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--local-only", action="store_true",
                        help="Να μην ανοίγει η θύρα στο δίκτυο.")
    parser.add_argument("--start", action="store_true")
    parser.add_argument("--stop", action="store_true")
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--uninstall", action="store_true")
    args = parser.parse_args()

    if args.status:
        return do_status()
    if args.stop:
        step("Διακοπή")
        result = run_task("end", TASK_NAME)
        ok("Σταμάτησε." if result.returncode == 0
           else "Η εργασία δεν εκτελούνταν ήδη.")
        return 0
    if args.start:
        step("Εκκίνηση")
        run_task("run", TASK_NAME)
        return 0 if health(args.port) else 1
    if args.uninstall:
        step("Αφαίρεση")
        run_task("end", TASK_NAME)
        result = run_task("delete", TASK_NAME)
        ok("Η εργασία διαγράφηκε." if result.returncode == 0 else "Δεν υπήρχε.")
        return 0
    return do_install(args.port, args.local_only, False)


if __name__ == "__main__":
    sys.exit(main())
