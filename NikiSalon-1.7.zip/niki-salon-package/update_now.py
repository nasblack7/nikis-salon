"""ΕΝΗΜΕΡΩΣΗ ΑΠΟ ΓΡΑΜΜΗ ΕΝΤΟΛΗΣ — η γέφυρα για την 1.0.1.

ΤΟ ΠΡΟΒΛΗΜΑ ΠΟΥ ΛΥΝΕΙ. Η 1.0.1 εγκαθιστά τις ενημερώσεις σε ΝΗΜΑ, και ένα νήμα
δεν έχει app context — οπότε η εγκατάσταση πέφτει στο πρώτο βήμα και η
αποτυχία χανόταν με «except UpdateError: pass». Ο ιδιοκτήτης έβλεπε
«μην κλείσετε τη σελίδα» και μετά τίποτα.

ΕΔΩ ΔΕΝ ΥΠΑΡΧΕΙ ΝΗΜΑ. Το σενάριο τρέχει στο κύριο thread και εισάγει
app context ρητά, οπότε ΟΛΑ ΛΕΙΤΟΥΡΓΕΙ — και μπορώ να το ελέγξω εδώ, σε
κάθε έκδοση, χωρίς Windows.

ΤΙ ΔΕΝ ΚΑΝΕΙ ΜΕ ΔΙΚΟ ΤΟΥ ΚΩΔΙΚΑ. Η υπογραφή ελέγχεται από το ΙΔΙΟ το
app/updates.py με το ΙΔΙΟ δημόσιο κλειδί. Αν είχα γράψει δικό μου έλεγχο
υπογραφής, θα είχα δύο υλοποιήσεις που μπορούν να διαφωνήσουν — και η δεύτερη
θα το θυμόμασταν μόνο όταν έσπαγε. Εδώ κανένας παράγοντας ασφαλείας δεν
γράφτηκε δύο φορές.
"""
from __future__ import annotations

import os
import sys
import traceback
import urllib.error
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

# Χωρίς αυτά, το config.py θα έπαιρνε τις τιμές από το παλιό .env ή θα
# τις έβρισκε ελλιπείς — και η εγκατάσταση θα σταματούσε με ασάφεια.
os.environ.setdefault("MAIL_ENABLED", "0")


#: Σφάλματα ΔΙΚΤΥΟΥ, όχι λογικής. Χρησιμοποιούνται ΜΟΝΟ για να γράψουμε
#: καλύτερο μήνυμα — η εγκατάσταση και η υπογραφή είναι του app/updates.py.
_NETWORK_ERRORS = (urllib.error.URLError, urllib.error.HTTPError,
                   TimeoutError, ConnectionError, OSError)


def _blame(step: str, message: str) -> str:
    """Προσθέτει στο μήνυμα το ΠΟΙΟ url έπεσε και ΠΟΙΟΣ είναι υπεύθυνος.

    Το όνομα του αρχείου το βγάζουμε από το ίδιο το μήνυμα, γιατί εκεί
    υπάρχει ήδη. Δεν προσπαθούμε να μαντέψουμε τίποτα: το μόνο που κάνουμε
    είναι να ξεχωρίσουμε τα δύο url, που είναι σίγουρη πληροφορία."""
    lowered = message.lower()
    if "404" not in message:
        return message

    if step == "check":
        # Ο έλεγχος κατεβάζει ΜΟΝΟ την περιγραφή. Άρα το 404 είναι
        # εκεί, και το .env του ιδιοκτήτη είναι όντως υπεύθυνο.
        return message + (
            "\n   Εδώ έπεσε η ΠΕΡΙΓΡΑΦΗ της ενημέρωσης (το μικρό update.json)."
            "\n   Αυτό το όνομα δίνεται από το UPDATE_URL στο .env — άρα"
            "\n   εδώ η ευθύνη είναι στη ρύθμιση αυτού του υπολογιστή.")

    # Η εγκατάσταση κατεβάζει ΤΟ ΑΡΧΕΙΟ. Αν το μήνυμα το λέει ρητά,
    # το χρησιμοποιούμε — είναι η πιο ακριβής πληροφορία που έχουμε.
    # ΑΛΛΙΩΣ η προεπιλογή είναι ΤΟ ΑΡΧΕΙΟ, επειδή στο βήμα «εγκατάσταση» το
    # μόνο url που κατεβάζεται είναι το .zip: την περιγραφή την έχει
    # κατεβάσει ήδη ο έλεγχος, που πέτυχε (αλλιώς δεν θα φτάναμε εδώ).
    # Χωρίς αυτή τη σαφή προεπιλογή, το `endswith` έπεφτε στο άδειο `tail` και
    # κατηγορούσε τον ιδιοκτήτη για το αρχείο που δεν ανέβηκε — δηλαδή
    # ακριβώς το λάθος που προσπαθούμε να διορθώσουμε.
    which = "ΤΟ ΑΡΧΕΙΟ της ενημέρωσης (το .zip)"
    for token in (".zip", "update.json"):
        if token in lowered:
            which = ("ΤΟ ΑΡΧΕΙΟ της ενημέρωσης (το .zip)" if token == ".zip"
                     else "η ΠΕΡΙΓΡΑΦΗ (το update.json)")
            break
    verb = "δεν ανέβηκε το ίδιο το αρχείο"
    if which.startswith("η ΠΕΡΙΓΡΑΦΗ"):
        verb = "δεν βρέθηκε ούτε η περιγραφή"
    return message + (
        f"\n   Εδώ έπεσε {which}, όχι το UPDATE_URL σου."
        "\n   Το update.json βρέθηκε κανονικά — το πρόβλημα είναι ότι "
        f"{verb}."
        "\n   Δεν είναι θέμα αυτού του υπολογιστή: είναι θέμα ότι το αρχείο"
        "\n   δεν υπάρχει εκεί που το descriptor δείχνει. (Στο GitHub, ένα "
        "αρχείο"
        "\n   που ανεβαίνει ως RELEASE δεν βρίσκεται στο main, και "
        "αντίστροφα —"
        "\n   είναι δύο διαφορετικά μέρη. Ο προγραμματιστής πρέπει να ελέγξει "
        "πού"
        "\n   ανέβηκε.)")


def _force_utf8() -> None:
    """Κάνει την έξοδο UTF-8, ή τουλάχιστον ΑΝΕΞΑΡΤΗΤΗ από την κωδικοποίηση.

    ΤΟ ΣΦΑΛΜΑ ΠΟΥ ΔΙΟΡΘΩΘΗΚΕ ΕΔΩ. Στο αγγλικό Windows (cp437/cp1252) το
    print() της Python κωδικοποιεί με την τοπική κωδικοποίηση· το ελληνικό
    γίνεται «μπερδεμένα χαρακτήρες» ή «???». Ο ιδιοκτήτης είδε ένα μήνυμα
    στα αγγλικά-παραξένα και δεν έμαθε τι είχε πάθει — που ήταν ακριβώς το
    πρόβλημα που η γέφυρα υπάρχει για να λύσει.

    Ένα δεύτερο πρόβλημα: το errors="replace" είναι ΥΠΟΧΡΕΩΤΙΚΟ. Χωρίς
    αυτό, ένα print() που δεν χωράει στην κωδικοποίηση σηκώνει
    UnicodeEncodeError, το οποίο σκοτώνει τη διαδικασία — και η ΠΡΑΓΜΑΤΙΚΗ
    αιτία της αποτυχίας χάνεται μαζί.
    """
    if os.name == "nt":
        # Ο console code page πρέπει να γίνει UTF-8, αλλιώς η Python θα
        # γράψει σωστά bytes που η κονσόλα θα τα διαβάσει λάθος.
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleCP(65001)
        except Exception:                              # noqa: BLE001
            pass                      # δεν κρίσιμο — το αρχείο καταγραφής
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:                              # noqa: BLE001
            pass


def _log_path() -> Path:
    """Αρχείο καταγραφής σε UTF-8. Η ΤΕΛΕΥΤΑΙΑ ΔΙΠΛΗ ΑΣΦΑΛΕΙΑ.

    Ακόμα κι αν η κονσόλα είναι σε cp437, ή δεν έχει γραμματοσειρά με
    ελληνικά (οι παλιές κονσόλες των Windows δείχνουν κουτιά), ο λόγος
    παραμένει εύγνωστος στο Notepad. Χωρίς αυτό το αρχείο, μια αποτυχία
    στο σαλόνι είναι αδιάγνωστη."""
    return APP_DIR / "logs" / "update-now.log"


_LOG_HANDLE = None


def _log(text: str) -> None:
    """Προσθέτει γραμμή στο αρχείο καταγραφής, ανοίγοντάς το ΜΙΑ ΦΟΡΑ.

    Η πρώτη εκδοχή είχε το guard ανάποδα: όταν το αρχείο υπήρχε ήδη,
    επέστρεφε ΧΩΡΙΣ να γράψει τίποτα. Δηλαδή το αρχείο περιείχε μόνο την
    επικεφαλίδα — δηλαδή ήταν ΑΚΡΙΒΩΣ άχρηστο στη στιγμή που το
    χρειαζόμαστε. Το έπιασε η δοκιμή κωδικοποίησης, όχι καμία εκτέλεση.
    """
    global _LOG_HANDLE
    if _LOG_HANDLE is None:
        try:
            path = _log_path()
            path.parent.mkdir(parents=True, exist_ok=True)
            # 'w': το αρχείο δείχνει την ΤΕΛΕΥΤΑΙΑ προσπάθεια. Δέκα
            # παλιές αποτυχίες μέσα σε ένα αρχείο μπερδεύουν τον
            # ιδιοκτήτη — και το ερώτημα είναι «τι έπαθε ΤΩΡΑ».
            _LOG_HANDLE = path.open("w", encoding="utf-8")
            stamp = __import__("datetime").datetime.now()
            _LOG_HANDLE.write(
                "Ενημέρωση από γραμμή εντολής\n"
                f"Έναρξη: {stamp:%Y-%m-%d %H:%M:%S}\n" + "=" * 66 + "\n")
            _LOG_HANDLE.flush()
        except Exception:                              # noqa: BLE001
            _LOG_HANDLE = None           # χωρίς δίσκο: τυπώνουμε και τελός
            return
    try:
        _LOG_HANDLE.write(text + "\n")
        _LOG_HANDLE.flush()
    except Exception:                                  # noqa: BLE001
        pass


def line(text: str = "") -> None:
    _log(text)
    try:
        print(text, flush=True)
    except Exception:                                  # noqa: BLE001
        # Το τελευταίο πόρτα: αν ακόμα και το print() αποτύχει, γράφουμε
        # τους χαρακτήρες που πιάνονται. Η απώλεια του μηνύματος είναι
        # χειρότερη από την απώλεια της ομορφιάς.
        try:
            print(text.encode("ascii", "replace").decode("ascii"), flush=True)
        except Exception:                              # noqa: BLE001
            pass


def reason_line(text: str) -> None:
    """Γράφει ΛΟΓΟ ΑΠΟΤΥΧΙΑΣ και στην κονσόλα και στο αρχείο, με επιμονή.

    Το όνομα είναι το κρίσιμο: χωρίς αυτό, «κάτι πήγε στραβά» σε μια
    κωδικοποίηση που δεν διαβάζεται = κανένα ίχνος."""
    _log("")
    _log("!" * 66)
    _log(f"ΛΟΓΟΣ: {text}")
    _log("!" * 66)
    try:
        print("!" * 66, flush=True)
        print(f"REASON: {text}", flush=True)
        print("!" * 66, flush=True)
    except Exception:                                  # noqa: BLE001
        pass


def die(text: str, code: int = 1) -> None:
    line()
    line("=" * 66)
    line(f"  {text}")
    line("=" * 66)
    reason_line(text)
    try:
        line(f"  (ο λόγος γράφτηκε και στο: {_log_path()})")
    except Exception:                                  # noqa: BLE001
        pass
    sys.exit(code)


# ═════════════════════════════════════════════════════ διόρθωση 1.0.2
def _repair_backup(application) -> bool:
    """Αντικαθιστά τη σπασμένη backup_database, ΜΟΝΟ αν όντως είναι σπασμένη.

    ΕΛΕΓΧΕΙ ΠΡΩΤΑ ΑΝ ΧΡΕΙΑΖΕΤΑΙ. Αν η τρέχουσα έκδοση έχει ήδη σωστή
    συνάρτηση, δεν αγγίζουμε τίποτα — μια γέφυρα δεν πρέπει να «διορθώνει»
    μια έκδοση που είναι εντάξει. Η ανίχνευση γίνεται συγκρίνοντας τον
    ΚΩΔΙΚΑ της συνάρτησης, όχι τον αριθμό έκδοσης: μια επόμενη μικρή
    έκδοση θα μπορούσε να το διορθώσει χωρίς να αλλάξει τίποτα ορατό.
    """
    try:
        import migrate
    except Exception as exc:                          # noqa: BLE001
        line(f"  ! Δεν βρέθηκε το migrate.py: {exc}")
        return False

    current = getattr(migrate, "backup_database", None)
    if current is None:
        line("  ! Η έκδοση δεν έχει backup_database - τίποτα να διορθώσω.")
        return False

    source = ""
    try:
        import inspect
        source = inspect.getsource(current)
    except (OSError, TypeError):
        # Χωρίς πηγή δεν μπορώ να κρίνω. Η ΑΣΦΑΛΗΣ ΕΠΙΛΟΓΗ ΕΙΝΑΙ ΝΑ ΜΗΝ
        # ΑΓΓΙΞΩ ΤΙΠΟΤΑ: η σωστή συνάρτηση δεν χαλάει από το να μην
        # εγκατασταθεί ποτέ, ενώ μια λάθος αντικατάσταση μπορεί να
        # καταστρέψει αντίγραφο. Και το λέω στην ιδιοκτήτρια.
        line("  ! Δεν μπορώ να διαβάσω τον κώδικα της συνάρτησης -")
        line("    δεν πειράζω τίποτα. Αν η ενημέρωση σταματήσει στο")
        line("    αντίγραφο της βάσης, στείλε το αποτέλεσμα.")
        return False

    if "PRAGMA database_list" in source:
        return False          # Ηδη σωστή. Δεν αγγίζουμε τίποτα.

    line("  · Διορθώνω το αντίγραφο της βάσης για αυτή την έκδοση.")
    line("    (Η 1.0.2 χειρουργεί το URL και στα Windows δεν βρίσκει το")
    line("     αρχείο. Χωρίς αυτό, η ενημέρωση σταματά στο βήμα 2.)")

    import sqlite3
    from pathlib import Path as _Path
    from datetime import datetime as _dt

    def backup_database() -> _Path:
        # ΔΙΑΔΡΟΜΗ: ρωτάμε την SQLite, δεν διαβάζουμε το URL. Στα Windows
        # δίνει το απόλυτο μονοπάτι, όπως το ξέρει η ίδια.
        file = None
        with migrate.db.engine.connect() as conn:
            rows = conn.exec_driver_sql("PRAGMA database_list").fetchall()
        for row in rows:
            if len(row) >= 3 and row[1] == "main" and row[2]:
                file = _Path(row[2])
                break
        if file is None:
            raise RuntimeError("Δεν εντοπίστηκε αρχείο SQLite.")
        if not file.is_file():
            raise RuntimeError("Δεν βρέθηκε το αρχείο της βάσης: %s" % file)

        target = file.with_name(
            "%s.bak-%s%s" % (file.stem, _dt.now().strftime("%Y%m%d-%H%M%S"),
                             file.suffix))
        # ONLINE BACKUP: δουλεύει με το αρχείο ΑΝΟΙΧΤΟ, όπως είναι όσο
        # τρέχει η εφαρμογή. Στα Windows το απλό copy πέφτει.
        src = dst = None
        try:
            src = sqlite3.connect("file:%s?mode=ro" % file, uri=True)
            dst = sqlite3.connect(target)
            src.backup(dst)
        except sqlite3.Error as exc:
            for handle in (dst, src):
                if handle is not None:
                    try:
                        handle.close()
                    except sqlite3.Error:
                        pass
            try:
                target.unlink()
            except OSError:
                pass
            raise RuntimeError(
                "Αποτυχία αντιγράφου της βάσης: %s\nΑρχείο: %s"
                % (exc, file)) from exc
        finally:
            for handle in (dst, src):
                if handle is not None:
                    try:
                        handle.close()
                    except sqlite3.Error:
                        pass
        with sqlite3.connect("file:%s?mode=ro" % target, uri=True) as probe:
            probe.execute("PRAGMA quick_check").fetchone()
        return target

    migrate.backup_database = backup_database
    line("    Θα γίνει με τη μέθοδο της 1.0.3 (ασφαλές online backup).")
    return True


def _release_db_handles(application=None) -> bool:
    """Κλείνει τις συνδέσεις της βάσης, ώστε το αρχείο να μην είναι κλειδωμένο.

    ΣΤΑ WINDOWS ΕΝΑ ΑΝΟΙΧΤΟ ΑΡΧΕΙΟ ΔΕΝ ΑΝΤΙΓΡΑΦΕΤΑΙ. Η εφαρμογή κρατάει
    ανοιχτές τις συνδέσεις SQLAlchemy όσο τρέχει, οπότε χωρίς αυτό το
    αντίγραφο πέφτει με «the file is being used by another process».

    ΔΕΝ ΣΠΑΤΑΙ Η ΕΦΑΡΜΟΓΗ. Το `dispose()` κλείνει τις συνδέσεις, όχι την
    εφαρμογή· η επόμενη ερώτηση ανοίγει καινούρια μόνη της. Αν κάτι αποτύχει
    μετά, η ιδιοκτήτρία συνεχίζει να δουλεύει κανονικά.

    Το ίδιο υπάρχει ήδη στο app/backup.py για την επαναφορά από αντίγραφο —
    η ενημέρωση το παραλείπε. Εδώ το κάνουμε γιατί η 1.0.2 δεν το έχει.
    """
    # ΤΟ ΣΦΑΛΜΑ ΠΟΥ ΒΡΗΚΑ ΣΤΗ ΛΕΞΗ ΤΟΥ ΙΔΙΟΚΤΗΤΗ. Ο `db.engine` του Flask
    # χρειάζεται application context· χωρίς αυτόν πετάει «Working outside
    # of application context». Η εξαίρεση πιάνονταν και μηνυνόταν, αλλά το
    # dispose ΔΕΝ ΕΙΧΕ ΓΙΝΕΙ — άρα η βάση παρέμενε κλειδωμένη, που είναι
    # ΑΚΡΙΒΩΣ το πρόβλημα που η συνάρτηση υπάρχει για να λύσει.
    #
    # Η διόρθωση δεν είναι «να μην το κοιτά κανείς»: είναι να το κάνουμε
    # μέσα στο context, ώστε να κάνει τη δουλειά του. Το context δίνεται
    # από τον καλώντα — στην γέφυρα το ξέρει ήδη, το έχει ανοίξει για τον
    # έλεγχο λίγες γραμμές πιο κάτω.
    try:
        from app.extensions import db
        if application is not None:
            with application.app_context():
                db.engine.dispose()
        else:
            db.engine.dispose()
        return True
    except Exception as exc:                          # noqa: BLE001
        line(f"  ! Δεν έκλεισαν οι συνδέσεις της βάσης: {exc}")
        line("    Αυτό είναι θέμα της γέφυρας, όχι του υπολογιστή σου —")
        line("    μην κλείσεις άλλες εφαρμογές, δεν φταίνε. Αν η εγκατάσταση")
        line("    σταματήσει στο αντίγραφο, στείλε μου ολόκληρη την οθόνη.")
        return False


def main() -> int:
    _force_utf8()
    line()
    line("  Ενημέρωση από γραμμή εντολής")
    line("=" * 66)

    python = Path(sys.executable)
    expected = APP_DIR / ".venv"
    if not str(python).lower().startswith(str(expected).lower()):
        # Δεν είναι θανασιμό — απλώς το σημειώνουμε, γιατί μπορεί να τρέξει
        # από άλλο Python και τότε οι βιβλιοθήκες θα λείπουν.
        line(f"  ! Τρέχει με {python.name}, όχι με το .venv της εγκατάστασης.")
        line("    Αν αποτύχει, τρέξε το από το .venv.")
        line()

    try:
        from app import create_app
    except Exception as exc:                          # noqa: BLE001
        die(f"Δεν φορτώθηκε η εφαρμογή: {exc}\n"
            f"   Τις βιβλιοθήκες τις βρίσκεις στο .venv. Τρέξε το αρχείο από εκεί.",
            2)

    line("  Ανοίγω την εφαρμογή...")
    try:
        application = create_app()
    except Exception as exc:                          # noqa: BLE001
        die(f"Η εφαρμογή δεν άνοιξε: {exc}", 2)

    from app.updates import (UpdateError, check_for_update, install_update,
                             request_restart, rollback)
    from app.version import APP_VERSION

    # ── ΙΑΤΡΙΚΗ ΔΙΟΡΘΩΣΗ ΓΙΑ ΤΗ ΣΠΑΣΜΕΝΗ ΕΚΔΟΣΗ ─────────────────────
    # Η εγκατάσταση κάνει το αντίγραφο της βάσης ΠΡΙΝ κατεβάσει τη νέα
    # έκδοση, και το κάνει με το migrate.py ΤΗΣ ΤΡΕΧΟΥΣΑΣ ΕΚΔΟΣΗΣ. Στη
    # 1.0.2 αυτό το κομμάτι χειρουργεί το URL με αλφαβητικά και στα Windows
    # παράγει `C:/NikiSalon/instance/salon.db` — χωρίς ριζικό. Δεν βρίσκει
    # το αρχείο, επιστρέφει None, και η εγκατάσταση σταματά στο βήμα 2.
    # Η διόρθωση που πήγε στην 1.0.3 είναι μέσα στο zip, το οποίο ΔΕΝ ΕΧΕΙ
    # ΑΚΟΜΑ ΚΑΤΕΒΑΣΤΕΙ.
    #
    # Άρα η 1.0.2 δεν μπορεί να μεταβεί στην 1.0.3 μόνη της — και η ίδια η
    # γέφυρα έπεφτε στο ΙΔΙΟ σημείο, γιατί καλεί το install_update() της
    # εφαρμογής. Αντικαθιστώ τη μέθοδο ΠΡΙΝ την κλήση, με την ίδια λογική
    # της 1.0.3. Μετά την εγκατάσταση υπάρχει ήδη το σωστό migrate.py,
    # άρα δεν χρειάζεται επέμβαση για τις επόμενες ενημερώσεις.
    _repair_backup(application)
    # ΚΑΙ ΟΙ ΛΑΒΕΣ. Χωρίς αυτό, στα Windows το αρχείο της βάσης είναι
    # κλειδωμένο από την ίδια την εφαρμογή που τρέχει την εγκατάσταση.
    # Η ιδιοκτήτρια το παρατήρησε σωστά: «the dbase locked».
    if _release_db_handles(application):
        line("  · Άφησα τη βάση ελεύθερη για το αντίγραφο.")

    # ── ΠΡΟΕΛΕΓΧΟΣ: Η ΔΙΕΥΘΥΝΣΗ ΤΩΝ ΕΝΗΜΕΡΩΣΕΩΝ ──────────────────────
    # ΚΑΝΕ ΤΟ ΠΡΟΒΛΗΜΑ ΔΙΑΓΝΩΣΙΜΟ ΠΡΙΝ ΤΟΝ ΚΑΛΕΣΟ. Στη 1.0.1 ο φύλακας
    # HTTPS λέει μόνο «Οι ενημερώσεις κατεβάζονται μόνο από HTTPS» — που
    # είναι σωστό αλλά δεν λέει ΠΟΙΑ διεύθυνση βλέπει. Με ένα
    # http://localhost στο .env ο ιδιοκτήτης δεν έχει πώς να μάθει ότι το
    # πρόβλημα είναι εκεί. Θέλουμε να πεις ακριβώς ΤΙ να αλλάξει.
    try:
        _url = (application.config.get("UPDATE_URL") or "").strip()
    except Exception:                                  # noqa: BLE001
        _url = ""
    if not _url:
        reason = ('Δεν υπάρχει διεύθυνση ενημερώσεων (UPDATE_URL) στο '
                  'αρχείο .env.\n'
                  '  Διόρθωσε:  ' + str(APP_DIR / ".env"))
        reason_line(reason)
        die("Δεν μπορώ να ελέγξω για ενημερώσεις: " + reason, 3)
    if not _url.lower().startswith("https://"):
        line()
        line("  Η διεύθυνση ενημερώσεων ΔΕΝ είναι https:")
        line(f"    {_url}")
        line()
        if "localhost" in _url or "127.0.0.1" in _url:
            reason = (
                f"Η διεύθυνση είναι τοπική ({_url}).\n"
                "  Αυτό είναι ρύθμιση δοκιμής — δεν λειτουργεί στο σαλόνι,\n"
                "  γιατί οι ενημερώσεις κατεβάζονται ΜΟΝΟ με ασφαλές https.\n"
                "  Διόρθωσε το αρχείο .env στο φάκελο της εφαρμογής:\n"
                "    UPDATE_URL=https://raw.githubusercontent.com/\n"
                "               nasblack7/nikis-salon/main/update.json")
        else:
            reason = (f"Η διεύθυνση δεν ξεκινά με https: {_url}\n"
                      "  Οι ενημερώσεις κατεβάζονται μόνο με ασφαλές https, "
                      "για να μην πειραχτεί κάποιος την εγκατάσταση.")
        reason_line(reason)
        die("Η διεύθυνση ενημερώσεων δεν είναι ασφαλής (https).", 3)
    line(f"  Διεύθυνση: {_url}")

    # ── Έλεγχος: υπάρχει ενημέρωση; ────────────────────────────────────
    with application.app_context():
        line(f"  Τρέχεις την {APP_VERSION}. Ρωτάω τον διακομιστή...")
        try:
            info = check_for_update()
        except UpdateError as exc:
            die(_blame("check", f"Ο έλεγχος απέτυχε: {exc}") + "\n"
                "   Χωρίς σύνδεση με το internet δεν γίνεται έλεγχος.", 3)
        except _NETWORK_ERRORS as exc:
            # Η 1.0.1 ΔΕΝ ΕΧΕΙ ΑΥΤΗ ΤΗ ΜΕΤΑΦΡΑΣΗ. Σε αυτή τη γέφυρα τρέχει
            # Ο ΠΑΛΙΟΣ κώδικας, όπου ένα 503 ή ένα DNS που δεν απαντά
            # έφτανε ως ακατανόητο «HTTP Error 503». Δεν αντιγράφω τη
            # λογική της _fetch — μόνο τη ΦΡΑΣΗ του μηνύματος, που είναι
            # δουλειά της γέφυρας. Η υπογραφή παραμένει του app/updates.py.
            die(f"Δεν ήταν δυνατή η επικοινωνία με τον διακομιστή "
                f"ενημερώσεων: {exc}\n"
                "   Έλεγξε το internet ή τον διακομιστή που φιλοξενεί το "
                "update.json.", 3)
        except Exception as exc:                      # noqa: BLE001
            die(f"Απροσδόκητο σφάλμα στον έλεγχο: "
                f"{type(exc).__name__}: {exc}", 3)

        if not info.available:
            line(f"  Η εφαρμογή είναι ήδη ενημερωμένη ({APP_VERSION}).")
            line("  (Υπάρχει και η " + info.version + ", αλλά δεν είναι νεότερη.)")
            return 0

        line(f"  Διαθέσιμη: {info.version}  (τώρα {APP_VERSION})")
        if info.notes:
            line(f"  Σημειώσεις: {info.notes}")
        line()
        line("  Εγκαθιστώ. ΜΗΝ ΚΛΕΙΣΕΣ ΤΟ ΠΑΡΑΘΥΡΟ ΑΥΤΟ.")
        line("-" * 66)

        # ── Εγκατάσταση, με πρόοδο στην οθόνη ──────────────────────────
        # ΤΟ ΙΔΙΟ ΜΕ ΤΟΝ ΕΛΕΓΧΟ, ΓΙΑ ΤΟΝ ΙΔΙΟ ΛΟΓΟ. Ο 1.0.1 κωδικός
        # αφήνει και το σφάλμα του ΚΑΤΕΒΑΣΜΑΤΟΣ να περάσει ακατέργαστο —
        # το χειρότερο σημείο, γιατί εκεί γίνεται το μεγαλύτερο μέρος της
        # δουλειάς και το πιο πιθανό σημείο αποτυχίας.
        try:
            report = install_update(info)
        except UpdateError as exc:
            die(_blame("install", f"Η εγκατάσταση απέτυχε: {exc}") + "\n"
                "   Η παλιά έκδοση παραμένει ενεργή — τα δεδομένα σου "
                "είναι ασφαλή.", 4)
        except _NETWORK_ERRORS as exc:
            die(f"Η λήψη διακόπηκε: {exc}\n"
                "   Μπορεί να έχει κοπεί το internet. Δοκίμασε ξανά — "
                "αυτό που μπήκε ήδη δεν θα μπει δύο φορές.", 4)
        for step in report.steps:
            mark = "  [OK]  " if step.ok else "  [FAIL]"
            line(f"{mark} {step.name}")
            if step.detail:
                line(f"         {step.detail}")

    line("-" * 66)
    line()
    line(f"  Η {info.version} εγκαταστάθηκε.")
    line()
    line("  ΤΕΛΕΙΩΣΕ. ΧΡΕΙΑΖΕΤΑΙ ΜΟΝΟ ΝΑ ΑΝΟΙΞΕΣ ΞΑΝΑ ΤΟ ΣΑΛΟΝΙ:")
    line("    1· Κλείσε το παράθυρο του σαλονιού αν είναι ανοιχτό.")
    line("    2· Άνοιξέ το ξανά από τη διεύθυνση του σαλονιού στο browser.")
    line()

    # Η ΓΕΦΥΡΑ ΔΕΝ ΜΠΟΡΕΙ ΝΑ ΕΠΑΝΕΚΚΙΝΗΣΕΙ ΤΟ ΣΑΛΟΝΙ. Το `os._exit(0)`
    # σκοτώνει ΟΠΟΙΑΔΗΠΟΤΕ ΔΙΑΔΙΚΑΣΙΑ ΤΟ ΚΑΛΕΙ — εδώ, ΑΥΤΗ ΜΕΤΑ ΤΗ ΔΙΚΗ
    # ΤΗΣ. Η εφαρμογή στο browser είναι ΑΛΛΗ ΔΙΑΔΙΚΑΣΙΑ, άλλο παράθυρο,
    # και δεν την πειράζει καν.
    #
    # ΤΟ ΜΗΝΥΜΑ ΠΟΥ ΕΔΙΝΕ ΗΤΑΝ ΨΕΜΑ: έλεγε «Ζητήθηκε επανεκκίνηση»,
    # ενώ δεν ζητήθηκε τίποτα — κλείθηκε η ίδια η γέφυρα. Ο ιδιοκτήτης το
    # διάβασε, άνοιξε το σαλόνι, είδε «1.0.2» και σκέφτηκε ότι δεν
    # εγκαταστάθηκε τίποτα. Ένα μήνυμα που λέει «έγινε» όταν δεν έγινε
    # χρεώνει την εμπιστοσύνη σε όλη τη διαδικασία.
    try:
        request_restart(reason=f"update {info.version}")
        line("  (Η γέφυρα κλείνει τώρα. ΑΥΤΟ ΔΕΝ ΕΙΝΑΙ ΕΠΑΝΕΚΚΙΝΗΣΗ ΤΟΥ")
        line("   ΣΑΛΟΝΙΟΥ — μην το περιμένεις.)")
    except Exception as exc:                          # noqa: BLE001
        line(f"  · Η γέφυρα δεν έκλεισε μόνη της ({exc}).")
        line("    Αυτό δεν επηρεάζει την εγκατάσταση.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        die("Διεκόπηκε από τον χρήστη. Η εφαρμογή έμεινε ως ήταν.", 130)
    except SystemExit:
        raise
    except Exception:                                 # noqa: BLE001
        print(traceback.format_exc(), file=sys.stderr)
        die("Απροσδόκητο σφάλμα. Η εφαρμογή ΔΕΝ άλλαξε — "
            "μπορείς να την ξανανοίξεις κανονικά.", 9)
