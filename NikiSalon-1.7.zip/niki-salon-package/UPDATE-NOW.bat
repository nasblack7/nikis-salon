@echo off
REM ============================================================
REM  Salon booking - update from the command line.
REM
REM  WHY THIS FILE IS IN ENGLISH ONLY:
REM  cmd.exe reads a .bat file using the console's OEM code page -
REM  cp437 or cp1252 on most Windows machines - and NOT UTF-8.
REM  Greek text in a UTF-8 .bat comes out as unreadable garbage, and
REM  there is no way to fix it from inside the file.
REM  So this file stays pure ASCII and hands everything to
REM  update_now.py, which forces UTF-8 correctly.
REM
REM  This file does nothing on its own. It calls the venv Python
REM  with update_now.py. All the logic - download, signature check,
REM  install - lives in Python, where it can be tested.
REM
REM  update_now.py runs in the MAIN thread with an app context,
REM  which is exactly what the 1.0.1 "Install" button lacked.
REM
REM  The full output is also written to logs\update-now.log in
REM  UTF-8. If this window shows boxes instead of Greek, open
REM  that file in Notepad - the reason is always there.
REM
REM  SAME FOUR RULES AS INSTALL.bat, FOR THE SAME REASONS:
REM    1. pure ASCII, so the parser never loses its place
REM    2. CRLF line endings
REM    3. no parenthesis blocks - cmd counts brackets even
REM       inside quotes, and a quoted bracket ends the block early
REM    4. no percent sign inside a quoted argument
REM  Breaking rule 3 on a customer's machine produced a wall of
REM  "'xyz' is not recognized as an internal or external command"
REM  with no other symptom. The same four rules are documented at
REM  the top of INSTALL.bat, and probe_batch.py enforces both.
REM ============================================================

REM  chcp BEFORE cd, never after. cmd.exe hands the command line to
REM  the program in the console's current code page, so a Greek
REM  install path such as C:\Users\Niki\... fails the cd silently
REM  and the rest of the file runs from the wrong directory.
chcp 65001 >nul 2>&1
setlocal EnableExtensions
cd /d "%~dp0"
if errorlevel 1 goto :no_cd

set "PY=%~dp0.venv\Scripts\python.exe"
if exist "%PY%" goto :run

echo.
echo   The installation's Python was not found:
echo   "%PY%"
echo.
echo   This usually means the app is not installed yet.
echo   Please run C:\NikiSalon\INSTALL.bat first.
echo.
pause
exit /b 1

:run
"%PY%" "%~dp0update_now.py" %*
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" goto :failed
echo   Done.
goto :end

:failed
echo   The update did not finish - error %RC%.
echo.
echo   The full reason is in:  logs\update-now.log
echo   Open that file with Notepad - the Greek text is correct there.
echo.
echo   The app is still working on the previous version.
echo   You can open it normally.

:end
echo.
pause
exit /b %RC%

:no_cd
echo.
echo   [X]  Could not enter the application folder:
echo   "%~dp0"
echo.
echo   Close this window and open update_now.py from an explorer
echo   window instead, or tell the developer.
echo.
pause
exit /b 1
