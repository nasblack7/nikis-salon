"""
WSGI entry point — σύστημα διαχείρισης ραντεβού σαλονιού.

Χρήσιμο για εργαλεία που χρειάζονται ένα αντικείμενο `app`:
  · flask --app wsgi send-reminders
  · flask --app wsgi mail-status
  · flask --app wsgi create-user ...
  · waitress-serve --port=5000 wsgi:app

Η εκτέλεση μέσω IIS γίνεται με το server.py (διαβάζει το %HTTP_PLATFORM_PORT%).
"""

from app import create_app, force_utf8_stdio

# Τα logs του IIS (stdout.log) κρατούν UTF-8, οπότε το stdout πρέπει να
# είναι UTF-8, αλλιώς κάθε ελληνικό μήνυμα στα logs γίνεται \uXXXX.
force_utf8_stdio()

app = create_app()
