"""Εισαγωγή και εξαγωγή πελατών από/προς αρχείο Excel.

ΔΥΟ ΑΠΟΦΑΣΕΙΣ ΠΟΥ ΕΙΝΑΙ ΣΗΜΑΝΤΙΚΕΣ ΚΑΙ ΔΕΝ ΕΙΝΑΙ ΠΡΟΦΑΝΕΙΣ

═══════════════════════════════════════════════════════════════
1. Η ΕΙΣΑΓΩΓΗ ΔΕΝ ΣΤΑΜΑΤΑ ΣΤΗ ΜΙΣΗ ΔΙΑΔΡΟΜΗ
═══════════════════════════════════════════════════════════════
Μια ιδιοκτήτρια έχει 300 πελάτες να μπει. Αν η γραμμή 87 έχει λάθος email,
δεν θα πρέπει να χάσει και τις 299. Κάθε γραμμή αξιολογείται ΜΕΜΟΝΩΜΕΝΑ
και αναφέρεται: πόσοι μπήκαν, πόσοι απορρίφθηκαν και ΓΙΑΤΙ ο καθένας.
Χωρίς αυτό, η εισαγωγή είναι μια μαύρη τρύπα που ή εισάγει τα πάντα ή
τις πετάει.

ΚΑΘΕ ΑΠΟΡΡΙΨΗ ΕΙΝΑΙ ΣΥΓΚΕΚΡΙΜΕΝΗ. Η ιδιοκτήτρια πρέπει να ξέρει τι να
διορθώσει, όχι απλώς «μερικοί απέτυχαν». Άρα κάθε λόγος λέει το πρόβλημα
ΚΑΙ ΤΙ ΝΑ ΚΑΝΕΙ: «Άκυρο email: "pelatis@" — λείπει το @».

═══════════════════════════════════════════════════════════════
2. ΤΑ ΔΙΠΛΟΟΜΕΝΑ ΑΠΟΡΡΙΦΘΗΚΑΝ, ΟΧΙ ΔΙΠΛΟΟΜΕΝΑ
═══════════════════════════════════════════════════════════════
Η χειροκίνητη φόρμα δεν ελέγχει για διπλόομα — ορθά, γιατί μπορεί να υπάρχουν
δύο άνθρωποι με το ίδιο όνομα. Στην ΕΙΣΑΓΩΓΗ όμως το διπλόομο είναι σχεδόν
πάντα λάθος: κάποιος ξαναφόρτωσε το ίδιο αρχείο και θα είχαμε 600 πελάτες
στους 300. Γι' αυτό το τηλέφωνο ή το email που υπάρχει ήδη απορρίφθηκε με
ρητό λόγο — ώστε να το δει και να το διορθώσει, όχι να το χάσει σιωπηλά.
Το όνομα ΔΕΝ απορρίφθηκε μόνο του: δύο «Μαρία Παπαδοπούλου» είναι πιθανό.
"""
from __future__ import annotations

import re
from datetime import date, datetime

from .xlsx import Workbook
from .xlsx_read import read_table

# ─────────────────────────────────────────────────────────── πρότυπο Excel

#: Οι στήλες, με τις ΕΛΛΗΝΙΚΕΣ κεφαλίδες που βλέπει η ιδιοκτήτρια.
#: Οι δεύτερες τιμές είναι επεξηγήσεις που μπαίνουν στη 2η σειρά, ώστε να
#: τις βλέπει κανείς πριν γεμίσει — τις τρώει και οι δύο, αν τις αγνοήσει.
TEMPLATE_COLUMNS: list[tuple[str, str]] = [
    ("Ονοματεπώνυμο", "Υποχρεωτικό. Π.χ. Μαρία Παπαδοπούλου"),
    ("Τηλέφωνο", "Προαιρετικό. Οπαδήποτε μορφή"),
    ("Email", "Προαιρετικό. Π.χ. pelatis@example.com"),
    ("Διεύθυνση", "Προαιρετικό"),
    ("Σημειώσεις", "Προαιρετικό. Ελεύθερο κείμενο"),
    ("Σκύλος 1 - Όνομα", "Προαιρετικό"),
    ("Σκύλος 1 - Είδος", "σκύλος / γάτα / άλλο"),
    ("Σκύλος 1 - Φυλή", "Προαιρετικό"),
    ("Σκύλος 1 - Φύλο", "αρσενικό / θηλυκό / -"),
    ("Σκύλος 1 - Γέννηση", "Π.χ. 01/03/2021"),
    ("Σκύλος 1 - Βάρος (kg)", "Αριθμός, π.χ. 12.5"),
    ("Σκύλος 2 - Όνομα", "Προαιρετικό. Δεύτερο κατοικίδιο"),
    ("Σκύλος 2 - Είδος", "σκύλος / γάτα / άλλο"),
    ("Σκύλος 2 - Φυλή", "Προαιρετικό"),
    ("Σκύλος 2 - Φύλο", "αρσενικό / θηλυκό / -"),
    ("Σκύλος 2 - Γέννηση", "Π.χ. 01/03/2023"),
    ("Σκύλος 2 - Βάρος (kg)", "Αριθμός, π.χ. 8.2"),
]

HEADERS = [h for h, _ in TEMPLATE_COLUMNS]
GUIDE = [g for _, g in TEMPLATE_COLUMNS]

# ── πώς αναγνωρίζουμε τις στήλες ──────────────────────────────────────────
# Το Excel πειράζει τα κεφαλίδα: βάζει τόνους, αλλάζει πεζά/κεφαλαία, κόβει
# κενά. Χωρίς αυτή τη ζεύξη, η στήλη «ΤΗΛΕΦΩΝΟ » δεν ταιριάζει με «Τηλέφωνο»
# και η ιδιοκτήτρια βλέπει «η στήλη δεν αναγνωρίστηκε» χωρίς λόγο.
def _strip_tonos(text: str) -> str:
    """Κατάληψη τον τόνο, ΜΕ ΤΟ ΙΔΙΟ ΤΟ UNICODE.

    ΤΟ ΛΑΘΟΣ ΠΟΥ ΔΙΟΡΘΩΘΗΚΕ ΕΔΩ. Είχα γράψει πίνακα με το χέρι:
        str.maketrans("άέίόύήώ", "αειουυηηω")
    και ΠΕΣΕ με ValueError «the first two maketrans arguments must have
    equal length» — 7 γράμματα απέναντι σε 8. Ένας τυπογραφικός χαρακτήρας
    σε πίνακα τόνων, που σημαίνει ότι ΚΑΘΕ γράμμα έπρεπε να γραφτεί σωστά
    — και η μία παραλήψη σκοτώνει ΟΛΗ ΤΗΝ ΕΙΣΑΓΩΓΗ ΠΕΛΑΤΩΝ.

    Το Unicode ξέρει ήδη ποιος χαρακτήρας έχει τόνο: το NFD σπάει τον «ά»
    σε «α» + τονισμό, και αφαιρούμε τους τονισμούς. Έτσι καλύπτει και τα
    ΐ, ΰ, ώ, ά, έ — και όσα προσθέσουμε αύριο, χωρίς να γράψουμε τίποτα."""
    import unicodedata
    return "".join(ch for ch in unicodedata.normalize("NFD", text or "")
                   if not unicodedata.combining(ch))


def _norm(text: str) -> str:
    """Κάτω, χωρίς τόνους, χωρίς διαστικά — για να αναγνωρίζονται οι
    στήλες ανεξάρτητα από το πώς τις έγραψε η ιδιοκτήτρια."""
    s = _strip_tonos((text or "").lower())
    return re.sub(r"[\s_\-–—·.]+", " ", s).strip()


#: {_κανονικό_όνομα: κανονικό_όνομα} — μόνο για την αναγνώριση.
_NORM_HEADERS = {_norm(h): h for h in HEADERS}

#: Πιο συγκεκριμένα ονόματα που δεχόμαστε, για να μην παραβολιστεί η
#: κεφαλίδα. Το «Σκύλος 1 - Όνομα» γίνεται «σκυλος 1 ονομα».
_ALIASES = {
    "ονομα": "Ονοματεπώνυμο", "επωνυμο": "Ονοματεπώνυμο",
    "ονομα πελατη": "Ονοματεπώνυμο", "πελατης": "Ονοματεπώνυμο",
    "κινητο": "Τηλέφωνο", "κινητό": "Τηλέφωνο", "τηλεφωνο": "Τηλέφωνο",
    "tel": "Τηλέφωνο", "phone": "Τηλέφωνο", "μειλ": "Email",
    "διευθυνση": "Διεύθυνση", "σχολιο": "Σημειώσεις",
    "σημειωσεις": "Σημειώσεις", "notes": "Σημειώσεις",
}


def map_columns(header_row: list[str]) -> tuple[dict[str, int], list[str]]:
    """Επιστρέφει ({κανονικό όνομα κεφαλίδας: δείκτης στήλης}, άγνωστες).

    Το κλειδί ΕΙΝΑΙ ΤΟ ΚΑΝΟΝΙΚΟ ΟΝΟΜΑ, όχι ο αριθμός του. Το ίδιο λεξικό
    το διαβάζουν δύο μέρη — ο έλεγχος «υπάρχει η στήλη Ονοματεπώνυμο;» και το
    value(). Όταν ήταν αριθμός στο ένα και όνομα στο άλλο, ΚΑΘΕ αρχείο έπεφτε
    με «δεν βρέθηκε η στήλη Ονοματεπώνυμο» — η εισαγωγή δεν δούλευε καθόλου,
    χωρίς σφάλμα, χωρίς εξήγηση."""
    found: dict[str, int] = {}
    unknown: list[str] = []
    for i, cell in enumerate(header_row):
        key = _norm(cell)
        if not key:
            continue
        if key in _NORM_HEADERS:
            found.setdefault(_NORM_HEADERS[key], i)
            continue
        if key in _ALIASES:
            canonical = _ALIASES[key]
            found.setdefault(canonical, i)
            continue
        # Οι στήλες κατοικίδιων: «σκυλος 1 ονομα», «σκυλος 2 φυλη» κ.λπ.
        pet = re.match(r"^(?:σκυλος|κατοικιδιο|pet)\s*([12])\s+(.+)$", key)
        if pet:
            slot, field = int(pet.group(1)) - 1, pet.group(2)
            want = {"ονομα": "Όνομα", "ειδος": "Είδος", "φυλη": "Φυλή",
                    "φυλο": "Φύλο", "γεννηση": "Γέννηση",
                    "βαρος": "Βάρος (kg)", "βαρος kg": "Βάρος (kg)"}
            if field in want:
                found.setdefault(f"Σκύλος {slot + 1} - {want[field]}", i)
                continue
        if cell.strip():
            unknown.append(cell.strip())
    return found, unknown


# ────────────────────────────────────────────────────────── κανονικοποίηση

#: Κανονικοποίηση τόνων. Δείτε _strip_tonos γιατί δεν γράφεται πίνακας
#: με το χέρι — είχαμε «άέίόύήώ» απέναντι σε «αειουυηω» και το ValueError
#: σκότωνε ΟΛΗ ΤΗΝ ΕΙΣΑΓΩΓΗ, ενώ το όνομα ήταν σωστό στα μάτια.
def _fold(text: str) -> str:
    return _strip_tonos((text or "").strip().lower())
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s.]+(\.[^@\s.]+)+$")
_DATE_FORMATS = ("%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%Y-%m-%d",
                 "%d/%m/%y", "%m/%d/%Y")

SPECIES_MAP = {
    "σκυλος": "dog", "σκύλος": "dog", "dog": "dog", "κ": "dog",
    "γατα": "cat", "cat": "cat", "γ": "cat",
    "αλλο": "other", "άλλο": "other", "other": "other",
    "σκυλο": "dog", "γατ": "cat",
}
GENDER_MAP = {
    "αρσενικο": "male", "αρσενικό": "male", "male": "male", "α": "male",
    "θηλυκο": "female", "θηλυκό": "female", "female": "female", "θ": "female",
    "θηλυκια": "female", "θηλυκιά": "female",
    "": "unknown", "-": "unknown", "—": "unknown", "unknown": "unknown",
    "ουδετερο": "unknown", "ουδέτερο": "unknown",
}


def _text(value) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _digits(value) -> str:
    return "".join(ch for ch in str(value or "") if ch.isdigit())


def parse_date(value):
    """Ημερομηνία από ό,τι γράψει ο Excel. Επιστρέφει (date, λόγος_σφάλματος)."""
    raw = _text(value)
    if not raw:
        return None, ""
    # Το Excel δίνει σειρά (αριθμός ημερών από το 1899) όταν το κελί
    # «αναγνωριστεί» ως ημερομηνία. Το 1/1/2020 = 43831.
    if re.fullmatch(r"\d{5}(\.\d+)?", raw):
        try:
            serial = float(raw)
            if 1 <= serial <= 80000:
                base = date(1899, 12, 30)
                from datetime import timedelta
                return base + timedelta(days=int(serial)), ""
        except (ValueError, OverflowError):
            pass
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(raw, fmt).date(), ""
        except ValueError:
            continue
    return None, f'Άκυρη ημερομηνία γέννησης: "{raw}" (π.χ. 01/03/2021)'


def parse_number(value):
    """Αριθμός από ό,τι γράψει ο Excel. Επιστρέφει (τιμή, λόγος_σφάλματος)."""
    raw = _text(value)
    if not raw:
        return None, ""
    cleaned = raw.replace(",", ".").replace(" ", "")
    # Το Excel βάζει € ή kg στο ίδιο κελί αν το πληκτρολογήσει κάποιος.
    cleaned = re.sub(r"[^0-9.\-]", "", cleaned)
    if not cleaned or cleaned in ("-", ".", "-."):
        return None, ""
    try:
        num = float(cleaned)
    except ValueError:
        return None, f'Άκυρο βάρος: "{raw}" (γράψτε έναν αριθμό, π.χ. 12.5)'
    if num <= 0 or num > 200:
        return None, f'Άκυρο βάρος: "{raw}" (το βάρος είναι 0.1–200 kg)'
    return num, ""


# ─────────────────────────────────────────────────────────────── εξαγωγή

def _build_sheet(rows: list[list]) -> "Workbook":
    """Κοινός σκελετός για πρότυπο και εξαγωγή."""
    wb = Workbook()
    ws = wb.add_sheet("Πελάτες")
    ws.header_row(HEADERS)
    for row in rows:
        ws.add(list(row))
    ws.freeze("A2")            # η επικεφαλίδα μένει ορατή κάτω
    ws.widths_from([HEADERS] + rows)
    return wb


def export_customers(customers) -> bytes:
    """Κτίζει το .xlsx με τους πελάτες που ζητήθηκαν.

    Δεχόμαστε ΛΙΣΤΑ αντικειμένων, όχι όλη τη βάση, ώστε το ίδιο αρχείο να
    χρησιμεύει και για «κράτησε όλους» και για «κράτησε τους φίλτρου μου»
    (τηλεφώνημα, γράμμα, αναζήτηση). Αυτό που βλέπει η ιδιοκτήτρια στον
    κατάλογο είναι αυτό που πήρε."""
    rows = []
    for c in customers:
        pets = [p for p in (c.pets or []) if p.name or p.breed][:2]
        row = [_text(c.name), _text(c.phone), _text(c.email),
               _text(c.address), _text(c.notes)]
        for i in range(2):
            if i < len(pets):
                pet = pets[i]
                born, _ = parse_date(pet.birth_date)
                row += [_text(pet.name),
                        _text(pet.species_label),
                        _text(pet.breed),
                        _text(pet.gender_label if pet.gender != "unknown" else ""),
                        born.strftime("%d/%m/%Y") if born else "",
                        pet.weight_kg if pet.weight_kg is not None else ""]
            else:
                row += [""] * 6
        rows.append(row)
    return _build_sheet(rows).to_bytes()


def template_bytes() -> bytes:
    """Το κενό πρότυπο, με τη 2η σειρά να εξηγεί κάθε στήλη."""
    return _build_sheet([GUIDE]).to_bytes()


# ─────────────────────────────────────────────────────────────── εισαγωγή

class Rejected:
    """Μία γραμμή που δεν μπήκε, με τον λόγο — και τον αριθμό γραμμής
    του Excel, ώστε η ιδιοκτήτρια να τη βρει ανοίγοντας το αρχείο."""

    def __init__(self, row_no: int, name: str, reason: str):
        self.row_no = row_no
        self.name = name or "(χωρίς όνομα)"
        self.reason = reason

    def __repr__(self) -> str:
        return f"γρ.{self.row_no} {self.name}: {self.reason}"


class ImportResult:
    def __init__(self):
        self.inserted = 0
        self.pets = 0
        self.rejected: list[Rejected] = []
        self.skipped_blank = 0
        self.unknown_columns: list[str] = []
        self.total = 0

    @property
    def ok(self) -> bool:
        return self.inserted > 0

    def summary(self) -> str:
        parts = [f"Εισήχθησαν {self.inserted} πελάτες"]
        if self.pets:
            parts.append(f"και {self.pets} κατοικίδια")
        if self.rejected:
            parts.append(f"· {len(self.rejected)} απορρίφθηκαν")
        if self.skipped_blank:
            parts.append(f"· {self.skipped_blank} κενές γραμμές παραλείφθηκαν")
        return " ".join(parts)


def _pet_fields(base: int) -> dict:
    return {
        "name": base, "species": base + 1, "breed": base + 2,
        "gender": base + 3, "birth": base + 4, "weight": base + 5,
    }


def _build_pet(f, row, base: int, errors: list[str], label: str):
    """Φτιάχνει ένα κατοικίδιο από έξι στήλες. Επιστρέφει None αν η
    γραμμή του ζώου είναι κενή — που είναι το συνηθισμένο, όχι σφάλμα."""
    idx = _pet_fields(base)

    def cell(key):
        i = idx[key]
        return _text(row[i]) if 0 <= i < len(row) else ""

    name, species_raw = cell("name"), cell("species")
    breed, gender_raw = cell("breed"), cell("gender")
    born_raw, weight_raw = cell("birth"), cell("weight")
    if not any((name, breed, born_raw, weight_raw,
                species_raw if species_raw.lower() in SPECIES_MAP else "")):
        return None

    species = SPECIES_MAP.get(_fold(species_raw),
                              "dog")
    if species_raw and _fold(species_raw) \
            not in SPECIES_MAP:
        errors.append(f'{label}: άγνωστο είδος "{species_raw}" '
                      "(έγραψε σκύλος, γάτα ή άλλο)")

    gender = GENDER_MAP.get(_fold(gender_raw))
    if gender is None:
        errors.append(f'{label}: άγνωστο φύλο "{gender_raw}" '
                      "(έγραψε αρσενικό, θηλυκό ή -)")
        gender = "unknown"

    born, err = parse_date(born_raw)
    if err:
        errors.append(err)
    weight, err = parse_number(weight_raw)
    if err:
        errors.append(err)

    return {
        "name": name or None, "species": species, "breed": breed or None,
        "gender": gender, "birth_date": born, "weight_kg": weight,
    }


def import_customers(data: bytes, filename: str = ""):
    """Διαβάζει το αρχείο και εισάγει. ΕΠΙΣΤΡΕΦΕΙ ImportResult.

    ΔΕΝ κάνει commit — το κάνει ο καλών, για να δει πρώτα τα αποτελέσματα.
    Κάθε γραμμή γράφεται σε υπο-συναλλαγή, ώστε ένα σφάλμα στη γραμμή 87 να
    μην κυλίσει πίσω και τις 86 προηγούμενες."""
    from .extensions import db
    from .models import Customer, Pet

    result = ImportResult()
    rows = read_table(data, filename)
    if not rows:
        raise ValueError("Το αρχείο είναι κενό.")

    # Η κεφαλίδα μπορεί να είναι στη 1η ή στη 2η γραμμή: αν η 1η δεν έχει
    # καμία αναγνωρισμένη στήλη, δοκιμάζουμε την 2η. Έτσι δουλεύει και το
    # αρχείο που μοιράζουμε, και αυτό που η ιδιοκτήτρία έκανε «αποθήκευση
    # ως» χωρίς να κρατήσει την πρώτη σειρά.
    cols, unknown = map_columns(rows[0])
    header_at = 0
    if len(cols) < 2 and len(rows) > 1:
        cols2, unknown2 = map_columns(rows[1])
        if len(cols2) > len(cols):
            cols, unknown, header_at = cols2, unknown2, 1
    result.unknown_columns = unknown

    # Ένας χάρτης υπαρκόντων, χτισμένος ΜΙΑ ΦΟΡΑ. Το εναλλακτικό — ένα
    # SELECT * ανά γραμμή — σε 300 πελάτες σημαίνει 300 πλήρη τραβήγματα
    # του πίνακα, και το ίδιο τηλέφωνο να εμφανίζεται ξανά και ξανά.
    existing_phones: dict[str, str] = {}
    existing_emails: dict[str, str] = {}
    for c in Customer.query.all():
        digits = _digits(c.phone or "")
        if digits:
            existing_phones.setdefault(digits, c.name)
        if c.email:
            existing_emails.setdefault(c.email.strip().lower(), c.name)
    if "Ονοματεπώνυμο" not in cols:
        raise ValueError(
            "Δεν βρέθηκε η στήλη «Ονοματεπώνυμο». Χρησιμοποίησε το πρότυπο "
            "που κατεβάζεις από τη σελίδα Πελάτες.")

    def value(row, header):
        i = cols.get(header)
        if i is None or i >= len(row):
            return ""
        return row[i]

    for n, row in enumerate(rows[header_at + 1:], start=header_at + 2):
        result.total += 1
        if not any(_text(c) for c in row):
            result.skipped_blank += 1
            continue

        name = _text(value(row, "Ονοματεπώνυμο"))
        phone = _text(value(row, "Τηλέφωνο"))
        email = _text(value(row, "Email"))
        errors: list[str] = []

        if not name:
            result.rejected.append(
                Rejected(n, "", "Άδειο ονοματεπώνυμο — είναι υποχρεωτικό"))
            continue
        if not phone and not email:
            result.rejected.append(
                Rejected(n, name, "Ούτε τηλέφωνο ούτε email — χωρίς επαφή "
                                  "δεν ξέρουμε πώς να ειδοποιήσουμε"))
            continue
        if email and not _EMAIL_RE.match(email):
            result.rejected.append(
                Rejected(n, name, f'Άκυρο email: "{email}" (λείπει το @ '
                                  "ή έχει λάθος μορφή)"))
            continue

        # Διπλόομμα. Το τηλέφωνο συγκρίνεται ΜΕ ΤΑ ΨΗΦΙΑ ΤΟΥ, ώστε το
        # «210 985 0000» και το «2109850000» να βρίσκουν το ίδιο πρόσωπο.
        # Χωρίς αυτό, η δεύτερη εισαγωγή του ίδιου αρχείου δημιουργούσε
        # διπλόα τηλέφωνα, γιατί κανένας δεν ταίριαζε.
        phone_key = _digits(phone)
        hit_name, how = None, ""
        if phone_key and phone_key in existing_phones:
            hit_name, how = existing_phones[phone_key], "τηλέφωνο"
        elif email and email.lower() in existing_emails:
            hit_name, how = existing_emails[email.lower()], "email"
        if hit_name is not None:
            result.rejected.append(
                Rejected(n, name, f"Υπάρχει ήδη πελάτης με το ίδιο {how} "
                                  f"({hit_name})"))
            continue

        pets = []
        for slot, base in ((1, 5), (2, 11)):
            pet = _build_pet(value, row, base, errors, f"Σκύλος {slot}")
            if pet:
                pets.append(pet)
        if errors:
            result.rejected.append(Rejected(n, name, "· ".join(errors)))
            continue

        try:
            with db.session.begin_nested():
                customer = Customer(
                    name=name, phone=phone or None, email=email or None,
                    address=_text(value(row, "Διεύθυνση")) or None,
                    notes=_text(value(row, "Σημειώσεις")) or None,
                )
                db.session.add(customer)
                db.session.flush()
                for p in pets:
                    db.session.add(Pet(customer_id=customer.id, **p))
                db.session.flush()
        except Exception as exc:                    # noqa: BLE001
            result.rejected.append(
                Rejected(n, name, f"Δεν μπήκε στη βάση ({type(exc).__name__})"))
            continue

        result.inserted += 1
        result.pets += len(pets)

    return result
