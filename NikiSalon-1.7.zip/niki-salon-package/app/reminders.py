"""Ειδοποιήσεις πελατών με email — σύστημα διαχείρισης ραντεβού σαλονιού."""

from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta
from pathlib import Path

from flask import current_app, url_for

from config import LOG_DIR as LOGS_ROOT          # noqa: E402  (μόνο fallback)

from . import mailer
from .extensions import db
from .models import ROLE_OWNER, Appointment, Notification, SalonSettings, User

logger = logging.getLogger("salon.reminders")

KIND_WELCOME = "welcome"
KIND_CONFIRMATION = "confirmation"
KIND_REMINDER = "reminder"
KIND_CANCELLATION = "cancellation"

KIND_LABELS = {
    KIND_WELCOME: "Καλωσόρισμα",
    KIND_CONFIRMATION: "Επιβεβαίωση",
    KIND_REMINDER: "Υπενθύμιση",
    KIND_CANCELLATION: "Ακύρωση",
    "contact": "Μήνυμα από το κουμπί επικοινωνίας",
}

# ΕΠΙΤΗΔΕΣ ΟΥΔΕΤΕΡΟ. Παλαιότερα εδώ κατοικούσε το προσωπικό σλόγκαν ενός
# συγκεκριμένου ανθρώπου — και κάθε email που έφευγε από ΚΑΘΕ εγκατάσταση
# τελείωνε με αυτό, γραμμένο σαν να ήταν του πελάτη. Τώρα πρώτα ρωτάμε το
# σλόγκαν του ίδιου του σαλονιού (βλ. salon_context) και μόνο αν δεν υπάρχει
# πέφτουμε σε αυτό — ένα γενικό, χωρίς κανένα όνομα.
CLOSING_QUOTE = (
    "Ευχαριστούμε που μας εμπιστεύεστε το αγαπημένο σας κατοικίδιο."
)

# Ένα κατοικίδιο χωρίς όνομα δεν εξαφανίζεται από το μήνυμα: παίρνει την
# ίδια λέξη που χρησιμοποιεί η εφαρμογή παντού (βλ. Appointment.pets_label).
ANONYMOUS_PET = "χωρίς όνομα"


def _join_greek(words: list[str]) -> str:
    """Σύνδεση λέξεων με «και»: «Ρέξι», «Ρέξι και Μπίσκυ», «A, B και C»."""
    if len(words) < 2:
        return words[0] if words else ""
    if len(words) == 2:
        return f"{words[0]} και {words[1]}"
    return f"{', '.join(words[:-1])} και {words[-1]}"


def pet_names_label(pets) -> str:
    """Τα ονόματα ΟΛΩΝ των κατοικιδίων του ραντεβού σε μία φράση.

    ΠΡΙΝ, εδώ κατοικούσε ΜΟΝΟ το πρώτο κατοικίδιο — κι αν αυτό ήταν χωρίς
    όνομα, το θέμα και η πρώτη γραμμή του email έλεγαν γενικά «το κατοικίδιό
    σας», ακόμη κι αν το ραντεβού αφορούσε δύο σκύλους. Ο πελάτης δεν μπορούσε
    να πει ούτε πόσα κατοικίδια έχει στο ραντεβού.
    """
    labels = [((p.name or "").strip() or ANONYMOUS_PET) for p in pets]
    if not labels:
        return "το κατοικίδιό σας"
    if all(word == ANONYMOUS_PET for word in labels):
        return "το κατοικίδιό σας" if len(labels) == 1 else "τα κατοικίδιά σας"
    return _join_greek(labels)


def prep_note(pets) -> str:
    """Υπόμνηση για ειδικά αντικείμενα, μόνο αν χρειάζονται."""
    return (
        "Αν υπάρχει συνταγή ή ειδικό σαμπουάν, παρακαλώ φέρτε το μαζί σας. "
        "Αν χρειάζεται κάποιο συγκεκριμένο παιχνίδι ή άλλο αντικείμενο, "
        "παρακαλώ επίσης να το φέρετε."
    )


def service_groups(appointment) -> list[dict]:
    """Οι υπηρεσίες ομαδοποιημένες ανά κατοικίδιο, έτοιμες για εμφάνιση.

    ΧΩΡΙΣ αυτό, η «σύνοψη υπηρεσιών» έδινε μία λίστα ονομάτων και ο πελάτης
    δεν μπορούσε να δει ποια υπηρεσία αντιστοιχεί σε ποιο κατοικίδιο — ακριβώς
    ότι ρωτάει ο ιδιοκτήτης όταν ένα ραντεβού έχει δύο σκύλους.
    """
    many = len(list(appointment.pets)) > 1
    out: list[dict] = []
    for group in appointment.services_by_pet:
        if not group["links"]:
            continue
        pet = group["pet"]
        if not many:
            label = ""
        elif pet is not None:
            label = pet.display_name
        elif group["all_pets"]:
            label = "Όλα τα κατοικίδια"
        else:
            # Παλιό ραντεβού χωρίς καταχωρισμένο κατοικίδιο: το λέμε αντί
            # να μαντέψουμε σε ποιο ανήκει η υπηρεσία.
            label = "Χωρίς κατοικίδιο"
        parts = []
        for line in group["links"]:
            name = line["service"].name
            qty = int(line["quantity"] or 1)
            parts.append(f"{name} ×{qty}" if qty > 1 else name)
        out.append({"label": label, "text": ", ".join(parts)})
    return out


def services_block(groups: list[dict], fallback: str) -> str:
    """Το συμπλήρωμα της γραμμής «Υπηρεσίες:» για τα απλά κείμενα (txt).

    Με μία ομάδα μένει μία γραμμή, όπως πάντα. Με περισσότερες, κάθε
    κατοικίδιο παίρνει τη δική του γραμμή: μία γραμμή με δύο ευρετήρια
    διαβάζεται σαν σούπα και ο πελάτης ξεχνά ποιο είναι τι.
    """
    if not groups:
        return f"Υπηρεσίες: {fallback}"
    if len(groups) == 1:
        only = groups[0]
        prefix = f"{only['label']}: " if only["label"] else ""
        return f"Υπηρεσίες: {prefix}{only['text']}"
    lines = ["Υπηρεσίες:"]
    for group in groups:
        lines.append(f"{group['label']}: {group['text']}" if group["label"]
                     else f"  {group['text']}")
    return "\n".join(lines)


def owner_name() -> str:
    owner = User.query.filter_by(role=ROLE_OWNER).order_by(User.id).first()
    if owner is None:
        return ""
    full = f"{owner.first_name or ''} {owner.last_name or ''}".strip()
    return full


def salon_context() -> dict:
    info = SalonSettings.as_dict()
    phone = (info.get("phone") or "").strip()
    return {
        "salon": {
            "name": info.get("name") or "TEST PET SALON",
            "tagline": info.get("tagline") or "",
            "phone": phone,
            "phone_href": re.sub(r"[^\d+]", "", phone),
            "email": info.get("email") or "",
            "address": info.get("address") or "",
            "facebook": info.get("facebook") or "",
            "tiktok": info.get("tiktok") or "",
            "owner_name": owner_name(),
            # ΠΡΩΤΑ ΤΟ ΔΙΚΟ ΤΟΥΣ ΣΛΟΓΚΑΝ. Παλαιότερα εδώ υπήρχε πάντα ένα
            # έτοιμο σλόγκαν — το προσωπικό κείμενο ενός συγκεκριμένου
            # ανθρώπου — οπότε κάθε email έλεγε τα λόγια της.
            "closing_quote": (info.get("slogan") or "").strip() or CLOSING_QUOTE,
        },
        "brand": "#ff3091",
        "site_url": (current_app.config.get("PUBLIC_BASE_URL") or "").rstrip("/"),
        "logo_cid": mailer.LOGO_CID,
        "has_logo": mailer.logo_cid_path() is not None,
        "unsubscribe_hint": "#",
    }


def _first_word(full_name: str | None) -> str:
    """Από «Μαριάννα Νικολάου» το «Μαριάννα» για την απόστοση."""
    return (full_name or "").strip().split(" ")[0]


def _appointment_context(appointment: Appointment, base: dict) -> dict:
    customer = appointment.customer
    # Ένα ραντεβού μπορεί να αφορά περισσότερα από ένα κατοικίδιο.
    pets = list(appointment.pets)
    pet = pets[0] if pets else appointment.pet
    start = appointment.start_at

    pet_label = ", ".join(
        (f"{p.name} ({p.breed})" if p.breed else (p.name or "χωρίς όνομα"))
        for p in pets
    ) or "—"

    end = appointment.end_at
    spans_hours = end is not None and (end - start) >= timedelta(hours=2)
    time_label = start.strftime("%H:%M")
    if spans_hours and end is not None:
        time_label += f" – {end.strftime('%H:%M')}"

    # Η υπενθύμιση διαβάζει το δικό της παράθυρο, όχι το προειδοποιητικό παράθυρο
    # κλεισίματος. Η παλιά έκδοση διάβαζε το MIN_LEAD_MINUTES και το `or 2` έκρυβε το
    # λάθος: με προειδοποιητικό παράθυρο μηδέν λεπτών θα επέστρεφε «2 ώρες», ενώ κανένα
    # τέτοιο παράθυρο δεν υπάρχει. Η υπενθύμιση στέλνεται REMINDER_LEAD_HOURS ώρες πριν —
    # αυτό είναι το νόημα της λέξης.
    lead_hours = int(current_app.config.get("REMINDER_LEAD_HOURS", 24))

    pet_notes: list[tuple[str, str]] = []
    # Τα σημειώσεις αφορούν ΟΛΑ τα κατοικίδια του ραντεβού. Παλαιότερα
    # εδώ κοιταγόταν μόνο το πρώτο — ένας σκύλος με αλλεργία έμενε έξω αν
    # δεν ήταν ο πρώτος στη λίστα, και κανείς δεν το έβλεπε γιατί το email
    # έλεγε απλά «Σημειώσεις για το κατοικίδιό σας».
    note_pets = pets or ([appointment.pet] if appointment.pet else [])
    many_pets = len(note_pets) > 1
    for one in note_pets:
        suffix = f" ({one.display_name})" if many_pets else ""
        if one.allergies:
            pet_notes.append((f"Αλλεργίες{suffix}", one.allergies))
        if one.coat_notes:
            pet_notes.append((f"Κατάσταση τριχώματος{suffix}", one.coat_notes))
        if one.temperament:
            pet_notes.append((f"Χαρακτήρας{suffix}", one.temperament))

    groups = service_groups(appointment)
    flat_services = appointment.services_label or "—"
    phrase = pet_phrase(note_pets)

    return {
        **base,
        "first_name": _first_word(customer.name if customer else None) or "πελάτη σας",
        "pets": pets,
        "pet": pet,
        # ΟΛΑ τα κατοικίδια, όχι μόνο το πρώτο: το θέμα του email και η
        # πρώτη γραμμή της ουσίας λένε τώρα «Ρέξι και Μπίσκυ».
        "pet_name": pet_names_label(note_pets),
        "pet_phrase": phrase,
        "pet_article": pet_article(pet),
        "pet_label": pet_label,
        "pet_notes": pet_notes,
        "notes_heading": f"Σημειώσεις για {phrase}",
        "appointment_note": appointment.customer_note or None,
        "when": f"{_greek_weekday(start)} {start:%d/%m/%Y}",
        "time_label": time_label,
        "groomer": appointment.groomer.name if appointment.groomer else "—",
        "services": flat_services,
        "service_groups": groups,
        "services_block": services_block(groups, flat_services),
        "reason": appointment.cancel_reason or None,
        "lead_hours": lead_hours,
        "prep_note": prep_note(note_pets),
    }


_GREEK_DAYS = ["Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο", "Κυριακή"]


def _greek_weekday(moment: datetime) -> str:
    return _GREEK_DAYS[moment.weekday()]


_GENDER_ARTICLE = {
    "male": "τον",
    "female": "την",
    "unknown": "το",
}


def pet_article(pet, fallback: str = "το") -> str:
    if pet is None:
        return fallback
    return _GENDER_ARTICLE.get(getattr(pet, "gender", "unknown"), fallback)


def pet_phrase(pets) -> str:
    """Η φράση μετά το «για»: «για τον Ρέξι», «για Ρέξι και Μπίσκυ».

    Το άρθρο μπαίνει ΜΟΝΟ με ένα κατοικίδιο που έχει όνομα. Αλλιώς βγαίνουν
    φράσεις σαν «για το το κατοικίδιό σας» ή «για το Ρέξι και Μπίσκυ» — δηλαδή
    άρθρο μπροστά σε λίστα, που δεν στέκει στα ελληνικά.
    """
    if len(pets) == 1:
        name = (pets[0].name or "").strip()
        if name:
            return f"{pet_article(pets[0])} {name}"
        return "το κατοικίδιό σας"
    return pet_names_label(pets)


CTA_LABELS = {
    KIND_WELCOME: "Προσθέστε το κατοικίδιό σας",
    KIND_CONFIRMATION: "Δείτε το ραντεβού σας",
    KIND_REMINDER: "Δείτε το ραντεβού σας",
    KIND_CANCELLATION: "Κλείστε νέο ραντεβού",
}


def _preheader(kind: str, context: dict) -> str:
    pet = context.get("pet_name", "το κατοικίδιό σας")
    when = context.get("when", "")
    when = when.split(" ", 1)[-1] if " " in when else when
    time_label = context.get("time_label", "")
    if kind == KIND_CONFIRMATION:
        return f"Ραντεβού για {pet} στις {time_label} ({when}) — επιβεβαιώθηκε."
    if kind == KIND_REMINDER:
        return f"Ραντεβού {when} στις {time_label} — {pet}"
    if kind == KIND_CANCELLATION:
        return f"Το ραντεβού για {pet} στις {time_label} ({when}) ακυρώθηκε."
    return "Ο λογαριασμός σας δημιουργήθηκε — προσθέστε το κατοικίδιό σας."


def _render(kind: str, context: dict) -> tuple[str, str, str]:
    env = current_app.jinja_env
    context.setdefault("cta_label", CTA_LABELS.get(kind, "Άνοιξτε το site"))
    text_body = env.get_template(f"emails/{kind}.txt").render(**context)
    html_body = env.get_template(f"emails/{kind}.html").render(**context)

    salon_name = context["salon"]["name"]
    if kind == KIND_CONFIRMATION:
        subject = f"Επιβεβαίωση ραντεβού — {context['pet_name']}"
    elif kind == KIND_REMINDER:
        subject = f"Υπενθύμιση: ραντεβού για {context['pet_name']}"
    elif kind == KIND_CANCELLATION:
        subject = f"Ακύρωση ραντεβού — {context['pet_name']}"
    else:
        subject = f"Καλώς ήρθατε στο {salon_name}"
    return subject, text_body.strip(), html_body


def _log_line(kind: str, recipient: str, subject: str, body: str, channel: str,
              sent: bool, reason: str = "") -> str:
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    state = "ΣΤΑΛΘΗΚΕ" if sent else f"ΔΕΝ ΣΤΑΛΘΗΚΕ ({reason or 'κανάλι ' + channel})"
    return (
        f"\n{'=' * 78}\n"
        f"[{stamp}] {KIND_LABELS.get(kind, kind).upper()} · κανάλι: {channel} · {state}\n"
        f"Προς: {recipient}\nΘέμα: {subject}\n{'-' * 78}\n{body}\n"
    )


def _write_log(line: str) -> None:
    try:
        # Διαδρομή ΑΠΟ ΤΗ ΡΥΘΜΙΣΗ, όχι επαυτοσχεδιασμός με root_path: το
        # root_path δείχνει τον φάκελο του πακέτου `app`, άρα το "../logs"
        # ήταν υπόθεση για τη δομή του φακέλου και έσπαγε σε οποιαδήποτε
        # άλλη διάταξη. Επίσης δημιουργούμε τον φάκελο: χωρίς αυτό η εγγραφή
        # έπεφτε αθόρυβα και η ιδιοκτήτρια έβλεπε «στάλθηκε (βλ. το log)»
        # χωρίς ποτέ να γραφτεί αρχείο.
        log_dir = Path(current_app.config.get("LOG_DIR") or (LOGS_ROOT))
        log_dir.mkdir(parents=True, exist_ok=True)
        with (log_dir / "notifications.log").open("a", encoding="utf-8") as fh:
            fh.write(line)
    except OSError as exc:
        logger.error("Αποτυχία εγγραφής αρχείου ειδοποιήσεων: %s", exc)


def _dispatch(kind: str, recipient: str, subject: str, text: str, html: str,
              context: dict) -> tuple[bool, str]:
    channel = current_app.config.get("REMINDER_CHANNEL", "email")
    if channel != "email":
        return False, f"κανάλι={channel}"

    result = mailer.send_email(
        recipient, subject, text, html, reply_to=context.get("reply_to")
    )
    if not result.ok:
        logger.warning("Το %s δεν στάλθηκε: %s", kind, result.reason)
    return result.ok, result.reason


def _record(kind: str, appointment: Appointment | None, recipient: str,
            channel: str, body: str, sent: bool) -> Notification:
    note = Notification(
        appointment_id=appointment.id if appointment is not None else None,
        kind=kind,
        channel=channel,
        recipient=recipient,
        body=body,
        sent=sent,
    )
    db.session.add(note)
    return note


def send(kind: str, appointment: Appointment) -> Notification:
    salon = salon_context()
    context = _appointment_context(appointment, salon)
    context["cta_url"] = _appointment_url(appointment)
    context["hidden_preheader"] = _preheader(kind, context)

    recipient = (
        appointment.customer.email if appointment.customer else ""
    )
    subject, text, html = _render(kind, context)

    sent, reason = _dispatch(kind, recipient, subject, text, html, context)
    channel = current_app.config.get("REMINDER_CHANNEL", "email")
    note = _record(kind, appointment, recipient or "—", channel, text, sent)

    now = datetime.now()
    if kind == KIND_CONFIRMATION:
        appointment.confirmation_sent_at = now if sent else None
    elif kind == KIND_REMINDER and appointment.reminder_sent_at is None and sent:
        appointment.reminder_sent_at = now

    line = _log_line(kind, recipient or "—", subject, text, channel, sent, reason)
    print(line)
    _write_log(line)
    return note


def send_welcome(user: User) -> Notification:
    if not user.email:
        return None
    salon = salon_context()
    context = {
        **salon,
        "first_name": user.first_name or "φίλε μου",
        "cta_url": _safe_url("staff.dashboard"),
    }
    context["hidden_preheader"] = _preheader(KIND_WELCOME, context)
    subject, text, html = _render(KIND_WELCOME, context)
    sent, reason = _dispatch(KIND_WELCOME, user.email, subject, text, html, context)
    channel = current_app.config.get("REMINDER_CHANNEL", "email")
    note = _record(KIND_WELCOME, None, user.email, channel, text, sent)

    line = _log_line(KIND_WELCOME, user.email, subject, text, channel, sent, reason)
    print(line)
    _write_log(line)
    return note


def _safe_url(endpoint: str, **values) -> str:
    try:
        return url_for(endpoint, _external=True, **values)
    except RuntimeError:
        pass

    base = (current_app.config.get("PUBLIC_BASE_URL") or "").rstrip("/")
    path = current_app.url_map.bind("localhost").build(endpoint, values)
    return f"{base}{path}" if base else path


def build_preview(kind: str, to: str, **overrides) -> tuple[str, str, str]:
    if kind == KIND_WELCOME:
        context: dict = {
            **salon_context(),
            "first_name": overrides.pop("first_name", "Δοκιμή"),
            "cta_url": _safe_url("staff.dashboard"),
        }
    else:
        appointment = overrides.pop("appointment", None)
        if appointment is None:
            appointment = _next_appointment()
        if appointment is None:
            raise ValueError("Δεν υπάρχει διαθέσιμο ραντεβού για προεπισκόπηση.")
        context = {**_appointment_context(appointment, salon_context()), **overrides}
        context["cta_url"] = _appointment_url(appointment)
    context.update(overrides)
    context["hidden_preheader"] = _preheader(kind, context)
    return _render(kind, context)


def _next_appointment() -> Appointment | None:
    return (
        Appointment.query.filter(Appointment.start_at >= datetime.now())
        .order_by(Appointment.start_at)
        .first()
    )


def _appointment_url(appointment: Appointment) -> str:
    return _safe_url("staff.appointment_detail", appointment_id=appointment.id)


def due_reminders(window_hours: int | None = None) -> list[Appointment]:
    hours = window_hours or current_app.config.get("REMINDER_LEAD_HOURS", 24)
    now = datetime.now()
    upper = now + timedelta(hours=hours)
    return (
        Appointment.query.filter(
            Appointment.status.in_(["pending", "confirmed"]),
            Appointment.reminder_sent_at.is_(None),
            Appointment.start_at > now,
            Appointment.start_at <= upper,
        )
        .order_by(Appointment.start_at)
        .all()
    )


def appointments_between(start_day, end_day) -> list[Appointment]:
    """Ραντεβού από την 00:00 της start_day έως την 00:00 της end_day+1.

    ΓΙΑ ΤΙΣ ΕΞΩΤΕΡΙΚΕΣ ΠΕΡΙΟΔΟΥΣ (μήνας, χρόνος). Το `upcoming_for_day` καλείται
    μία φορά ανά ημέρα — για τον μήνα θα ήταν 30 ερωτήματα και για τον χρόνο
    365. Σε ένα παλιός υπολογιστής με σκληρό δίσκο αυτό το «γρήγορο φίλτρο»
    έπαιρνε δεκάδες δευτερόλεπτα κάθε φορά που η ιδιοκτήτρια άνοιγε τον
    ημερολόγιο. Εδώ γίνεται ΜΙΑ μόνο ερώτημα για όλο το διάστημα.
    """
    lo = datetime.combine(start_day, datetime.min.time())
    hi = datetime.combine(end_day + timedelta(days=1), datetime.min.time())
    return (
        Appointment.query.filter(
            Appointment.start_at >= lo,
            Appointment.start_at < hi,
        )
        .order_by(Appointment.start_at)
        .all()
    )


def upcoming_for_day(day) -> list[Appointment]:
    return (
        Appointment.query.filter(
            Appointment.start_at >= datetime.combine(day, datetime.min.time()),
            Appointment.start_at < datetime.combine(day, datetime.min.time()) + timedelta(days=1),
        )
        .order_by(Appointment.start_at)
        .all()
    )
