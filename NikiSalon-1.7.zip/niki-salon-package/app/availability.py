"""Μηχανή διαθεσιμότητας — σύστημα διαχείρισης ραντεβού σαλονιού."""

from __future__ import annotations

from datetime import date as date_cls, datetime, time, timedelta
from typing import Iterable, Optional

from flask import current_app

from .extensions import db
from .models import (
    OPEN_STATUSES,
    Appointment,
    AvailabilityRule,
    Groomer,
    SalonDaySettings,
    TimeOff,
)

REASON_CLOSED = "closed"
REASON_NO_STAFF = "no_staff"
REASON_BOOKED = "booked"
REASON_PAST = "past"
REASON_LEAD = "lead"
REASON_RUNNING = "running"
REASON_HORIZON = "horizon"
REASON_OFF = "off"
REASON_FREE = "free"

#: Λόγοι που δεν προτείνονται ποτέ στη λίστα των επόμενων ωρών: ώρες που έχουν
#: περάσει, ώρες που εκτελούνται τώρα, ώρες μέσα στο προειδοποιητικό παράθυρο και
#: ώρες πέρα από το όριο κλεισίματος. Μαζεμένα εδώ, ώστε κάθε νέος λόγος να μην
#: ξεχαστεί στο φίλτρο του next_free_slots.
NOT_PROPOSABLE = (REASON_PAST, REASON_RUNNING, REASON_LEAD, REASON_HORIZON)

#: Κείμενο που εμφανίζεται δίπλα στην ώρα. Κάθε ετικέτα έχει σαφή παράγοντα: η
#: «Κλεισμένη ώρα» συμφωνεί με το «ώρα» και όχι με κάτι αόριστο.
REASON_LABELS = {
    REASON_CLOSED: "Κλειστό",
    REASON_NO_STAFF: "Δεν εργάζεται στυλίστρια",
    REASON_BOOKED: "Κλεισμένη ώρα",
    REASON_PAST: "Έχει περάσει",
    REASON_RUNNING: "Σε εξέλιξη",
    REASON_LEAD: "Πολύ κοντά στην ώρα αυτή",
    REASON_HORIZON: "Πέρα από το όριο κλεισίματος",
    REASON_OFF: "Απουσία",
    REASON_FREE: "Ελεύθερη ώρα",
}


def _minutes(value: time) -> int:
    return value.hour * 60 + value.minute


def _time_from_minutes(total: int) -> time:
    total = max(0, min(24 * 60 - 1, total))
    return time(total // 60, total % 60)


def combine(day: date_cls, minutes: int) -> datetime:
    return datetime.combine(day, _time_from_minutes(minutes))


def parse_hhmm(value: str) -> int:
    try:
        hours, _, mins = str(value).strip().partition(":")
        return int(hours) * 60 + int(mins or 0)
    except (TypeError, ValueError):
        return 0


def slot_step() -> int:
    """Διάστημα μεταξύ διαθέσιμων ωρών, σε λεπτά.

    Προέρχεται από τις Ρυθμίσεις σπα (προεπιλογή 60 = ανά ώρα). Η τιμή
    επιβάλλεται στον έλεγχο ώστε να μην είναι 0 ή μη λογική.
    """
    try:
        from .models import SalonSettings

        value = SalonSettings.get("slot_minutes")
    except Exception:
        value = None
    try:
        step = int(value)
    except (TypeError, ValueError):
        step = 0
    if step < 5:
        step = int(current_app.config.get("SLOT_MINUTES", 60) or 60)
    return step


def horizon_days() -> int:
    return int(current_app.config.get("BOOKING_HORIZON_DAYS", 60))


def min_lead_minutes() -> int:
    return int(current_app.config.get("MIN_LEAD_MINUTES", 120))


def salon_hours_for(day: date_cls) -> tuple[bool, int, int]:
    row = SalonDaySettings.query.filter_by(weekday=day.weekday()).first()
    if row is None:
        if day.weekday() == 6:
            return True, 0, 0
        return False, 9 * 60, 18 * 60
    if row.is_closed:
        return True, 0, 0
    return False, _minutes(row.open_time), _minutes(row.close_time)


def groomer_windows_for(groomer_id: int, day: date_cls) -> list[tuple[int, int]]:
    closed, salon_open, salon_close = salon_hours_for(day)
    if closed:
        return []
    rules = AvailabilityRule.query.filter_by(groomer_id=groomer_id, weekday=day.weekday()).all()
    windows = []
    for rule in rules:
        start = max(_minutes(rule.start_time), salon_open)
        end = min(_minutes(rule.end_time), salon_close)
        if end - start >= slot_step():
            windows.append((start, end))
    return sorted(windows)


def bookable_groomers() -> list[Groomer]:
    return Groomer.query.filter_by(is_bookable=True).order_by(Groomer.sort_order, Groomer.id).all()


def _busy_from_appointments(groomer_ids: Iterable[int], day: date_cls,
                            exclude_appointment_id: Optional[int] = None):
    ids = [g for g in groomer_ids if g]
    if not ids:
        return {}
    day_start = datetime.combine(day, time(0, 0))
    day_end = day_start + timedelta(days=1)

    query = Appointment.query.filter(
        Appointment.groomer_id.in_(ids),
        Appointment.status.in_(OPEN_STATUSES),
        Appointment.start_at < day_end,
        Appointment.end_at > day_start,
    )
    if exclude_appointment_id:
        query = query.filter(Appointment.id != exclude_appointment_id)

    busy: dict[int, list[tuple[int, int]]] = {}
    for appt in query.all():
        start = appt.start_at
        end = appt.end_at
        s = max(_minutes(start.time()), 0) if start.date() == day else 0
        e = min(_minutes(end.time()), 24 * 60) if end.date() == day else 24 * 60
        busy.setdefault(appt.groomer_id, []).append((s, e))
    return busy


def _busy_from_time_off(groomer_ids: Iterable[int], day: date_cls):
    ids = [g for g in groomer_ids if g]
    if not ids:
        return {}
    day_start = datetime.combine(day, time(0, 0))
    day_end = day_start + timedelta(days=1)
    rows = TimeOff.query.filter(
        TimeOff.groomer_id.in_(ids),
        TimeOff.start_at < day_end,
        TimeOff.end_at > day_start,
    ).all()
    busy: dict[int, list[tuple[int, int]]] = {}
    for row in rows:
        s = max(_minutes(row.start_at.time()), 0) if row.start_at.date() == day else 0
        e = min(_minutes(row.end_at.time()), 24 * 60) if row.end_at.date() == day else 24 * 60
        busy.setdefault(row.groomer_id, []).append((s, e))
    return busy


def _merge(busy: dict) -> dict:
    out = {}
    for groomer_id, ranges in busy.items():
        merged: list[list[int]] = []
        for start, end in sorted(ranges):
            if merged and start <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])
        out[groomer_id] = [(s, e) for s, e in merged]
    return out


def busy_map(groomer_ids: Iterable[int], day: date_cls, exclude_appointment_id=None) -> dict:
    merged = _merge(_busy_from_appointments(groomer_ids, day, exclude_appointment_id))
    off = _merge(_busy_from_time_off(groomer_ids, day))
    for groomer_id, ranges in off.items():
        merged.setdefault(groomer_id, []).extend(ranges)
        merged[groomer_id] = sorted(merged[groomer_id])
    return merged


def slots_for_date(
    day: date_cls,
    duration: int,
    groomer_id: Optional[int] = None,
    exclude_appointment_id: Optional[int] = None,
) -> list[dict]:
    step = slot_step()
    # Η διάρκεια των υπηρεσιών ΔΕΝ καθορίζει τα slots: το βήμα είναι σταθερό
    # (ώρες) από το άνοιγμα ως το κλείσιμο. Κρατάμε την παράμετρο για
    # συμβατότητα, αλλά δεν τη χρησιμοποιούμε για να κόψουμε ώρες.
    _ = duration

    closed, salon_open, salon_close = salon_hours_for(day)
    if closed:
        return [
            {
                "start": "—", "end": "—", "start_min": 0, "end_min": 0,
                "groomer_ids": [], "groomer_id": groomer_id, "available": False,
                "reason": REASON_CLOSED, "label": "Κλειστό",
            }
        ]

    groomers = [
        g
        for g in ([db.session.get(Groomer, groomer_id)] if groomer_id else bookable_groomers())
        if g is not None and g.is_bookable
    ]
    if not groomers:
        return [
            {
                "start": "—", "end": "—", "start_min": 0, "end_min": 0,
                "groomer_ids": [], "groomer_id": groomer_id, "available": False,
                "reason": REASON_NO_STAFF, "label": REASON_LABELS[REASON_NO_STAFF],
            }
        ]

    ids = [g.id for g in groomers]
    busy = busy_map(ids, day, exclude_appointment_id)
    now = datetime.now()
    earliest = now + timedelta(minutes=min_lead_minutes())
    latest_bookable = now.date() + timedelta(days=horizon_days())
    too_early = day > latest_bookable

    result: list[dict] = []
    # Κάθε βήμα από το άνοιγμα ως το κλείσιμο. Η τελευταία ώρα δείχνεται
    # μόνο αν χωράει ένα ολόκληρο βήμα πριν το κλείσιμο.
    for start in range(salon_open, max(salon_open - 1, salon_close - step) + 1, step):
        end = start + step
        free_ids: list[int] = []
        # ΠΟΙΕΣ ΕΙΝΑΙ ΑΠΑΣΧΟΛΗΜΕΝΕΣ ΣΕ ΑΥΤΗ ΤΗΝ ΩΡΑ. Χωρίς αυτό το όνομα,
        # η προειδοποίηση θα έλεγε απλώς «η ώρα είναι κατειλημμένη» και η
        # ιδιοκτήτρια δεν θα ήξερε ποιον αφορά — οπότε δεν θα μπορούσε ούτε
        # να αποφασίσει αν το θέλει.
        busy_ids: list[int] = []
        for g in groomers:
            windows = groomer_windows_for(g.id, day)
            # Διαθέσιμος αν η ιδία ώρα έναρξης πέφτει μέσα στο παράθυρό του.
            inside = any(w_start <= start < w_end for w_start, w_end in windows)
            if not inside:
                continue
            clash = any(start < b_end and b_start < end for b_start, b_end in busy.get(g.id, []))
            if clash:
                busy_ids.append(g.id)
            else:
                free_ids.append(g.id)

        slot_start_dt = combine(day, start)
        slot_end_dt = combine(day, end)
        # Οι έλεγχοι χρόνου έρχονται πρώτοι. Το «έχει περάσει» και το «προειδοποιητικό
        # παράθυρο» αφορούν την ώρα, όχι το ημερολόγιο, και δεν πρέπει να εξαρτώνται από
        # το αν υπάρχει ελεύθερη στυλίστρια. Η παλιά σειρά (πρώτα το «ελεύθερη») έκανε
        # ακριβώς αυτό: ώρα 09:00 όταν ήταν 14:00, χωρίς κλείδωμα, εμφανιζόταν ως
        # διαθέσιμη.
        if too_early:
            reason = REASON_HORIZON
        elif day < now.date():
            reason = REASON_PAST
        elif slot_end_dt <= now:
            # Ξεκίνησε ή τελείωσε ήδη. Κρατώνται ξεχωριστά από το προειδοποιητικό
            # παράθυρο, ώστε η ένδειξη να μην λέει «πολύ κοντά στην ώρα αυτή» για κάτι
            # που έχει ήδη περάσει.
            reason = REASON_PAST
        elif slot_start_dt <= now:
            # Ξεκίνησε και δεν έχει τελειώσει ακόμα. Χωριστή ένδειξη επειδή με μηδέν
            # προειδοποιητικό παράθυρο αυτή είναι η μόνη περίπτωση που το «πολύ κοντά στην
            # ώρα αυτή» θα παραποιούσε.
            reason = REASON_RUNNING
        elif slot_start_dt < earliest:
            reason = REASON_LEAD
        elif free_ids:
            reason = REASON_FREE
        else:
            reason = REASON_BOOKED

        result.append(
            {
                "start": f"{start // 60:02d}:{start % 60:02d}",
                "end": f"{end // 60:02d}:{end % 60:02d}",
                "start_min": start,
                "end_min": end,
                "groomer_ids": free_ids,
                "groomer_id": groomer_id if groomer_id in free_ids else (free_ids[0] if free_ids else None),
                "available": bool(free_ids) and reason == REASON_FREE,
                "reason": reason,
                "label": REASON_LABELS.get(reason, ""),
                # Ποιος είναι απασχολημένος. Το διαβάζει η επιβεβαίωση
                # «η ώρα είναι κατειλημμένη — κλείστες όμως;».
                "busy": bool(busy_ids),
                "busy_groomers": [
                    {"id": g.id, "name": g.name}
                    for g in groomers if g.id in busy_ids
                ],
            }
        )
    return result


def next_free_slots(
    count: int = 5,
    duration: int = 60,
    groomer_id: Optional[int] = None,
    exclude_appointment_id: Optional[int] = None,
    from_day: Optional[date_cls] = None,
) -> list[dict]:
    """Οι επόμενες ώρες του ημερολογίου, σε σειρά χρόνου.

    Ελεύθερες και κλεισμένες. Ζητήθηκε ρητά να προτείνονται μόνο μελλοντικές ώρες και
    να συμπεριλαμβάνονται οι κλεισμένες. Κάθε εγγραφή έχει το πεδίο `booked`: True
    για κατειλημμένη, False για ελεύθερη.

    Γιατί και οι κλεισμένες: η λίστα απαντά στο ερώτημα «πότε θα γεμίσει;». Με μόνο
    ελεύθερες ώρες η απάντηση ήταν ασυνεπής, γιατί η ίδια ώρα εμφανιζόταν πέντε
    φορές και η λίστα δεν έλεγε πού έχει ήδη κόσμο.

    Τι ζητήθηκε: «να είναι δυναμικές ανάλογα με τη διάρκεια που βάζει η ιδιοκτήτρια
    (30 ή 60 λεπτά)».

    Προηγούμενη λειτουργία — και όχι μόνο λάθος, αλλά μάταια: πύρανε το πρώτο ελεύθερη
    της ημέρας. Κάθε μέρας η πρώτη ελεύθερη είναι η ώρα ανοίγματος, οπότε η λίστα
    έδειχνε πάντα «09:00, 09:00, 09:00, 09:00, 09:00» — μια λίστα που δεν άλλαζε ποτέ
    και δεν έλεγε τίποτα για τη διάρκεια. Η ιδιοκτήτρια νόμιζε ότι η εφαρμογή χάλασε.

    Τώρα σαρώνουμε τον χρόνο προς τα εμπρός, βήμα βήμα, μέχρι να βρούμε τον αριθμό των
    πραγματικά ελεύθερων ωρών. Η λίστα μεταβάλλεται μόνη της με τις κλήσεις και δείχνει
    τη σειρά που θα γεμίσει το πραγματικό ημερολόγιο.

    Η διάρκεια μετράει: ένα ραντεβού πιάνει όσες ώρες χρειάζεται. Με βήμα 60 λεπτών,
    μια υπηρεσία 30 λεπτών παίρνει μία ώρα (δεν χωράει δύο διαφορετικές κλήσεις στην
    ίδια ώρα), ενώ μια στην ώρα και τρία τέταρτα χρειάζεται δύο. Χωρίς αυτό το μέτρημα η
    λίστα προτείνει ώρες που δεν χωράνε με τη διάρκεια που ζητήθηκε.
    """
    start_day = from_day or date_cls.today()
    step = slot_step() or 60
    # Πόσες συνεχόμενες ώρες πρέπει να είναι ελεύθερες.
    need = max(1, int(-(-int(duration or step) // step)))
    last = start_day + timedelta(days=horizon_days())
    found: list[dict] = []
    day = start_day
    while day <= last and len(found) < count:
        slots = slots_for_date(day, 0, groomer_id,
                               exclude_appointment_id=exclude_appointment_id)
        if not (slots and slots[0].get("start") == "—"):
            usable = [s for s in slots if s.get("start_min") is not None]
            # Οι ώρες που έχουν περάσει δεν προτείνονται. Χωρίς αυτό το φίλτρο η λίστα έδειχνε
            # «σήμερα 09:00» και την αμέσως επόμενη, με την ίδια ένδειξη «ελεύθερη», ενώ η
            # ιδιοκτήτρια δεν ξεχώριζε τη διαφορά — δεν τις έδειχνε καν η ίδια η λίστα.
            # Ζητήθηκε ρητά να προτείνονται μόνο μελλοντικές ώρες. Οι λόγοι κρατώνται στο
            # NOT_PROPOSABLE, ώστε κάθε νέος λόγος να μην ξεχαστεί εδώ.
            usable = [s for s in usable
                      if s.get("reason") not in NOT_PROPOSABLE]
            for i, head in enumerate(usable):
                if len(found) >= count:
                    break
                if not head.get("available"):
                    # Η κλεισμένη ώρα προτείνεται, και η διάρκεια δεν μετράει. Μια κλεισμένη ώρα
                    # δεν δέχεται ραντεβού, άρα το ερώτημα «χωράει η διάρκεια;» δεν τίθεται: το μέτρημα
                    # από εκεί και πέρα θα έβρισκε μια ώρα που τελικά δεν κλείνεται. Ζητήθηκε ρητά να
                    # συμπεριλαμβάνονται.
                    #
                    # Γιατί χρήσιμο: μια κλεισμένη ώρα ανάμεσα σε δύο κενές λέει «πλήρες εδώ, ελεύθερα
                    # εκεί», χωρίς να χρειαστεί άνοιγμα ημερολογίου και αναζήτηση — είναι η ίδια η
                    # απάντηση στο «πού θα γεμίσει;» που ρωτά η ιδιοκτήτρια κάθε μέρα.
                    found.append({"date": day.isoformat(),
                                  "start": head["start"], "end": head["end"],
                                  "booked": True,
                                  "label": head.get("label") or ""})
                    continue
                # Ελεύθερη: πρέπει να χωράει η διάρκεια από εδώ και μετά.
                run = usable[i:i + need]
                if len(run) < need or any(not r.get("available") for r in run):
                    continue
                found.append({"date": day.isoformat(),
                              "start": head["start"], "end": run[-1]["end"],
                              "booked": False, "label": ""})
        day += timedelta(days=1)
    return found


def week_preview(from_day: date_cls, days: int = 7, duration: int = 60,
                 groomer_id: Optional[int] = None) -> list[dict]:
    preview = []
    for day in [from_day + timedelta(days=i) for i in range(days)]:
        slots = slots_for_date(day, duration, groomer_id)
        closed = bool(slots) and slots[0]["reason"] == REASON_CLOSED
        free = [s for s in slots if s["available"]]
        preview.append(
            {
                "date": day,
                "iso": day.isoformat(),
                "weekday": day.weekday(),
                "weekday_short": ["Δε", "Τρ", "Τε", "Πε", "Πα", "Σα", "Κυ"][day.weekday()],
                "day": day.day,
                "closed": closed,
                "free_count": len(free),
                "first_free": free[0]["start"] if free else None,
                "slots": [] if closed else slots,
            }
        )
    return preview


def first_conflict(start_at: datetime, end_at: datetime, groomer_id: int,
                   exclude_appointment_id: Optional[int] = None):
    day = start_at.date()
    if end_at.date() != day:
        return "Το ραντεβού δεν μπορεί να διασχίσει δύο μέρες."

    # ══ ΠΑΡΕΛΘΟΝΤΙΚΗ ΗΜΕΡΟΜΗΝΙΑ = ΚΑΤΑΓΡΑΦΗ, ΟΧΙ ΠΡΟΓΡΑΜΜΑΤΙΣΜΟΣ ══
    # ΠΡΩΤΟΣ ΕΛΕΓΧΟΣ, ΕΠΙΤΡΕΠΤΟΝΤΑΣ ΟΛΑ ΤΑ ΥΠΟΛΟΙΠΑ ΝΑ ΠΑΡΑΠΕΡΑΣΟΥΝ.
    # Η σειρά έχει νόημα: όταν γράφουμε κάτι που έγινε, το ωράριο του
    # σαλονιού ΣΗΜΕΡΑ δεν έχει καμία σχέση με τότε. Με τον έλεγχο αυτό
    # ΜΕΤΑ τις ώρες, η ιδιοκτήτρια έπαιρνε «Το Salon είναι κλειστό
    # Κυριακή» για μια επίσκεψη που είχε γίνει Κυριακή — και δεν μπορούσε
    # να τη γράψει. Ίδια λογική και με ώρα εκτός του σημερινού ωραρίου.
    if day < datetime.now().date():
        return None

    closed, salon_open, salon_close = salon_hours_for(day)
    if closed:
        return f"Το Salon είναι κλειστό {['Δευτέρα','Τρίτη','Τετάρτη','Πέμπτη','Παρασκευή','Σάββατο','Κυριακή'][day.weekday()]}."
    if _minutes(start_at.time()) < salon_open or _minutes(end_at.time()) > salon_close:
        return f"Εκτός ωρών λειτουργίας ({salon_open // 60:02d}:00 – {salon_close // 60:02d}:00)."

    windows = groomer_windows_for(groomer_id, day)
    if not windows:
        return "Η συγκεκριμένη στυλίστρια δεν εργάζεται αυτή την ημέρα."
    if not any(w_start <= _minutes(start_at.time()) and _minutes(end_at.time()) <= w_end
               for w_start, w_end in windows):
        return "Η ώρα δεν είναι εντός του ωραρίου της στυλίστριας."

    # Μόνο για ώρα που δεν έχει περάσει ακόμα. Ένα ραντεβού για την ώρα που τρέχει
    # τώρα είναι λογικό — κάποιος μπαίνει στο κουρίζι τώρα. Ένα ραντεβού για χθες
    # δεν είναι, και την περίπτωση αυτή την έχουμε ήδη απορρίψει παραπάνω.
    # Σε λεπτά, όχι σε ώρες. Το `// 60` έκοβε το υπόλοιπο (90 λεπτά → «1 ώρες») και
    # με προειδοποιητικό παράθυρο μηδέν λεπτών θα έγραφε «0 ώρες». Το `lead > 0` κάνει
    # αδύνατη την εμφάνιση του μηνύματος όταν δεν υπάρχει παράθυρο — το
    # `timedelta(minutes=0)` θα το έκανε από μόνο του, αλλά το λέμε ρητά.
    lead = min_lead_minutes()
    if lead > 0 and start_at > datetime.now() \
            and start_at < datetime.now() + timedelta(minutes=lead):
        return f"Χρειάζεται προειδοποίηση τουλάχιστον {lead} λεπτών νωρίτερα."
    if start_at.date() > datetime.now().date() + timedelta(days=horizon_days()):
        return f"Δεν επιτρέπεται ραντεβού πάνω από {horizon_days()} μέρες."

    return None


def slot_taken(start_at: datetime, end_at: datetime, groomer_id: int,
               exclude_appointment_id: Optional[int] = None) -> Optional[str]:
    """Προειδοποίηση, όχι εμπόδιος: υπάρχει ήδη ραντεβού σε αυτή την ώρα.

    Ξεχωριστά από το first_conflict, και επίτηδες. Η κάλυψη ώρας δεν είναι
    λάθος: η ιδιοκτήτρια μπορεί να έχει δύο πελάτες την ίδια ώρα ή να γράφει
    αναδρομικά από τη μνήμη της και να ξεχάσει.

    Το πρόβλημα του πρώτου «μπλοκ» ήταν πρακτικό: σταματούσε ολόκληρη την εγγραφή.
    Η ιδιοκτήτρια έβλεπε «η ώρα είναι κλειστή» — χωρίς να μάθει ποια ώρα, χωρίς να
    μπορεί να αλλάξει εύκολα — και το ραντεβού χανόταν. Τώρα προειδοποιεί και
    αποθηκεύει.

    Σε παρελθόν δεν προειδοποιεί: η κάλυψη ώρας δεν λέει τίποτα όταν κάθε ραντεβού
    είναι στο παρελθόν.
    """
    if groomer_id is None or start_at.date() < datetime.now().date():
        return None
    busy = busy_map([groomer_id], start_at.date(), exclude_appointment_id)
    for b_start, b_end in busy.get(groomer_id, []):
        if _minutes(start_at.time()) < b_end and b_start < _minutes(end_at.time()):
            return ("Υπάρχει ήδη άλλο ραντεβού σε αυτή την ώρα με την ίδια "
                    "στυλίστρια. Αποθηκεύτηκε κανονικά — αν ήταν λάθος, "
                    "διόρθωσέ το μετά.")
    return None


def groomer_is_free(groomer_id: int, start_at: datetime, end_at: datetime,
                    exclude_appointment_id: Optional[int] = None) -> bool:
    return first_conflict(start_at, end_at, groomer_id, exclude_appointment_id) is None


def auto_assign_groomer(start_at: datetime, end_at: datetime,
                        preferred: Optional[int] = None) -> Optional[int]:
    if preferred:
        if groomer_is_free(preferred, start_at, end_at):
            return preferred
    for groomer in bookable_groomers():
        if groomer_is_free(groomer.id, start_at, end_at):
            return groomer.id
    return None
