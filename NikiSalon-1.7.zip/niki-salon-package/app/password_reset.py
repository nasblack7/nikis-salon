"""Επαναφορά ξεχασμένου κωδικού μέσω email.

Δύο πράγματα κρατούν αυτό ασφαλές, και τα δύο είναι υποχρεωτικά:

1. **Κανένα token δεν αποθηκεύεται.** Στη βάση πάει μόνο το SHA-256. Όποιος
   διαβάσει τη βάση δεν μπορεί να μπει σε κανέναν λογαριασμό — τα token έχουν
   ήδη λήξει ή χρησιμοποιηθεί, οπότε το hash δεν περνάει καν.
2. **Η απάντηση είναι ίδια ανεξαρτήτως αν υπάρχει ο χρήστης.** Αλλιώς η σελίδα
   θα λεγεί «δεν υπάρχει τέτοιος λογαριασμός» και θα γίνεται εργαλείο
   εύρεσης ονομάτων χρήστη. Ούτε το πότε έγινε αίτημα αποκαλύπτεται, γι' αυτό
   κάθε αίτημα κάνει τον ίδιο χρόνο εργασίας.
"""

from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta

from flask import current_app, request
from sqlalchemy import func

from .extensions import db
from .models import PasswordResetToken, SalonSettings, User

#: Μία ώρα αρκεί για να πατήσει κανείς το link, αρκετά για να μην εκμεταλλεύεται
#: αν το email περιέχεται σε κοινόχρηστο inbox.
TOKEN_TTL_MINUTES = 60

#: Όχι περισσότερες από 3 αιτήματα ανά 15 λεπτά για τον ίδιο λογαριασμό.
MAX_REQUESTS = 3
RATE_WINDOW_MINUTES = 15

#: Το ίδιο μήνυμα πάντα — μηδενίζει την πληροφορία ποιος υπάρχει.
NEUTRAL_MESSAGE = (
    "Αν το όνομα χρήστη υπάρχει και έχει email, σας στείλαμε σύνδεσμο για να "
    "βάλετε νέο κωδικό. Ισχύει για 60 λεπτά."
)

#: Μήνυμα όταν το SMTP δεν έχει ρυθμιστεί σε αυτή την εγκατάσταση.
#: Αποκαλύπτει μόνο μια ΡΥΘΜΙΣΗ ΤΟΥ ΣΠΑ, όχι αν υπάρχει ο λογαριασμός —
#: άρα δεν βοηθάει κανέναν να μάθει ποιοι έχουν λογαριασμό. Και λέει κάτι
#: χρήσιμο αντί για ένα «σας στείλαμε σύνδεσμο» που δεν έρχεται ποτέ.
NO_SMTP_MESSAGE = (
    "Δεν έχει ρυθμιστεί το email σε αυτή την εγκατάσταση, οπότε δεν είναι "
    "δυνατή η αυτόματη αποστολή συνδέσμου. Επικοινωνήστε με τον διαχειριστή "
    "της εφαρμογής για βοήθεια."
)


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _recent_request_count(user_id: int) -> int:
    since = datetime.now() - timedelta(minutes=RATE_WINDOW_MINUTES)
    return PasswordResetToken.query.filter(
        PasswordResetToken.user_id == user_id,
        PasswordResetToken.created_at >= since,
    ).count()


def purge_expired(older_than_days: int = 30) -> int:
    """Καθαρίζει τα token που έχουν λήξει ή χρησιμοποιηθεί παλιότερα."""
    cutoff = datetime.now() - timedelta(days=older_than_days)
    removed = PasswordResetToken.query.filter(
        db.or_(
            PasswordResetToken.used_at.isnot(None),
            PasswordResetToken.expires_at < cutoff,
        )
    ).delete(synchronize_session=False)
    db.session.commit()
    return removed


def request_reset(identifier: str) -> tuple[bool, str]:
    """Δημιουργεί token και στέλνει email. Επιστρέφει (στάλθηκε, μήνυμα).

    Δυο διαφορετικά μηνύματα, για δυο διαφορετικούς λόγους:

    - **Δεν έχει ρυθμιστεί το SMTP.** Λέμε την αλήθεια, γιατί αφορά τη
      ρύθμιση του σπα και όχι τον λογαριασμό — δεν αποκαλύπτει ποιος έχει
      λογαριασμό. Και δεν δημιουργούμε token, αφού δεν θα σταλεί.
    - **Αποτυχία στάλματος ενώ το SMTP υπάρχει** (λάθος κωδικός, δίκτυο).
      Εδώ το μήνυμα μένει ΟΛΟΙΝΩΝΙΚΑ ΤΟ ΙΔΙΟ, γιατί το «προσπάθησα να στείλω
      στο δικό σας email και απέτυχα» θα έλεγε στον επόμενο ότι ο
      λογαριασμός υπάρχει. Το token διαγράφεται.
    """
    from . import mailer

    if not mailer.is_configured():
        return False, NO_SMTP_MESSAGE

    identifier = (identifier or "").strip()
    user = User.find_by_identifier(identifier) if identifier else None

    if user is None or not user.email:
        # Επιστρέφουμε ακριβώς το ίδιο πράγμα. Χωρίς email δεν γίνεται τίποτα,
        # αλλά ο καλούντες δεν πρέπει να το μάθει.
        return False, NEUTRAL_MESSAGE

    if _recent_request_count(user.id) >= MAX_REQUESTS:
        return False, NEUTRAL_MESSAGE

    # Ακυρώνουμε τα παλιά αχρησία — ένα νέο αίτημα σημαίνει ότι το
    # προηγούμενο link δεν το χρειάστηκε κανείς.
    _invalidate_all(user.id)

    token = secrets.token_urlsafe(32)
    row = PasswordResetToken(
        user_id=user.id,
        token_hash=_hash_token(token),
        expires_at=datetime.now() + timedelta(minutes=TOKEN_TTL_MINUTES),
    )
    db.session.add(row)
    db.session.commit()

    result = _send(user, token)
    if not getattr(result, "ok", False):
        # Το link δεν έφταγε ποτέ. Αφήνοντάς το, τρία τέτοια tokens θα
        # μπλοκάρουν τις επόμενες νόμιμες προσπάθειες ανά 15 λεπτά.
        db.session.delete(row)
        db.session.commit()
        return False, NEUTRAL_MESSAGE
    return True, NEUTRAL_MESSAGE


def _invalidate_all(user_id: int) -> None:
    PasswordResetToken.query.filter(
        PasswordResetToken.user_id == user_id,
        PasswordResetToken.used_at.is_(None),
    ).update({PasswordResetToken.used_at: datetime.now()},
             synchronize_session=False)
    db.session.commit()


def find_valid_token(token: str):
    """Ο χρήστης ενός έγκυρου token, ή None."""
    if not token:
        return None
    row = PasswordResetToken.query.filter_by(
        token_hash=_hash_token(token.strip())).first()
    if row is None or not row.is_usable:
        return None
    return row.user


def complete_reset(token: str, new_password: str) -> tuple[bool, str]:
    """Βάζει νέο κωδικό και καταργεί όλα τα token του χρήστη."""
    if not token:
        return False, "Ο σύνδεσμος δεν είναι έγκυρος ή έχει λήξει."
    row = PasswordResetToken.query.filter_by(
        token_hash=_hash_token(token.strip())).first()
    if row is None or not row.is_usable:
        return False, "Ο σύνδεσμος δεν είναι έγκυρος ή έχει λήξει."

    user = row.user
    user.set_password(new_password)
    row.used_at = datetime.now()
    # Κάθε άλλο link του ίδιου λογαριασμού παύει να ισχύει.
    _invalidate_all(user.id)
    db.session.commit()
    return True, "Ο νέος κωδικός ενημερώθηκε. Μπορείτε να συνδεθείτε."


def _reset_path(token: str) -> str:
    """Το μονοπάτι της σελίδας επαναφοράς, χωρίς request context.

    Το url_for() απαιτεί ενεργή αίτηση, αλλά τη δεύτερη φορά το ίδιο link
    φτιάχνεται από γραμμή εντολής. Χτίζουμε το μονοπάτι από το url_map,
    που δεν θέλει κανένα context.
    """
    adapter = current_app.url_map.bind(
        "localhost",
        script_name=current_app.config.get("APPLICATION_ROOT", "/"),
    )
    return adapter.build("auth.reset_password", {"token": token})


def _send(user: User, token: str):
    """Στέλνει το email. Επιστρέφει το αποτέλεσμα του mailer."""
    from . import mailer

    base = (current_app.config.get("PUBLIC_BASE_URL") or "").rstrip("/")
    if not base:
        # Χωρίς PUBLIC_BASE_URL στο .env η ίδια η σελίδα ζητάει την
        # επαναφορά, άρα γνωρίζουμε τη διεύθυνσή της. Παλαιότερα
        # έπεφτε σε μια προεπιλογή με domain κάποιου άλλου σαλονιού.
        try:
            base = request.host_url.rstrip("/")
        except RuntimeError:                            # χωρίς request
            base = ""
    link = f"{base}{_reset_path(token)}"

    name = user.full_name or user.username
    text = (
        f"Γεια σας {name},\n\n"
        "Ζητήθηκε επαναφορά του κωδικού σας. Αν το ζητήσατε εσείς, πατήστε "
        "τον παρακάτω σύνδεσμο:\n\n"
        f"{link}\n\n"
        f"Ο σύνδεσμος ισχύει για {TOKEN_TTL_MINUTES} λεπτά και "
        "χρησιμοποιείται μία φορά.\n\n"
        "Αν δεν το ζητήσατε εσείς, αγνοήστε αυτό το email. Ο κωδικός σας δεν "
        "άλλαξε και κανείς δεν μπορεί να μπει στον λογαριασμό σας χωρίς αυτόν.\n"
    )
    return mailer.send_email(
        to=user.email,
        subject="Επαναφορά κωδικού — %s" % (
            str(SalonSettings.get("name") or "").strip()
            or current_app.config.get("SALON_NAME") or "Salon"),
        text_body=text,
        reply_to=current_app.config.get("MAIL_FROM") or None,
    )


def reset_link_for_cli(user: User) -> str:
    """Σύνδεσμος για επαναφορά από γραμμή εντολής, όταν δεν έχει SMTP.

    Χρήσιμο για τον προγραμματιστή: τυπώνει τον σύνδεσμο στο τερματικό και τον
    στέλνει στον ιδιοκτήτη με ασφαλές κανάλι. Δεν χρειάζεται πρόσβαση στο email.
    """
    _invalidate_all(user.id)
    token = secrets.token_urlsafe(32)
    db.session.add(PasswordResetToken(
        user_id=user.id,
        token_hash=_hash_token(token),
        expires_at=datetime.now() + timedelta(minutes=TOKEN_TTL_MINUTES),
    ))
    db.session.commit()
    base = (current_app.config.get("PUBLIC_BASE_URL") or "").rstrip("/")
    return f"{base}{_reset_path(token)}"
