"""Σελίδα online ενημερώσεων — μόνο για την ιδιοκτήτρια.

Οι ενημερώσεις αλλάζουν τρέξιμο κώδικα, οπότε η πρόσβαση είναι
ιδιοκτητρίας (οι βοηθοί δεν έχουν λόγο να τις τρέξουν).
"""

from __future__ import annotations

import threading
import time

from flask import (
    Blueprint,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    url_for,
)

from ..helpers import admin_required
from ..updates import (
    InstallReport,
    UpdateError,
    UpdateInfo,
    check_for_update,
    probe_internet,
    write_check_cache,
    write_internet_state,
    offline_message,
    pending_restart,
    internet_state,
    in_maintenance,
    installed_state,
    known_releases,
    maintenance_off,
    maintenance_on,
    active_release,
    install_update,
    public_key_hex,
    request_restart,
    rollback,
    unsupported_reason,
    updates_configured,
)
from ..version import APP_VERSION

#: Πόσα δευτερόλεπτα μένει η οθόνη συντήρησης μετά μια ΑΠΟΤΥΧΙΑ, ώστε να
#: προλάβει η ιδιοκτήτρια να δει ΓΙΑΤΙ απέτυχε. Χωρίς αυτό, μια γρήγορη
#: αποτυχία έκλεινε την οθόνη πριν το browser προλάβει να τη ζητήσει.
FAILURE_GRACE_SECONDS = 6.0


bp = Blueprint("updates", __name__, url_prefix="/staff/updates")

#: Η εγκατάσταση τρέχει σε νήμα, για να μη μπλοκάρει την αίτηση (η ίδια
#: διαρκεί αρκετά λεπτά). Μία εγκατάσταση τη φορά.
_install_lock = threading.Lock()
_installing = False

#: Ζωντανή κατάσταση για την οθόνη συντήρησης. Με την ΙΔΙΑ
#: κλειδαριά που φυλάει το _installing: μία κλειδαριά, μία
#: πηγή αλήθειας. (Η υπάρχουσα _install_lock ήταν θνητή —
#: δεν την έπαιρνε κανείς.)
_install_phase = "idle"      # idle|installing|restarting|failed
_install_version = ""
_install_report: InstallReport | None = None


#: «Μην άλλαξεις αυτό το πεδίο». Χωρίς αυτό, το None της _set_phase θα
#: έπρεπε να σημαίνε δύο πράγματα ταυτόχρονα («άδειασέ το» και «άσε το»).
_UNSET = object()


def _set_phase(phase: str, version: str = "", report=_UNSET) -> None:
    """Θέτει τη ζωντανή φάση. Με κλειδαριά, γιατί το γράφει το νήμα της
    εγκατάστασης και το διαβάζει το νήμα του HTTP που ρωτά για την πρόοδο.

    Το report=None ΚΑΘΑΡΙΖΕΙ τη λίστα βημάτων. Χωρίς αυτό, η επόμενη
    εγκατάσταση θα έδειχνε τα βήματα της προηγούμενης.
    """
    global _install_phase, _install_version, _install_report
    with _install_lock:
        _install_phase = phase
        if version:
            _install_version = version
        if report is not _UNSET:
            _install_report = report


def live_install() -> dict:
    """Η τρέχουσα φάση και τα βήματα, έτοιμα για JSON."""
    with _install_lock:
        phase, version, report = _install_phase, _install_version, _install_report
    steps = []
    if report is not None:
        for s in report.snapshot():
            steps.append({"name": s.name, "ok": s.ok, "detail": s.detail[:200]})
    return {"phase": phase, "version": version, "steps": steps,
            "in_maintenance": in_maintenance()}


def _status_payload() -> dict:
    release = active_release()
    # Η πρώτη εγκατάσταση είναι ο ίδιος ο φάκελος του installer, οπότε δεν
    # δείχνουμε το «.» — μοιάζει σφάλμα στον ιδιοκτήτη.
    release_note = ("η εγκατάσταση του installer"
                    if release == "."
                    else release.rsplit("/", 1)[-1])
    blocked = unsupported_reason()
    return {
        "version": APP_VERSION,
        "release": release,
        "release_note": release_note,
        "installed": installed_state(),
        "releases": known_releases(),
        # Στο exe η λειτουργία δεν τρέχει· το λέμε ανοιχτά αντί να δείξουμε
        # κουμπί που δεν κάνει τίποτα.
        "supported": not blocked,
        "unsupported_reason": blocked,
        "configured": updates_configured() and not blocked,
        "public_key_set": bool(public_key_hex()),
        "update_url": current_app.config.get("UPDATE_URL", ""),
        "in_maintenance": in_maintenance(),
        # Έχει εγκατασταθεί νεότερη αλλά ΔΕΝ τρέχει ακόμα — χρειάζεται
        # επανεκκίνηση του υπολογιστή. Χωρίς αυτό, η ιδιοκτήτρια βλέπει
        # «τρέχω 1.0.0» αφού εγκατέστησε την 1.0.1 και νομίζει ότι κάτι
        # πήγε στραβά.
        "pending_restart": pending_restart(),
        # Ζωντανή πρόοδος της εγκατάστασης (βλ. live_install).
        "install": live_install(),
        "auto_pip": bool(current_app.config.get("UPDATE_AUTO_PIP", True)),
        "check_hours": current_app.config.get("UPDATE_CHECK_HOURS", 0),
    }


@bp.route("/")
@admin_required
def page():
    return render_template("staff/updates.html",
                           status=_status_payload(),
                           APP_VERSION=APP_VERSION)


@bp.route("/status")
@admin_required
def status():
    return jsonify(_status_payload())


@bp.route("/check", methods=["POST"])
@admin_required
def check():
    """Έλεγχος για διαθέσιμη ενημέρωση (χειροκίνητα ή από τον προγραμματιστή)."""
    if not updates_configured():
        flash("Δεν έχουν ρυθμιστεί οι ενημερώσεις (UPDATE_URL / δημόσιο κλειδί).",
              "error")
        return redirect(url_for("updates.page"))
    # Η ιδιοκτήτρια ΠΑΤΗΣΕ ΤΟ ΚΟΥΜΠΙ, άρα δικαιολογημένα θέλει να μάθει.
    #
    # ΑΠΟΦΑΣΗ ΜΕ ΖΩΝΤΑΝΗ ΜΕΤΡΗΣΗ. Όταν ο έλεγχος αποτύχει, ρωτάμε το
    # internet ΤΩΡΑ και αυτό κρίνει. Δεν χρησιμοποιούμε την αποθηκευμένη
    # κατάσταση ως αιτιολογία: αν ήταν χαλασμένη, λέμε ψευδώς στην ίδια μας την
    # ιδιοκτήτρια ότι δεν έχει internet, ενώ το έχει.
    try:
        info = check_for_update()
    except UpdateError as exc:
        if probe_internet() is False:
            write_internet_state(False)
            # ΤΟ ΧΡΩΜΑ ΕΙΝΑΙ ΜΕΡΟΣ ΤΟΥ ΜΗΝΥΜΑΤΟΣ. Η ιδιοκτήτρια ΠΑΤΗΣΕ το κουμπί
            # και ο έλεγχος δεν έγινε — αλλά το ίδιο το κείμενο λέει ότι η
            # εφαρμογή λειτουργεί κανονικά. Με κόκκινο η εφαρμογή έλεγε «κάτι πήγε
            # στραβά» ενώ η ιδιοκτήτρία έβλεπε το σαλόν της να δουλεύει απέναντι.
            # Το πορτοκαλί λέει «προσοχή». Το κόκκινο μένει για την περίπτωση
            # παρακάτω, όπου το internet ΛΕΙΤΟΥΡΓΕΙ και αποτυγχάνει κάτι άλλο —
            # εκεί το κόκκινο είναι σωστό.
            flash(offline_message(), "warning")
        else:
            # Το internet λειτουργεί, άρα το πρόβλημα είναι αλλού — στον
            # διακομιστή ενημερώσεων ή στη διαδρομή. Λέμε την αληθινή αιτία.
            write_internet_state(True)
            flash(f"Ο έλεγχος απέτυχε: {exc}", "error")
        return redirect(url_for("updates.page"))
    except Exception as exc:                       # noqa: BLE001
        # ΔΙΠΛΗ ΑΣΦΑΛΕΙΑ. Οποιαδήποτε απροσδόκητη εξαίρεση από τον έλεγχο
        # πρέπει να είναι μήνυμα στην ιδιοκτήτρια, όχι «500 — Κάτι πήγε
        # στραβά». Έχουμε ήδη διορθώσει την αιτία (η _fetch δεν έπινε τις
        # αποτυχίες δικτύου και έβρισκε το 500 όταν το GitHub δεν
        # απαντούσε), αλλά αυτό το πλαίσιο εγγυάται ότι η σελίδα δεν θα
        # ξανασπάσει μπροστά σε ανθρώπινο μάτι, όποια και αν είναι η αιτία.
        #
        # Στο log βάζουμε ΟΛΟ το traceback και το όνομα της εξαίρεσης:
        # χωρίς αυτό το πρόβλημα είναι ανεξήγητο αύριο.
        current_app.logger.exception(
            "Αποτυχία στον χειροκίνητο έλεγχο ενημερώσεων")
        flash("Ο έλεγχος ενημερώσεων δεν ολοκληρώθηκε "
              f"({type(exc).__name__}: {exc}). Δοκίμασε ξανά· αν επαναληφθεί, "
              "μήνυσέ μου.", "error")
        return redirect(url_for("updates.page"))

    write_internet_state(True)
    # ΤΟ ΚΡΙΣΙΜΟ: και ο χειροκίνητος έλεγχος γράφει την κατάσταση. Αλλιώς
    # η ιδιοκτήτρια θα έβλεπε χειροκίνητα ότι υπάρχει ενημέρωση, και η
    # επόμενη σύνδεση δεν θα το ήξερε — ένας έλεγχος που δεν αποθηκεύει
    # τίποτα δεν προσφέρει τίποτα.
    write_check_cache(info)
    if info.available:
        flash(f"Διαθέσιμη ενημέρωση {info.version} (τρέχουσα {APP_VERSION}).", "info")
    else:
        flash(f"Η εφαρμογή είναι ενημερωμένη ({APP_VERSION}).", "success")
    return redirect(url_for("updates.page"))


@bp.route("/install", methods=["POST"])
@admin_required
def install():
    """Κατεβάζει, ελέγχει την υπογραφή και εγκαθιστά την ενημέρωση."""
    global _installing
    if not updates_configured():
        flash("Δεν έχουν ρυθμιστεί οι ενημερώσεις.", "error")
        return redirect(url_for("updates.page"))
    if _installing:
        flash("Μια εγκατάσταση ενημέρωσης εκτελείται ήδη.", "error")
        return redirect(url_for("updates.page"))

    try:
        info = check_for_update()
    except UpdateError as exc:
        flash(str(exc), "error")
        return redirect(url_for("updates.page"))
    if not info.available:
        flash("Δεν υπάρχει διαθέσιμη ενημέρωση.", "info")
        return redirect(url_for("updates.page"))

    maintenance_on(f"Εγκατάσταση ενημέρωσης {info.version}")
    _installing = True
    report = InstallReport()
    # Μπαίνει στη ζωντανή κατάσταση ΠΡΙΝ ξεκινήσει το νήμα, ώστε η
    # οθόνη συντήρησης να βλέπει τα βήματα μόλις εμφανιστεί.
    _set_phase("installing", info.version, report)

    # Ο ΠΡΑΓΜΑΤΙΚΟΣ ΑΝΤΙΚΕΙΜΕΝΟΣ ΤΗΣ ΕΦΑΡΜΟΓΗΣ. Το current_app είναι
    # LocalProxy: ζει μόνο όσο η αίτηση. Στο νήμα πεθαίνει — και μαζί του
    # και το ίδιο το «with current_app.app_context():», που έτσι έπεφτε με το
    # ίδιο RuntimeError που προσπαθούσε να λύσει. Το _get_current_object() το
    # βγάζει ΜΙΑ ΦΟΡΑ, εδώ, όπου η αίτηση ζει ακόμα.
    flask_app = current_app._get_current_object()

    def _work():
        # ══ Η ΒΑΣΙΚΗ ΑΙΤΙΑ ΤΟΥ «ΔΕΝ ΟΛΟΚΛΗΡΩΘΗΚΕ ΠΟΤΕ» ══
        #
        # Η εγκατάσταση τρέχει σε ΝΗΜΑ, και ένα νήμα ΔΕΝ έχει app context.
        # Το install_update() και οι βοηθοί του (migrate.backup_database,
        # _health_check, instance_dir) διαβάζουν current_app. Χωρίς context
        # σκοτώνονταν με «RuntimeError: Working outside of application
        # context» — που πιάνεται ως UpdateError και με τον κανόνα «pass»
        # ΧΑΝΟΤΑΝ ΟΛΟΚΛΗΡΑ.
        #
        # Η ιδιοκτήτρια έβλεπε «μην κλείσετε τη σελίδα» και μετά ΤΙΠΟΤΑ. Και το
        # χειρότερο: η αποτυχία ήταν ΤΑΧΥΤΗ, οπότε το maintenance_off()
        # πρόλαβε να ξεκλειδώσει την εφαρμογή πριν το browser προλάβει να
        # ζητήσει την επόμενη σελίδα — οπότε ούτε οθόνη συντήρησης έφανε.
        #
        # Το app_context() περνάει στο νήμα ΟΛΑ όσα χρειάζεται: βάση, ρυθμίσεις,
        # INSTANCE_DIR.
        global _installing
        ok = False
        try:
            with flask_app.app_context():
                install_update(info, report)
            ok = True
        except UpdateError as exc:
            # ΚΑΤΑΛΗΨΤΕ ΤΟ ΜΗΝΥΜΑ. Το «pass» ήταν ψευδής ασφάλεια: η εγκατάσταση
            # δεν είναι προαιρετική, και μια αποτυχία που δεν λέει τι απέτυχε
            # δεν αξίζει τίποτα. Η ιδιοκτήτρια θέλει τον λόγο στην οθόνη.
                        # Ο ΛΟΓΟΣ ΣΤΟ detail, ΟΧΙ ΣΤΟ ΟΝΟΜΑ. Το όνομα είναι η ετικέτα του
                    # βήματος και φαίνεται σε μία στείλη· ένα μήνυμα σφάλματος θα
                    # χορταίνει τη γραμμή και θα φαίνεται σαν κομμένο κείμενο. Το
                    # detail έχει δικό του χώρο και είναι αυτό που διαβάζει πρώτα.
                    report.add("Η εγκατάσταση απέτυχε", False, str(exc)[:400])
        except Exception as exc:            # μη γνωστό: καταγραφή, όχι κρίσιμο
            report.add("Απροσδόκητο σφάλμα", False,
                       f"{type(exc).__name__}: {exc}"[:300])
        finally:
            _installing = False
            if ok:
                # ΠΡΙΝ το restart: η διεργασία σκοτώνεται, οπότε
                # αυτή είναι η ΤΕΛΕΥΤΑΙΑ ευκαιρία να το δει η
                # ιδιοκτήτρια. Χωρίς αυτή τη φάση, το polling θα
                # έβλεπε «εγκατάσταση» και μετά σκέτο σφάλμα
                # σύνδεσης, χωρίς εξήγηση.
                _set_phase("restarting", info.version)
                # ΕΠΙΤΥΧΙΑ => επανεκκίνηση. Χωρίς αυτήν τη διεργασία κρατά τον
                # ΠΑΛΙΟ κώδικα στη μνήμη: το set_active_release αλλάζει μόνο
                # ποιος φάκελος είναι ενεργός, δεν επαναφορτώνει την Python.
                # Η εφαρμογή θα συνέχιζε να λέει 1.0.0 μέχρι να ξαναμπεί ο
                # υπολογιστής — ενώ το μήνυμα υπόσχεται επανεκκίνηση.
                request_restart(reason=f"update {info.version}")
            else:
                # ΑΠΟΤΥΧΙΑ => ξεκλείδωμα και συνέχεια στην παλιά έκδοση.
                # Χωρίς restart: είναι ήδη η ενεργή, το restart δεν θα έφερε
                # τίποτα και θα έκοβε την εφαρμογή από το πρόσωπο της χρήστη.
                _set_phase("failed", info.version)
                # Η ΠΑΥΗ ΠΡΙΝ ΤΟ ΞΕΚΛΕΙΔΩΜΑ. Χωρίς αυτήν, μια ΓΡΗΓΟΡΗ
                # αποτυχία (αρχείο που λείπει, URL που δεν απαντά) έσβηνε τη
                # συντήρηση πριν προλάβει το browser να ζητήσει την επόμενη
                # σελίδα· η ιδιοκτήτρια έβλεπε κανονική σελίδα με το «μην
                # κλείσετε τη σελίδα» και ΧΩΡΙΣ ΠΡΟΟΔΟ — ακριβώς το σύμπτωμα
                # που ανέφερε. Με την παύση προλαβαίνει να δει ΓΙΑΤΙ.
                time.sleep(FAILURE_GRACE_SECONDS)
                maintenance_off()

    threading.Thread(target=_work, name="update-install", daemon=True).start()
    # Η ΑΝΑΚΑΤΕΥΘΥΝΣΗ ΣΤΟ DASHBOARD ΗΤΑΝ ΛΑΘΟΣ, ΚΑΙ ΕΜΦΑΝΙΖΕΤΑΝ ΣΑΝ ΔΥΟ
    # ΠΡΟΒΛΗΜΑΤΑ ΕΝΩ ΕΙΝΑΙ ΕΝΑ.
    #
    # Το dashboard ζητήθηκε αμέσως μετά την εγκατάσταση, ενώ η διαδικασία
    # ετοιμαζόταν να πεθάνει. Ο browser προλαβαίνει να το φορτώσει ΑΠΟ ΤΗΝ
    # ΠΑΛΙΑ ΔΙΑΔΙΚΑΣΙΑ, με την ΠΑΛΙΑ ΕΚΔΟΣΗ — «Έκδοση 1.3» ενώ είχε ήδη μπει
    # η 1.4 — και ένα δευτερόλεπτο αργότερα η διεύθυνση είναι νεκρή. Δύο
    # συμπτώματα, μία αιτία: πήγαμε σε σελίδα που εξαρτάται από τη διαδικασία
    # που σκοτώνεται.
    #
    # Το /restarting ΔΕΝ ΕΞΑΡΤΑΤΑΙ ΑΠΟ ΑΥΤΗΝ — το ίδιο το αρχείο σερβίρουν οι
    # στατικές, και το ίδιο το /health (εκτός κάθε πύλης) λέει στη ΖΩΝΤΑΝΗ
    # διαδικασία πού να πάει η ιδιοκτήτρια: στο σαλόνι αν η άδεια είναι
    # ενεργή, στη σελίδα άδειας αν όχι.
    flash("Η ενημέρωση ξεκίνησε. Η εφαρμογή θα επανεκκινήσει μόλις ολοκληρωθεί — "
          "μην κλείσετε αυτή τη σελίδα, θα επιστρέψει μόνη της.", "info")
    return redirect(url_for("restarting"))


@bp.route("/rollback", methods=["POST"])
@admin_required
def do_rollback():
    try:
        name = rollback()
    except UpdateError as exc:
        flash(str(exc), "error")
        return redirect(url_for("updates.page"))
    flash(f"Επιστροφή στην έκδοση {name}. Η εφαρμογή επανεκκινεί τώρα.", "success")
    request_restart(reason="rollback")
    # Η ίδια λογική με την εγκατάσταση: όχι σε σελίδα που εξαρτάται από τη
    # διαδικασία που σκοτώνεται, αλλά στη σελίδα που περιμένει να γυρίσει.
    return redirect(url_for("restarting"))


@bp.route("/maintenance/off", methods=["POST"])
@admin_required
def clear_maintenance():
    maintenance_off()
    flash("Καθάρισε η λειτουργία συντήρησης.", "success")
    return redirect(url_for("updates.page"))
