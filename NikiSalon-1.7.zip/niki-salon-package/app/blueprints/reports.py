"""Αναφορές & στατιστικά — σύστημα διαχείρισης ραντεβού σαλονιού."""

from __future__ import annotations

import re
import unicodedata
import urllib.parse
from collections import defaultdict
from datetime import date as date_cls, datetime, time, timedelta

from flask import Blueprint, Response, render_template, request
from sqlalchemy import func

from ..extensions import db
from ..exports import build_finance_workbook, build_stats_workbook
from ..helpers import admin_required, staff_required
from ..models import (
    SPECIES,
    OPEN_STATUSES,
    STATUS_CANCELLED,
    STATUS_COMPLETED,
    STATUS_NO_SHOW,
    Appointment,
    Customer,
    Groomer,
    Pet,
    Service,
    WEEKDAYS,
)

bp = Blueprint("reports", __name__, url_prefix="/staff/reports")

XLSX_MIMETYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

MONTHS = ["Ιαν", "Φεβ", "Μαρ", "Απρ", "Μαΐ", "Ιουν", "Ιουλ", "Αυγ", "Σεπ", "Οκτ", "Νοέ", "Δεκ"]


def _month_bounds(months_back: int = 0) -> tuple[date_cls, date_cls]:
    today = date_cls.today()
    year = today.year
    month = today.month - months_back
    while month <= 0:
        month += 12
        year -= 1
    start = date_cls(year, month, 1)
    end = (date_cls(year + 1, 1, 1) if month == 12 else date_cls(year, month + 1, 1))
    return start, end


@bp.route("/")
@staff_required
def overview():
    start, end = _month_bounds()
    start_dt = datetime.combine(start, time(0, 0))
    end_dt = datetime.combine(end, time(0, 0))

    period_appointments = (
        Appointment.query.filter(Appointment.start_at >= start_dt, Appointment.start_at < end_dt)
        .order_by(Appointment.start_at)
        .all()
    )
    completed = [a for a in period_appointments if a.status == STATUS_COMPLETED]
    cancelled = [a for a in period_appointments if a.status == STATUS_CANCELLED]
    no_shows = [a for a in period_appointments if a.status == STATUS_NO_SHOW]

    # --- Ημερήσια κατανομή ---
    daily = defaultdict(int)
    for appt in completed:
        daily[appt.start_at.date()] += 1
    days_in_month = (end - timedelta(days=1)).day
    daily_series = []
    for d in range(days_in_month):
        day = date_cls(start.year, start.month, d + 1)
        count = daily.get(day, 0)
        daily_series.append({"day": d + 1, "count": count})
    max_daily = max((d["count"] for d in daily_series), default=0) or 1
    for entry in daily_series:
        entry["pct"] = round(entry["count"] / max_daily * 100, 1)

    # --- Ανά ημέρα εβδομάδας ---
    weekday = defaultdict(int)
    for appt in completed:
        weekday[appt.start_at.weekday()] += 1
    weekday_series = []
    for wd in range(7):
        count = weekday.get(wd, 0)
        weekday_series.append({
            "label": WEEKDAYS[wd],
            "short": WEEKDAYS[wd][:3],
            "count": count,
        })
    max_wd = max((w["count"] for w in weekday_series), default=0) or 1
    for entry in weekday_series:
        entry["pct"] = round(entry["count"] / max_wd * 100, 1)

    # --- Ανά υπηρεσία ---
    service_rows = []
    for service in Service.query.order_by(Service.sort_order).all():
        related = [a for a in completed if any(s.id == service.id for s in a.services)]
        if not related:
            continue
        service_rows.append({
            "service": service,
            "count": len(related),
        })
    max_service = max((r["count"] for r in service_rows), default=0) or 1
    for row in service_rows:
        row["pct"] = round(row["count"] / max_service * 100, 1)

    # --- Ανά στυλίστρια ---
    groomer_rows = []
    for groomer in db.session.query(Groomer).join(Groomer.user).all():
        related = [a for a in completed if a.groomer_id == groomer.id]
        duration_min = sum(
            int((a.end_at - a.start_at).total_seconds() // 60) for a in related
        )
        groomer_rows.append({
            "groomer": groomer,
            "count": len(related),
            "minutes": duration_min,
        })

    # --- Κορυφαίοι πελάτες ---
    top_customers = []
    for customer in db.session.query(Customer).all():
        related = [a for a in completed if a.customer_id == customer.id]
        if not related:
            continue
        top_customers.append({
            "customer": customer,
            "visits": len(related),
            "last": max(a.start_at for a in related),
        })
    top_customers.sort(key=lambda r: -r["visits"])

    # --- Νέοι πελάτες μήνα ---
    new_customers = (
        db.session.query(Customer)
        .filter(Customer.created_at >= start_dt, Customer.created_at < end_dt)
        .count()
    )

    # --- Είδη κατοικιδίων (το μέγεθος καταργήθηκε, το είδος παραμένει) ---
    total_pets = 0
    species_rows = []
    for species, label in SPECIES.items():
        count = db.session.query(func.count(Pet.id)).filter(Pet.species == species).scalar()
        species_rows.append({"label": label, "count": count})
        total_pets += count
    total_pets = total_pets or 1
    for row in species_rows:
        row["pct"] = round(row["count"] / total_pets * 100, 1)

    total_booked = len(period_appointments) or 1
    metrics = {
        "completed": len(completed),
        "booked": len(period_appointments),
        "cancelled": len(cancelled),
        "no_shows": len(no_shows),
        "new_customers": new_customers,
        "cancel_rate": round(len(cancelled) / total_booked * 100, 1),
        "no_show_rate": round(len(no_shows) / total_booked * 100, 1),
        "completion_rate": round(len(completed) / total_booked * 100, 1),
        "utilisation": round(
            sum(int((a.end_at - a.start_at).total_seconds() // 60) for a in completed)
            / max(1, len(completed) * 90) * 100, 1
        ),
    }

    return render_template(
        "reports/overview.html",
        start=start,
        end=end,
        period_label=f"{MONTHS[start.month - 1]} {start.year}",
        daily_series=daily_series,
        weekday_series=weekday_series,
        service_rows=service_rows,
        groomer_rows=groomer_rows,
        top_customers=top_customers[:10],
        species_rows=species_rows,
        metrics=metrics,
        show_revenue=False,
    )


@bp.route("/revenue")
@admin_required
def revenue():
    """Μηνιαίος κύκλος εργασιών για 12 μήνες (χωρίς έσοδα)."""
    today = date_cls.today()
    months = []
    for back in range(11, -1, -1):
        start, end = _month_bounds(back)
        start_dt = datetime.combine(start, time(0, 0))
        end_dt = datetime.combine(end, time(0, 0))
        completed = Appointment.query.filter(
            Appointment.status == STATUS_COMPLETED,
            Appointment.start_at >= start_dt,
            Appointment.start_at < end_dt,
        ).all()
        months.append({
            "start": start,
            "label": f"{MONTHS[start.month - 1]} {str(start.year)[2:]}",
            "count": len(completed),
            # Έσοδα μόνο από ολοκληρωμένα ραντεβού, με την τελική τιμή
            # (δηλαδή αφαιρούμενη την έκπτωση του καταστήματος).
            "revenue": sum(a.price_effective for a in completed),
        })
    max_revenue = max((m["revenue"] for m in months), default=0) or 1
    for month in months:
        month["pct"] = round(month["revenue"] / max_revenue * 100, 1)
    total = sum(m["revenue"] for m in months)
    best = max(months, key=lambda m: m["revenue"], default=None) if months else None

    return render_template(
        "reports/revenue.html",
        months=months,
        total=total,
        average=total / len(months) if months else 0,
        best=best,
        show_revenue=True,
    )


# ---------------------------------------------------------------- εξαγωγή Excel


def _anchor() -> date_cls:
    """Ημερομηνία στήριξης της περιόδου (default: σήμερα)."""
    raw = request.args.get("date", "")
    try:
        return date_cls.fromisoformat(raw) if raw else date_cls.today()
    except ValueError:
        return date_cls.today()


def _ascii_filename(name: str) -> str:
    """Έγκυρο latin-1 όνομα αρχείου, για πελάτες που δεν καταλαβαίνουν UTF-8."""
    stripped = unicodedata.normalize("NFKD", name)
    stripped = stripped.encode("ascii", "ignore").decode("ascii")
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", stripped)
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    return cleaned or "export.xlsx"


def _content_disposition(filename: str) -> str:
    """Κεφαλίδα λήψης αρχείου.

    Οι HTTP κεφαλίδες είναι latin-1, άρα ένα ελληνικό όνομα όπως «Μηνιαία»
    έσκαγε το σερβέρ με UnicodeEncodeError. Γι' αυτό δίνουμε:
      · filename       – ασφαλές ASCII, για παλιούς browsers/email clients
      · filename*      – το πραγματικό ελληνικό, κωδικοποιημένο (RFC 5987)
    """
    return 'attachment; filename="%s"; filename*=UTF-8\'\'%s' % (
        _ascii_filename(filename), urllib.parse.quote(filename, safe=""))


def _xlsx_response(data: bytes, filename: str) -> Response:
    response = Response(data, mimetype=XLSX_MIMETYPE)
    response.headers["Content-Disposition"] = _content_disposition(filename + ".xlsx")
    # Χωρίς αυτό, ο browser μπορεί να κρατήσει την παλιά έκδοση στο cache.
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@bp.route("/finance/export")
@admin_required
def finance_export():
    """Λογαριαστική αναφορά «Έσοδα – Έξοδα» σε Excel. Μόνο ιδιοκτήτρια."""
    data, filename, _ = build_finance_workbook(request.args.get("period", ""), _anchor())
    return _xlsx_response(data, filename)


@bp.route("/export")
@staff_required
def stats_export():
    """Στατιστικά σε Excel. Χωρίς χρηματικά ποσά, άρα και για τους βοηθούς."""
    data, filename, _ = build_stats_workbook(request.args.get("period", ""), _anchor())
    return _xlsx_response(data, filename)
