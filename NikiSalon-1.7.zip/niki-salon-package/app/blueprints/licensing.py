# -*- coding: utf-8 -*-
"""Η άδεια χρήσης — σελίδα ενεργοποίησης και ανανέωσης.

ΤΙ ΜΠΑΙΝΕΙ ΣΕ ΑΥΤΟ ΤΟ ΑΡΧΕΙΟ
    Τρία πράγματα, και τίποτα άλλο:

    1. Η σελίδα `/license/` — πού βλέπει κάποιος την κατάστασή του και
       στέλνει τα στοιχεία του υπολογιστή στον ιδιοκτήτη.
    2. Το `/license/block.txt` — το ίδιο κείμενο, σε μορφή που αντιγράφεται
       με ένα κλικ χωρίς JavaScript.
    3. Η `POST /license/activate` — η ανέβασμα του αρχείου άδειας.

ΓΙΑΤΙ Η ΣΕΛΙΔΑ ΔΕΝ ΖΗΤΑ ΣΥΝΔΕΣΗ
    Είναι το σημαντικότερο σημείο του αρχείου. Σκεφτείτε τι γίνεται αν η
    άδεια λείπει: η εφαρμογή κλειδώνει, ο χρήστης δεν μπαίνει, και η
    σελίδα που θα του έλυνε το πρόβλημα ήταν πίσω από τη σύνδεση — δηλαδή
    απρόσιτη. Ακριβώς στο χειρότερο σημείο. Άρα η σελίδα είναι ΑΝΟΙΧΤΗ.

    «Δεν είναι ασφαλές;» Όχι: η ανέβασμα δεκτή μόνο αν περάσει η ΥΠΟΓΡΑΦΗ
    του ιδιοκτήτη. Χωρίς αυτήν το αρχείο δεν γράφεται καν (βλ. `activate()`
    στο `license_check`), άρα η ανοιχτή σελίδα δεν ανοίγει πόρτα — κάνει
    μόνο το πράγμα που θα έκανε και με σύνδεση.

    Η σελίδα δείχνει το αποτύπωμα του υλικού σε κάθε επισκέπτη. Είναι το
    ΙΔΙΟ του υπολογιστή του, το οποίο μπορεί να διαβάσει και χωρίς την
    εφαρμογή από το αρχείο `instance/license.json`. Δεν κρύβει τίποτα.

ΤΙ ΔΕΝ ΜΠΑΙΝΕΙ ΕΔΩ
    Ο έλεγχος της άδειας (υπογραφή, λήξη, σύνδεση με το υλικό). Αυτός είναι
    στο `app/license_check.py` και είναι ΜΟΝΟ backend. Η σελίδα εδώ δείχνει
    — δεν αποφασίζει τίποτα.
"""

from __future__ import annotations

import json

from flask import (Blueprint, Response, flash, redirect, render_template,
                   request, url_for)

from .. import hwid, license_check
from ..license_check import check, copy_block, describe_status

bp = Blueprint("licensing", __name__, url_prefix="/license")


def _safe_next(target: str) -> str:
    """Δέχεται ΜΟΝΟ σχετική διαδρομή — ποτέ `http://evil.example`.

    Το `next` έρχεται από τη διεύθυνση της σελίδας, άρα το καθαρίζει. Το
    `//evil.example` και το `https://evil.example` δεκτά είναι τόσο
    «σχετικά» όσο ένας σύνδεσμος από τον εαυτό σου.
    """
    text = str(target or "").strip()
    if not text.startswith("/") or text.startswith("//") or "\\" in text:
        return ""
    return text


@bp.route("/")
def activation():
    """Η σελίδα της άδειας. Ανοιχτή — χωρίς σύνδεση, βλ. την κεφαλαία του
    αρχείου γιατί ακριβώς έτσι πρέπει να είναι."""
    state = check()
    return render_template(
        "licensing/activation.html",
        state=state,
        sentence=describe_status(state),
        block=copy_block(state, hwid.describe()),
        target=_safe_next(request.args.get("next") or ""),
        locked=state.locked,
    )


@bp.route("/block.txt")
def block_text():
    """Το ίδιο κείμενο σε απλό αρχείο.

    Υπάρχει για δύο λόγους. Πρώτον, το «αντίγραψε» σε απλό <textarea> χρειάζεται
    JavaScript, και το JavaScript μπορεί να μην τρέχει (παλιός browser,
    ή browser που το μπλοκάρει). Δεύτερον, κάποιος μπορεί να το κατεβάσει
    με το browser του καθαρά, χωρίς να πειράξει τίποτα.

    Είναι η ίδια μία συνάρτηση `copy_block()` με αυτή της τη σελίδα — άρα
    το αρχείο και η σελίδα δεν μπορούν να αποκλίσουν ποτέ. Και τα δύο
    προέρχονται από την ίδια κλήση, όχι από δύο αντίγραφα κειμένου.
    """
    state = check()
    return Response(copy_block(state, hwid.describe()),
                    mimetype="text/plain; charset=utf-8")


@bp.route("/activate", methods=["POST"])
def activate():
    """Ανέβασμα άδειας. Γράφει ΜΟΝΟ αν περάσει ο έλεγχος."""
    if request.content_length and request.content_length > 64 * 1024:
        flash("Το αρχείο είναι πολύ μεγάλο. Μια άδεια είναι μερικές εκατοντάδες "
              "bytes· στείλτε το αρχείο .lic, όχι κάτι άλλο.", "error")
        return redirect(url_for("licensing.activation"))

    upload = request.files.get("license")
    if upload is None or not upload.filename:
        flash("Δεν επιλέχθηκε αρχείο.", "error")
        return redirect(url_for("licensing.activation"))

    raw = upload.read()
    if len(raw) > license_check.MAX_LICENSE_BYTES:
        flash("Το αρχείο δεν μοιάζει με άδεια: είναι μεγαλύτερο από "
              "%d bytes." % license_check.MAX_LICENSE_BYTES, "error")
        return redirect(url_for("licensing.activation"))

    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        flash("Το αρχείο δεν διαβάστηκε. Βεβαιωθείτε ότι στέλνετε το .lic, "
              "όχι τη συνομιλία.", "error")
        return redirect(url_for("licensing.activation"))

    wrote, reason = license_check.activate(payload)
    if not wrote:
        flash(reason, "error")
        return redirect(url_for("licensing.activation"))

    hwid.forget()                      # η μέτρηση ξαναγίνεται μετά την εγκατάσταση
    serial = str(payload.get("serial") or "")
    flash("Η άδεια ενεργοποιήθηκε. Serial: %s" % serial, "success")

    target = _safe_next(request.form.get("target") or "")
    return redirect(target or url_for("staff.dashboard"))