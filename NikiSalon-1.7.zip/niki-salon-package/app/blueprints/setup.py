"""Πρώτη εγκατάσταση: δημιουργία του πρώτου λογαριασμού ιδιοκτήτριας.

Η σελίδα `/setup` υπάρχει μόνο όσο ΔΕΝ υπάρχει ιδιοκτήτρια. Μόλις δημιουργηθεί,
επιστρέφει 404 — «εξαφανίζεται για πάντα».

Ασφάλεια
---------
Η σελίδα είναι μη επιβεβαιωμένη (μπορεί να τη δει καθένας), οπότε:

* Από το ίδιο μηχάνημα (localhost) δεν ζητείται κωδικός: εκεί έχει πρόσβαση
  μόνο όποιος έχει φυσικά τον υπολογιστή. Έτσι το διπλό κλικ στο .exe
  δεν χρειάζεται τίποτα.
* Από άλλο μηχάνημα ζητείται μοναδικός κωδικός, ο οποίος τυπώνεται στο
  τερματικό της εγκατάστασης και αποθηκεύεται στο instance/setup_token.txt.
  Χωρίς αυτόν κανείς από το δίκτυο δεν μπορεί να «καταλάβει» τον ιδιοκτήτη.
* Ο CSRF προστατεύει τη φόρμα και ο κωδικός διαγράφεται μετά τη χρήση.
"""

from __future__ import annotations

import secrets
from pathlib import Path

from flask import (
    Blueprint,
    abort,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_login import current_user
from sqlalchemy.exc import OperationalError
from werkzeug.utils import secure_filename

from ..extensions import db
from ..helpers import MIN_PASSWORD_LENGTH, clean, admin_required
from ..models import (ROLE_OWNER, Groomer, SalonDaySettings, SalonSettings,
                     User, AvailabilityRule)

bp = Blueprint("setup", __name__, url_prefix="/setup")

TOKEN_FILE = "setup_token.txt"
TOKEN_BYTES = 16


# ------------------------------------------------------------------- token
def token_path() -> Path:
    return Path(current_app.config["INSTANCE_DIR"]) / TOKEN_FILE


def read_token() -> str:
    try:
        return token_path().read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def ensure_token() -> str:
    """Επιστρέφει τον κωδικό, δημιουργώντας τον αν δεν υπάρχει."""
    existing = read_token()
    if existing:
        return existing
    token = secrets.token_urlsafe(TOKEN_BYTES)
    path = token_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(token, encoding="utf-8")
    except OSError:
        # Χωρίς δικαίωμα εγγραφής το token δεν αποθηκεύεται· ο localhost
        # έχει πάντα πρόσβαση, οπότε η εγκατάσταση δεν μπλοκάρει.
        pass
    return token


def clear_token() -> None:
    try:
        token_path().unlink()
    except OSError:
        pass


def _token_matches(given: str | None, token: str) -> bool:
    """Ασφαλής σύγκριση κωδικού.

    Το secrets.compare_digest σηκώνει TypeError σε str με μη-ASCII χαρακτήρες,
    οπότε συγκρίνουμε πάντα bytes.
    """
    if not given or not token:
        return False
    return secrets.compare_digest(given.encode("utf-8"), token.encode("utf-8"))


def owner_exists() -> bool:
    """Υπάρχει ήδη ιδιοκτήτριας;

    Αν ο πίνακας users δεν υπάρχει ακόμη, λέμε «όχι» αντί να σκάσουμε. Στην
    παραγωγή ο server.py δημιουργεί τους πίνακες στην εκκίνηση, αλλά αν
    κάποιος τρέξει την εφαρμογή με άλλο τρόπο (flask run, wsgi.py) η πρώτη
    σελίδα που θα δει ο επισκέπτης είναι αυτή. Ένα 500 εδώ σημαίνει «χαλασμένη
    εγκατάσταση» αντί για «βάλε τον κωδικό σου».
    """
    try:
        return User.query.filter_by(role=ROLE_OWNER).first() is not None
    except OperationalError:
        db.session.rollback()
        return False


# Γιατί ζητείται ΠΑΝΤΑ κωδικός: πίσω από το IIS κάθε αίτηση φτάνει από το
# 127.0.0.1, οπότε ΔΕΝ μπορούμε να ξεχωρίσουμε τον τοπικό χρήστη από κάποιον
# στο δίκτυο. Η μόνη ασφαλής επιλογή είναι ο κωδικός εγκατάστασης.


# ------------------------------------------------------------------ routes
@bp.before_request
def _guard():
    # Υπάρχει ήδη ιδιοκτήτρια → η σελίδα εξαφανίζεται για πάντα.
    if owner_exists():
        abort(404)
    if current_user.is_authenticated:
        return redirect(url_for("staff.dashboard"))


@bp.route("/", methods=["GET", "POST"])
def first_run():
    token = ensure_token()

    # Το install.py ανοίγει τη σελίδα με το κωδικό στη διεύθυνση,
    # ώστε να μην ζητηθεί να πληκτρολογηθεί.
    if _token_matches(request.args.get("token"), token):
        session["setup_ok"] = True
    verified = bool(session.get("setup_ok"))

    if request.method == "POST":
        given = clean(request.form.get("token"))
        if verified or _token_matches(given, token):
            session["setup_ok"] = True
        else:
            flash("Ο κωδικός εγκατάστασης δεν είναι σωστός.", "error")
            return render_template("setup/first_run.html",
                                   salon_name=SalonSettings.get("name"))

        username = User.normalize_username(request.form.get("username"))
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm") or ""
        first_name = clean(request.form.get("first_name"))
        last_name = clean(request.form.get("last_name"))
        email = User.normalize_email(request.form.get("email"))
        # ΤΟ ΟΝΟΜΑ ΤΟΥ ΣΑΛΟΝΙ. Υποχρεωτικό: γράφεται στην άδεια, και χωρίς
        # αυτό οι άδειες δεν ξεχωρίζουν ποιος πελάτης έχει ποιον υπολογιστή.
        # Το σύνολο του κειμένου κόβεται στα 80, όσο και η στήλη στη βάση.
        salon_name = clean(request.form.get("salon_name"))[:80]

        if not salon_name:
            flash("Το όνομα του Salon είναι υποχρεωτικό.", "error")
        elif not username:
            flash("Το όνομα χρήστη είναι υποχρεωτικό.", "error")
        elif len(password) < MIN_PASSWORD_LENGTH:
            flash(
                f"Ο κωδικός πρέπει να έχει τουλάχιστον {MIN_PASSWORD_LENGTH} χαρακτήρες.",
                "error",
            )
        elif password != confirm:
            flash("Οι δύο κωδικοί δεν ταιριάζουν.", "error")
        else:
            clash = User.query.filter(db.func.lower(User.username) == username.lower()).first()
            if clash is None and email:
                clash = User.query.filter(db.func.lower(User.email) == email.lower()).first()
            if clash is not None:
                flash("Υπάρχει ήδη χρήστης με αυτό το όνομα χρήστη ή το email.", "error")
            else:
                return _create_owner(username, password, first_name, last_name,
                                     email, salon_name)

    return render_template("setup/first_run.html",
                           salon_name=SalonSettings.get("name"))


def _create_owner(username, password, first_name, last_name, email,
                  salon_name=""):
    # Ο ΚΑΝΩΝ ΤΟΥ ΟΝΟΜΑΤΟΣ ΤΟΥ ΣΑΛΟΝΙ ΓΡΑΦΕΤΑΙ ΠΡΩΤΟΣ. Αν μετά το commit
    # αποτύχει κάτι, χάνεται το όνομα — που είναι το μόνο πράγμα που
    # χρειάζεται για να ξεχωρίσει τις άδειες. Δεν θα το χάνουμε.
    if salon_name:
        SalonSettings.set("name", salon_name)

    user = User(
        username=username,
        email=email or None,
        role=ROLE_OWNER,
        first_name=first_name or username,
        last_name=last_name or "",
    )
    user.set_password(password)
    db.session.add(user)
    db.session.flush()

    groomer = Groomer(user_id=user.id, sort_order=user.id, color="#B0567A")
    db.session.add(groomer)
    db.session.flush()

    # Διαθεσιμότητα = ώρες λειτουργίας του σπα, ώστε να κλείδονται ραντεβού.
    #
    # Αν οι ώρες λειτουργίας λείπουν, η ιδιοκτήτριας θα έπαιρνε στυλίστρια ΧΩΡΙΣ
    # καμία διαθεσιμότητα και δεν θα μπορούσε να κλείσει ούτε ένα ραντεβού —
    # χωρίς κανένα μήνυμα που να το εξηγεί. Γι' αυτό τις δημιουργούμε πρώτα.
    if not SalonDaySettings.query.first():
        try:
            from migrate import seed_salon_hours

            seed_salon_hours()
        except Exception as exc:                # ποτέ να μη χαλάσει το /setup
            db.session.rollback()
            current_app.logger.warning("Οι ώρες λειτουργίας δεν δημιουργήθηκαν: %s", exc)

    days = SalonDaySettings.query.order_by(SalonDaySettings.weekday).all()
    for day in days:
        if day.is_closed:
            continue
        db.session.add(
            AvailabilityRule(
                groomer_id=groomer.id,
                weekday=day.weekday,
                start_time=day.open_time,
                end_time=day.close_time,
            )
        )

    db.session.commit()
    clear_token()  # η σελίδα κλείνει οριστικά
    flash(f"Δημιουργήθηκε η ιδιοκτήτρια «{username}». Συνδεθείτε για να ξεκινήσετε.", "success")
    return redirect(url_for("auth.login"))


# ------------------------------------------------------------------- CLI
def setup_url(base_url: str = "") -> str:
    """Η διεύθυνση της σελίδας /setup με τον κωδικό — έτοιμη για κλικ."""
    token = ensure_token()
    base = (base_url or current_app.config.get("PUBLIC_BASE_URL") or "").rstrip("/")
    host = request.host if base == "" else base
    return f"{host}/setup/?token={token}"
