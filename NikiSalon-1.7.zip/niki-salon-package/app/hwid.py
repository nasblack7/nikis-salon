# -*- coding: utf-8 -*-
"""Αποτύπωμα υλικού (HWID) για την άδεια χρήσης.

ΤΙ ΜΕΤΡΑΕΙ ΚΑΙ ΤΙ ΟΧΙ
    Μετράνε ΔΥΟ πράγματα, και μόνο αυτά, γιατί πρέπει να είναι σταθερά
    όσο ζει ο υπολογιστής:

        1. MachineGuid        — εγγραφή των Windows για τη μηχανή
        2. MAC φυσικής κάρτας — το τυπικό δίκτυο

    ΔΕΝ μετράνε ο δίσκος και η μνήμη: αλλάζουν. Γι' αυτό υπάρχουν ΔΥΟ
    hashes — το `core` (τα δύο παραπάνω, αμετάβλητα) και το `full`
    (core + σειρά δίσκου). Όταν αλλάζει δίσκος, το core παραμένει ίδιο και
    η άδεια μένει ενεργή με ειδοποίηση.

ΓΙΑΤΙ ΔΕΝ ΜΕΤΡΑΜΕ ΠΙΑ ΤΗΝ ΜΗΤΡΕΑ
    Στις 2026-10-04 μια ιδιοκτήτρια ενεργοποίησε την άδεια, δοκίμασε το
    email, και ΜΕΤΑ ΤΗ ΔΟΚΙΜΗ η εφαρμογή της είπε «η άδεια είναι για άλλον
    υπολογιστή». Το email δεν είχε καμία σχέση. Το αίτιο ήταν η μητρέα:
    διαβαζόταν με μια κλήση PowerShell με χρονικό όριο 4 δευτερολέπτων, και
    όταν αυτή η κλήση δεν προλάβαινε, η μέτρηση υποκαθιστούσε ΑΛΛΗ ΤΙΜΗ —
    την `uuid.getnode()`, που μετράει άλλο πράγμα. Άλλαζε, δηλαδή, το
    ύλικό που μετράμε με βάση το αν ένα subprocess είχε χρόνο.

    Ένα όριο χρόνου που λήγει δεν επιτρέπεται να αλλάζει ΤΑΥΤΟΤΗΤΑ. Άρα η
    ταυτότητα διαβάζεται ΜΟΝΟ από πηγές χωρίς subprocess, χωρίς χρονικό
    όριο, χωρίς εναλλακτική. Ο δίσκος έμεινε μόνο στο `full`, που είναι
    ανοχή και όχι ταυτότητα — αν εκεί αποτύχει, το χειρότερο είναι μια
    ψεύτικη ειδοποίηση, όχι κλειστό σαλόνι.

ΚΑΝΕΝΑ ΜΗΧΑΝΗΜΑ ΔΕΝ ΜΑΝΤΕΥΕΤΑΙ ΠΟΤΕ
    Όταν κάτι δεν διαβάζεται, η `_measure()` επιστρέφει ΚΕΝΟ και
    γράφει τον λόγο στο `unavailable_reason()`. Το άδειο είναι ΤΡΙΤΗ,
    ξεχωριστή κατάσταση — όχι «άδεια για άλλον υπολογιστή». Ένα αποτυχημένο
    μέτρημα και ένα λάθος μηχάνημα είναι δύο διαφορετικά γεγονότα, με δύο
    διαφορετικές οδηγίες προς τον πελάτη — και η σύγχυσή τους κόστισε ένα
    ταξίδι της ιδιοκτήτριας.

ΜΟΝΟ ΚΑΘΑΡΗ PYTHON
    Καμία βιβλιοθήκη τρίτου μέρους, καμία εγκατάσταση, καμία άδεια. Ο
    υπολογιστής του σαλονιού δεν χρειάζεται να μπει στο internet για να
    τρέξει αυτό το αρχείο.

ΕΜΠΙΣΤΟΣΥΝΗ
    Οι συγκρίσεις γίνονται ΜΟΝΟ μέσα στο backend. Η σελίδα δείχνει τις
    τιμές, αλλά καμία απόφαση δεν παίρνεται από το πρότυπο ή το JS.
"""

from __future__ import annotations

import hashlib
import os
import re
import threading
import time as _time
import uuid as _uuid
from typing import Optional, Tuple

#: Το μήκος του hash που κρατάμε στην άδεια. Το SHA-256 αρκεί εδώ: δεν
#: κρυπτογραφούμε κάτι, απλώς δεν θέλουμε δύο διαφορετικές μηχανές να
#: παράγουν το ίδιο αποτύπωμα κατά λάθος.
HASH_LEN = 64

#: Πόσα πρώτα ψηφία του core γίνονται το σύντομο Activation ID. Οκτώ
#: ψηφία (32 εκατομμύρια πιθανότητες) αρκούν για ανθρώπινο χειρισμό: το
#: ID δεν προστατεύει τίποτα μόνο του, απλών εντοπίζει γρήγορα ποιος
#: υπολογιστής είναι ποιος όταν σας στέλνουν ένα μήνυμα.
ACTIVATION_ID_LEN = 8


# ── δεξιά παραμέτρος για το μηχάνημα ─────────────────────────────────────────

def _machine_guid() -> str:
    """Το MachineGuid των Windows.

    Η εγγραφή είναι η πιο σταθερή ταυτότητα μηχανής που υπάρχει στα
    Windows. Διαβάζεται απευθείας από το registry με το `winreg` — χωρίς
    `wmic`, που αφαιρέθηκε από τα Windows 11, και χωρίς PowerShell.
    """
    if os.name != "nt":
        return ""
    try:
        import winreg  # type: ignore

        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
            0,
            winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
        ) as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
        return str(value)
    except Exception:
        return ""


#: Τύποι διεπαφής που είναι ΦΥΣΙΚΗ κάρτα. Οτιδήποτε άλλο — tunnel του VPN,
#: loopback, PPP, προσαρμογέας bridge — δεν μπαίνει ΠΟΤΕ στην ταυτότητα.
#: Χωρίς αυτή τη λίστα, η εγκατάσταση ενός VPN θα άλλαζε την άδεια χωρίς να
#: αλλάξει κανένας υπολογιστής — ίδια κατηγορία λάθος με αυτό που μόλις
#: διορθώσαμε, απλά με μικρότερη συχνότητα.
IF_TYPE_PHYSICAL = frozenset((6, 62, 71, 117))

#: Μήκος MAC σε bytes. Ethernet και Wi-Fi είναι 6· τα δίκτυα σε άλλα
#: πρωτόκολλα (InfiniBand, Token Ring) δεν είναι αυτό που θέλουμε να μετρήσουμε.
MAC_LEN = 6

#: Άνω όριο διεπαφών που διαβάζουμε. Στην πράξη μια μηχανή έχει λίγες —
#: δεκάδες το πολύ με όλες τις εικονικές. Ο αριθμός δεν είναι περιορισμός
#: λειτουργίας, είναι ασφαλής διακοπής: κλείδωμα αν η λίστα δεν τελειώνει.
MAX_ADAPTERS = 256


def _mac_is_fabricated(text: str) -> bool:
    """Αληθινή κάρτα ή τυχαίος αριθμός; Ένα bit αποφασίζει.

    Όταν η `uuid.getnode()` δεν βρίσκει κάρτα, επιστρέφει τυχαίο 48-bit με το
    bit 40 αναμμένο — και το ίδιο το CPython το τεκμηριώνει: «This bit is
    the unicast or multicast bit, which will never be set in IEEE 802
    addresses obtained from network cards». Άρα το bit μας λέει με
    βεβαιότητα αν η τιμή προέρχεται από κάρτα ή είναι μια χαζή εφεύρεση του
    `os.urandom`.

    Χωρίς αυτόν τον έλεγχο, μια τέτοια τιμή μπαίνει στην ταυτότητα και
    αλλάζει σε κάθε εκκίνηση της εφαρμογής — άδεια που πεθαίνει με το restart
    χωρίς να πει ποτέ γιατί. Είναι ακριβώς το λάθος που έφτιαξε την άδεια της
    ιδιοκτήτριας, μόνο ότι εκεί η εναλλακτική ήταν πιο πιθανή από το τυχαίο.
    """
    if len(text) != MAC_LEN * 2:
        return True
    try:
        first_octet = int(text[:2], 16)
    except ValueError:
        return True
    return bool(first_octet & 0x01)


def _mac_from_adapters() -> str:
    """Η MAC της πρώτης ΦΥΣΙΚΗΣ κάρτας, όπως τις ξέρει το ίδιο το Windows.

    ΧΩΡΙΣ ΚΑΜΙΑ ΕΚΤΕΛΕΣΗ ΠΡΟΓΡΑΜΜΑΤΟΣ — μια κλήση στο `iphlpapi.dll` μέσω
    `ctypes`, σε μικροδευτερόλεπτα, χωρίς χρονικό όριο και χωρίς εναλλακτική.
    Υπάρχει για έναν λόγο: η `uuid.getnode()` αφήνεται να αποφασίσει μόνη της
    ποια κάρτα είναι «η πρώτη», και η απάντηση εξαρτάται από τη σειρά με την
    οποία ταξινομεί τις διεπαφές το λειτουργικό. Αλλάζει αν εγκατασταθεί VPN,
    αν απενεργοποιηθεί μια κάρτα, αν μπει μια εικονική στο VirtualBox.

    Εμείς τη διαλέγουμε ΕΜΕΙΣ, με κανόνα που έχουμε γράψει: μόνο φυσικές
    κάρτες, μόνο αληθινές διευθύνσεις, και η μικρότερη. Ο κανόνας είναι
    προφανής — δηλαδή δεν μπορεί να αλλάξει με την επόμενη έκδοση των Windows.

    ΚΕΝΟ ΑΝ ΔΕΝ ΔΟΥΛΕΨΕ, ΚΑΙ ΟΧΙ ΣΦΑΛΜΑ. Μηχάνημα χωρίς `iphlpapi` ή χωρίς
    δικαιώματα δεν είναι ελάττωμά μας· δεν κλειδώνουμε σαλόνι γι' αυτό. Η
    εναλλακτική `_mac_from_uuid()` παίρνει τη σειρά, κι αν αποτύχει και αυτή,
    η μέτρηση δηλώνει «δεν μπόρεσα» με λόγο αντί για ψεύτικη ταυτότητα.
    """
    if os.name != "nt":
        return ""
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return ""

    class _AdapterAddresses(ctypes.Structure):
        # ΜΕΧΡΙ ΤΟ PhysicalAddressLength. Το `Flags` είναι το ίδιο union με
        # το `IfType:7`, οπότε τον τύπο της διεπαφής τον διαβάζουμε από εκεί.
        _fields_ = [
            ("Length", wintypes.ULONG),
            ("IfIndex", wintypes.ULONG),
            ("Next", ctypes.c_void_p),
            ("AdapterName", ctypes.c_char_p),
            ("FirstUnicastAddress", ctypes.c_void_p),
            ("FirstAnycastAddress", ctypes.c_void_p),
            ("FirstMulticastAddress", ctypes.c_void_p),
            ("FirstDnsServerAddress", ctypes.c_void_p),
            ("DnsSuffix", ctypes.c_wchar_p),
            ("Description", ctypes.c_wchar_p),
            ("FriendlyName", ctypes.c_wchar_p),
            ("PhysicalAddress", ctypes.c_ubyte * 8),
            ("PhysicalAddressLength", wintypes.ULONG),
            ("Flags", wintypes.ULONG),
        ]

    try:
        get_adapters = ctypes.WinDLL("iphlpapi.dll").GetAdaptersAddresses
        get_adapters.restype = wintypes.ULONG
        # Οι παράμετροι δηλώνονται ρητά: χωρίς αυτές ο ctypes σε 64-bit
        # περνά τον δείκτη του buffer σαν ακέραιο και τον κόβει στα μισά.
        get_adapters.argtypes = [wintypes.ULONG, wintypes.ULONG,
                                 ctypes.c_void_p,
                                 ctypes.POINTER(wintypes.ULONG)]
        # GAA_FLAG_SKIP_{UNICAST,ANYCAST,MULTICAST,DNS_SERVER}: μας
        # ενδιαφέρει ΜΟΝΟ η διεύθυνση υλικού, όχι τα δίκτυα της κάρτας.
        size = wintypes.ULONG(15 * 1024)
        buffer = ctypes.create_string_buffer(size.value)
        if get_adapters(0x000F, 0, ctypes.byref(buffer),
                        ctypes.byref(size)) != 0:
            return ""
        # ΔΥΟ ΦΥΛΑΚΕΣ ΠΟΥ ΔΕΝ ΕΠΙΤΡΕΠΟΥΝ ΚΑΤΑΣΤΡΟΦΗ. Αυτό το κομμάτι
        # διαβάζει δομές με τα χέρια, και δεν το έχουμε δοκιμάσει πάνω σε
        # Windows εδώ. Αν η διάταξη δεν είναι αυτή που νομίζουμε, ο δείκτης
        # `Next` μπορεί να διαβάσει τυχαία bytes και να δείχνει πίσω στον
        # εαυτό του — δηλαδή ατελής βρόχος σε ΚΑΘΕ σελίδα, δηλαδή παγωμένη
        # εφαρμογή. Ο ένας αριθμητής και ο έλεγχος του `Length` είναι ο
        # μόνος τρόπος να μην μετατρέψουμε μια ασφαλή αποτυχία σε κρίση.
        # Αν ποτέ δεν περάσουν, το αποτέλεσμα είναι το fallback της
        # `uuid.getnode()` — δηλαδή συμπεριφορά όπως πριν, όχι χειρότερη.
        limit = ctypes.sizeof(_AdapterAddresses)
        node = ctypes.cast(buffer, ctypes.POINTER(_AdapterAddresses))
        found = []
        seen = 0
        while node and seen < MAX_ADAPTERS:
            seen += 1
            item = node.contents
            if int(item.Length) < limit:
                # Το σύστημα μας έγραψε μικρότερη δομή από αυτή που
                # διαβάζουμε. Τα πεδία μετά από εκεί δεν είναι αξιόπιστα.
                break
            if_type = int(item.Flags) & 0x7F        # union: Flags / IfType:7
            if (if_type in IF_TYPE_PHYSICAL
                    and int(item.PhysicalAddressLength) == MAC_LEN):
                raw = bytes(bytearray(item.PhysicalAddress)[:MAC_LEN])
                text = "".join("%02X" % byte for byte in raw)
                if not _mac_is_fabricated(text):
                    found.append(text)
            node = (ctypes.cast(item.Next,
                                ctypes.POINTER(_AdapterAddresses))
                    if item.Next else None)
        if not found:
            return ""
        # Η ΤΑΞΙΝΟΜΗΣΗ ΕΙΝΑΙ ΤΟ ΣΗΜΑΝΤΙΚΟ. Χωρίς αυτήν, η επιλογή είναι η
        # «πρώτη κατά το λειτουργικό», δηλαδή τυχαία από τη μια εκκίνηση στην
        # επόμενη. Με την ταξινόμηση, δύο μηχανήματα με τις ίδιες κάρτες
        # δίνουν ίδια απάντηση, όσες φορές κι αν τρέξει η εφαρμογή.
        found.sort()
        return found[0]
    except Exception:
        return ""


def _mac_from_uuid() -> str:
    """Η `uuid.getnode()` ως εναλλακτική — ΜΟΝΟ αν είναι αληθινή κάρτα.

    Η δική της επιστροφή είναι ή αληθινή MAC ή ένας τυχαίος αριθμός, και ο
    `_mac_is_fabricated` ξεχωρίζει τα δύο. Ο τυχαίος δεν μπαίνει ΠΟΤΕ στην
    ταυτότητα: μια τιμή που αλλάζει σε κάθε εκκίνηση σκοτώνει την άδεια με
    τον πιο δύσκολο τρόπο που υπάρχει — όχι με μήνυμα, αλλά με κλειδωμένο
    σαλόνι χωρίς εξήγηση.
    """
    try:
        node = _uuid.getnode()
    except Exception:
        return ""
    if node in (0, 0x010000000000):
        return ""
    text = "%012X" % node
    if _mac_is_fabricated(text):
        return ""
    return text


def _mac_address() -> str:
    """Η MAC της ταυτότητας — ή ΚΕΝΟ αν δεν βρέθηκε αληθινή φυσική κάρτα."""
    for getter in (_mac_from_adapters, _mac_from_uuid):
        mac = getter()
        if mac:
            return mac
    return ""


def _disk_serial() -> str:
    """Η σειρά του δίσκου — ΜΟΝΟ για την ανοχή, ποτέ για την ταυτότητα.

    Στα Windows διαβάζεται με PowerShell από το `Win32_DiskDrive`· σε
    Linux/macOS από το `lsblk`. Αν δεν βρεθεί, μένει κενό και η ανοχή
    απλώς δεν χρειάζεται — ο έλεγχος γίνεται μόνο από το core.
    """
    if os.name == "nt":
        try:
            import subprocess

            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "(Get-CimInstance -ClassName Win32_DiskDrive | "
                 "Select-Object -First 1).SerialNumber"],
                capture_output=True, text=True, timeout=4.0, check=False,
            )
            return (out.stdout or "").strip().splitlines()[0].strip()
        except Exception:
            return ""
    try:
        import subprocess

        out = subprocess.run(["lsblk", "-no", "SERIAL"],
                             capture_output=True, text=True, timeout=4.0,
                             check=False)
        for line in (out.stdout or "").splitlines():
            value = line.strip()
            if value:
                return value
    except Exception:
        pass
    return ""


# ── κανονικοποίηση και κατανομή ─────────────────────────────────────────────

def _clean(value: str) -> str:
    """Καθαρίζει μια τιμή ώστε να είναι η ίδια κάθε φορά που διαβάζεται.

    Τα Windows δίνουν τα ίδια δεδομένα με διαφορετική γραφή κάθε φορά
    (κεφαλαία/πεζά, μοναδικά, κενά). Χωρίς αυτό το βήμα, ο ίδιος
    υπολογιστής θα έδινε διαφορετικό hash σε διαφορετική εκκίνηση και η
    άδεια θα έσπαγε μόνη της. Είναι το πιο σημαντικό σημείο όλης της
    υλοποίησης.
    """
    text = str(value or "").strip()
    if not text:
        return ""
    text = re.sub(r"[^0-9A-Za-z]", "", text)     # παύλες, κενά, άνω-κάτω τελεία
    return text.upper()


#: Πόσα δευτερόλεπτα ισχύει η μέτρηση πριν μετρηθεί ξανά. ΜΗΔΕΝ σημαίνει
#: «μετράω σε κάθε κλήση». Ο λόγος υπάρχει: το UUID της μητρέας και η σειρά
#: του δίσκου διαβάζονται στα Windows με μια κλήση PowerShell, που κάνει
#: 0,3–1 δευτερόλεπτα. Χωρίς προσωρινή αποθήκευση, ΚΑΘΕ σελίδα του σαλονιού
#: θα περίμενε δευτερόλεπτα — και αυτό είναι το χειρότερο πράγμα που μπορεί
#: να γίνει σε μια εφαρμογή κρατήσεων.
HWID_TTL_SECONDS = 600

_cache: dict = {}
_cache_lock = threading.Lock()
_cache_time: float = 0.0


def _ttl() -> float:
    """Η ισχύοντα TTL — οι δοκιμές το κάνουν 0 για να μετράτε φρέσκα."""
    try:
        from flask import current_app, has_app_context

        if has_app_context():
            value = current_app.config.get("HWID_TTL_SECONDS")
            if value is not None:
                return float(value)
    except Exception:
        pass
    return float(HWID_TTL_SECONDS)


def forget() -> None:
    """Ξεχνάει τη μέτρηση· η επόμενη κλήση την ξανακάνει.

    Χρησιμοποιείται μετά από αλλαγή υλικού, ή στις δοκιμές.
    """
    global _cache_time, _reason
    with _cache_lock:
        _cache.clear()
        _cache_time = 0.0
    _reason = ""


#: Γιατί δεν μετρήθηκε το μηχάνημα. Κενό = μετρήθηκε κανονικά. Γράφεται
#: ΜΟΝΟ από την `_measure()`.
_reason = ""


def unavailable_reason() -> str:
    """Γιατί η μέτρηση απέτυχε — ή ΚΕΝΟ αν πέτυχε.

    Υπάρχει για να μπορεί ο έλεγχος της άδειας να πει «δεν μπόρεσα να
    μετρήσω αυτό το μηχάνημα» αντί για «η άδεια είναι για άλλον υπολογιστή».
    Δύο τελείως διαφορετικές συνέπειες: το πρώτο λύνει ο πελάτης σε ένα
    λεπτό, το δεύτερο στέλνει τον ιδιοκτήτη να εκδώσει άδεια που δεν
    χρειάζεται. Η σύγχυσή τους κόστισε ένα ταξίδι στην πελάτισσα τον Οκτώβριο.
    """
    return _reason


def _measure() -> Tuple[str, str]:
    """Η πραγματική μέτρηση — χωρίς προσωρινή αποθήκευση.

    ΚΑΜΙΑ ΠΗΓΗ ΔΕΝ ΑΝΤΙΚΑΘΙΣΤΑΤΑΙ ΜΕ ΑΛΛΗ. Πριν, αν η μητρέας δεν
    διαβαζόταν μέσα σε 4 δευτερόλεπτα, υποκαθιστάταν η `uuid.getnode()` στη
    θέση της, η ταυτότητα άλλαζε σιωπηλά, και η άδεια έπαιρνε το «άλλος
    υπολογιστής». Τώρα υπάρχουν ΔΥΟ πηγές (μητρέα, MAC) — κι αν οποιαδήποτε
    από τις δύο δεν διαβαστεί, το αποτέλεσμα είναι ΚΕΝΟ με εξήγηση, όχι μια
    διαφορετική ταυτότητα και όχι μια τρίτη πηγή μπαϊ-τσαντίρικο.
    """
    global _reason
    _reason = ""

    guid = _clean(_machine_guid())
    mac = _clean(_mac_address())
    disk = _clean(_disk_serial())

    if os.name != "nt":
        # ΕΚΤΟΣ WINDOWS ΔΕΝ ΥΠΑΡΧΕΙ MachineGuid — ΚΑΘΟΛΟΥ. Δεν είναι αποτυχία
        # ανάγνωσης, είναι ένα λειτουργικό χωρίς αντίστοιχο κλειδί. Αν γύρναγε
        # κενό, κάθε μηχάνημα χωρίς Windows θα ήταν «αμέτρητο» για πάντα — δηλαδή
        # απαγορευμένο χωρίς εξήγηση, συγκρίνοντας με κάτι που δεν υπάρχει πουθενά.
        # Άρα εδώ η ταυτότητα είναι ΜΟΝΟ η κάρτα, και το σταθερό μαρκάρισμα
        # καταγράφει ότι δεν υπήρξε MachineGuid να μπει. Η εφαρμογή είναι
        # προορισμένη για Windows· εκτός Windows τρέχει μόνο για ανάπτυξη,
        # δοκιμές και το probe suite, και το "OTHEROS" είναι ορατό στο hash
        # του κάθε τέτοιου μηχανήματος — δεν μπορεί δηλαδή ένα τέτοιο μηχάνημα
        # να κερδίσει άδεια εκδοθείσα για Windows, ούτε το αντίστροφο.
        guid = "OTHEROS"
    elif not guid:
        _reason = ("Δεν διαβάστηκε το αναγνωριστικό της μηχανής (MachineGuid) "
                   "από το μητρώο των Windows. Χωρίς αυτό η εφαρμογή δεν "
                   "ξέρει σε ποιον υπολογιστή βρίσκεται — και δεν θα το "
                   "μαντέψει, γιατί το λάθος μηχάνημα κόστισε νέα άδεια.")
        return "", ""

    if not mac:
        _reason = ("Δεν βρέθηκε φυσική κάρτα δικτύου σε αυτόν τον υπολογιστή, "
                   "ή η διεύθυνσή της δεν μπόρεσε να διαβαστεί. Αν μόλις "
                   "εγκαταστήσατε ή αφαιρέσατε κάρτα, επανεκκινήστε τον "
                   "υπολογιστή και δοκιμάστε ξανά. Η άδειά σας μένει η ίδια — "
                   "δεν χρειάζεται νέα.")
        return "", ""

    core_raw = "|".join((guid, mac))
    # Ο δίσκος είναι ΑΝΟΧΗ, όχι ταυτότητα. Αν δεν διαβαστεί, μπαίνει το
    # σύμβολο κενού και το αποτέλεσμα παραμένει σταθερό για αυτόν τον
    # υπολογιστή — μια φθαρμένη ανάγνωση δίσκου δεν αλλάζει ποτέ ταυτότητα.
    full_raw = core_raw + "|" + (disk or "-")

    core = hashlib.sha256(core_raw.encode("utf-8")).hexdigest()
    full = hashlib.sha256(full_raw.encode("utf-8")).hexdigest()
    return core, full


def compute() -> Tuple[str, str]:
    """Επιστρέφει (core, full) — δύο SHA-256 σε hex.

    Το `core` είναι η ταυτότητα του μηχανήματος. Το `full` προσθέτει τον
    δίσκο και χρησιμοποιείται ΜΟΝΟ για την ανοχή.

    Η μέτρηση κρατιέται προσωρινά για `HWID_TTL_SECONDS` δευτερόλεπτα. Άρα η
    εγκατάσταση ενός νέου δίσκου ενδέχεται να μη φανεί αμέσως: το αντιλαμβάνεται
    ο έλεγχος στην επόμενη μέτρηση, το αργότερο δέκα λεπτά αργότερα. Είναι
    μικρό κόστος για σταθερότητα σε κάθε σελίδα.
    """
    global _cache_time
    with _cache_lock:
        age = _time.monotonic() - _cache_time
        if _cache and age < _ttl():
            return _cache["core"], _cache["full"]
    core, full = _measure()
    if not core:
        # ΜΙΑ ΑΠΟΤΥΧΙΑ ΔΕΝ ΚΛΕΙΝΕΙ ΤΟ ΣΑΛΟΝΙ ΓΙΑ ΔΕΚΑ ΛΕΠΤΑ. Το αποτέλεσμα
        # γράφεται μόνο όταν υπήρξε: αν η ανάγνωση αποτύχει για λόγο που
        # διορθώνεται με μια επανεκκίνηση ή με το επόμενο κλικ, η επόμενη
        # κλήση ξαναπροσπαθεί. Δεχόμαστε λοιπόν να ξαναμετρήσουμε σε κάθε
        # σελίδα όσο δεν έχουμε απάντηση — η μέτρηση τώρα είναι σε
        # μικροδευτερόλεπτα, οπότε δεν υπάρχει κόστος που να αξίζει να
        # αποθηκεύσουμε ένα λάθος.
        return core, full
    with _cache_lock:
        _cache["core"], _cache["full"] = core, full
        _cache_time = _time.monotonic()
    return core, full


def activation_id(core: str) -> str:
    """Το σύντομο ID που στέλνει ο χρήστης όταν ζητά άδεια.

    Προέρχεται από το `core` μόνο, ώστε να παραμένει ίδιο αν αλλάξει ο
    δίσκος — αλλιώς ο χρήστης θα έπρεπε να σας πει «άλλο ID», ενώ το μόνο
    που άλλαξε ήταν ο δίσκος, και εσείς δεν θα τον αναγνωρίσατε.
    """
    text = (core or "").strip().upper()
    if len(text) < ACTIVATION_ID_LEN:
        return text or "—"
    return "%s-%s" % (text[:4], text[4:ACTIVATION_ID_LEN])


def fingerprint() -> str:
    """Η τιμή που μπαίνει στην άδεια και στο μήνυμα προς τον ιδιοκτήτη."""
    core, full = compute()
    if not core:
        return ""
    return "%s:%s" % (core, full)


def describe() -> str:
    """Μία γραμμή με το τι είδους μηχάνημα είναι — για διαγνωστικό."""
    import platform
    return "%s %s" % (platform.system() or "?", platform.machine() or "?")
