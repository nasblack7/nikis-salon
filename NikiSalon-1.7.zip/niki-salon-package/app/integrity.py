"""ΕΛΕΓΧΟΣ ΟΤΙ Ο ΚΩΔΙΚΑΣ ΣΤΟ ΔΙΣΚΟ ΔΕΝ ΕΧΕΙ ΠΕΙΧΤΕΙ.

ΤΟ ΠΡΟΒΛΗΜΑ ΠΟΥ ΛΥΝΕΙ. Η εφαρμογή υπογράφει και ελέγχει Ο,ΤΙ ΚΑΤΕΒΑΖΕΙ
(`app/updates.py`): το πακέτο ενημέρωσης, το SHA-256 του, την υπογραφή Ed25519
του manifest. Αυτό είναι σωστό και αρκεί για το δίκτυο.

ΔΕΝ ΕΛΕΓΧΕ ΟΤΙ ΥΠΑΡΧΕΙ ΗΔΗ ΣΤΟ ΔΙΣΚΟ. Και εκεί είναι το κενό: η ιδιοκτήτρια
(ή κάποιος με πρόσβαση στο μηχάνημα) ανοίγει με το ΣΗΜΕΙΟΓΡΑΦΟ το
`app/license_check.py`, κάνει μία αλλαγή ώστε το `locked` να επιστρέφει False,
και το σαλόνι ανοίγει χωρίς άδεια. Δύο λεπτά δουλειά, καμία εντύπωση.

ΕΔΩ ΤΙ ΓΙΝΕΤΑΙ. Μετά κάθε εγκατάσταση (φρέσκα ή ενημέρωση) κρατάμε ένα
ΑΝΤΙΓΡΑΦΟ ΤΟΥ ΥΠΟΓΡΑΦΜΕΝΟΥ manifest, που ήδη περιέχει το SHA-256 κάθε
αρχείου. Σε κάθε εκκίνηση το ξαναελέγχουμε:

    1. Η υπογραφή του αντιγράφου είναι αληθινή;
       (το ιδιωτικό κλειδί δεν υπάρχει στο μηχάνημα — άρα ό,τι υπογράψαμε
        εμείς στο build, και τίποτα άλλο)
    2. Τα αρχεία που παρακολουθούμε υπάρχουν και έχουν αυτή την εικόνα.

ΤΡΙΑ ΠΡΑΓΜΑΤΑ ΠΟΥ ΤΟ ΚΑΝΟΥΝ ΛΟΓΙΚΟ ΝΑ ΜΗΝ ΤΟ ΕΧΕΙΣ:

  * ΔΕΝ κάνει restart loop σε περίπτωση παραβίασης. Ένα μη μηδενικό exit θα το
    έκανε ο `run_server.cmd` να ξανασκιάσει για πάντα, με μαύρο παράθυρο
    που ανοίγει και κλείνει. Οι ιδιοκτήτρια θα έβλεπε κάτι σαν το σφάλμα με το
    8080 — χωρίς να καταλάβει τον αληθινό λόγο. Αντί γι' αυτό το σαλόνι
    απλώς ΔΕΝ ΞΕΚΛΕΙΔΩΝΕΙ, και λέει ποιο αρχείο διαφέρει και πώς το
    διορθώνει. Το κόστος της παραβίασης είναι μηδέν, χωρίς να γίνει η μηχανή
    άχρηστη.

  * ΑΝ ΛΕΙΠΕΙ ΤΟ ΑΝΤΙΓΡΑΦΟ, δεν μπλοκάρει. Μια εγκατάσταση που έγινε με την
    1.4 δεν έχει `integrity.json`. Χωρίς αυτή την εκφώνηση, η πρώτη εκκίνηση
    μετά την αναβάθμιση θα έκανε το σαλόνι να μη σηκώνεται καθόλου — το χειρότερο
    δυνατό αποτέλεσμα από έναν έλεγχο ασφαλείας.

  * ΔΕΝ ελέγχει κάθε αρχείο. Μόνο αυτά που σημαίνουν «μπορεί να ξεκλειδωθεί το
    σαλόνι». Ένα πρότυπο ή ένα στιλ που διορθώνει κάποιος δεν πρέπει να κλείνει
    την εφαρμογή — και τα δεδομένα (βάση, άδεια, φωτογραφίες) δεν ανήκουν στο
    πακέτο ενημέρωσης, οπότε δεν υπάρχει ούτε εικόνα τους.

ΤΙ ΔΕΝ ΠΡΟΣΤΑΤΕΥΕΙ, ΜΕ ΕΙΛΙΚΡΙΝΕΙΑ. Όποιος μπορεί να γράψει στο δίσκο μπορεί να
σβήσει και το ίδιο το `integrity.py`. Καμία επαλήθευση από την πλευρά του
πελάτη δεν μπορεί να ξεπεράσει αυτό το γενικό κανόνα — γι' αυτό το PyArmor υπάρχει
ως επιλογή. Αυτό όμως σηκώνει το κόστος από «μία αλλαγή σε μία γραμμή» σε
«πρέπει να καταλάβεις τι κάνει το κώδικα», κι αυτό είναι ακριβώς το ζητούμενο.
Οι εγκαταστάσεις ενημέρωσης παραμένουν υπογραμμένες, άρα κανείς δεν μπορεί να
φέρνει και από το δίκτυο «μια δική του έκδοση».

ΤΑ ΤΡΙΑ ΜΕΡΗ:
  * `build_update.py`  — το υπογραφμένο manifest περιέχει ήδη τα hashes.
  * `app/updates.py`   — τη στέλνει εδώ μετά κάθε εγκατάσταση.
  * εδώ                — την κρατά και την ελέγχει σε κάθε εκκίνηση.
"""
from __future__ import annotations

import base64
import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path

#: Πόσα δευτερόλεπτα κρατάμε ένα επιτυχημένο (ή αποτυχημένο) αποτέλεσμα.
#: Βλ. `verify()` για το γιατί υπάρχει και τι ακριβώς αυτό αφήνει ανοιχτό.
CACHE_SECONDS = 10.0

#: (fingerprint, monotonic-when, result). Μόνο μία καταχώριση — το ενδιαφέρει
#: το τελευταίο αποτέλεσμα, όχι η ιστορία.
_CACHE = None

#: ΤΑ ΑΡΧΕΙΑ ΠΟΥ ΠΑΡΑΚΟΛΟΥΘΟΥΝΤΑΙ. Ο,ΤΙ ΜΕΤΡΑΕΙ ΓΙΑ ΝΑ ΞΕΚΛΕΙΔΩΣΕΙ ΤΟ ΣΑΛΟΝΙ
#: Ή ΓΙΑ ΝΑ ΔΕΧΤΕΙ ΜΙΑ ΕΝΗΜΕΡΩΣΗ. Το ίδιο το `integrity.py` μπαίνει στη λίστα:
#: όποιος το αλλάξει έτσι και αλλάζει και τον έλεγχο, οπότε θέλει να το
#: προσέξει. Δεν είναι απόδειξη — είναι το πρώτο εμπόδιο, όχι το τελευταίο.
WATCHED = (
    "app/license_check.py",
    "app/ed25519.py",
    "app/hwid.py",
    "app/version.py",
    "app/updates.py",
    "app/integrity.py",
)

STATE_NAME = "integrity.json"

#: Οι τρεις καταστάσεις. Η «άγνωστη» ΔΕΝ είναι αποτυχία: σημαίνει ότι δεν υπάρχει
#: ακόμη αντίγραφο, άρα δεν έχει πει κανείς ψέμα — απλώς δεν έχει μετρηθεί.
OK = "ok"
UNKNOWN = "unknown"
TAMPERED = "tampered"


@dataclass
class IntegrityResult:
    status: str = UNKNOWN
    problems: list[str] = field(default_factory=list)
    version: str = ""
    checked: int = 0

    @property
    def ok(self) -> bool:
        return self.status != TAMPERED

    @property
    def blocking(self) -> bool:
        """True μόνο όταν ΥΠΑΡΧΕΙ απόδειξη ότι κάτι πειράχτηκε.

        Η «άγνωστη» κατάσταση δεν μπλοκάρει: βλ. το μοναδικό κίνητρο του `state_file`.
        """
        return self.status == TAMPERED

    def note(self) -> str:
        """Το κείμενο για την ιδιοκτήτρια — σε καθαρά ελληνικά, χωρίς κωδικούς."""
        if self.status == OK:
            return ""
        if self.status == UNKNOWN:
            return ""
        listed = "".join(f"\n    · {p}" for p in self.problems[:8])
        return ("Εντοπίστηκε αλλαγή σε αρχεία της εφαρμογής μετά την εγκατάσταση. "
                "Για να μπορέσει το σαλόνι να ξεκλειδωθεί, πρέπει να επανέλθουν "
                "τα αρχεία όπως τα εγκατέστησε ο ιδιοκτήτης:" + listed)


# --------------------------------------------------------------- πού τα κοιτάζουμε

def _instance_dir() -> Path:
    """Ο φάκελος instance/ — εκεί μένει το αντίγραφο του manifest."""
    try:
        from config import INSTANCE_DIR
        return Path(INSTANCE_DIR)
    except Exception:
        return Path(__file__).resolve().parent.parent / "instance"


def state_file() -> Path:
    return _instance_dir() / STATE_NAME


def release_dir() -> Path:
    """Ο φάκελος του ΚΩΔΙΚΑ ΠΟΥ ΤΡΕΧΕΙ ΤΩΡΑ, όχι της ρίζας του project.

    Οι ενημερώσεις ζουν στο `instance/updates/releases/release-<stamp>/`, και το
    `current.txt` δείχνει ποιος είναι ο ενεργός. Χωρίς αυτό, ο έλεγχος θα
    έκρινε άλλα αρχεία από αυτά που τρέχουν — δηλαδή θα έδινε ψευδώς «όλα
    εντάξει» ενώ το σαλόνι τρέχει από αλλού.
    """
    root = Path(__file__).resolve().parent.parent
    try:
        value = (_instance_dir() / "current.txt").read_text(
            encoding="utf-8").strip()
    except OSError:
        return root
    if not value or value == "." or value.startswith("/") or ".." in value:
        return root
    candidate = (_instance_dir() / value).resolve()
    return candidate if candidate.is_dir() else root


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ------------------------------------------------------------------ αποθήκευση

def save(manifest_bytes: bytes, signature: bytes) -> bool:
    """Κράτησε το υπογραφμένο manifest για τους ελέγχους των επόμενων εκκινήσεων.

    Καλείται ΜΟΝΟ αφού έχει επαληθευτεί η υπογραφή του πακέτου. Κρατάμε τα
    ΩΜΑΙΑ bytes του manifest και την υπογραφή, όχι τις αναλύσεις του — γιατί
    μια αντίγραφη λίστα hashes χωρίς υπογραφή δεν αποδεικνύει τίποτα.
    """
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        payload = {
            "version": str(manifest.get("version", "")),
            "manifest_b64": base64.b64encode(manifest_bytes).decode("ascii"),
            "signature_hex": signature.hex(),
            "saved_at": manifest.get("released_at", ""),
        }
        path = state_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                       encoding="utf-8")
        tmp.replace(path)
        _drop_cache()
        return True
    except Exception:
        # Η αποτυχία να αποθκευτεί ΔΕΝ είναι λόγος να πέσει η εγκατάσταση. Η
        # εφαρμογή θα μείνει απλώς σε κατάσταση «άγνωστη» — ασφαλής.
        return False


def _drop_cache() -> None:
    """Ξέχασε το τελευταίο αποτέλεσμα. Καλείται μόλις αλλάξει η κατάσταση."""
    global _CACHE
    _CACHE = None


# --------------------------------------------------------------------- έλεγχος

def verify() -> IntegrityResult:
    """Ελέγχει τα επιτηρούμενα αρχεία, με μικρή μνήμη. ΠοΤΕ δεν σηκώνει εξαίρεση.

    ΤΟ ΚΟΣΤΟΣ ΚΑΙ Η ΜΝΗΜΗ. Ο έλεγχος Ed25519 είναι καθαρή Python και κάνει
    ~4,5 ms — και το `license_check.check()` τρέχει σε ΚΑΘΕ σελίδα. Χωρίς
    μνήμη, ένα σαλόνι με αρκετούς χρήστες θα έτρωγε δεκάδες mss κάθε
    δευτερόλεπτο για έναν έλεγχο που δεν αλλάζει. Οπότε κρατάμε το αποτέλεσμα
    για `CACHE_SECONDS` δευτερόλεπτα.

    ΤΟ ΠΡΟΒΛΗΜΑ ΤΟΥ TTL, ΕΙΛΙΚΡΙΝΑ. Δέκα δευτερόλεπτα είναι το παράθυρο μέσα
    στο οποίο μια αλλαγή δεν θα φανεί. Δέκα δευτερόλεπτα είναι ασήμαντο για τον
    ιδιοκτήτη (δεν κοιτάει την εφαρμογή τόσο γρήγορα) και ασήμαντο για τον
    κακόπαθο (ας προλάβει να τρέξει το σαλόνι δέκα φορές). Αντιθέτως, μια μνήμη
    «για πάντα» θα ήταν χειρότερη: θα έκανε τον έλεγχο διακόσμηση.

    ΤΟ `stat()` ΣΤΟΝ ΟΡΟ. Η μνήμη ακυρώνεται ΑΜΕΣΩΣ αν αλλάξει κάτι, χωρίς να
    περιμένει το TTL — οπότε μια κανονική ενημέρωση ή εγκατάσταση έχει
    αποτέλεσμα αμέσως, όχι «σε δέκα δευτερόλεπτα». Άρα το TTL δεν επιβάλλει
    καθυστέρηση σε κανονική χρήση· υπάρχει μόνο για να κλείσει το παράθυρο του
    «μένω ήσυχα και κρύβω την αλλαγή αλλάζοντας το mtime».
    """
    global _CACHE
    stamp = _fingerprint()
    now = time.monotonic()
    if _CACHE and _CACHE[0] == stamp and now - _CACHE[1] < CACHE_SECONDS:
        return _CACHE[2]

    result = _verify_uncached()
    _CACHE = (stamp, now, result)
    return result


def _fingerprint():
    """Μικρή υπογραφή του «τι υπάρχει τώρα στο δίσκο». Ένα `stat` ανά αρχείο.

    Οχτώ `stat` κάνουν κάτι κάτω από ένα χιλιοστό — και το `_verify_uncached`
    που τρέχει μόνο όταν προκύψει αλλαγή είναι 4,5 ms.
    """
    marks = []
    try:
        st = state_file().stat()
        marks.append((st.st_mtime_ns, st.st_size))
    except OSError:
        marks.append(None)
    base = release_dir()
    for rel in WATCHED:
        try:
            st = (base / rel).stat()
            marks.append((st.st_mtime_ns, st.st_size))
        except OSError:
            marks.append(None)
    return tuple(marks)


def _verify_uncached() -> IntegrityResult:
    """Ο ίδιος ο έλεγχος, χωρίς μνήμη. ΠοΤΕ δεν σηκώνει εξαίρεση.

    Οι εξαιρέσεις εδώ θα έρισχαν μια εφαρμογή που μόλις εγκαταστάθηκε, γι' αυτό
    κάθε αβεβαιότητα γυρίζει ως αποτέλεσμα, όχι ως σφάλμα. Η διαφορά είναι
    που ακριβώς κρίθηκε: «άγνωστη» (δεν έχω απόδειξη) ή «παραβιάστηκε»
    (η υπογραφή ή το hash δεν ταιριάζουν).
    """
    result = IntegrityResult()
    path = state_file()
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return result                      # UNKNOWN: πρώτη εκκίνηση μετά αναβάθμιση
    except OSError:
        return result

    try:
        payload = json.loads(raw)
        manifest_bytes = base64.b64decode(payload["manifest_b64"])
        signature = bytes.fromhex(payload["signature_hex"])
    except Exception:
        # Υπογραφή που δεν μπορεί να διαβαστεί = όχι αποδεκτή απόδειξη. Το
        # λέμε «παραβιάστηκε» και όχι «άγνωστη»: το αρχείο υπάρχει, αλλά είναι
        # σκουπίδι, και το σκουπίδι δεν είναι εγγύηση.
        result.status = TAMPERED
        result.problems.append(
            f"Το αρχείο ελέγχου {STATE_NAME} δεν διαβάζεται.")
        return result

    # 1. Η υπογραφή. Χωρίς αυτήν τα hashes είναι απλώς αριθμοί.
    try:
        from app.ed25519 import verify as ed_verify
        from app.version import UPDATE_PUBLIC_KEY
    except Exception:
        result.status = TAMPERED
        result.problems.append("Δεν διαβάζεται το δημόσιο κλειδί επαλήθευσης.")
        return result

    # Το `UPDATE_PUBLIC_KEY` ΕΙΝΑΙ ΗΔΗ το δημόσιο κλειδί — το δεχόμαστε
    # όπως το δεχόμαστε και η εγκατάσταση ενημερώσεων. Ο `public_key()` του
    # ed25519 ΔΕΝ χρησιμοποιείται εδώ: εκείνος ΠΑΡΑΓΕΙ δημόσιο κλειδί από
    # ΙΔΙΩΤΙΚΟ σπόρο, και δώσαμε δημόσιο. Θα μας έδινε άλλο κλειδί, και κάθε
    # έλεγχος θα έρισχε συνεχώς — δηλαδή η προστασία θα έλεγε «πειραγμένο»
    # σε μια εγκατάσταση που είναι καθαρή.
    try:
        pub = bytes.fromhex(UPDATE_PUBLIC_KEY)
    except ValueError:
        result.status = TAMPERED
        result.problems.append("Το δημόσιο κλειδί δεν είναι έγκυρο.")
        return result

    if not ed_verify(manifest_bytes, signature, pub):
        result.status = TAMPERED
        result.problems.append(
            "Το αντίγραφο ελέγχου δεν έχει τη δική μας υπογραφή — έχει "
            "αλλαχθεί.")
        return result

    # 2. Τα αρχεία.
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        images = manifest.get("files", {})
    except Exception:
        result.status = TAMPERED
        result.problems.append("Το υπογραφμένο αντίγραφο δεν διαβάζεται.")
        return result

    result.version = str(manifest.get("version", ""))
    base = release_dir()
    for rel in WATCHED:
        expected = images.get(rel)
        if expected is None:
            # Ο φάκελος αυτός δεν περιέχει το αρχείο (π.χ. παλιότερη έκδοση
            # που δεν είχε integrity.py). Δεν είναι παραβίαση — είναι απλώς
            # ασφαλές να μην το μετράμε.
            continue
        target = base / rel
        try:
            data = target.read_bytes()
        except OSError:
            result.problems.append(f"{rel} — δεν βρέθηκε στον εγκατεστημένο φάκελο")
            continue
        result.checked += 1
        if sha256_bytes(data) != str(expected).lower():
            result.problems.append(f"{rel} — το περιεχόμενο διαφέρει από το υπογραφμένο")

    if result.problems:
        result.status = TAMPERED
        return result

    result.status = OK
    return result