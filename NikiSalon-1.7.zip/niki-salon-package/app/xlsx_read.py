"""ΑΝΑΓΝΩΣΗ .xlsx — μόνο ανάγνωση.

ΤΟ ΥΠΑΡΧΕΙ ΗΔΗ app/xlsx.py ΜΕ ΓΡΑΨΙΜΟ (Cell/Sheet/Workbook) και το
χρησιμοποιεί οι οικονομικές αναφορές. Εκεί ΔΕΝ υπάρχει ανάγνωση — και
δεν προστίθεται εδώ: το xlsx.py θα παραμένει ο ΜΟΝΟς γράφτης.

ΑΥΤΟ ΤΟ ΑΡΧΕΙΟ ΕΙΝΑΙ Ο ΜΟΝΟΣ ΑΝΑΓΝΩΣΤΗΣ. Το κρατάω χωριστά σκόπιμα: αν
μπει μέσα στο xlsx.py, κάθε αλλαγή στις οικονομικές αναφορές θα έπρεπε να
ξαναδοκιμάζεται, ενώ εδώ αλλάζει μόνο η εισαγωγή πελατών.

ΓΙΑΤΙ ΟΧΙ Η openpyxl. Η εγκατάσταση στο σαλόνι έχει ήδη αποτύχει μία φορά
επειδή το pip δεν κατέβαλε τίποτα (κακό internet ή proxy). Κάθε νέα
βιβλιοθήκη είναι μία ακόμα ευκαιρία να χαλάσει η εγκατάσταση σε μηχάνημα
που μπορεί να μην έχει σύνδεση. Άρα: μόνο βιβλιοθήκες της Python.

ΤΟ ΠΡΑΓΜΑΤΙΚΟ ΔΥΣΚΟΛΟ. Όταν ΓΡΑΦΟΥΜΕ, ελέγχουμε τον κώδικά μας. Όταν
ΔΙΑΒΑΖΟΥΜΕ, το αρχείο το έγραψε το Excel, και το Excel χρησιμοποιεί
ΠΙΝΑΚΑ ΣΥΜΒΟΛΩΝ (sharedStrings) — όχι inline strings. Χωρίς ανάγνωση
του πίνακα, κάθε «Μαρία» θα διαβαζόταν ως ο αριθμός 3. Γι' αυτό υποστηρίζουμε
και τα δύο.
"""
from __future__ import annotations

import csv
import io
import re
import zipfile
from datetime import date, datetime, timedelta
from xml.etree import ElementTree as ET


def _local(tag: str) -> str:
    """Η ετικέτα χωρίς τον χώρο ονομάτων (xmlns)."""
    return tag.rsplit("}", 1)[-1]


def _col_index(ref: str) -> int:
    """«BC12» → 54 (το 0-οποιοδήποτε στήλη)."""
    letters = "".join(c for c in ref if c.isalpha())
    n = 0
    for ch in letters.upper():
        n = n * 26 + (ord(ch) - 64)
    return max(0, n - 1)


def _read_shared_strings(zf: zipfile.ZipFile) -> list[str]:
    """Ο πίνακας συμβόλων του Excel. Χωρίς αυτόν, όλα τα κείμενα
    είναι αριθμοί — και θα διαβαζόμασταν ως «3» αντί για «Μαρία»."""
    try:
        raw = zf.read("xl/sharedStrings.xml")
    except KeyError:
        return []
    out = []
    for si in ET.fromstring(raw).iter():
        if _local(si.tag) != "si":
            continue
        # Ένα κείμενο μπορεί να είναι σπασμένο σε πολλά <r><t> (runs),
        # όταν το Excel αλλάζει γραμματοσειρά μέσα στο κελί.
        out.append("".join(t.text or "" for t in si.iter()
                           if _local(t.tag) == "t"))
    return out


def _first_sheet(zf: zipfile.ZipFile) -> str:
    """Το πρώτο φύλλο, ακόμα κι αν το αρχείο έχει πολλά."""
    try:
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
    except KeyError:
        return "xl/worksheets/sheet1.xml"
    rels = {}
    try:
        for rel in ET.fromstring(zf.read("xl/_rels/workbook.xml.rels")):
            rels[rel.get("Id")] = rel.get("Target", "")
    except KeyError:
        pass
    for sheet in wb.iter():
        if _local(sheet.tag) != "sheet":
            continue
        rid = None
        for k, v in sheet.attrib.items():
            if _local(k) == "id":
                rid = v
        target = rels.get(rid or "", "")
        if target:
            target = target.lstrip("/")
            if not target.startswith("xl/"):
                target = "xl/" + target
            return target
        return "xl/worksheets/sheet1.xml"
    return "xl/worksheets/sheet1.xml"


def read_xlsx(data: bytes) -> list[list[str]]:
    """Διαβάζει το πρώτο φύλλο και επιστρέφει γραμμές λέξεων."""
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        shared = _read_shared_strings(zf)
        root = ET.fromstring(zf.read(_first_sheet(zf)))
        rows: list[list[str]] = []
        for row in root.iter():
            if _local(row.tag) != "row":
                continue
            cells: dict[int, str] = {}
            for c in row:
                if _local(c.tag) != "c":
                    continue
                ref = c.get("r") or ""
                idx = _col_index(ref) if ref else len(cells)
                ctype = c.get("t") or ""
                value = ""
                if ctype == "s":                       # δείκτης συμβόλου
                    v = c.find("{*}v")
                    if v is not None and v.text and v.text.isdigit():
                        i = int(v.text)
                        value = shared[i] if i < len(shared) else ""
                elif ctype == "inlineStr":
                    value = "".join(t.text or "" for t in c.iter()
                                    if _local(t.tag) == "t")
                elif ctype == "str":                   # αποτέλεσμα formula
                    v = c.find("{*}v")
                    value = (v.text or "") if v is not None else ""
                else:                                  # αριθμός ή κενό
                    v = c.find("{*}v")
                    if v is not None and v.text is not None:
                        value = _trim_number(v.text)
                cells[idx] = value
            width = (max(cells) + 1) if cells else 0
            rows.append([cells.get(i, "") for i in range(width)])
        return rows


def _trim_number(text: str) -> str:
    """Το Excel γράφει τους αριθμούς ως «36.0» ή «2109850000.0». Τα
    θέλουμε όπως τα έγραψε η ιδιοκτήτρια: χωρίς την άχρητη «.0»."""
    if "." not in text:
        return text
    cleaned = text.rstrip("0").rstrip(".")
    return cleaned or "0"


# ───────────────────────────────────────────────────── CSV: η ίδια διαδρομή

def read_csv(data: bytes) -> list[list[str]]:
    """Ανοίγει και CSV. Πολλοί βάζουν «Αποθήκευση ως CSV» στο Excel, και
    τότε το αρχείο δεν είναι .xlsx. Αν το τύπωμα δε ταιριάζει, το
    αγνοούμε — όχι σφάλμα."""
    text = None
    for enc in ("utf-8-sig", "cp1253", "latin-1"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ValueError("Το αρχείο δεν είναι αναγνώσιμο κείμενο.")
    # Ο Excel στα ελληνικά βάζει «;» σε ορισμένες εκδόσεις.
    sample = text[:4096]
    delim = ";" if sample.count(";") > sample.count(",") else ","
    return [row for row in csv.reader(io.StringIO(text), delimiter=delim)]


def read_table(data: bytes, filename: str = "") -> list[list[str]]:
    """Η μία είσοδος του πελάτη: δοκιμάζει .xlsx, αλλιώς CSV.

    Δοκιμάζουμε ΠΡΩΤΑ το xlsx και όχι με βάση την επέκταση, γιατί ο Excel
    σώζει πολλές φορές ως .xls ή χωρίς επέκταση, ενώ τα περιεχόμενα είναι
    κανονικό zip. Και το αντίστροφο: ένα αρχείο .xlsx που δεν είναι zip
    (γιατί το άνοιξε κάποιος και το έσωσε ως CSV) πρέπει να διαβαστεί."""
    if data[:2] == b"PK":                    # υπογραφή ZIP = .xlsx
        try:
            rows = read_xlsx(data)
            if any(any(c.strip() for c in r) for r in rows):
                return rows
        except (zipfile.BadZipFile, ET.ParseError, KeyError, IndexError):
            pass                              # πέφτει στο CSV παρακάτω
    return read_csv(data)
