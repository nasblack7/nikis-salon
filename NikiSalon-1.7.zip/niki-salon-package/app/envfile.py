r"""Ασφαλής εγγραφή τιμών στο `.env` από τις Ρυθμίσεις.

ΤΟ `.env` ΔΕΝ ΕΙΝΑΙ «ΑΡΧΕΙΟ ΡΥΘΜΙΣΕΩΝ». Μέσα του είναι το `SECRET_KEY` που
υπογράφει τα cookies σύνδεσης και το `UPDATE_PUBLIC_KEY` που επιτρέπει τις
ενημερώσεις. Μια γραμμή που γράφτηκε λάθος δεν είναι «μια ρύθμιση χαλασμένη» —
είναι όλη η εφαρμογή κλειστή, και η ιδιοκτήτρια χωρίς να ξέρει γιατί.

ΤΡΙΑ ΚΑΝΟΝΕ, ΚΑΙ ΟΙ ΤΡΕΙΣ ΕΙΝΑΙ ΕΞΑΓΩΓΕΣ ΑΠΟ ΑΥΤΑ:

1· ΜΟΝΟ ΑΥΤΑ ΤΑ ΚΛΕΙΔΙΑ. Η λίστα είναι σταθερή εδώ μέσα. Η φόρμα δεν
   «περνάει κλειδί στο .env» — ζητάει από αυτή τη λίστα και τίποτα άλλο δεν
   γράφεται ποτέ. Χωρίς αυτό, ένα κρυφό πεδίο `<input name="SECRET_KEY">`
   θα ήταν μια κλειδαριά σε μια φόρμα ρυθμίσεων.

2· ΤΑ ΥΠΟΛΟΙΠΑ ΑΡΧΕΙΑ ΠΑΜΕ ΑΨΗΧΑ. Δεν ξαναγράφουμε το αρχείο από την αρχή
   με ένα dictionary — κρατάμε τις γραμμές που δεν αγγίζουμε όπως είναι,
   συμπεριλαμβανομένων των σχολίων και της σειράς τους.

3· ΓΡΑΦΕΤΑΙ ΜΕ ΟΝΟΜΑ ΜΕΤΑΒΑΤΗΣ, ΟΧΙ ΜΕ ΟΤΙ ΜΑΤΣΙΑΣΕ Ο ΧΡΗΣΤΗΣ. Το `value`
   μπαίνει σε quotes και τα `"`, `\` και newlines διαφεύγουν. Χωρίς αυτό,
   ένας κωδικός με ειδικό χαρακτήρα θα έσπαγε το αρχείο στη μισή γραμμή.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

#: ΤΑ ΜΟΝΑ ΚΛΕΙΔΙΑ ΠΟΥ ΜΠΟΡΟΥΝ ΝΑ ΓΡΑΦΤΟΥΝ ΑΠΟ ΤΗ ΦΟΡΜΑ. Κάτι εκτός
#: από αυτή τη λίστα δεν γράφεται, ακόμα κι αν το ζητήσει η φόρμα.
ALLOWED_KEYS = (
    "MAIL_ENABLED",
    "MAIL_SERVER",
    "MAIL_PORT",
    "MAIL_SECURITY",
    "MAIL_USER",
    "MAIL_PASSWORD",
    "MAIL_FROM",
    "MAIL_FROM_NAME",
    "MAIL_TIMEOUT",
)

_LINE_RE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=(.*)$")


def _quote(value: str) -> str:
    """Κάνει μια τιμή ασφαλή για το .env, ανεξάρτητα από τι περιέχει."""
    text = str(value)
    text = text.replace("\\", "\\\\").replace('"', '\\"')
    text = text.replace("\r", " ").replace("\n", " ")
    return f'"{text}"'


def env_file_path(base_dir: str | os.PathLike) -> Path:
    """Ο ίδιος κανόνας με το config.py — αλλιώς γράφουμε σε άλλο αρχείο
    από αυτό που διαβάζει η εφαρμογή, και η αλλαγή «δεν κρατά»."""
    return Path(base_dir) / ".env"


def set_env_values(path: Path, values: dict) -> list[str]:
    """Ενημερώνει τα επιτρεπόμενα κλειδιά, αφήνοντας τα υπόλοιπα αψήχα.

    Επιστρέφει τα κλειδιά που άλλαξαν πΡΑΓΜΑΤΙΚΑ — όχι απλώς αυτά που
    ήρθαν στη φόρμα. Οι αλλαγές που δεν άλλαξαν τίποτα δεν θέλουν να
    ξαναγραφτούν το αρχείο επειδή η ιδιοκτήτρία πάτησε «Αποθήκευση».
    """
    changed: list[str] = []
    wanted = {k: v for k, v in values.items() if k in ALLOWED_KEYS}
    if not wanted:
        return changed

    try:
        original = path.read_text(encoding="utf-8")
        had_trailing_newline = original.endswith("\n")
        lines = original.splitlines()
    except OSError:
        lines = []
        had_trailing_newline = True

    # Τι έχει ήδη μέσα, ώστε να ξεχωρίσουμε το «άλλαξε» από το «ίδιο».
    current: dict[str, str] = {}
    for line in lines:
        m = _LINE_RE.match(line)
        if m:
            current[m.group(1)] = m.group(2).strip()

    done: set[str] = set()
    out: list[str] = []
    for line in lines:
        m = _LINE_RE.match(line)
        key = m.group(1) if m else None
        if key is None or key not in wanted or key in done:
            out.append(line)
            continue
        new_value = _quote(wanted[key])
        if m.group(2).strip() != new_value:
            changed.append(key)
        out.append(f"{key}={new_value}")
        done.add(key)

    # Και τα κλειδιά που δεν υπήρχαν: προστίθενται στο τέλος, με τμήμα.
    missing = [k for k in wanted if k not in done]
    if missing:
        if out and not (out[-1].strip() == "" or out[-1].startswith("#")):
            out.append("")
        out.append("# --- Ρυθμίσεις email (από το μενού Ρυθμίσεις) ---")
        out.extend(f"{k}={_quote(wanted[k])}" for k in missing)
        changed.extend(missing)

    if not changed:
        return []

    text = "\n".join(out)
    if had_trailing_newline or text:
        text += "\n"

    # ΓΡΑΦΗ ΜΕ ΟΝΟΜΑ ΠΡΟΣΩΡΙΝΟ + ΑΝΤΙΚΑΤΑΣΤΑΣΗ. Με απλό write_text(), μια
    # διακοπή ρεύματος στη μέση αφήνει μισό αρχείο — και το μισό .env σημαίνει
    # μισό SECRET_KEY. Το os.replace είναι ατομικό στο ίδιο σύστημα αρχείων.
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    try:
        os.replace(tmp, path)
    except OSError:
        tmp.unlink(missing_ok=True)
        raise
    return changed


def apply_to_runtime(app, values: dict) -> None:
    """Κάνε τις νέες τιμές να ισχύσουν ΧΩΡΙΣ επανεκκίνηση.

    Το `mailer` διαβάζει το `current_app.config`, και αυτό διαβάζεται μία
    φορά στην εκκίνηση από το .env. Μόνο το αρχείο δεν αρκεί: η διεργασία θα
    συνέχιζε με τις ΠΑΛΙΕΣ τιμές μέχρι να ξαναμπει ο υπολογιστής — και η
    ιδιοκτήτρια θα έβλεπε «δεν έχει ρυθμιστεί το SMTP» αφού μόλις το ρύθμισε.
    """
    for key, value in values.items():
        if key not in ALLOWED_KEYS:
            continue
        if key in {"MAIL_PORT", "MAIL_TIMEOUT"}:
            try:
                app.config[key] = int(value)
                os.environ[key] = str(int(value))
                continue
            except (TypeError, ValueError):
                continue
        if key == "MAIL_ENABLED":
            app.config[key] = str(value).strip().lower() in {
                "1", "true", "yes", "on"}
            os.environ[key] = app.config[key] and "1" or "0"
            continue
        app.config[key] = value
        os.environ[key] = str(value)

    # Το MAIL_FROM είναι «κενό = ό,τι είναι το MAIL_USER». Μόλις άλλαξε το
    # χρήστη, ένας παλιός MAIL_FROM θα έμενε να στέλνει από τη λάθος διεύθυνση.
    if not app.config.get("MAIL_FROM") and app.config.get("MAIL_USER"):
        app.config["MAIL_FROM"] = app.config["MAIL_USER"]