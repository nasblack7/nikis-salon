"""Αποστολή email μέσω SMTP — σύστημα διαχείρισης ραντεβού σαλονιού."""

from __future__ import annotations

import logging
import smtplib
import socket
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid
from pathlib import Path

from flask import current_app

logger = logging.getLogger("salon.mail")

_last_error: str | None = None

# ΚΑΝΕΝΑ ΠΡΟΕΠΙΛΕΓΜΕΝΟ ΛΟΓΟΤΥΠΟ ΣΤΑ EMAIL. Παλαιότερα εδώ κατοικούσε το
# λογότυπο ενός συγκεκριμένου σαλονιού, οπότε ΚΑΘΕ εγκατάσταση έστελνε
# στους πελάτες της email με δικό της λογότυπο. Τώρα: αν ο χρήστης δεν
# ανέβασε δικό του, το header γράφει απλώς το όνομα του σαλονιού
# (δες `has_logo` στο emails/layout.html).
DEFAULT_LOGO: Path | None = None


#: Ο ΔΙΑΚΟΜΙΣΤΗΣ ΕΙΝΑΙ ΤΟ ΜΟΝΟ ΠΡΑΓΜΑ ΠΟΥ ΧΡΕΙΑΖΕΤΑΙ ΠΑΝΤΑ.
#: Χρήστης και κωδικός ζητούνται ΜΟΝΟ όταν υπάρχουν, γιατί αυτό ακριβώς
#: κάνει και η αποστολή — βλ. `send()`: κάνει login μόνο αν υπάρχει
#: MAIL_USER. Οι δύο πρέπει να συμφωνούν, αλλιώς το «έτοιμο» και το
#: «στάλθηκε» λένε αντίθετα πράγματα.
_REQUIRED = ("MAIL_SERVER",)


def is_configured() -> bool:
    cfg = current_app.config
    if not cfg.get("MAIL_ENABLED", True):
        return False
    return not missing_settings()


def missing_settings() -> list[str]:
    """Τι λείπει ΠΡΑΓΜΑΤΙΚΑ — δηλαδή ό,τι η αποστολή δεν μπορεί να κάνει.

    Ο ΚΩΔΙΚΟΣ ΧΡΕΙΑΖΕΤΑΙ ΜΟΝΟ ΑΝ ΥΠΑΡΧΕΙ ΧΡΗΣΤΗΣ, και ο χρήστης μόνο αν
    πρόκειται για διακομιστή με λογαριασμό. Ένα τοπικό relay (ένα Postfix
    στο ίδιο δίσκο) στέλνει χωρίς ταυτοπροσωπία, και η `send()` το έχει
    προνοήσει — αλλιώς η ιδιοκτήτρια έβλεπε «Δεν έχει ρυθμιστεί το SMTP» σε
    μια ρύθμιση που δουλεύει, και γράφε κωδικό εκεί που δεν ζητείται κανένας.
    """
    cfg = current_app.config
    if not cfg.get("MAIL_ENABLED", True):
        return ["MAIL_ENABLED"]
    missing = [name for name in _REQUIRED if not cfg.get(name)]
    if cfg.get("MAIL_USER") and not cfg.get("MAIL_PASSWORD"):
        missing.append("MAIL_PASSWORD")
    return missing


def status() -> str:
    if not current_app.config.get("MAIL_ENABLED", True):
        return "off"
    if not is_configured():
        return "incomplete"
    return f"error:{_last_error}" if _last_error else "ready"


def describe() -> str:
    cfg = current_app.config
    user = cfg.get("MAIL_USER") or "—"
    pw = cfg.get("MAIL_PASSWORD") or ""
    return (
        f"διακομιστής : {cfg.get('MAIL_SERVER') or '—'}:{cfg.get('MAIL_PORT')} "
        f"({cfg.get('MAIL_SECURITY')})\n"
        f"χρήστης     : {user}\n"
        f"κωδικός     : {'*' * len(pw) if pw else '(λείπει)'}\n"
        f"αποστολέας  : {cfg.get('MAIL_FROM') or '—'} <{cfg.get('MAIL_FROM_NAME') or ''}>\n"
        f"κατάσταση   : {status()}"
    )


def _connect():
    cfg = current_app.config
    host, port = cfg["MAIL_SERVER"], int(cfg["MAIL_PORT"])
    timeout = int(cfg.get("MAIL_TIMEOUT", 10))
    security = (cfg.get("MAIL_SECURITY") or "starttls").lower()

    if security == "ssl":
        context = ssl.create_default_context()
        return smtplib.SMTP_SSL(host, port, timeout=timeout, context=context)

    smtp = smtplib.SMTP(host, port, timeout=timeout)
    try:
        smtp.ehlo()
        if security == "starttls":
            smtp.starttls(context=ssl.create_default_context())
            smtp.ehlo()
        return smtp
    except Exception:
        smtp.close()
        raise


def logo_cid_path() -> Path | None:
    """Το λογότυπο που μπαίνει ως inline εικόνα στα email.

    Σειρά: ό,τι ανέβασε η ιδιοκτήτρια από τις Ρυθμίσεις → το MAIL_LOGO
    του .env → τίποτα (χωρίς λογότυπο το header γράφει το όνομα). Διαβάζεται σε ΚΑΘΕ αποστολή, όχι μία
    φορά, ώστε η αλλαγή λογότύπου να ισχύει αμέσως χωρίς επανεκκίνηση.
    """
    from . import logo as _logo
    uploaded = _logo.uploaded_logo_path()
    if uploaded is not None:
        return uploaded
    configured = current_app.config.get("MAIL_LOGO")
    if configured:
        path: Path | None = Path(configured)
    else:
        path = DEFAULT_LOGO
    if path is None:
        return None
    return path if path.is_file() else None


LOGO_CID = "salon-logo"


@dataclass
class Result:
    ok: bool
    reason: str = ""
    recipient: str = ""
    subject: str = ""


def build_message(
    to: str,
    subject: str,
    text_body: str,
    html_body: str | None = None,
    *,
    reply_to: str | None = None,
) -> EmailMessage:
    cfg = current_app.config
    sender = cfg.get("MAIL_FROM") or cfg.get("MAIL_USER") or ""
    sender_name = cfg.get("MAIL_FROM_NAME") or ""
    if not sender_name:
        # Χωρίς ρύθμιση, όνομα αποστολέα = το όνομα του ΣΑΛΟΝΙΟΥ από τη
        # βάση. Παλαιότερα έπεφτε πάνω σε μια προεπιλογή που ανήκε σε
        # κάποιον συγκεκριμένο ιδιοκτήτη.
        try:
            from .models import SalonSettings
            sender_name = str(SalonSettings.get("name") or "").strip()
        except Exception:                               # noqa: BLE001
            sender_name = ""

    message = EmailMessage()
    message["From"] = formataddr((sender_name, sender))
    message["To"] = to
    message["Subject"] = subject
    message["Date"] = formatdate(localtime=True)
    # ΤΟ DOMAIN ΤΟΥ Message-ID ΔΕΝ ΕΙΝΑΙ ΣΤΑΘΕΡΟ: παλαιότερα ήταν το
    # domain ενός συγκεκριμένου σαλονιού, οπότε ΚΑΘΕ εγκατάσταση έστελνε
    # email με το domain κάποιου άλλου. Παίρνουμε το domain από τη
    # διεύθυνση αποστολέα· χωρίς αυτήν, το make_msgid βάζει το hostname.
    _domain = (sender.split("@")[-1] or "").strip() or None
    message["Message-ID"] = make_msgid(domain=_domain)
    message["X-Mailer"] = "SalonBooking"
    if reply_to:
        message["Reply-To"] = reply_to
    bcc = (cfg.get("MAIL_SENDER_BCC") or "").strip()
    if bcc and bcc != to:
        message["Bcc"] = bcc

    message.set_content(text_body)
    if not html_body:
        return message

    message.add_alternative(html_body, subtype="html")

    logo = logo_cid_path()
    if logo is not None:
        message.get_payload()[1].add_related(
            logo.read_bytes(), maintype="image", subtype="png", cid=f"<{LOGO_CID}>"
        )
    return message


def send_email(
    to: str,
    subject: str,
    text_body: str,
    html_body: str | None = None,
    *,
    reply_to: str | None = None,
) -> Result:
    global _last_error

    to = (to or "").strip()
    if not to or "@" not in to:
        _last_error = "invalid-recipient"
        return Result(False, "Μη έγκυρος παραλήπτης.", to, subject)

    if not is_configured():
        missing = ", ".join(missing_settings())
        _last_error = "not-configured"
        logger.warning(
            "Email προς %s (%s) δεν στάλθηκε — λείπουν: %s", to, subject, missing
        )
        return Result(False, f"Δεν έχει ρυθμιστεί το SMTP (λείπει: {missing}).", to, subject)

    message = build_message(to, subject, text_body, html_body, reply_to=reply_to)

    try:
        with _connect() as smtp:
            if current_app.config.get("MAIL_USER"):
                smtp.login(current_app.config["MAIL_USER"], current_app.config["MAIL_PASSWORD"])
            smtp.send_message(message)
        _last_error = None
        logger.info("Email στάλθηκε προς %s — %s", to, subject)
        return Result(True, "", to, subject)
    except smtplib.SMTPAuthenticationError as exc:
        _last_error = "auth"
        logger.error(
            "Αποτυχία ταυτοποίησης στο SMTP (%s). Μήπως δεν έχεις βάλει κωδικό εφαρμογής;",
            exc.smtp_error.decode("utf-8", "replace") if exc.smtp_error else exc,
        )
        return Result(False, "Λάθος διαπιστευτήρια SMTP (πιθανόν λάθος app password).", to, subject)
    except (smtplib.SMTPException, socket.timeout, OSError, ssl.SSLError) as exc:
        _last_error = type(exc).__name__
        logger.error("Αποτυχία SMTP προς %s: %s: %s", to, type(exc).__name__, exc)
        return Result(False, f"Σφάλμα SMTP ({type(exc).__name__}).", to, subject)
    except Exception as exc:
        _last_error = type(exc).__name__
        logger.exception("Απροσδόκητο σφάλμα αποστολής email προς %s", to)
        return Result(False, f"Απροσδόκητο σφάλμα: {exc}", to, subject)
