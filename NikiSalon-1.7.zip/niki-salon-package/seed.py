"""Επιδειγματικά δεδομένα — σύστημα διαχείρισης ραντεβού σαλονιού."""

from __future__ import annotations

import random
from datetime import date as date_cls, datetime, time, timedelta

from app.extensions import db
from app.helpers import pricing_for
from app.models import (
    ROLE_OWNER,
    SOURCE_PHONE,
    STATUS_COMPLETED,
    STATUS_CONFIRMED,
    Appointment,
    AppointmentService,
    AvailabilityRule,
    Customer,
    Groomer,
    Pet,
    SalonDaySettings,
    SalonSettings,
    Service,
    TimeOff,
    User,
)


def seed_services() -> int:
    """Δημιουργεί τον κατάλογο υπηρεσιών, αν είναι άδειος. Επιστρέφει πόσες μπήκαν.

    Χωρίς αυτές δεν υπάρχει τίποτα να κλείσει ο πελάτης — τις φορτώνει και η
    εγκατάσταση σε IIS, όταν η βάση έρχεται έτοιμη από το instance/salon.db.
    """
    from app.models import Service

    if Service.query.first():
        return 0

    services_data = [
        ("Μπάνιο", "Μπάνιο & Στέγνωμα",
             "Μπάνιο σε μικρόσωμες και μεγαλόσωμες φυλές. Ειδικά σαμπουάν, μάσκες περιποίησης τριχώματος και φυτικό άρωμα.",
             [18, 24, 32, 40],
             [30, 40, 50, 60], False, 10),
        ("Κουρέματα", "Κούρεμα με μηχανή",
             "Κούρεμα με επαγγελματική μηχανή, χωρίς να τραβάμε το τρίχωμα.",
             [22, 28, 36, 44],
             [25, 35, 45, 55], False, 20),
        ("Κουρέματα", "Κούρεμα με ψαλίδι",
             "Ψαλιδιστό τελείωμα και «γλυπτική» του τριχώματος, σύμφωνα με το αποτέλεσμα που θέλουμε.",
             [28, 36, 46, 56],
             [35, 45, 60, 75], False, 30),
        ("Κουρέματα", "Κούρεμα φυλής",
             "Κούρεμα σύμφωνα με το πρότυπο της φυλής — Maltese, Shih Tzu, Poodle, Yorkie κ.α.",
             [34, 42, 54, 66],
             [40, 55, 70, 90], False, 40),
        ("Κουρέματα", "Stripping",
             "Stripping για Terriers, Cockers, Afghan Hounds, Schnauzers, Dachshunds κ.α. — χειροκίνητη αφαίρεση του λάσπου του τριχώματος.",
             [30, 38, 48, 58],
             [40, 50, 65, 80], False, 50),
        ("Περιποίηση", "Μείωση υπερβολικού μαδήματος",
             "Μείωση του υπερβολικού μαδήματος, ιδίως κατά την αλλαγή εποχών.",
             [10, 12, 15, 18],
             [15, 20, 25, 30], True, 60),
        ("Περιποίηση", "Ξεκόμπιασμο & αφαίρεση τζίβας",
             "Ξεκόμπιασμο υπερβολικά μπερδεμένου τριχώματος και αφαίρεση τζίβας, πάντα με αγάπη και υπομονή.",
             [12, 15, 20, 25],
             [20, 30, 40, 50], True, 70),
        ("Πρόσθετα", "Κόψιμο νυχιών",
             "Κόψιμο & λείανση νυχιών.",
             [6, 8, 10, 12],
             [10, 15, 20, 25], True, 80),
        ("Πρόσθετα", "Καθάρισμα αυτιών",
             "Καθάρισμα των αυτιών.",
             [6, 8, 10, 12],
             [10, 10, 15, 15], True, 90),
        ("Πρόσθετα", "Πατουσάκια & πισινός",
             "Καθάρισμα πατουσάκια, κοιλίτσα και πισινός.",
             [8, 10, 12, 14],
             [10, 15, 15, 20], True, 100),
        ]

    created = 0
    for category, name, description, prices, durations, addon, order in services_data:
        db.session.add(Service(
            name=name, description=description, category=category,
            is_addon=addon, is_active=True, sort_order=order,
            price=prices[2], duration_minutes=durations[2],
        ))
        created += 1
    db.session.commit()
    return created


def seed_all(force: bool = False) -> None:
    """Γεμίζει τη βάση με επιδειγματικά δεδομένα."""
    # Σταθερή σειρά τυχαίων αριθμών ώστε τα επιδειγματικά δεδομένα να είναι
    # ίδια σε κάθε εκτέλεση (ίδια και η εικόνα προεπισκόπησης).
    random.seed(20260927)
    if force:
        db.session.execute(db.text("DELETE FROM appointment_services"))
        db.session.query(Appointment).delete()
        db.session.query(Pet).delete()
        db.session.query(Customer).delete()
        db.session.query(Groomer).delete()
        db.session.query(User).delete()
        db.session.query(AvailabilityRule).delete()
        db.session.query(TimeOff).delete()
        db.session.query(SalonDaySettings).delete()
        db.session.query(Service).delete()
        db.session.query(SalonSettings).delete()
        db.session.commit()

    # --- Ρυθμίσεις καταστήματος ---
    # ΟΥΔΕΤΡΑ ΔΕΙΓΜΑΤΑ. Κανένα από αυτά δεν είναι στοιχεία κάποιου: το
    # `seed.py` είναι δείγμα, και κάθε πραγματική εγκατάσταση γεμίζει τα
    # δικά της. Το Instagram βγήκε ολοκληρωτικά — δεν υπάρχει πλέον ούτε
    # πεδίο στις Ρυθμίσεις ούτε κλειδί εδώ.
    SalonSettings.set("name", "TEST PET SALON")
    SalonSettings.set("tagline", "Δοκιμαστικά δεδομένα — αλλάξτε τα από τις Ρυθμίσεις")
    SalonSettings.set("logo_path", "/static/img/site/logo-paw.svg")
    SalonSettings.set("phone", "210 000 0000")
    SalonSettings.set("email", "testpetsalon@example.com")
    SalonSettings.set("address", "Δοκιμαστική Διεύθυνση 1")

    # --- Ώρες λειτουργίας σπα ---
    for wd in range(7):
        if not SalonDaySettings.query.filter_by(weekday=wd).first():
            db.session.add(
                SalonDaySettings(
                    weekday=wd,
                    is_closed=(wd == 6),
                    open_time=time(9, 0),
                    close_time=time(18, 0),
                )
            )

    # --- Υπηρεσίες (δείγμα) ---
    seed_services()

    # --- Χρήστες ---
    if not User.query.first():
        # Ιδιοκτήτρια — μόνο αυτή δημιουργείται αυτόματα.
        # Οι βοηθοί δημιουργούνται από την ίδια μέσα από Διαχείριση → Χρήστες.
        owner = User(
            username="testpet",
            email="testpetsalon@example.com",
            role=ROLE_OWNER,
            first_name="Δοκιμή", last_name="Χρήστρια",
            phone="210 000 0000",
        )
        owner.set_password("salon1234")
        db.session.add(owner)
        db.session.flush()
        db.session.add(Groomer(user_id=owner.id, sort_order=1, color="#B0567A", title="Ιδιοκτήτρια & Κύρια Στυλίστρια"))

    # --- Ωράρια ιδιοκτήτριας ---
    owner_groomer = db.session.query(Groomer).first()
    if owner_groomer and not AvailabilityRule.query.filter_by(groomer_id=owner_groomer.id).first():
        for wd in range(6):
            db.session.add(AvailabilityRule(
                groomer_id=owner_groomer.id, weekday=wd,
                start_time=time(9, 0), end_time=time(18, 0),
            ))

    # --- Πελάτες & Κατοικίδια ---
    if not Customer.query.first():
        customers_data = [
            ("Μαρία", "Παπαδοπούλου", "210 1234567", "maria@mail.gr", [
                ("Μπίτζι", "dog", "Maltese", "female"),
                ("Ροκή", "dog", "Jack Russell", "male"),
            ]),
            ("Γιώργος", "Αντωνίου", "210 2345678", "giorgos@mail.gr", [
                ("Μάξ", "dog", "Labrador", "male"),
            ]),
            ("Ελένη", "Νικολάου", "210 3456789", "eleni@mail.gr", [
                ("Λούλα", "cat", "Persian", "female"),
            ]),
            ("Κώστας", "Δημητρίου", "210 4567890", "kostas@mail.gr", [
                ("Τζιμ", "dog", "Poodle", "male"),
                ("Μιμί", "dog", "Chihuahua", "female"),
            ]),
            ("Άννα", "Γεωργίου", "210 5678901", "anna@mail.gr", [
                ("Ρέξ", "dog", "German Shepherd", "male"),
            ]),
            ("Πέτρος", "Κωνσταντίνου", "210 6789012", "petros@mail.gr", [
                ("Ντάλι", "dog", "Dalmatian", "male"),
            ]),
            ("Σοφία", "Μαρίνου", "210 7890123", "sofia@mail.gr", [
                ("Κλέο", "cat", "Siamese", "female"),
            ]),
            ("Νίκος", "Παπαδόπουλος", "210 8901234", "nikos@mail.gr", [
                ("Μπράουνι", "dog", "Golden Retriever", "male"),
            ]),
            ("Κατερίνα", "Βασιλείου", "210 9012345", "katerina@mail.gr", [
                ("Σάρα", "dog", "Beagle", "female"),
            ]),
            ("Δημήτρης", "Σταυρόπουλος", "210 0123456", "dimitris@mail.gr", [
                ("Χάσκι", "dog", "Siberian Husky", "male"),
            ]),
        ]

        today = date_cls.today()
        for i, (fname, lname, phone, email, pets) in enumerate(customers_data):
            customer = Customer(
                name=f"{fname} {lname}",
                phone=phone, email=email,
                address=f"Οδός {i+1}",
            )
            db.session.add(customer)
            db.session.flush()

            for j, (pet_name, species, breed, gender) in enumerate(pets):
                birth = today - timedelta(days=random.randint(365, 3650))
                db.session.add(Pet(
                    customer_id=customer.id,
                    name=pet_name, species=species, breed=breed,
                    gender=gender,
                    birth_date=birth,
                    weight_kg=round(random.uniform(3, 35), 1),
                    is_neutered=random.choice([True, False]),
                    allergies=random.choice([None, None, "Γλουτένη", "Πολύτριχο τρίχωμα"]),
                    temperament=random.choice([None, "Φιλικό", "Ντροπαλό", "Ενεργητικό"]),
                ))

        db.session.commit()

        # --- Επιδειγματικά ραντεβού ---
        all_customers = Customer.query.all()
        all_services = Service.query.all()
        groomer = db.session.query(Groomer).first()
        all_pets = [p for c in all_customers for p in c.pets]

        # Τα δύο τελευταία κατοικίδια μένουν χωρίς ιστορικό επισκέψεων, ώστε να
        # εμφανίζονται στο «χρειάζονται περίποιηση».
        new_pets = set(p.id for p in all_pets[-2:])

        for day_offset in range(-30, 30):
            day = today + timedelta(days=day_offset)
            if day.weekday() == 6:
                continue
            num_appointments = random.randint(2, 6)
            used_times = set()
            for _ in range(num_appointments):
                pool = [p for p in all_pets if p.id not in new_pets or day >= today]
                pet = random.choice(pool)
                customer = db.session.get(Customer, pet.customer_id)
                services = random.sample(all_services, random.randint(1, 3))

                start_hour = random.randint(9, 16)
                start_minute = random.choice([0, 30])
                start_time = start_hour * 60 + start_minute
                if start_time in used_times:
                    continue
                used_times.add(start_time)

                # pricing_for επιστρέφει (τιμή, διάρκεια) — όχι το αντίστροφο.
                total_price, total_duration = pricing_for(services)
                start_dt = datetime.combine(day, time(start_hour, start_minute))
                end_dt = start_dt + timedelta(minutes=total_duration)

                if day < today:
                    status = STATUS_COMPLETED
                else:
                    status = STATUS_CONFIRMED

                appt = Appointment(
                    customer_id=customer.id,
                    pet_id=pet.id,
                    groomer_id=groomer.id,
                    start_at=start_dt,
                    end_at=end_dt,
                    status=status,
                    source=SOURCE_PHONE,
                    total_price=total_price,
                    created_by_id=1,
                )
                # Οι υπηρεσίες κρατούνται στις γραμμές με ποσότητα· το `services`
                # είναι πλέον μόνο ανάγνωση.
                appt.service_links = [
                    AppointmentService(
                        service_id=s.id, quantity=1,
                        duration=int(s.duration_minutes or 0),
                    )
                    for s in services
                ]
                appt.pets = [pet]
                db.session.add(appt)

    db.session.commit()
