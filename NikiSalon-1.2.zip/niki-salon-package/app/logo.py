"""Λογότυπο σαλονι: αποθήκευση, προβολή και ασφαλής επικύρωση.

ΓΙΑΤΙ ΣΤΟ instance/ ΚΑΙ ΟΧΙ ΣΤΟ app/static
========================================
Ο φάκελος της εφαρμογής είναι ΜΟΝΟ ΓΙΑ ΑΝΑΓΝΩΣΗ (τα δικαιώματα δίνονται
μόνο στο instance\\ και στο logs\\). Ένα λογότυπο που «ανέβαινε» στο
app/static/img/site/ θα έπεφτε με Permission denied στον server.

Το instance/ είναι σωστή επιλογή και για δεύτερο λόγο: οι ενημερώσεις δεν
πειράζουν ποτέ το instance\\ (το FORBIDDEN_PARTS του app/updates.py το
αποκλείει), άρα το λογότυπο επιβιώνει σε κάθε αναβάθμιση — όπως και η βάση.

ΑΣΦΑΛΕΙΑ
========
Το όνομα του αρχείου ΔΕΝ χρησιμοποιείται ποτέ — παράγεται δικό μας. Το
περιεχόμενο ελέγχεται με τα «υπογραφές» (magic bytes) των μορφών, όχι με
το όνομα ούτε με το Content-Type που στέλνει ο browser (και τα δύο
ελέγχονται από τον χρήστη).

Το SVG είναι ΕΞΑΙΡΕΣΗ: σερβίρεται από την ίδια origin με την εφαρμογή, άρα
ένα SVG με script εκτελείται στο session της ιδιοκτήτριας. Οι εικόνες
παραμένουν PNG/JPEG/WebP, που τα browsers δεν εκτελούν.
"""
from __future__ import annotations

from pathlib import Path

from flask import current_app, send_from_directory

#: Πρόθεμα του αρχείου στο instance\\. Σταθερό, ώστε η διαδρομή που
#: αποθηκεύεται στη βάση να μην αλλάζει ποτέ μεταξύ των uploads.
STEM = "salon-logo"
#: ΤΟ ICO ΤΟΥ ΣΑΛΟΝΙΟΥ. ΞΕΧΩΡΙΣΤΟ ΑΡΧΕΙΟ ΑΠΟ ΤΟ ΛΟΓΟΤΥΠΟ ΓΙΑΤΙ ΧΡΗΣΙΜΟΠΟΙΕΙΤΑΙ
#: ΣΕ ΔΥΟ ΔΙΑΦΟΡΕΤΙΚΑ ΜΕΓΕΘΗ (32px στο συμπτυγμένο μενού και στην καρτέλα του
#: browser, 192px στην εγκατάσταση εφαρμογής) — και το λογότυπο είναι συνήθως
#: οριζόντιο, που στο 32px διαβάζεται σαν μπάρα. ΜΕΤΑΦΟΡΑ ΤΟ ΙΔΙΟ ΑΡΧΕΙΟ ΣΑΝ
#: ICO ΚΑΙ ΛΟΓΟΤΥΠΟ ΣΗΜΑΙΝΕΙ ΝΑ ΒΛΕΠΕΙ ΜΙΑ ΜΠΑΡΑ ΣΤΟ ΜΕΝΟΥ ΚΑΙ ΜΙΑ ΜΠΑΡΑ
#: ΣΤΟΝ browser.
STEM_ICON = "salon-icon"

#: Η διαδρομή που αποθηκεύεται στη βάση (SalonSettings.logo_path) και
#: χρησιμοποιείται ως <img src>. Δεν περιέχει επίληξη ούτε μέγεθος, άρα
#: δεν χρειάζεται cache-busting στο URL.
URL_RULE = "/salon-logo"

MAX_BYTES = 2 * 1024 * 1024        # 2 MB — πολύ πάνω από ένα λογότυπο

#: Μορφές → επίληξη. Ο έλεγχος γίνεται στα ΠΡΩΤΑ ΒΑΙΤΑ ΤΟΥ ΑΡΧΕΙΟΥ, όχι
#: στο όνομα: ένας .png μπορεί να περιέχει οτιδήποτε.
_SIGNATURES = (
    (b"\x89PNG\r\n\x1a\n", ".png"),
    (b"\xff\xd8\xff", ".jpg"),
)
#: Το WebP είναι «RIFF....WEBP» — τα 4 bytes-κλειδιά στη θέση 8.
_WEBP_MARKER = b"WEBP"


class LogoError(Exception):
    """Το ανεβασμένο αρχείο δεν δεκτόταν."""


def instance_dir() -> Path:
    """Ο φάκελος instance/ από τη ρύθμιση της εφαρμογής."""
    raw = current_app.config.get("INSTANCE_DIR")
    if raw:
        return Path(raw)
    return Path(__file__).resolve().parent.parent.parent / "instance"


#: Το τέλος ενός PNG. Χωρίς αυτό το chunk το αρχείο δεν έχει κλείσει και
#: κανένας browser δεν θα το αποκωδικοποιήσει.
_PNG_IEND = b"IEND\xaeB`\x82"

#: Ένα από αυτά τα chunk σημαίνει «έχω εικόνα» σε αρχείο WebP.
_WEBP_CHUNKS = (b"VP8 ", b"VP8L", b"VP8X")


def _png_is_complete(data: bytes) -> bool:
    """Το PNG έχει πλήρες IEND στο τέλος."""
    return data.endswith(_PNG_IEND)


def _jpeg_is_complete(data: bytes) -> bool:
    """Το JPEG έχει SOI στην αρχή και EOI στο τέλος.

    Χωρίς το EOI το αρχείο είναι αλλοθραυσμένο: το browser το δείχνει
    σαν σπασμένο σύμβολο, και το λογότυπο εμφανίζεται σε ΚΑΘΕ σελίδα,
    στη σύνδεση και στα email. Έτσι ακριβώς το μπλέ.
    """
    return data.startswith(b"\xff\xd8\xff") and data.endswith(b"\xff\xd9")


def _webp_is_complete(data: bytes) -> bool:
    """Το WebP έχει RIFF/WEBP και ένα κομμάτι εικόνας μέσα του."""
    if len(data) < 16 or data[:4] != b"RIFF" or data[8:12] != _WEBP_MARKER:
        return False
    return any(data[12:16] == chunk for chunk in _WEBP_CHUNKS)


#: Πώς ελέγχουμε την ολότητα ανά μορφή. Καμία νέα εξάρτηση: μόνο bytes.
_COMPLETE = {
    ".png": _png_is_complete,
    ".jpg": _jpeg_is_complete,
    ".webp": _webp_is_complete,
}


def detect_extension(data: bytes) -> str:
    """Η επίκταξη με βάση το ΠΕΡΙΕΧΟΜΕΝΟ. Κενή αν δεν αναγνωρίζεται.

    ΔΕΚΤΕ ΚΑΙ ΜΗ ΟΛΟΚΛΗΡΑ. Τα πρώτα bytes λένε τη ΜΟΡΦΗ. Το αν η εικόνα
    είναι ΟΛΟΚΛΗΡΗ το λέει η δομή του αρχείου, και χωρίς αυτόν τον
    έλεγχο ένα αλλοθραυσμένο αρχείο αποθηκευόταν: το μέτρησα, ένα JPEG
    204 bytes που σταματά στη μέση πέρασε και έσπαγε το λογότυπο σε
    όλες τις σελίδες, στη σύνδεση και στα email, χωρίς εξήγηση.

    Ο έλεγχος στον διακομιστή είναι το ΤΕΛΕΥΤΑΙΟ ΟΡΙΟ, όχι η πρώτη
    γραμμή άμυνας: το αρχείο μπορεί να έρθει και από άλλο browser ή
    από drag&drop, όπου δεν περνά ο έλεγχος του browser.
    """
    for magic, ext in _SIGNATURES:
        if data.startswith(magic) and _COMPLETE[ext](data):
            return ext
    if (len(data) >= 12 and data[:4] == b"RIFF"
            and data[8:12] == _WEBP_MARKER and _webp_is_complete(data)):
        return ".webp"
    return ""


def current_logo() -> Path | None:
    """Το τρέχον αρχείο λογότυπου, αν υπάρχει."""
    for path in sorted(instance_dir().glob(f"{STEM}.*")):
        if path.is_file():
            return path
    return None


def save_icon(data: bytes) -> str:
    """Αποθηκεύει το ICO του σαλονιού (το συμπτυγμένο μενού και η καρτέλα).

    ΙΔΙΑ ΛΟΓΙΚΗ ΜΕ ΤΟ save_logo, ΧΩΡΙΣ ΤΟ ΔΙΠΛΟ. Δεκτές οι ίδιες μορφές
    (PNG/JPG/WebP) και το ίδιο όριο μεγέθους: το SVG αποκλείεται για τον
    ίδιο λόγο ασφαλείας — ένα SVG σε favicon εκτελεί κώδικα στο browser.
    """
    if not data:
        raise LogoError("Το αρχείο είναι κενό.")
    if len(data) > MAX_BYTES:
        raise LogoError("Το αρχείο είναι πολύ μεγάλο (όριο 2 MB).")
    ext = detect_extension(data)
    if not ext:
        raise LogoError(
            "Μη υποστηριζόμενη μορφή. Δεκτές: PNG, JPG, WebP. "
            "Το SVG δεν γίνεται δεκτό για λόγους ασφαλείας."
        )
    target_dir = instance_dir()
    try:
        target_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise LogoError(f"Δεν μπόρεσα να προσπελάσω το φάκελο: {exc}") from exc
    target = target_dir / f"{STEM_ICON}{ext}"
    try:
        target.write_bytes(data)
    except OSError as exc:
        raise LogoError(f"Η αποθήκευση απέτυχε: {exc}") from exc
    _drop_others(STEM_ICON)
    return f"/instance/{target.name}"


def delete_icon() -> bool:
    """Διαγράφει το ico του σαλονιού. True αν σβήστηκε κάτι."""
    removed = False
    for old in sorted(instance_dir().glob(f"{STEM_ICON}.*")):
        try:
            old.unlink()
            removed = True
        except OSError:
            pass
    return removed


def _drop_others(stem: str) -> None:
    """Σβήνει τα παλιά αρχεία του ίδιου stem, κρατά μόνο το νέο."""
    for old in sorted(instance_dir().glob(f"{stem}.*")):
        try:
            old.unlink()
        except OSError:
            pass


def save_logo(data: bytes) -> str:
    """Αποθηκεύει το λογότυπο και επιστρέφει τη διαδρομή για τη βάση.

    Δεν χρησιμοποιεί το όνομα που έστειλε ο χρήστης, ούτε τη διαδρομή του:
    παράγεται όνομα από εμάς, μέσα στο instance\\, και το παλιό αρχείο
    διαγράφεται ώστε να μην σωρεύονται.
    """
    if not data:
        raise LogoError("Το αρχείο είναι κενό.")
    if len(data) > MAX_BYTES:
        raise LogoError(
            "Το αρχείο είναι πολύ μεγάλο (όριο 2 MB). Χρησιμοποίησε μικρότερο "
            "λογότυπο."
        )
    ext = detect_extension(data)
    if not ext:
        raise LogoError(
            "Μη υποστηριζόμενη μορφή. Δεκτές: PNG, JPG, WebP. "
            "Το SVG δεν γίνεται δεκτό για λόγους ασφαλείας."
        )

    target_dir = instance_dir()
    try:
        target_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise LogoError(f"Δεν μπόρεσα να προσπελάσω το φάκελο: {exc}") from exc

    target = target_dir / f"{STEM}{ext}"
    try:
        target.write_bytes(data)
    except OSError as exc:
        raise LogoError(f"Η αποθήκευση απέτυχε: {exc}") from exc

    # Καθαρισμός: το παλιό λογότυπο (ίδιο όνομα, διαφορετική επίληξη)
    # διαγράφεται, αλλιώς μένουν στο δίσκο όλα.
    for old in target_dir.glob(f"{STEM}.*"):
        if old != target and old.is_file():
            try:
                old.unlink()
            except OSError:
                pass
    return URL_RULE


def delete_logo() -> bool:
    """Διαγράφει το λογότυπο. True αν κατέργησε να φύγει."""
    removed = False
    for path in instance_dir().glob(f"{STEM}.*"):
        if path.is_file():
            try:
                path.unlink()
                removed = True
            except OSError:
                pass
    return removed


def serve_logo():
    """Σερβίρει το λογότυπο χωρίς σύνδεση (χρειάζεται και στο login, στα
    email και στις κάρτες επισκεπτών)."""
    path = current_logo()
    if path is None:
        # 404, όχι εικόνα σφάλματος: ώστε το <img onerror> πέσει στο εναλλακτικό.
        return ("", 404)
    # ΠΟΤΕ κράχτη. Το όνομα του αρχείου δεν αλλάζει ποτέ (salon-logo.png),
    # άρα με οποιοδήποτε max_age η δεύτερη αλλαγή λογότυπου δεν θα φανόταν:
    # ο browser θα επέστρεφε την παλιά εικόνα από τη δική του κράχτη. Το
    # αρχείο είναι μικρό και το σερβερ είναι τοπικό — η ορθή συμπεριφορά
    # αξίζει τη μία επιπλέον αίτηση.
    response = send_from_directory(
        instance_dir(), path.name, max_age=0,
        mimetype=_mimetype_for(path),
    )
    # Το no-store είναι το ασφαλέστερο: λέει ρητά στον browser να μην
    # κρατά τίποτα. Το no-cache θα το έπαιρνε μόνο αν ξαναελέγχει τον
    # διακομιστή, και αν αλλάξει το αρχείο μέσα στο ίδιο δευτερόλεπτο το
    # ETag μένει ίδιο — πάλι παλιά εικόνα.
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


def _mimetype_for(path: Path) -> str:
    return {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".webp": "image/webp",
    }.get(path.suffix.lower(), "application/octet-stream")


def uploaded_logo_path() -> Path | None:
    """Το λογότυπο σε μορφή διαδρομής για τα email (το logo_cid)."""
    path = current_logo()
    if path is not None and path.is_file():
        return path
    return None
