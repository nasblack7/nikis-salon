"""App factory — Niki's Grooming Salon Appointment Management."""

from __future__ import annotations

import os
import sys
from datetime import date, time

import click
from flask import (Flask, has_request_context, render_template,
                   request)

from config import LOG_DIR, Config

from . import logo
from .extensions import csrf, db, login_manager


def force_utf8_stdio() -> None:
    """Αναγκάζει stdout/stderr σε UTF-8.

    Στα Windows η κονσόλα χρησιμοποιεί τη code page της (συνήθως cp1252),
    οπότε οποιοδήποτε print() με ελληνικά σταματά με UnicodeEncodeError.
    Το ίδιο ισχύει και όταν η έξοδος πηγαίνει σε αρχείο (π.χ. το
    logs/stdout.log του IIS). Με errors='replace' δεν σταματά ποτέ,
    απλώς αντικαθιστά τους χαρακτήρες που δεν μπορούν να γραφτούν.
    """
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except (ValueError, OSError, AttributeError):
            pass


def create_app(config_object=Config) -> Flask:
    force_utf8_stdio()

    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(config_object)
    config_object.init_app(app)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    _register_pwa_routes(app)
    _register_root_route(app)
    _register_blueprints(app)
    _register_template_globals(app)
    _register_error_handlers(app)
    _register_cli(app)
    _register_maintenance_guard(app)
    _register_license_guard(app)
    _clear_stale_maintenance()
    _prune_on_startup(app)
    _warn_about_mail(app)
    _start_update_checker(app)
    return app


def _prune_on_startup(app: Flask) -> None:
    """Καθαρίζει τα παλιά αρχεία ενημέρωσης ΜΟΛΙΣ ΞΕΚΙΝΗΣΕ Η ΕΦΑΡΜΟΓΗ.

    Ο ΚΑΝΟΝΑΣ ΤΟΥ ΙΔΙΟΚΤΗΤΗ: «κράτα 1 έκδοση πριν, όλα τα υπόλοιπα να
    σβήνουν». Ο καθαρισμός υπήρχε, αλλά έτρεχε ΜΟΝΟ μετά από επιτυχή
    εγκατάσταση — άρα ό,τι έμενε από παλιότερες προσπάθειες ή από
    εγκαταστάσεις που έκοψαν στη μέση, ΜΕΝΕ ΓΙΑ ΠΑΝΤΑ. Ο φάκελος του σαλονιού
    μεγάλωνε χωρίς να υπάρχει κάποιος να τον καθαρίσει.

    ΜΕ ΑΥΤΟ ΤΟΝΑ Ο ΚΑΘΑΡΙΣΜΟΣ ΓΙΝΕΤΑΙ ΜΟΝΟΣ ΤΟΥ, ΣΕ ΚΑΘΕ ΕΚΚΙΝΗΣΗ. Ο
    υπολογιστής του σπατιού ανοίγει κάθε μέρα — κάθε εκκίνηση είναι μια
    ευκαιρία να φύγει ό,τι περισσεύει.

    ΔΥΟ ΠΡΟΥΠΟΘΕΣΕΙΣ:

    · ΠΟΤΕ όσο η εφαρμογή είναι σε συντήρηση. Μια εγκατάσταση μπορεί να
      τρέχει αυτή τη στιγμή σε αυτή τη διεργασία, και ο καθαρισμός θα
      έσβηνε το φάκελο που προσπαθεί να εγκαταστήσει.
    · ΠΟΤΕ δεν πετάει σφάλμα στην εκκίνηση. Αν ο καθαρισμός αποτύχει, η
      εφαρμογή σηκώνεται κανονικά — η τάξη στον δίσκο δεν αξίζει ένα
      σαλόνι που δεν ανοίγει.
    """
    try:
        from .updates import in_maintenance, installed_state, prune_after_install
        if in_maintenance():
            # Η εγκατάσταση τρέχει τώρα. Μην αγγίξεις τίποτα.
            return
        state = installed_state()
        prune_after_install(str(state.get("version") or ""))
    except Exception as exc:                            # noqa: BLE001
        app.logger.info(f"Ο καθαρισμός παλιών αρχείων στην εκκίνηση "
                        f"παραλείφθηκε: {exc}")


def _start_update_checker(app: Flask) -> None:
    """Ξεκινά τον περιοδικό έλεγχο ενημερώσεων.

    Ο background_check() υπήρχε αλλά ΔΕΝ ΚΑΛΕΙΤΟΠΟΥ. Η σελίδα ενημερώσεων
    έλεγε «ο έλεγχος γίνεται αυτόματα κάθε 12 ώρες» — και δεν γινόταν ποτέ.
    Χωρίς αυτή τη γραμμή, το 12 ήταν διακόσμηση, και κανείς δεν μπορούσε να
    μάθει ότι υπάρχει ενημέρωση χωρίς να μπει μόνος του στις ρυθμίσεις.

    Το νήμα κάνε καθυστέρεση 90s μέσα του, άρα δεν απλώνε internet μόλις
    ξεκινήσει ο υπολογιστής.
    """
    try:
        from .updates import background_check
        background_check(app, app.config.get("UPDATE_CHECK_HOURS", 12))
    except Exception as exc:                            # noqa: BLE001
        app.logger.warning(f"Ο αυτόματος έλεγχος ενημερώσεων δεν ξεκίνησε: {exc}")


def _clear_stale_maintenance() -> None:
    """Ξεκλειδώνει την εφαρμογή αν έμεινε κλειστή από διακοπή στην εγκατάσταση.

    Χωρίς αυτό, μια διακοπή ρεύματος (ή kill του IIS) στη μέση ενημέρωσης
    θα άφηνε την εφαρμογή κλειστή μόνιμα, με την ιδιοκτήτριας να μην μπορεί
    να μπει. Ο έλεγχος γίνεται μία φορά, κατά την εκκίνηση.
    """
    from .updates import clear_stale_maintenance

    try:
        if clear_stale_maintenance():
            print("  (Καθαρίστηκε παλιά σημαία συντήρησης από διακοπή.)")
    except Exception as exc:
        print(f"  (Ο έλεγχος σημαίας συντήρησης απέτυχε: {exc})")


def _register_maintenance_guard(app: Flask) -> None:
    """Κλείδώνει την εφαρμογή όσο εγκαταστάθενται ενημέρωση.

    Σκοπός: να μην γράψει κανείς ραντεβού ενώ η βάση μετατρέπεται. Οι
    σελίδες των ρυθμίσεων ενημέρωσης και το /health μένουν προσβάσιμα, ώστε
    ο ιδιοκτήτριας να μπορεί να δει τι γίνεται και να επιστρέψει πίσω.
    """
    from .updates import in_maintenance, maintenance_reason

    ALLOWED_PREFIXES = ("/static/", "/staff/updates", "/auth/", "/health")

    @app.before_request
    def _maintenance_gate():
        from flask import render_template, request

        path = request.path or "/"
        if any(path.startswith(prefix) for prefix in ALLOWED_PREFIXES):
            return None
        if not in_maintenance():
            return None
        return render_template("maintenance.html",
                               reason=maintenance_reason()), 503


def _register_license_guard(app: Flask) -> None:
    """Κλείδώνει την εφαρμογή όταν δεν υπάρχει έγκυρη άδεια — ΜΕ ΑΝΟΙΧΤΗ ΠΟΡΤΑ.

    Ο ΚΑΝΟΝΑΣ: όταν κλειδώνει, η πόρτα που λύνει το πρόβλημα πρέπει να είναι
    ανοιχτή. Αλλιώς ο χρήστης κάθεται μπροστά σε μια κλειστή εφαρμογή
    χωρίς να ξέρει τι να κάνει — το χειρότερο πράγμα που μπορεί να γίνει.

    ΤΙ ΠΑΡΑΜΕΝΕΙ ΑΝΟΙΧΤΟ:
      · /static/       — τα αρχεία της σελίδας, αλλιώς η άδεια είναι άσπρη
      · /auth/         — σύνδεση και αποσύνδεση· χωρίς αποσύνδεση δεν
                         μπορεί ούτε να κάνει login αλλού
      · /license       — η ίδια η σελίδα της άδειας και η ανανέωσή της
      · /health        — το /health του ελέγχου λειτουργίας
      · /salon-logo    — το λογότυπο της σελίδας σύνδεσης
      · /setup         — μόνο για φρέσκα εγκατάσταση. Σε εγκατεστημένο
                         σύστημα η σελίδα δίνει ήδη 404 (βλ. setup.py)

    ΠΟΙΟΙ ΠΕΡΝΑΝΕ ΠΑΝΤΑ: όσοι ΔΕΝ έχουν συνδεθεί. Δεν έχουν τίποτα να
    χάσουν, η σελίδα σύνδεσης τους δείχνει το μήνυμα της άδειας, και το
    μόνο που θα πετύχαινε η άρνηση είναι να τους κρύψει το πρόβλημα από
    την πόρτα που το λύνει.

    Η ΜΕΤΡΗΣΗ ΔΕΝ ΓΙΝΕΤΑΙ ΣΕ ΚΑΘΕ ΑΙΤΗΜΑ ΜΕ ΤΗ ΣΕΙΡΑ ΤΟΥ ΧΡΗΣΤΗ.
    `license_check.check()` κάνει verify υπογραφής και διάβασμα αρχείου —
    περίπου 2-4 ms. Οι σελίδες της εφαρμογής κάνουν δεκάδες ερωτήματα στη
    βάση, άρα η διαφορά δεν φαίνεται. Αν ποτέ φανεί, το `hwid.py` έχει ήδη
    προσωρινή αποθήκευση για το αποτύπωμα του υλικού, που είναι το ακριβό
    μέρος (PowerShell στα Windows).
    """
    from . import license_check

    ALLOWED_PREFIXES = ("/static/", "/auth/", "/license", "/health",
                        "/setup", logo.URL_RULE)

    @app.before_request
    def _license_gate():
        from flask import current_app, redirect, request, url_for
        from flask_login import current_user

        path = request.path or "/"
        if any(path.startswith(prefix) for prefix in ALLOWED_PREFIXES):
            return None
        # Χωρίς σύνδεση δεν κλειδώνουμε κανέναν. Η ίδια η απόπειρα μπαίνει
        # στη σελίδα σύνδεσης, κι εκεί βλέπει και το μήνυμα της άδειας.
        try:
            user = current_user._get_current_object()
        except RuntimeError:
            return None
        if not (user and user.is_authenticated):
            return None
        # Ο διακόπτης του ιδιοκτήτη (config.LICENSE_ENFORCE). Με 0 η
        # εφαρμογή δείχνει την κατάσταση της άδειας αλλά δεν κλειδώνει —
        # υπάρχει για να ξεκλειδώνει το σαλόνι χωρίς επανεγκατάσταση.
        if not current_app.config.get("LICENSE_ENFORCE", True):
            return None
        if not license_check.check().locked:
            return None
        return redirect(url_for("licensing.activation", next=path))


def _warn_about_mail(app: Flask) -> None:
    from . import mailer

    with app.app_context():
        if mailer.status() == "incomplete":
            missing = ", ".join(mailer.missing_settings())
            app.logger.warning(
                "Email: δεν έχει ρυθμιστεί το SMTP (λείπει %s). "
                "Τα μηνύματα θα γράφονται μόνο στο logs/notifications.log.",
                missing,
            )


def _register_blueprints(app: Flask) -> None:
    from .blueprints.admin import bp as admin_bp
    from .blueprints.auth import bp as auth_bp
    from .blueprints.licensing import bp as licensing_bp
    from .blueprints.reports import bp as reports_bp
    from .blueprints.setup import bp as setup_bp
    from .blueprints.staff import bp as staff_bp
    from .blueprints.updates import bp as updates_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(staff_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(setup_bp)
    app.register_blueprint(updates_bp)
    app.register_blueprint(licensing_bp)
    # Το λογότυπο ΣΕΡΒΙΡΕΤΑΙ ΑΝΟΙΧΤΑ, χωρίς σύνδεση: το βλέπει η σελίδα
    # σύνδεσης (όπου κανείς δεν έχει μπει ακόμα) και ενσωματώνεται στα email
    # ως inline εικόνα. Μια προστατευμένη διαδρομή θα έδειχνε σπασμένο
    # λογότυπο στο login και κενό στα email.
    app.add_url_rule(logo.URL_RULE, "salon_logo", logo.serve_logo)

def _admin_role() -> bool:
    """Έχει δικαιώματα διοίκησης (ιδιοκτήτρια ή υπεύθυνος) — ΜΕ ΑΣΦΑΛΕΙΑ.

    Το `current_user` του Flask-Login είναι LocalProxy. Δύο παγίδες, και
    η δεύτερη τρώγει την πρώτη:
      · `is not None` είναι ΠΑΝΤΑ True (του proxy, όχι του χρήστη)
      · χωρίς αίτημα, η ανάγνωσή του σηκώνει RuntimeError
    Άρα: υπάρχει αίτημα; αν όχι, όχι. Αν όχι, ή μην διαβάσεις καθόλου.
    """
    if not has_request_context():
        return False
    from flask_login import current_user          # μέσα, όχι στην κορυφή
    # ΔΕΥΤΕΡΗ ΠΑΓΙΔΑ ΤΟΥ ΙΔΙΟΥ proxy: ακόμα και με αίτημα, αν ο
    # LoginManager δεν έχει προλάβει να δεσμεύσει χρήστη (φρέσκη εγκατάσταση,
    # αίτημα πριν το before_request), η ανάγνωση σηκώνει RuntimeError.
    # Η σωστή συμπεριφορά είναι «δεν είμαι ιδιοκτήτρια» — όχι 500 στη σελίδα.
    try:
        user = current_user._get_current_object()
    except RuntimeError:
        return False
    return bool(user and user.is_authenticated and getattr(user, "is_admin", False))


def _register_template_globals(app: Flask) -> None:
    from . import models
    from .helpers import salon_context

    @app.context_processor
    def inject_context():
        from flask_login import current_user

        from . import license_check
        from .reminders import KIND_LABELS

        ctx = salon_context()
        from .models import SalonDaySettings
        # Αν ο σχήμα δεν υπάρχει ακόμη (καθαρή εγκατάσταση), δεν θέλουμε
        # 500 σε κάθε σελίδα — τα πρότυπα τα βλέπουν ως κενή λίστα.
        try:
            salon_hours = SalonDaySettings.query.order_by(
                SalonDaySettings.weekday).all()
        except Exception:
            # Καθαρή εγκατάσταση: ο πίνακας δεν υπάρχει ακόμη. Καταγράφουμε
            # και συνεχίζουμε με κενές ώρες, αντί να πέσει κάθε σελίδα.
            db.session.rollback()
            salon_hours = []
        ctx.update(
            salon_hours=salon_hours,
            config=app.config,
            DEVELOPER_NAME=app.config.get("DEVELOPER_NAME"),
            DEVELOPER_EMAIL=app.config.get("DEVELOPER_EMAIL"),
            # Ο έλεγχος ζει στον βοηθό _admin_role() — εκεί εξηγείται γιατί
            # το `is not None` δεν αρκούσε (το current_user είναι LocalProxy).
            is_admin_role=_admin_role(),
            STATUS_LABELS=models.STATUS_LABELS,
            SOURCE_LABELS=models.SOURCE_LABELS,
            ROLE_LABELS=models.ROLE_LABELS,
            KIND_LABELS=KIND_LABELS,
            SPECIES=models.SPECIES,
            WEEKDAYS=models.WEEKDAYS,
            fmt_date=models.fmt_date,
            fmt_datetime=models.fmt_datetime,

            relative_days=models.relative_days,
            minutes_to_label=models.minutes_to_label,
            # Η μέρα που παρακολουθεί η ζωντανή ενημέρωση: η μέρα που
            # βλέπει ο χρήστης στον ημερολόγιο, αλλιώς η σημερινή.
            # ΤΟ ΙΔΙΟ ΜΕ ΤΟ current_user: ΚΑΙ ΤΟ request ΠΕΦΤΕΙ ΧΩΡΙΣ ΑΙΤΗΜΑ.
            # Ένα context processor δεν τρέχει μόνο μέσα σε αίτημα (τα τεστ
            # και οι διαγνωστικές κλήσεις το καλούν και έξω), και η ανάγνωσή
            # του σηκώνει RuntimeError — 500 χωρίς λόγο. Χωρίς αίτημα, δεν
            # υπάρχει «η μέρα που βλέπει ο χρήστης»: είναι η σημερινή.
            live_calendar_date=(
                request.args.get("date")
                if has_request_context()
                and request.endpoint == "staff.calendar"
                else None
            ) or date.today().isoformat(),
            # Η άδεια, ΔΙΑΒΑΣΜΕΝΗ ΑΠΟ ΤΟ BACKEND. Τα πρότυπα τη δείχνουν
            # και δεν αποφασίζουν τίποτα γι' αυτήν. Υπολογίζεται σε κάθε
            # σελίδα, αλλά κοστίζει 2-4 ms (έλεγχος υπογραφής σε καθαρή
            # Python) — αν φανεί ποτέ ασθενές, το `hwid.py` έχει ήδη
            # προσωρινή αποθήκευση στο αποτύπωμα του υλικού, που είναι το
            # ακριβό μέρος.
            license=license_check.check(),
        )
        return ctx



    from .helpers import plural

    @app.template_filter("money")
    def money_filter(value):
        """{{ 1234.5|money }} -> «1.234,50 €»"""
        return models.fmt_money(value)

    @app.template_filter("plural")
    def plural_filter(value, singular, many):
        """{{ pets|length|plural('κατοικίδιο', 'κατοικίδια') }}"""
        return plural(value, singular, many)

    @app.template_filter("greekdate")
    def date_filter(value):
        return models.fmt_date(value)

    @app.template_filter("greekdatetime")
    def datetime_filter(value):
        return models.fmt_datetime(value)


def _register_pwa_routes(app: Flask) -> None:
    """PWA + favicon routes — must be registered before static file handler."""
    @app.route("/health")
    def health():
        """Έλεγχος ζωής — μικρός, χωρίς βάση, ώστε να μην επηρεάζεται από συντήρηση.

        ΛΕΕ ΚΑΙ ΑΝ ΕΙΜΑΣΤΕ ΣΕ ΣΥΝΤΗΡΗΣΗ. Χωρίς αυτό, η σελίδα συντήρησης
        έβλεπε ΜΟΝΟ την έκδοση, και η επιστροφή στο σαλόνι ήταν δυνατή ΜΟΝΟ
        όταν η έκδοση άλλαζε.

        ΑΥΤΟ ΗΤΑΝ ΛΑΘΟΣ ΣΤΗ ΦΑΡΜΑΚΟΠΟΙΙΑ ΤΟΥ ΜΗΧΑΝΗΜΑΤΟΥ ΤΟΥ ΣΑΛΟΝΙΟΥ:
        όταν μια ενημέρωση ΑΠΟΤΥΓΧΑΝΕΙ και η έκδοση μένει η ίδια, η έκδοση
        δεν «άλλαζε ποτέ» και η σελίδα έμενε μονίμως στο «Γίνεται
        εγκατάσταση…» — ενώ η ίδια η εγκατάσταση είχε ήδη τελειώσει (ή
        αποτύχει) και το σαλόνι ήταν έτοιμο. Δηλαδή: ακριβώς στη στιγμή
        που η ιδιοκτήτρια χρειάζεται να ξαναμπει, η εφαρμογή της κορίζει.

        Τώρα η σελίδα παρακολουθεί ΚΑΙ ΤΑ ΔΥΟ. Οποιοδήποτε από τα δύο
        πει «τελείωσε» και η σελίδα επιστρέφει.
        """
        from .version import APP_VERSION

        try:
            from .updates import in_maintenance as _in_maint

            maintenance = bool(_in_maint())
        except Exception:
            # Το /health δεν μπορεί να πέσει επειδή δεν μπόρεσε να διαβάσει ένα
            # αρχείο. «Δεν ξέρω» σημαίνει «δεν είναι σε συντήρηση» — τόσο
            # χαμηλότερο ρίσκο από το να μένει κλειστή.
            maintenance = False

        return {"status": "ok", "version": APP_VERSION,
                "maintenance": maintenance}, 200

    @app.route("/sw.js")
    def service_worker():
        return app.send_static_file("sw.js")

    @app.route("/manifest.webmanifest")
    def manifest():
        return app.send_static_file("manifest.webmanifest")

    @app.route("/favicon.ico")
    def favicon():
        # Οι browsers ζητούν το /favicon.ico αυτόματα στη ρίζα του site.
        # ΖΗΤΗΘΗΚΕ ΝΑ ΕΙΝΑΙ ΤΟ ICO ΤΗΣ ΙΔΙΟΚΤΗΤΡΙΑΣ. ΜΕ ΤΟ ΠΡΟΣΩΡΙΝΟ ΕΙΧΑΜΕ
        # «το λογότυπο του Νίκι σε κάθε καρτέλα» — και το favicon δείχνει
        # μικροσκοπικά, οπότε η διαφορά δεν φαίνεται μέχρι να τη χρειαστεί.
        # ΜΕΣΑ ΣΤΗ ΣΥΝΑΡΤΗΣΗ, ΟΧΙ ΣΤΗΝ ΚΟΡΥΦΗ: το .updates εισάγει το
        # package, και μια εισαγωγή σε επίπεδο αρχείου θα το έπαινε σε κύκλο
        # μόλις χτυπούσε οποιαδήποτε σελίδα.
        # ΤΟ ΤΟΥ FLASK, ΟΧΙ ΤΟΥ WERKZEUG. Η συνάρτηση του werkzeug θέλει
        # και το environ, που εδώ δεν υπάρχει — και έριχνε TypeError σε ΚΑΘΕ
        # αίτημα favicon. Το ίδιο όνομα σε δύο βιβλιοθήκες: χρήσιμο μόνο του
        # ονόματος, χωρίς να το ξέρεις.
        from flask import send_from_directory
        from werkzeug.exceptions import NotFound

        from .models import SalonSettings
        from .updates import instance_dir

        # Η ΜΕΤΑΒΛΗΤΗ ΠΕΡΙΕΧΕΙ ΗΔΗ ΤΟ «/instance/». Το send_from_directory
        # θέτει ΔΙΠΛΑ ΤΟΝ ΦΑΚΕΛΟ ΟΤΑΝ ΤΟ ΔΕΙΣ ΜΕ ΚΑΘΕΤΟ — και έψαχνε
        # instance/instance/salon-icon.png, που δεν υπάρχει. ΟΧΙ ΜΟΝΟ ΤΟ
        # ΟΝΟΜΑ ΤΟΥ ΑΡΧΕΙΟΥ, ΠΟΥ ΕΙΝΑΙ Ο,ΤΙ ΘΕΛΟΥΜΕ ΝΑ ΣΕΡΒΙΡΟΥΜΕ.
        custom = (SalonSettings.get("icon_path") or "").strip().lstrip("/")
        if custom.startswith("instance/"):
            custom = custom[len("instance/"):]
        if custom:
            try:
                response = send_from_directory(instance_dir(), custom,
                                               max_age=604800)
                return response
            except NotFound:
                # Το αρχείο λείπει (π.χ. διεγράφηκε από τον φάκελο). ΠΗΔΑΜΕ
                # ΣΤΟ ΠΡΟΣΩΡΙΝΟ ΧΩΡΙΣ ΝΑ ΠΕΣΟΥΜΕ «σφάλμα 404» ΣΤΟΝ BROWSER —
                # η καρτέλα πρέπει να δείχνει κάτι, όχι τίποτα.
                app.logger.warning("Λείπει το ico %s· μένει το προσωρινό.",
                                   custom)
        response = app.send_static_file("img/site/favicon.ico")
        response.headers["Cache-Control"] = "public, max-age=604800"
        return response


def _register_root_route(app: Flask) -> None:
    """Η εφαρμογή είναι εσωτερική — η ρίζα πάει στον πίνακα ή στη σύνδεση."""
    from flask import redirect, url_for
    from flask_login import current_user

    @app.route("/")
    def index():
        if current_user.is_authenticated:
            return redirect(url_for("staff.dashboard"))
        return redirect(url_for("auth.login"))


def _register_error_handlers(app: Flask) -> None:
    @app.errorhandler(403)
    def forbidden(error):
        return render_template("errors/error.html", code=403,
                               title="Πρόσβαση απαγορευμένη",
                               message=getattr(error, "description", "Δεν έχετε δικαίωμα πρόσβασης.")), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/error.html", code=404,
                               title="Η σελίδα δεν βρέθηκε",
                               message="Το ζητούμενο δεν υπάρχει ή μετακινήθηκε."), 404

    @app.errorhandler(500)
    def server_error(error):
        db.session.rollback()
        return render_template("errors/error.html", code=500,
                               title="Κάτι πήγε στραβά",
                               message="Παρουσιάστηκε μη αναμενόμενο σφάλμα. Δοκιμάστε ξανά."), 500


def _register_cli(app: Flask) -> None:
    @app.cli.command("init-db")
    def init_db():
        """Δημιουργεί όλους τους πίνακες."""
        db.create_all()
        click.echo("Οι πίνακες δημιουργήθηκαν.")

    @app.cli.command("seed")
    @click.option("--force", is_flag=True, help="Διαγράφει τα υπάρχοντα δεδομένα πριν την εισαγωγή.")
    def seed_db(force):
        """Γεμίζει τη βάση με επιδειγματικά δεδομένα."""
        from seed import seed_all

        seed_all(force=force)
        click.echo("Τα επιδειγματικά δεδομένα εισήχθησαν.")

    @app.cli.command("send-reminders")
    @click.option("--window", default=None, type=int, help="Παράθυρο υπενθύμισης σε ώρες.")
    def send_reminders(window):
        """Στέλνει τις υπενθυμίσεις 24ωρου."""
        from . import mailer
        from .reminders import KIND_REMINDER, due_reminders, send

        appointments = due_reminders(window)
        sent = sum(1 for a in appointments if send(KIND_REMINDER, a).sent)
        db.session.commit()
        failed = len(appointments) - sent
        if failed:
            click.secho(
                f"Στάλθηκαν {sent} από {len(appointments)} υπενθυμίσεις.", fg="yellow"
            )
            if not mailer.is_configured():
                click.secho(
                    f"  Δεν υπάρχει SMTP: λείπουν {', '.join(mailer.missing_settings())}.",
                    fg="yellow",
                )
        else:
            click.echo(f"Στάλθηκαν {sent} υπενθυμίσεις.")

    @app.cli.command("mail-status")
    def mail_status():
        """Δείχνει αν το SMTP είναι έτοιμο."""
        from . import mailer

        click.echo(mailer.describe())
        state = mailer.status()
        if state == "ready":
            click.secho("Έτοιμο για πραγματική αποστολή.", fg="green")
        elif state == "off":
            click.secho("Απενεργοποιημένο (MAIL_ENABLED=false).", fg="yellow")
        elif state == "incomplete":
            click.secho(
                f"Λείπουν: {', '.join(mailer.missing_settings())}.",
                fg="yellow",
            )
        else:
            click.secho(f"Τελευταίο σφάλμα: {state}", fg="yellow")

    @app.cli.command("setup-token")
    @click.option("--base-url", default="", help="Διεύθυνση του site, π.χ. http://localhost")
    def setup_token(base_url):
        """Δείχνει τη διεύθυνση της πρώτης εγκατάστασης (/setup).

        Χρειάζεται μία φορά, για να δημιουργηθεί ο πρώτος λογαριασμός ιδιοκτήτριας.
        Μόλις δημιουργηθεί, η σελίδα /setup κλείνει οριστικά.
        """
        from .blueprints.setup import ensure_token, owner_exists, token_path

        with app.app_context():
            if owner_exists():
                click.echo("Υπάρχει ήδη ιδιοκτήτρια — η σελίδα /setup είναι κλειστή.")
                return
            token = ensure_token()
            base = (base_url or app.config.get("PUBLIC_BASE_URL") or "http://localhost").rstrip("/")
            hint = token_path()
        click.echo()
        click.echo("  Πρώτη εγκατάσταση — άνοιξε αυτή τη διεύθυνση στον browser:")
        click.echo()
        click.echo(f"    {base}/setup/?token={token}")
        click.echo()
        click.echo(f"  Ο κωδικός αποθηκεύτηκε στο: {hint}")

    @app.cli.command("reset-password")
    @click.argument("username")
    def reset_password(username):
        """Βάζει νέο κωδικό σε υπάρχον χρήστη — για ξεχασμένο κωδικό.

        Η άλλη επιλογή είναι το «--link», που τυπώνει σύνδεσμο επαναφοράς για να
        σταλεί ο προγραμματιστής στον ιδιοκτήτη (δεν θέλει να γράψει τον
        κωδικό από το τηλέφωνο).
        """
        from .models import User

        with app.app_context():
            user = User.find_by_identifier(username)
            if user is None:
                click.echo(f"Δεν βρέθηκε χρήστης «{username}».")
                raise SystemExit(1)

            click.echo(f"  Χρήστης: {user.username} ({user.role})")
            if not click.confirm("  Να αλλάξει ο κωδικός;", default=True):
                click.echo("  Ακυρώθηκε.")
                return

            password = click.prompt("  Νέος κωδικός", hide_input=True,
                                    confirmation_prompt=True)
            if len(password) < 8:
                click.echo("  Ο κωδικός πρέπει να έχει τουλάχιστον 8 χαρακτήρες.")
                raise SystemExit(1)

            user.set_password(password)
            # Όλα τα link επαναφοράς του χρήστη παύουν να ισχύουν.
            from .models import PasswordResetToken

            PasswordResetToken.query.filter_by(user_id=user.id).delete()
            db.session.commit()
            click.echo()
            click.echo("  ✓ Ο κωδικός ενημερώθηκε. Τα δεδομένα δεν άλλαξαν.")

    @app.cli.command("reset-link")
    @click.argument("username")
    def reset_link(username):
        """Τυπώνει σύνδεσμο επαναφοράς (1 ώρα) — χωρίς να πεις τον κωδικό.

        Χρήσιμο όταν δεν έχει ρυθμιστεί email: στέλνεις τον σύνδεσμο στον
        ιδιοκτήτη με ασφαλές κανάλι (SMS, τηλέφωνο) και εκείνος βάζει μόνος
        του τον κωδικό.
        """
        from .models import User
        from .password_reset import reset_link_for_cli

        with app.app_context():
            user = User.find_by_identifier(username)
            if user is None:
                click.echo(f"Δεν βρέθηκε χρήστης «{username}».")
                raise SystemExit(1)
            link = reset_link_for_cli(user)
            click.echo()
            click.echo("  Σύνδεσμος επαναφοράς (ισχύει 60 λεπτά, μία χρήση):")
            click.echo()
            click.echo(f"    {link}")
            click.echo()

    @app.cli.command("create-user")
    @click.argument("username")
    @click.argument("password")
    @click.option("--email", default=None, help="Email (προαιρετικό).")
    @click.option("--first-name", prompt="Όνομα", default="")
    @click.option("--last-name", prompt="Επώνυμο", default="")
    @click.option("--role", type=click.Choice(["owner", "manager", "staff"]),
              default="staff",
              help="owner=Ιδιοκτήτης, manager=Υπεύθυνος (ίδια δικαιώματα), staff=Βοηθός")
    def create_user(username, password, first_name, last_name, role, email):
        """Δημιουργεί λογαριασμό ιδιοκτήτη ή βοηθού."""
        from .models import Groomer, User

        username = User.normalize_username(username)
        email = User.normalize_email(email)
        if not username:
            click.echo("Το όνομα χρήστη είναι υποχρεωτικό.")
            return
        conflict = User.query.filter(db.func.lower(User.username) == username.lower()).first()
        if conflict is None and email:
            conflict = User.query.filter(db.func.lower(User.email) == email).first()
        if conflict is not None:
            click.echo("Υπάρχει ήδη χρήστης με αυτό το όνομα χρήστη ή email.")
            return
        user = User(username=username, email=email, role=role, first_name=first_name, last_name=last_name)
        user.set_password(password)
        db.session.add(user)
        db.session.flush()
        if role == "owner":
            groomer = Groomer(user_id=user.id, sort_order=user.id, color="#B0567A")
            db.session.add(groomer)
            db.session.flush()
            # Χωρίς διαθεσιμότητα η στυλίστρια δεν βλέπει κανένα ελεύθερο
            # ραντεβού. Η διαθεσιμότητα παράγεται από τις ΎΡΕΣ ΛΕΙΤΟΥΡΓΙΑΣ ΤΟΥ
            # ΣΠΑ, ώστε να ταιριάζει με το πραγματικό ωράριο (π.χ. Τρ/Πε 12:00–21:00).
            from .models import AvailabilityRule, SalonDaySettings

            days = SalonDaySettings.query.order_by(SalonDaySettings.weekday).all()
            if days:
                for day in days:
                    if day.is_closed:
                        continue
                    db.session.add(AvailabilityRule(
                        groomer_id=groomer.id, weekday=day.weekday,
                        start_time=day.open_time, end_time=day.close_time,
                    ))
            else:  # δεν έχουν οριστεί ώρες σπα — προσωρινά Δευτέρα–Σάββατο
                for weekday in range(6):
                    db.session.add(AvailabilityRule(
                        groomer_id=groomer.id, weekday=weekday,
                        start_time=time(9, 0), end_time=time(18, 0),
                    ))
        db.session.commit()
        click.echo(f"Δημιουργήθηκε ο χρήστης {username} ({role}).")
        if role == "owner":
            click.echo("  Διαθεσιμότητα = ώρες λειτουργίας του Salon (αλλάζονται από το "
                       "Διοίκηση → Ώρες λειτουργίας).")
