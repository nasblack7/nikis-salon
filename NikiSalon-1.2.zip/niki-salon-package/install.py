#!/usr/bin/env python3
"""ΜΕ ΕΝΑ ΚΛΙΚ: εγκατάσταση, ρύθμιση και εκκίνηση της εφαρμογής στα Windows.

Το μόνο αρχείο που χρειάζεται ο χρήστης να πατήσει δύο φορές.

ΤΙ ΚΑΝΕΙ, ΜΕ ΤΗ ΣΕΙΡΑ
====================
  1. Σηκώνεται σε Administrator μόνος του (χρειάζεται για την εργασία SYSTEM)
  2. Ελέγχει ότι υπάρχει Python 3.10+
  3. Δημιουργεί το .venv και εγκαθιστά τις βιβλιοθήκες
  4. Δημιουργεί τους πίνακες της βάσης
  5. Γράφει .env με τυχαίο SECRET_KEY
  6. Δημιουργεί την εργασία Windows που ξεκινά την εφαρμογή σε κάθε
     εκκίνηση και ξαναξεκινά την αν πέσει
  7. ΕΛΕΓΧΕΙ ΟΤΙ Η ΕΦΑΡΜΟΓΗ ΑΠΑΝΤΑ — αν όχι, σταματάει και λέει ποιο είναι
     το πρόβλημα, αντί να «τελειώνει επιτυχώς» με σπασμένη εφαρμογή
  8. Εκτυπώνει τη διεύθυνση για τη δημιουργία του λογαριασμού ιδιοκτήτριας

Δεν απαιτεί IIS, HttpPlatformHandler ή οποιαδήποτε εγκατάσταση — μόνο τα
Windows και την Python που ζητά το πρόγραμμα.
"""
from __future__ import annotations

import ast
import argparse
import os
import secrets
import subprocess
import sys
import time
from pathlib import Path

IS_WINDOWS = os.name == "nt"
APP_DIR = Path(__file__).resolve().parent
VENV = APP_DIR / ".venv"
VENV_PY = VENV / "Scripts" / "python.exe"
PY_MIN = (3, 10)
GREEN, YELLOW, RED, DIM, BOLD, RESET = (
    "\033[32m", "\033[33m", "\033[31m", "\033[2m", "\033[1m", "\033[0m")

_tasks: list[str] = []


def _c(text: str, colour: str) -> str:
    return f"{colour}{text}{RESET}" if sys.stdout.isatty() else text


def step(text: str) -> None:
    print()
    print(_c(f"── {text} " + "─" * max(2, 58 - len(text)), DIM))


def ok(text: str) -> None:
    print(f"  {_c('[OK]', GREEN)}  {text}")


def warn(text: str) -> None:
    print(f"  {_c('[!]', YELLOW)}   {text}")


def fail(text: str) -> None:
    print(f"  {_c('[X]', RED)}   {text}")


def info(text: str) -> None:
    print(f"       {text}")


def head(text: str) -> None:
    print()
    print(_c("=" * 64, BOLD))
    print(_c(f"  {text}", BOLD))
    print(_c("=" * 64, BOLD))


# --------------------------------------------------------------- δικαιώματα
def is_admin() -> bool:
    if not IS_WINDOWS:
        return True
    try:
        out = subprocess.run(["net", "session"], capture_output=True,
                             timeout=20)
        return out.returncode == 0
    except Exception:                                  # noqa: BLE001
        return False


def elevate() -> bool:
    """Ξαναξεκινά τον εαυτό του ως Administrator. True αν επιτύχει."""
    if not IS_WINDOWS or is_admin():
        return False
    script = (
        "Start-Process -FilePath '%s' -ArgumentList '%s' -Verb RunAs"
        % (sys.executable, " ".join('"%s"' % a for a in [str(Path(__file__).resolve())] + sys.argv[1:]))
    )
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", script], check=True)
    except Exception:                                  # noqa: BLE001
        fail("Δεν ήταν δυνατή η αύξηση δικαιωμάτων.")
        info("Κάνε δεξί κλικ → «Εκτέλεση ως διαχειριστής» στο αρχείο.")
        return False
    return True


# ------------------------------------------------------------------ Python
def python_ok(version: tuple[int, ...]) -> bool:
    return version >= PY_MIN


def check_python() -> str:
    step(f"Python {PY_MIN[0]}.{PY_MIN[1]}+")
    version = sys.version_info[:2]
    if not python_ok(version):
        fail(f"Χρειάζεται Python {PY_MIN[0]}.{PY_MIN[1]}+· έχεις {version[0]}.{version[1]}")
        info("Κατέβασέ την από https://www.python.org/downloads/ και άφηλε")
        info("το «Add Python to PATH» τσεκαρισμένο.")
        return ""
    ok(f"Python {version[0]}.{version[1]}")
    return str(Path(sys.executable).resolve())


# ------------------------------------------------------------------ venv
def setup_venv() -> Path | None:
    step("Περιβάλλον Python (.venv)")
    if VENV_PY.exists():
        ok("Υπάρχει ήδη — δεν το αγγίζω.")
        return VENV_PY
    info("Δημιουργείται (λίγα δευτερόλεπτα)...")
    try:
        result = subprocess.run([sys.executable, "-m", "venv", str(VENV)],
                                capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=900)
    except Exception as exc:                          # noqa: BLE001
        fail(f"Αποτυχία: {exc}")
        return None
    if result.returncode != 0 or not VENV_PY.exists():
        fail("Το .venv δεν δημιουργήθηκε.")
        info((result.stderr or result.stdout or "").strip()[-400:])
        return None
    ok("Δημιουργήθηκε.")
    return VENV_PY


def install_deps(python: Path) -> bool:
    step("Βιβλιοθήκες")
    info("Κατέβασμα (1-3 λεπτά, μόνο την πρώτη φορά)...")
    try:
        result = subprocess.run(
            [str(python), "-m", "pip", "install", "--disable-pip-version-check",
             "--no-input", "-r", str(APP_DIR / "requirements.txt")],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=1800)
    except Exception as exc:                          # noqa: BLE001
        fail(f"Αποτυχία: {exc}")
        return False
    if result.returncode != 0:
        fail("Η εγκατάσταση απέτυχε.")
        for line in (result.stdout or result.stderr or "").splitlines()[-15:]:
            info(line.strip()[:150])
        return False
    installed = [l.strip() for l in (result.stdout or "").splitlines()
                 if l.strip().startswith("Successfully installed")]
    if installed:
        info(installed[0][:150])
    ok("Έτοιμες.")
    return True


#: Ό,τι ΠΡΕΠΕΙ να μπορεί να κάνει import το venv. Το click και το werkzeug
#: δεν τα γράφουμε στο requirements.txt — έρχονται μαζί με το Flask — αλλά
#: τα ελέγχουμε, γιατί αν δεν μπήκε το Flask δεν θα υπάρχουν ούτε αυτά.
REQUIRED_MODULES = ("flask", "dotenv", "waitress", "click", "sqlalchemy",
                    "flask_login", "flask_wtf", "werkzeug")

#: Ακόμα πιο σημαντικό: να σηκωθεί η ίδια η εφαρμογή. Ένα import που πετάει
#: σε κάποιο ασυνήθιστο σημείο (π.χ. λάθος διαδρομή) δεν φαίνεται από τον
#: έλεγχο των ονομάτων μόνων.
_PROBE = (
    "import importlib, sys\n"
    "bad = []\n"
    "for name in %r:\n"
    "    try:\n"
    "        importlib.import_module(name)\n"
    "    except Exception as exc:\n"
    "        bad.append(name + ': ' + type(exc).__name__)\n"
    "try:\n"
    "    import app\n"
    "    app.create_app()\n"
    "except Exception as exc:\n"
    "    bad.append('app: ' + type(exc).__name__ + ' ' + str(exc)[:120])\n"
    "print(chr(10).join(bad))\n"
)


def verify_env(python: Path) -> bool:
    """Αποδεικνύει ότι ΤΟ ΠΡΑΓΜΑΤΙΚΟ ΠΑΚΕΤΟ μπήκε, όχι ότι το pip είπε «οκ».

    Χωρίς αυτό τον έλεγχο, ένα αποτυχημένο κατέβασμα (κακό internet,
    proxy, απενεργοποιημένο pip) εμφανίζεται τρία βήματα αργότερα σαν
    «No module named click» — που δεν λένε τίποτα στον ιδιοκτήτρια.
    """
    step("Έλεγχος περιβάλλοντος")
    try:
        result = subprocess.run(
            [str(python), "-c", _PROBE % (REQUIRED_MODULES,)],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=300, cwd=str(APP_DIR))
    except Exception as exc:                          # noqa: BLE001
        fail(f"Δεν μπόρεσα να ελέγξω το περιβάλλον: {exc}")
        return False

    missing = [l.strip() for l in (result.stdout or "").splitlines() if l.strip()]
    if result.returncode != 0 and not missing:
        fail("Το περιβάλλον Python δεν απαντά σωστά.")
        for line in (result.stderr or "").splitlines()[-8:]:
            info(line.strip()[:150])
        return False
    if not missing:
        ok(f"Η εφαρμογή σηκώνεται· {len(REQUIRED_MODULES)} βιβλιοθήκες + η ίδια η εφαρμογή.")
        return True

    fail("Λείπουν βιβλιοθήκες — το κατέβασμα ΔΕΝ ολοκληρώθηκε.")
    for line in missing:
        info("  λείπει: " + line[:150])
    info("")
    info("Συνήθειοι λόγοι, κατά σειρά πιθανότητας:")
    info("  1. Δεν έχει internet. Το pip κατεβάζει τις βιβλιοθήκες από το")
    info("     internet κατά την εγκατάσταση· χωρίς σύνδεση δεν γίνεται.")
    info("  2. Υπάρχει proxy ή firewall που κόβει το pypi.org.")
    info("  3. Το κατέβασμα διακόπηκε (κλείσε το παράθυρο, δίκτυο).")
    info("")
    info(f"Δοκίμασε:  {VENV_PY} -m pip install -r requirements.txt")
    return False


def bootstrap_db(python: Path) -> bool:
    step("Βάση δεδομένων")
    try:
        result = subprocess.run([str(python), str(APP_DIR / "migrate.py")],
                                capture_output=True, text=True, encoding="utf-8",
                                errors="replace", timeout=600, cwd=str(APP_DIR))
    except Exception as exc:                          # noqa: BLE001
        fail(f"Αποτυχία: {exc}")
        return False
    if result.returncode != 0:
        fail("Οι πίνακες δεν δημιουργήθηκαν.")
        for line in (result.stdout or result.stderr or "").splitlines()[-12:]:
            info(line.strip()[:150])
        return False
    ok("Οι πίνακες είναι έτοιμοι.")
    return True


def _source_literals(path: Path) -> dict:
    """Συλλέγει τις ΣΤΑΘΕΡΕΣ τιμές από ένα αρχείο Python, χωρίς να το
    εκτελέσουμε. Μόνο stdlib (ast), γιατί αυτό τρέχει με το Python του
    συστήματος, χωρίς εγκατεστημένα πακέτα.

    Επιστρέφει {όνομα: τιμή} για τις αναθέσεις μονό-τιμής. Οι εκφράσεις
    που δεν είναι απλές συμβατικές (π.χ. os.environ.get(...)) δεν
    περιλαμβάνονται — τις διαβάζουμε με τη δική τους συνάρτηση.
    """
    import ast

    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError) as exc:
        raise SystemExit(f"Δεν μπόρεσα να διαβάσω το {path.name}: {exc}")

    found: dict = {}

    def walk(node):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, ast.ClassDef):
                walk(child)
            elif isinstance(child, ast.Assign):
                if not isinstance(child.value, ast.Constant):
                    continue
                if not isinstance(child.value.value, (str, int, float)):
                    continue
                for target in child.targets:
                    if isinstance(target, ast.Name):
                        found[target.id] = child.value.value

    walk(tree)
    return found


def _target_name(node) -> str:
    """Το όνομα στον αριστερό όρο μιας ανάθεσης.

    Στο config.py το UPDATE_URL είναι μέσα σε `class Config:`, άρα ο στόχος
    του AST είναι Name(id=...). Αν ποτέ γραφτεί ως `Config.UPDATE_URL = ...`
    τότε είναι Attribute(attr=...). Δεχόμαστε ΚΑΙ ΤΑ ΔΥΟ, γιατί το ποιο είναι
    σωστό εξαρτάται από το πού βρίσκεται η γραμμή — όχι από τη θέλησή μας.
    """
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return ""


def _update_url_default() -> str:
    """Η προεπιλογή του UPDATE_URL, όπως τη γράφει το config.py.

    Η γραμμή είναι `UPDATE_URL = os.environ.get("UPDATE_URL", "https://…")`
    μέσα στην class Config. Δεν κοιτάζουμε τη ΘΕΣΗ του string: το πρώτο
    όρισμα είναι το όνομα της μεταβλητής, το δεύτερο το URL. Διαλέγουμε
    εκείνο που μοιάζει διεύθυνση, ώστε η ανάγνωση να μην εξαρτάται από τη
    διάταξη της γραμμής. Η μορφοποίηση αλλάζει, η σημασία όχι.
    """
    path = APP_DIR / "config.py"
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError) as exc:
        raise SystemExit(f"Δεν μπόρεσα να διαβάσω το config.py: {exc}")

    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if not any(_target_name(t) == "UPDATE_URL" for t in node.targets):
            continue
        # Το string της διεύθυνσης μπορεί να είναι μέσα σε κλήση
        # (os.environ.get(...)) ή να είναι κατ' ευθείαν η τιμή.
        pools = ([node.value.args, node.value.keywords]
                 if isinstance(node.value, ast.Call) else [node.value])
        for pool in pools:
            for item in pool:
                if isinstance(item, ast.Constant) and isinstance(item.value, str) \
                        and "://" in item.value:
                    return item.value

    raise SystemExit(
        "Δεν βρέθηκε προεπιλογή για το UPDATE_URL στο config.py. "
        "Χωρίς αυτήν οι ενημερώσεις δεν θα ρυθμιστούν στο .env.")


def ensure_env(port: int, host: str) -> None:
    """Γράφει .env με ΤΥΧΑΙΟ κλειδί — το προεπιλεγμένο είναι δημόσιο στον
    κώδικα, οπότε θα το μπορούσε οποιοσδήποτε."""
    step("Ρυθμίσεις (.env)")
    env = APP_DIR / ".env"
    if env.exists():
        ok("Υπάρχει ήδη — δεν αγγίχτηκε.")
        return
    base = f"http://{host}:{port}" if port not in (80, 443) else f"http://{host}"
    # Διαβάζονται ΑΠΟ ΤΟΝ ΠΗΓΑΙΟ ΚΩΔΙΚΑ, χωρίς import: αυτό το αρχείο
    # τρέχει με το Python του ΣΥΣΤΗΜΑΤΟΣ, όπου δεν υπάρχουν ούτε dotenv
    # ούτε Flask. Το import του config.py σκοτώνε την εγκατάσταση στο
    # μηχάνημα του πελάτη.
    public_key = _source_literals(APP_DIR / "app" / "version.py").get(
        "UPDATE_PUBLIC_KEY", "")
    if not public_key:
        raise SystemExit(
            "Δεν βρέθηκε δημόσιο κλειδί ενημερώσεων (UPDATE_PUBLIC_KEY) "
            "στο app/version.py. Χωρίς αυτό οι ενημερώσεις δεν θα "
            "ρυθμιστούν — ξαναφτιάξτε το app/version.py.")
    update_url = _update_url_default()
    content = f"""# Niki's Grooming Salon — δημιουργήθηκε από το install.py
# Το SECRET_KEY υπογράφει τα cookies σύνδεσης. Μην το μοιράζεσαι και
# μην το αλλάξεις: η αλλαγή κόβει τις ενεργές συνδεδεμένες συνεδρίες.
SECRET_KEY={secrets.token_urlsafe(64)}

# Η διεύθυνση που βλέπει ο χρήστης. Χρησιμοποιείται στους συνδέσμους
# επαναφοράς κωδικού — αν δεν ταιριάζει, αυτοί δεν δουλεύουν.
PUBLIC_BASE_URL={base}

# Email (προαιρετικά). Χωρίς αυτά δεν στέλνονται email, και η εφαρμογή
# λειτουργεί κανονικά. Για επαναφορά κωδικού με email χρειάζεται.
MAIL_ENABLED=false

# Η θύρα στην οποία ακούει η εφαρμογή.
PORT={port}

# Αυτόματες ενημερώσεις. Το κλειδί είναι ΔΗΜΟΣΙΟ (είναι το δημόσιο μισό του
# ιδιωτικού που υπογράφει τις εκδόσεις) και βρίσκεται και στον κώδικα, στο
# app/version.py. Το γράφουμε και εδώ για να το βλέπει η ιδιοκτήτρια και να
# μπορεί να το αλλάξει αν ποτέ χρειαστεί. Χωρίς αυτά τα δύο η εφαρμογή
# ΔΕΝ προσφέρει ποτέ ενημέρωση — και δεν το λέει, μοιάζει απλώς «δεν υπάρχει
# νέα έκδοση».
UPDATE_URL={update_url}
UPDATE_PUBLIC_KEY={public_key}
"""
    env.write_text(content, encoding="utf-8")
    ok(f"Δημιουργήθηκε με τυχαίο SECRET_KEY (PUBLIC_BASE_URL={base})")


def setup_link(python: Path, base_url: str) -> str:
    """Δημιουργεί τον κωδικό πρώτης εγκατάστασης και επιστρέφει τη διεύθυνση."""
    try:
        result = subprocess.run(
            [str(python), "-m", "flask", "--app", "wsgi", "setup-token",
             "--base-url", base_url],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=180, cwd=str(APP_DIR))
    except Exception:                                  # noqa: BLE001
        return ""
    for line in (result.stdout or "").splitlines():
        if "/setup/?token=" in line:
            return line.strip()
    return ""


# ------------------------------------------------------------------ main
def main() -> int:
    head("Niki's Grooming Salon  ·  εγκατάσταση με ένα κλικ")

    if not IS_WINDOWS:
        fail("Αυτό το σενάριο στοχεύει Windows.")
        return 1
    if elevate():
        return 0                                     # ξαναξεκίνησε ως admin

    print()
    info(f"Φάκελος: {APP_DIR}")
    print()

    if not check_python():
        pause()
        return 1

    # Προειδοποίηση ασφαλείας: μέσα στο wwwroot, το IIS σερβίρει τα πάντα.
    try:
        sys.path.insert(0, str(APP_DIR))
        import install_service
        if install_service.is_under_wwwroot() is not None:
            step("ΠΡΟΣΟΧΗ")
            fail("Η εφαρμογή είναι μέσα στο wwwroot του IIS.")
            info("Το Default Web Site του IIS θα σερβίρει τη βάση και το .env")
            info("στο δίκτυο, χωρίς κωδικό. Μεταφέρε την πριν συνεχίσεις:")
            info(f'    robocopy "{APP_DIR}" "{APP_DIR.drive}\\NikiSalon" /MOVE /E')
            pause()
            return 1
    except Exception:                                  # noqa: BLE001
        pass

    python = setup_venv()
    if not python:
        pause()
        return 1
    if not install_deps(python):
        pause()
        return 1
    # Ο ΠΡΟΕΛΓΧΟΣ ΜΕ ΤΗ ΒΑΣΗ. Χωρίς αυτό, ένα αποτυχημένο κατέβασμα
    # εκδηλώνεται εδώ σαν «No module named click» — μήνυμα που δεν λέει στον
    # ιδιοκτήτρια τι έχει πάθει.
    if not verify_env(python):
        pause()
        return 1
    if not bootstrap_db(python):
        pause()
        return 1

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--local-only", action="store_true")
    parser.add_argument("--backup-dir", default=None,
                        help="Φάκελος για το καθημερινό αυτόματο αντίγραφο.")
    known, rest = parser.parse_known_args()
    port, local_only = known.port, known.local_only
    ensure_env(port, "localhost")

    # Η εγκατάσταση της εργασίας (Task Scheduler) + ο έλεγχος υγείας.
    import install_service
    rc = install_service.do_install(port, local_only, False)
    if rc != 0:
        pause()
        return rc

    # Υπενθυμίσεις κάθε 30 λεπτά + καθημερινό αντίγραφο. Χωρίς αυτά η
    # εφαρμογή δεν θυμάται να υπενθυμίσει ραντεβού και δεν έχει αντίγραφο
    # ασφαλείας. Χωρίς αυτά η εφαρμογή δεν θυμάται να υπενθυμίσει
    # ραντεβού και δεν έχει αντίγραφο όταν πάει στραβά.
    backup_dir = Path(known.backup_dir).expanduser() if known.backup_dir \
        else APP_DIR / "backups"
    install_service.setup_automation(python, backup_dir)

    base = f"http://localhost:{port}"
    link = setup_link(python, base)
    head("ΕΤΟΙΜΟ")
    print(f"   {link or base + '/setup/'}")
    print()
    print(f"   {install_service.lan_hint(local_only, port)}")
    print()
    ok("Η εφαρμογή θα ξεκινά μόνη της σε κάθε επανεκκίνηση του υπολογιστή.")
    ok("Χειροκίνητα:  python install_service.py --status  |  --stop  |  --start")
    print()
    pause()
    return 0


def pause() -> None:
    """Κρατά το παράθυρο ανοιχτό — το .bat το καλεί και μετά κλείνει."""
    if not sys.stdin or sys.stdin.isatty():
        try:
            input(f"\n{_c('Πάτησε Enter για κλείσιμο...', DIM)}")
        except Exception:                              # noqa: BLE001
            pass


if __name__ == "__main__":
    sys.exit(main())
