@echo off
REM ============================================================
REM  Niki's Grooming Salon - update from the command line.
REM
REM  WHY THIS FILE IS IN ENGLISH ONLY:
REM  cmd.exe reads a .bat file using the console's OEM code page
REM  (cp437 / cp1252 on most Windows machines), NOT UTF-8. Greek
REM  text in a UTF-8 .bat comes out as unreadable garbage, and
REM  there is no way to fix it from inside the file.
REM  So this file stays pure ASCII and hands everything to
REM  update_now.py, which forces UTF-8 correctly.
REM
REM  This file does nothing on its own. It calls the venv Python
REM  with update_now.py. All logic - download, signature check,
REM  install - lives in Python where it can be tested.
REM
REM  update_now.py runs in the MAIN thread with an app context,
REM  which is exactly what the 1.0.1 "Install" button lacked.
REM
REM  The full output is also written to logs\update-now.log in
REM  UTF-8. If this window shows boxes instead of Greek, open
REM  that file in Notepad - the reason is always there.
REM ============================================================

setlocal
cd /d "%~dp0"

set "PY=%~dp0.venv\Scripts\python.exe"

if not exist "%PY%" (
  echo.
  echo   The installation's Python was not found:
  echo   %PY%
  echo.
  echo   This usually means the app is not installed yet.
  echo   Please run C:\NikiSalon\INSTALL.bat first.
  echo.
  pause
  exit /b 1
)

REM UTF-8 on the console. Best effort: if the code page cannot be
REM changed, update_now.py still writes everything to the log file.
chcp 65001 >nul 2>&1

"%PY%" "%~dp0update_now.py" %*
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo   Done.
) else (
  echo   The update did not finish ^(error %RC%^).
  echo.
  echo   The full reason is in:  logs\update-now.log
  echo   Open that file with Notepad - the Greek text is correct there.
  echo.
  echo   The app is still working on the previous version.
  echo   You can open it normally.
)
echo.
pause
exit /b %RC%
