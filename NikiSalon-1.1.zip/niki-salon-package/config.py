"""Ρυθμίσεις εφαρμογής — Niki's Grooming Salon Appointment Management."""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv

# Με PyInstaller (--onefile) τα αρχεία της εφαρμογής αποσυμπακώνονται σε έναν
# ΠΡΟΣΩΡΙΝΟ φάκελο (sys._MEIPASS) που διαγράφεται μόλις κλείσει το πρόγραμμα.
# Αν η βάση ή τα logs γράφονταν εκεί, θα χανόταν σε κάθε εκτέλεση.
# Γι' αυτό, όταν το πρόγραμμα είναι "frozen", τα δεδομένα μπαίνουν δίπλα
# στο ίδιο το .exe.
FROZEN = getattr(sys, "frozen", False)
if FROZEN:
    RELEASE_DIR = Path(sys.executable).resolve().parent
else:
    RELEASE_DIR = Path(__file__).resolve().parent

# ΧΩΡΙΣ ΑΥΤΟ ΤΟ ΔΙΑΧΩΡΙΣΜΟ ΟΙ ΕΝΗΜΕΡΩΣΕΣ ΘΑ ΕΧΑΝΑΝ ΤΗ ΒΑΣΗ ΔΕΔΟΜΕΝΩΝ.
#
# Οι ενημερώσεις δεν γράφουν πάνω στον φάκελο της εγκατάστασης: κάθε
# έκδοση μπαίνει στο <root>/instance/releases/<φάκελος>/ και ο server.py
# βάζει πρώτο στο sys.path την ενεργή. Άρα το config.py που εκτελείται
# προέρχεται από τον φάκελο της έκδοσης, όχι από τη ρίζα.
#
# Αν το πάρουμε στα ίσια, το instance/ θα έδειχνε στο <έκδοση>/instance/,
# που είναι ΆΔΕΙΟ — η εφαρμογή θα ξεκινούσε σαν καθαρή εγκατάσταση και θα
# ζητούσε νέο ιδιοκτήτη, με όλα τα δεδομένα να φαίνονται χαμένα.
#
# Ο κώδικας (πρότυπα, static, Python) έρχεται από την έκδοση·
# τα δεδομένα (βάση, logs) πάντα από τη ρίζα της εγκατάστασης.
def _install_root(code_dir: Path) -> Path:
    """Επιστρέφει τη ρίζα της εγκατάστασης από τον φάκελο του κώδικα."""
    # .../<root>/instance/releases/<έκδοση>  ->  .../<root>
    if (code_dir.parent.name == "releases"
            and code_dir.parent.parent.name == "instance"):
        return code_dir.parent.parent.parent
    return code_dir


BASE_DIR = _install_root(RELEASE_DIR) if not FROZEN else RELEASE_DIR

# Ο ΦΑΚΕΛΟΣ ΤΩΝ ΔΕΔΟΜΕΝΩΝ — ΜΕ ΔΥΝΑΤΟΤΗΤΑ ΠΑΡΑΚΑΜΨΗΣ.
#
# ΤΟ ΜΠΟΡΙΟ ΠΟΥ ΣΚΑΒΕ ΜΕΤΑ ΤΑ ΜΙΣΑ. Ήταν σκληρά `BASE_DIR / "instance"`, χωρίς
# τίποτα να το αλλάξει. Κι επειδή το DATABASE_URL ρυθμίζεται από το
# περιβάλλον, ένα τεστ που έστειλε μόνο το DATABASE_URL σε προσωρινό
# αρχείο συνέχιζε να γράφει στο ΠΡΑΓΜΑΤΙΚΟ instance/: τα updates/, τα
# releases/, τα αντίγραφα της βάσης και — εδώ είναι το κακό — το ίδιο το
# signing_key.hex. Ένα τεστ καθαρισμού διέγραψε το κλειδί υπογραφής σου, και
# το έβρισκες μόνο από το μέγεθος του αρχείου.
#
# Δύο διορθώσεις, και η δεύτερη είναι η σημαντική:
#   1. το NIKI_INSTANCE_DIR μετακινεί ΟΛΟ ΤΟ instance/ μαζί
#   2. κάθε τεστ βάζει ΟΡΙΟ ΕΛΕΓΧΟΥ και σταματά αν δεν το σέβεται —
#      γιατί ένα τεστ που γράφει στο σπίτι σου δεν είναι «μερικώς» επικίνδυνο
NIKI_INSTANCE_DIR = os.environ.get("NIKI_INSTANCE_DIR", "").strip()
INSTANCE_DIR = Path(NIKI_INSTANCE_DIR) if NIKI_INSTANCE_DIR else BASE_DIR / "instance"
LOG_DIR = BASE_DIR / "logs"
STATIC_DIR = RELEASE_DIR / "app" / "static"

# Διαβάζει το .env από τη ρίζα του έργου (SECRET_KEY, MAIL_PASSWORD κ.λπ.)
load_dotenv(BASE_DIR / ".env")


def env_bool(key: str, default: bool = False) -> bool:
    raw = os.environ.get(key)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def env_int(key: str, default: int) -> int:
    try:
        return int(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{INSTANCE_DIR / 'salon.db'}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    WTF_CSRF_TIME_LIMIT = None

    # --- Κατασκευαστής εφαρμογής ---
    # Εμφανίζεται στο υποσέλιδο. Αλλάζει από το .env αν χρειαστεί:
    #   DEVELOPER_NAME=...
    #   DEVELOPER_EMAIL=...
    DEVELOPER_NAME = os.environ.get("DEVELOPER_NAME", "K.Intris")
    DEVELOPER_EMAIL = os.environ.get("DEVELOPER_EMAIL", "k.intris@yahoo.com")

    # --- Σπα ---
    SALON_NAME = "Niki's Grooming Salon"
    SALON_TIMEZONE = "Europe/Athens"
    # Προεπιλογή· αλλάζει από τις Ρυθμίσεις σπα (salon_settings.slot_minutes).
    SLOT_MINUTES = 60
    BOOKING_HORIZON_DAYS = 60
    # Προειδοποιητικό παράθυρο κλεισίματος: καμία προειδοποίηση. Ζητήθηκε ρητά να μπορεί
    # να κλείσει και λίγο πριν. Η προηγούμενη τιμή (120 λεπτά) ήταν εμπόδιο και όχι
    # προειδοποίηση: μια κλήση για αύριο στις 11:00 έπαιρνε απάντηση «δύο ώρες νωρίτερα»,
    # ενώ η ιδιοκτήτρια κλείνει το ραντεβού δίπλα στο κουρίζι. Ο έλεγχος επικάλυψης
    # παραμένει: το μηδέν σημαίνει απλώς ότι οι ώρες που πλησιάζουν δεν αποκλείονται.
    MIN_LEAD_MINUTES = 0
    REMINDER_LEAD_HOURS = 24
    REMINDER_CHANNEL = "email"

    PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "https://nikis-grooming.gr")

    # --- Online ενημερώσεις ---
    # Διεύθυνση του μικρού JSON που περιγράφει τη διαθέσιμη ενημέρωση:
    #   {"version": "...", "url": "...zip", "sha256": "...", "signature": "<base64>"}
    # ΠΡΟΕΠΙΛΟΓΗ, ΟΧΙ ΚΕΝΟ. Με κενό URL οι ενημερώσεις ήταν απενεργοποιημένες
    # σε κάθε νέα εγκατάσταση και η 1.0.1 δεν θα προσφερόταν ποτέ, χωρίς
    # κανένα ορατό σφάλμα. Ο ιδιοκτήτρια δεν χρειάζεται να αγγίξει τίποτα:
    # το .env που γράφει ο installer έχει ήδη την ίδια τιμή, και το αντιγράφει
    # εδώ ώστε να τη βλέπει. Άδειο => απενεργοποιημένες, αν το θέλει κάποιος.
    UPDATE_URL = os.environ.get("UPDATE_URL", "https://raw.githubusercontent.com/nasblack7/nikis-salon/main/update.json")
    # Πόσο συχνά γίνεται αυτόματος έλεγχος για ενημέρωση (ώρες). 0 = ποτέ.
    UPDATE_CHECK_HOURS = env_int("UPDATE_CHECK_HOURS", 12)
    # Μέγιστο μέγεθος πακέτου ενημέρωσης (MB) — προστασία απάτησης.
    UPDATE_MAX_MB = env_int("UPDATE_MAX_MB", 40)
    # Να εγκατασταθούν αυτόματα οι βιβλιοθήκες του requirements.txt.
    UPDATE_AUTO_PIP = env_bool("UPDATE_AUTO_PIP", True)
    # Δεύτεροι για τον έλεγχο ανανέωσης μετά την εγκατάσταση.
    UPDATE_HEALTH_TIMEOUT = env_int("UPDATE_HEALTH_TIMEOUT", 20)

    # --- Άδεια χρήσης ---
    #
    # Ο ΔΙΑΚΟΠΤΗΣ ΑΣΦΑΛΕΙΑΣ ΤΟΥ ΙΔΙΟΚΤΗΤΗ. ΜΕ ΝΟΗΜΑ ΟΧΙ «για να το
    # παρακάμψει κάποιος», αλλά για να ξεκλειδώνει το ΣΑΛΟΝΙ χωρίς
    # επανεγκατάσταση.
    #
    # Ο λόγος που υπάρχει: η πρώτη φορά που η 1.1 μπαίνει στον υπολογιστή του
    # σαλονιού, ΔΕΝ υπάρχει ακόμα άδεια στο instance/. Η εφαρμογή κλειδώνει
    # (όχι με σφάλμα — με τη σελίδα της άδειας, που δείχνει το κείμενο να
    # σταλεί). Αν κάτι πάει στραβά εκεί, ο ιδιοκτήτης θέλει ΜΙΑ μεταβολή στο
    # .env και επανεκκίνηση — όχι επανεγκατάσταση από το μηδέν σε ένα
    # σαλόνι με δεδομένα.
    #
    # 1 = κλειδώνει. 0 (ΠΡΟΕΠΙΛΟΓΗ) = η εφαρμογή δείχνει την κατάσταση
    # της άδειας αλλά ΔΕΝ κλειδώνει τίποτα.
    #
    # ΓΙΑΤΙ ΠΡΟΕΠΙΛΟΓΗ ΤΟ 0 — ΚΑΙ ΟΧΙ ΤΟ 1
    #   Οι δοκιμές το απέδειξαν: με προεπιλογή 1, ΟΛΕΣ οι 44 σουίτ ελέγχου
    #   έπεσαν, γιατί κάθε σελίδα πήγαινε στη σελίδα της άδειας. Δηλαδή το
    #   κλειδώριμο ΔΕΝ είναι «μια ρύθμιση» — είναι απόσταξη μιας ολόκληρης
    #   εγκατάστασης, μέχρι να βγει η πρώτη άδεια από το instance/.
    #
    #   Αυτό σημαίνει ότι με προεπιλογή 1, ΚΑΘΕ ΕΓΚΑΤΑΣΤΑΣΗ ΠΟΥ
    #   ΕΝΗΜΕΡΩΘΕΙ ΘΑ ΚΛΕΙΔΩΝΕΙ ΜΕΧΡΙ Ο ΙΔΙΟΚΤΗΤΗΣ ΝΑ ΕΚΔΩΣΕΙ ΑΔΕΙΑ
    #   ΧΕΙΡΟΚΙΝΗΤΑ. Για σαλόνι με δεδομένα μέσα, αυτό είναι διακοπή
    #   εργασίας που ζητά τηλεφώνημα. Καμία ενημέρωση δεν πρέπει να
    #   κάνει κάτι τέτοιο από τον χρήστη, γι' αυτό ο ιδιοκτήτης το
    #   ανάβει μόνος του, όταν είναι έτοιμος — σε κάθε υπολογιστή ξεχωριστά.
    #
    # ΓΙΑ ΝΑ ΤΟ ΑΝΑΨΕΤΕ ΣΤΟ ΣΑΛΟΝΙ
    #   Στο αρχείο `.env` της εγκατάστασης, μία γραμμή:
    #       LICENSE_ENFORCE=1
    #   και επανεγκατάσταση της υπηρεσίας. Η σελίδα Ενημερώσεις δείχνει
    #   μόνη της πότε το κλειδώριμο είναι κλειστό σε αυτόν τον υπολογιστή.
    #
    # ΣΗΜΕΙΩΣΗ ΑΣΦΑΛΕΙΑΣ: όποιος γράφει στο .env έχει ήδη δικαίωμα στον
    # διακομιστή, άρα ο διακόπτης δεν αφαιρεί καμία προστασία — την
    # μετατοπίζει από τον κώδικα στον ιδιοκτήτη. Γι' αυτό δεν είναι
    # επιλογή του πελάτη.
    LICENSE_ENFORCE = env_bool("LICENSE_ENFORCE", False)


    # --- Email (SMTP) ---
    MAIL_ENABLED = env_bool("MAIL_ENABLED", True)
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
    MAIL_PORT = env_int("MAIL_PORT", 587)
    MAIL_SECURITY = os.environ.get("MAIL_SECURITY", "starttls")
    MAIL_USER = os.environ.get("MAIL_USER") or "nikis.grooming@gmail.com"
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
    MAIL_FROM = os.environ.get("MAIL_FROM") or MAIL_USER
    MAIL_FROM_NAME = os.environ.get("MAIL_FROM_NAME", "Niki's Grooming Salon")
    MAIL_TIMEOUT = env_int("MAIL_TIMEOUT", 10)
    MAIL_LOGO = os.environ.get("MAIL_LOGO", "")
    # Όριο μεγέθους των uploads της εφαρμογής (λογότυπο). Χωρίς όριο, ένα
    # μεγάλο αρχείο θα έφταν ολόκληρο στη μνήμη πριν απορριφθεί. Οι ενημερώσεις
    # κατεβαίνουν από URL, όχι με upload, άρα δεν τις περιορίζει.
    MAX_CONTENT_LENGTH = 4 * 1024 * 1024

    # ΣΤΑΤΙΚΑ ΑΡΧΕΙΑ: ΧΩΡΙΣ ΚΡΑΤΗΣΗ ΣΤΗ ΜΝΗΜΗ. ΚΑΘΕ ΦΟΡΑ ΑΠΟ ΤΟ ΔΙΣΚΟ.
    #
    # ΤΟ FLASK ΚΡΑΤΑΕ ΤΑ ΣΤΑΤΙΚΑ ΣΤΗ ΜΝΗΜΗ ΓΙΑ 12 ΩΡΕΣ, ΑΝ ΔΕΝ ΤΟ ΠΕΙΣ
    # ΡΗΤΑ (το None σημαίνει «12 ώρες»). ΑΥΤΟ ΟΚΤΩ ΜΟΝΟ ΟΤΑΝ ΔΕΝ
    # ΜΕΤΑΦΕΡΟΤΑΝ ΠΟΤΕ ΑΡΧΕΙΑ ΜΕΣΑ ΣΤΟΝ ΙΔΙΟ ΤΟ ΦΑΚΕΛΟ ΤΗΣ ΕΦΑΡΜΟΓΗΣ.
    #
    # ΟΤΑΝ ΓΙΝΕΤΑΙ, ΟΧΙ: η εγκατάσταση μιας ενημέρωσης ΑΝΤΙΚΑΘΙΣΤΑ ΤΑ ΑΡΧΕΙΑ
    # κάτω από έναν διακόπτη που κρατά τα ΙΔΙΑ ΑΡΧΕΙΑ στη μνήμη. Οι δύο
    # βλέπουν διαφορετικά πράγματα, και ο διακόπτης σταματά να σερβίρει
    # ΣΤΑΤΙΚΑ ΜΕ 500 — που στον χρήστη μοιάζει σαν «χαλασμένη εφαρμογή».
    #
    # ΧΕΙΡΟΤΕΡΟ ΑΠΟ ΤΟ 500: ΧΩΡΙΣ CSS ΚΑΙ ΧΩΡΙΣ JAVASCRIPT. Η ιδιοκτήτρια
    # βλέπει γυμνό κείμενο, και η σελίδα συντήρησης δεν «κολλάει» ποτέ,
    # επειδή το JS που επιστρέφει στο σαλόνι δεν φορτώθηκε ποτέ.
    #
    # ΤΟ ΚΟΣΤΟΣ: μηδέν. Τα αρχεία είναι μικρά και τοπικά στο δίσκο· το
    # μόνο «χάνεται» είναι η ταχύτητα από τη RAM.
    SEND_FILE_MAX_AGE_DEFAULT = 0
    MAIL_SENDER_BCC = os.environ.get("MAIL_SENDER_BCC", "")

    @staticmethod
    def init_app(app):
        INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        # Χρειάζεται από το /setup (instance/setup_token.txt)
        app.config["INSTANCE_DIR"] = str(INSTANCE_DIR)
        # Και ο φάκελος των logs, ώστε το αρχείο ειδοποιήσεων να γράφεται
        # εκεί που λέει η εφαρμογή — όχι σε διαδρομή που μαντεύεται κάθε
        # φορά από το root_path.
        app.config["LOG_DIR"] = str(LOG_DIR)
        # Το δημόσιο κλειδί μπορεί να έρθει και από το .env, ώστε η ρύθμιση
        # μιας εγκατάστασης να μην απαιτεί επεξεργασία κώδικα.
        from app.version import UPDATE_PUBLIC_KEY

        app.config.setdefault(
            "UPDATE_PUBLIC_KEY",
            os.environ.get("UPDATE_PUBLIC_KEY") or UPDATE_PUBLIC_KEY,
        )
