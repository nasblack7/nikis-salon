"""Δημιουργία αρχείων Excel (.xlsx) χωρίς εξωτερικές βιβλιοθήκες.

Ένα αρχείο .xlsx είναι απλώς ένα ZIP με αρχεία XML, οπότε γράφεται με τη
βασική βιβλιοθήκη `zipfile`. Έτσι δεν προσθέτουμε εξάρτηση (π.χ. openpyxl) που
θα έπρεπε να εγκατασταθεί στον Windows server και να μπει στο PyInstaller.

Υποστηρίζονται: πολλά φύλλα, παχύτερες γραμμές/στήλες, πάγωμα γραμμών,
συγχώνευση κελιών, αυτόματο φίλτρο, μορφοποιήσεις € · ημερομηνία · ποσοστό ·
ακέραια, καθώς και παχύτερη/χοντρή γραμμή, χρώμα γραμματοσειράς και γέμισμα.
Οι τιμές γράφονται στατικά (όχι τύποι), ώστε το αρχείο να λέει πάντα αυτά
που υπολογίστηκε η εφαρμογή.
"""

from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from datetime import date, datetime, time
from io import BytesIO

# Το Excel θέλει τις ημερομηνίες ως σειριακό αριθμό, με βάση την 30/12/1899.
_EXCEL_EPOCH = date(1899, 12, 30)

_CT = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

# ------------------------------------------------------------------ μορφοποιήσεις

# Οι μορφοποιήσεις γράφονται στο XML μέσα σε εισαγωγικά, γι' αυτό το "€"
# μένει εδώ ως απλό χαρακτήρα· η απόδοση σε XML γίνεται στο esc().
MONEY = '"€"#,##0.00'
MONEY0 = '"€"#,##0'
PCT1 = "0.0%"
INT = "#,##0"
DATE = "dd/mm/yyyy"
DATETIME = "dd/mm/yyyy\\ hh:mm"
TIME = "hh:mm"
DEC2 = "#,##0.00"


def esc(text: str) -> str:
    """Ασφαλής XML διαφύγηση."""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _col_letter(index: int) -> str:
    """0 -> A, 25 -> Z, 26 -> AA."""
    letters = ""
    index += 1
    while index:
        index, rem = divmod(index - 1, 26)
        letters = chr(65 + rem) + letters
    return letters


def _serial(value: date | datetime | time) -> float:
    if isinstance(value, datetime):
        days = (value.date() - _EXCEL_EPOCH).days
        secs = value.hour * 3600 + value.minute * 60 + value.second
        return days + secs / 86400.0
    if isinstance(value, date):
        return float((value - _EXCEL_EPOCH).days)
    return value.hour / 24.0 + value.minute / 1440.0 + value.second / 86400.0


# ---------------------------------------------------------------------- στυλ

@dataclass(frozen=True)
class Style:
    bold: bool = False
    italic: bool = False
    size: float = 11.0
    color: str | None = None          # RGB χωρίς #
    fill: str | None = None           # RGB χωρίς #
    numfmt: str | None = None
    align: str | None = None          # left | center | right
    wrap: bool = False
    indent: int = 0
    top: bool = False                 # πάνω γραμμή (για συνολικά)
    border: bool = False              # πλαίσιο γύρω από το κελί


# Τα ονομαστικά στυλ που χρησιμοποιούν τα αναφορά. Κάθε ένα είναι μια
# πραγματική εμφάνιση, ώστε τα φύλλα να μοιάζουν με λογιστική αναφορά.
STYLES: dict[str, Style] = {
    "title": Style(bold=True, size=16, color="1F2933"),
    "subtitle": Style(italic=True, size=10, color="6B7280"),
    "h1": Style(bold=True, size=13, color="1F2933"),
    "header": Style(bold=True, color="FFFFFF", fill="8C3A5B", align="center",
                    wrap=True, border=True),
    "header_left": Style(bold=True, color="FFFFFF", fill="8C3A5B",
                         align="left", wrap=True, border=True),
    "text": Style(border=True),
    "text_wrap": Style(wrap=True, border=True),
    "text_muted": Style(color="6B7280", border=True),
    "label": Style(bold=False),
    "label_bold": Style(bold=True),
    "section": Style(bold=True, color="FFFFFF", fill="4E7E9C"),
    "money": Style(numfmt=MONEY, align="right", border=True),
    "money_bold": Style(bold=True, numfmt=MONEY, align="right", border=True),
    "money_total": Style(bold=True, numfmt=MONEY, align="right", top=True,
                         border=True),
    "money_neg": Style(numfmt=MONEY, align="right", color="B42318", border=True),
    "int": Style(numfmt=INT, align="right", border=True),
    "int_bold": Style(bold=True, numfmt=INT, align="right", border=True),
    "int_total": Style(bold=True, numfmt=INT, align="right", top=True, border=True),
    "pct": Style(numfmt=PCT1, align="right", border=True),
    "pct_bold": Style(bold=True, numfmt=PCT1, align="right", border=True),
    "date": Style(numfmt=DATE, align="center", border=True),
    "datetime": Style(numfmt=DATETIME, align="center", border=True),
    "time": Style(numfmt=TIME, align="center", border=True),
    "dec2": Style(numfmt=DEC2, align="right", border=True),
    "note": Style(italic=True, size=9, color="6B7280", wrap=True),
}


@dataclass
class Cell:
    value: object
    style: str = "text"


@dataclass
class Sheet:
    name: str
    rows: list[list[Cell]] = field(default_factory=list)
    widths: list[float] = field(default_factory=list)
    freeze_panes: str | None = None      # π.χ. "A3"
    autofilter: str | None = None        # π.χ. "A1:F40"
    merges: list[str] = field(default_factory=list)
    max_row: int = 0
    max_col: int = 0

    # ------------------------------------------------------------- γραφή
    def add(self, values, style: str = "text") -> int:
        """Προσθέτει γραμμή. `values` μπορεί να έχει διαφορετικό στυλ ανά κελί."""
        row: list[Cell] = []
        for value in values:
            if isinstance(value, Cell):
                row.append(value)
            else:
                row.append(Cell(value, style))
        self.rows.append(row)
        n = len(self.rows)
        self.max_row = max(self.max_row, n)
        self.max_col = max(self.max_col, len(row))
        return n

    def blank(self, count: int = 1) -> None:
        for _ in range(count):
            self.add([])

    def title(self, text: str, subtitle: str = "", span: int = 8) -> None:
        self.add([Cell(text, "title")] + [Cell("", "title")] * (span - 1))
        self.merges.append("A%d:%s%d" % (self.max_row, _col_letter(span - 1), self.max_row))
        if subtitle:
            self.add([Cell(subtitle, "subtitle")] + [Cell("", "subtitle")] * (span - 1))
            self.merges.append("A%d:%s%d" % (self.max_row, _col_letter(span - 1), self.max_row))
        self.blank()

    def section(self, text: str, span: int = 8) -> None:
        self.add([Cell(text, "section")] + [Cell("", "section")] * (span - 1))
        self.merges.append("A%d:%s%d" % (self.max_row, _col_letter(span - 1), self.max_row))

    def header_row(self, labels) -> int:
        return self.add([Cell(str(x), "header") for x in labels])

    def kv(self, label: str, value, value_style: str = "text") -> None:
        self.add([Cell(label, "label"), Cell(value, value_style)])

    def widths_from(self, values) -> None:
        self.widths = list(values)

    def freeze(self, ref: str) -> None:
        """Παγώνει γραμμές/στήλες πάνω από το ref, π.χ. freeze("A4")."""
        self.freeze_panes = ref

    def filter(self, ref: str) -> None:
        """Αυτόματο φίλτρο στην περιοχή ref, π.χ. filter("A1:F40")."""
        self.autofilter = ref


class Workbook:
    def __init__(self, creator: str = "Niki's Grooming Salon") -> None:
        self.sheets: list[Sheet] = []
        self.creator = creator

    def add_sheet(self, name: str) -> Sheet:
        # Το Excel δεν δέχεται όνομα φύλλου πάνω από 31 χαρακτήρες ή με : \ / ? * [ ]
        clean = "".join(ch for ch in name if ch not in ':\\/?*[]')[:31] or "Φύλλο"
        sheet = Sheet(clean)
        self.sheets.append(sheet)
        return sheet

    # ---------------------------------------------------------------- XML
    def _styles_xml(self) -> str:
        names = list(STYLES)
        # Προσθέτουμε και τις μορφοποιήσεις που δεν αντιστοιχούν σε όνομα.
        numfmts: list[str] = []
        fmt_index: dict[str, int] = {}
        for name in names:
            code = STYLES[name].numfmt
            if code and code not in fmt_index:
                fmt_index[code] = 164 + len(numfmts)
                numfmts.append(code)

        fonts: list[str] = []
        fills: list[str] = []
        borders: list[str] = []
        xfs: list[str] = []
        xf_index: dict[str, int] = {}

        # Το Excel απαιτεί τους δύο πρώτους γεμίσματα να είναι none/gray125.
        fills.append('<fill><patternFill patternType="none"/></fill>')
        fills.append('<fill><patternFill patternType="gray125"/></fill>')

        for name in names:
            st = STYLES[name]
            font_id = len(fonts)
            bits = ['<font>']
            if st.bold:
                bits.append("<b/>")
            if st.italic:
                bits.append("<i/>")
            bits.append('<sz val="%s"/>' % st.size)
            bits.append('<color rgb="FF%s"/>' % (st.color or "1F2933"))
            bits.append('<name val="Calibri"/><family val="2"/></font>')
            fonts.append("".join(bits))

            fill_id = 0
            if st.fill:
                fill_id = len(fills)
                fills.append('<fill><patternFill patternType="solid">'
                             '<fgColor rgb="FF%s"/><bgColor indexed="64"/>'
                             "</patternFill></fill>" % st.fill)

            numfmt_id = fmt_index[st.numfmt] if st.numfmt else 0

            align = ""
            if st.align or st.wrap or st.indent:
                align = ('<alignment%s%s%s horizontal="%s"/>'
                         % (' indent="%d"' % st.indent if st.indent else "",
                            ' vertical="top"' if st.wrap else "",
                            "", st.align or "left"))
            # Το <border> στο OOXML έχει ή τα attributes (left="thin") ή τα
            # στοιχεία-παιδιά (<left style="thin"/>), όχι και τα δύο. Θέλουμε τα
            # στοιχεία-παιδιά, γιατί έτσι δίνουμε χρώμα ανά πλευρά.
            light, strong = "FFD8D8D8", "FF8C3A5B"
            def side(name: str) -> str:
                if name == "top" and st.top:
                    return '<top style="thin"><color rgb="%s"/></top>' % strong
                if st.border:
                    return '<%s style="thin"><color rgb="%s"/></%s>' % (name, light, name)
                return "<%s/>" % name

            border = ("<border>%s%s%s%s</border>"
                      % (side("left"), side("right"), side("top"), side("bottom")))
            border_id = 1 if (st.border or st.top) else 0
            while len(borders) <= border_id:
                borders.append(None)
            borders[border_id] = border

            xf_index[name] = len(xfs)
            xfs.append(
                '<xf numFmtId="%d" fontId="%d" fillId="%d" borderId="%d" xfId="0"'
                ' applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"%s>'
                "%s</xf>"
                % (numfmt_id, font_id, fill_id, border_id,
                   ' applyAlignment="1"' if align else "", align)
            )

        parts = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
        ]
        if numfmts:
            parts.append('<numFmts count="%d">' % len(numfmts))
            for code in numfmts:
                parts.append('<numFmt numFmtId="%d" formatCode="%s"/>'
                             % (fmt_index[code], esc(code)))
            parts.append("</numFmts>")
        parts.append('<fonts count="%d">%s</fonts>' % (len(fonts), "".join(fonts)))
        parts.append('<fills count="%d">%s</fills>' % (len(fills), "".join(fills)))
        parts.append('<borders count="%d">%s</borders>' % (len(borders), "".join(borders)))
        parts.append('<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0"'
                     ' borderId="0"/></cellStyleXfs>')
        parts.append('<cellXfs count="%d">%s</cellXfs>' % (len(xfs), "".join(xfs)))
        parts.append('<cellStyles count="1"><cellStyle name="Normal" xfId="0"'
                     ' builtinId="0"/></cellStyles>')
        parts.append("</styleSheet>")
        return "".join(parts)

    @staticmethod
    def _cell_xml(ref: str, cell: Cell, xf: dict[str, int]) -> str:
        style = cell.style if cell.style in xf else "text"
        s = ' s="%d"' % xf[style]
        value = cell.value
        if value is None or value == "":
            return '<c r="%s"%s/>' % (ref, s)
        if isinstance(value, bool):
            value = int(value)
        if isinstance(value, (int, float)):
            return '<c r="%s"%s><v>%s</v></c>' % (ref, s, repr(float(value))
                                                   if isinstance(value, float) else value)
        if isinstance(value, (datetime, date, time)):
            return '<c r="%s"%s><v>%s</v></c>' % (ref, s, _serial(value))
        return ('<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>'
                % (ref, s, esc(value)))

    def _sheet_xml(self, sheet: Sheet, xf: dict[str, int]) -> str:
        cols = ""
        if sheet.widths:
            items = "".join(
                '<col min="%d" max="%d" width="%s" customWidth="1"/>'
                % (i + 1, i + 1, w)
                for i, w in enumerate(sheet.widths) if w
            )
            cols = "<cols>%s</cols>" % items

        rows = []
        for r, row in enumerate(sheet.rows, start=1):
            if not row:
                continue
            cells = "".join(
                self._cell_xml("%s%d" % (_col_letter(c), r), cell, xf)
                for c, cell in enumerate(row)
            )
            rows.append('<row r="%d">%s</row>' % (r, cells))

        pane = ""
        if sheet.freeze_panes:
            col, row = _split_ref(sheet.freeze_panes)
            top = "1" if row <= 1 else str(row)
            left = "0" if col <= 1 else _col_letter(col - 1)
            active = "bottomLeft" if col <= 1 else "bottomRight"
            pane = ('<pane xSplit="%d" ySplit="%d" topLeftCell="%s" activePane="%s" state="frozen"/>'
                    % (col - 1, row - 1, sheet.freeze_panes, active))
        view = ('<sheetViews><sheetView workbookViewId="0"%s>%s</sheetView></sheetViews>'
                % (' tabSelected="1"' if sheet is self.sheets[0] else "", pane))

        merge = ""
        if sheet.merges:
            merge = '<mergeCells count="%d">%s</mergeCells>' % (
                len(sheet.merges),
                "".join('<mergeCell ref="%s"/>' % m for m in sheet.merges))

        filt = '<autoFilter ref="%s"/>' % sheet.autofilter if sheet.autofilter else ""
        dim = "A1:%s%d" % (_col_letter(max(0, sheet.max_col - 1)), max(1, sheet.max_row))
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<dimension ref="%s"/>%s'
            '<sheetFormatPr defaultRowHeight="15"/>'
            "%s<sheetData>%s</sheetData>%s%s"
            '<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75"'
            ' header="0.3" footer="0.3"/>'
            "</worksheet>"
            % (dim, view, cols, "".join(rows), filt, merge)
        )

    def to_bytes(self) -> bytes:
        xf = {name: i for i, name in enumerate(STYLES)}
        buf = BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            n = len(self.sheets)
            z.writestr("[Content_Types].xml",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                       '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                       '<Default Extension="xml" ContentType="application/xml"/>'
                       '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                       + "".join(
                           '<Override PartName="/xl/worksheets/sheet%d.xml"'
                           ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1)
                           for i in range(n))
                       + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                       '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
                       "</Types>")
            z.writestr("_rels/.rels",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                       '<Relationship Id="rId1" Type="%s/officeDocument" Target="xl/workbook.xml"/>'
                       '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/'
                         'relationships/metadata/core-properties" Target="docProps/core.xml"/>'
                       "</Relationships>" % _REL)
            z.writestr("docProps/core.xml",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"'
                       ' xmlns:dc="http://purl.org/dc/elements/1.1/">'
                       "<dc:creator>%s</dc:creator><cp:lastModifiedBy>%s</cp:lastModifiedBy>"
                       "</cp:coreProperties>" % (esc(self.creator), esc(self.creator)))
            z.writestr("xl/_rels/workbook.xml.rels",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                       + "".join(
                           '<Relationship Id="rId%d" Type="%s/worksheet" Target="worksheets/sheet%d.xml"/>'
                           % (i + 1, _REL, i + 1) for i in range(n))
                       + '<Relationship Id="rId%d" Type="%s/styles" Target="styles.xml"/>'
                       % (n + 1, _REL)
                       + "</Relationships>")
            z.writestr("xl/styles.xml", self._styles_xml())
            sheets = "".join(
                '<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (esc(s.name), i + 1, i + 1)
                for i, s in enumerate(self.sheets)
            )
            z.writestr("xl/workbook.xml",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                       '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
                       ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                       '<workbookPr/><sheets>%s</sheets></workbook>' % sheets)
            for i, sheet in enumerate(self.sheets):
                z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), self._sheet_xml(sheet, xf))
        return buf.getvalue()

    def save(self, path: str) -> None:
        with open(path, "wb") as fh:
            fh.write(self.to_bytes())


def _split_ref(ref: str) -> tuple[int, int]:
    """'B4' -> (2, 4) — στήλη, γραμμή (1-based)."""
    col = row = 0
    for ch in ref:
        if ch.isalpha():
            col = col * 26 + (ord(ch.upper()) - 64)
        else:
            row = row * 10 + int(ch)
    return col, row
