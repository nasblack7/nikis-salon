/* Service worker για το Niki's Grooming Salon.
   Κάνει τη σελίδα εγκαταστάσιμη (PWA) και διαθέσιμη offline για βασικές σελίδες. */

// Αλλάζει σε κάθε σημαντική ενημέρωση, ώστε οι εγκαταστημένες εφαρμογές
// (PWA) να μην κρατούν παλιά JS/CSS. Χωρίς αυτό η φόρμα κράτησης θα
// συνέχιζε να τρέχει την παλιά λογική μεγέθους.
// Ο ΑΡΙΘΜΟΣ ΑΥΤΟΣ ΠΡΕΠΕΙ ΝΑ ΜΕΓΑΛΩΝΕΙ ΟΠΟΤΕ ΑΛΛΑΖΕΙ Η app.css Η Η app.js.
//
// Ο v9 ήταν για το λογότυπο. Το v10 είναι για το app.js: μέσα στο v9
// υπήρχε ένα `})();` παραπάνω, δηλαδή ΛΑΘΟΣ ΣΥΝΤΑΞΗΣ, και το ΟΛΟ ΤΟ
// ΑΡΧΕΙΟ ΔΕΝ ΕΚΤΕΛΟΥΝΤΑΝ — πέθαναν κάθε κουμπί, κάθε modal και κάθε
// φόρμα σε κάθε ενότητα. Ένα αρχείο με σφάλμα σύνταξης δεν «λειτουργεί
// λίγο λάθος»: δεν εκτελείται καθόλου.
//
// Τα αρχεία πιάνονται network-first (βλ. παρακάτω), άρα όσοι είναι
// online παίρνουν τη διόρθωση αμέσως. Αλλά το pre-cache κρατάει την ΠΑΛΙΑ
// έκδοση — χωρίς νέο αριθμό, όσοι έμειναν offline θα ξανανοίξουν το
// νεκρό script. Ο νέος αριθμός σβήνει τις παλιές κάψες στην εγκατάσταση.
const CACHE = "niki-grooming-v10";
const CORE = [
  "/",
  "/static/css/app.css",
  "/static/js/app.js",
  "/static/img/site/logo-transparent.png",
  "/static/img/site/icon-192.png",
  "/static/img/site/icon-512.png",
  "/static/img/paw.svg",
  "/auth/login",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      /* Ένα αρχείο που λείπει δεν πρέπει να ακυρώνει όλη την εγκατάσταση. */
      .then((cache) => Promise.all(CORE.map((url) => cache.add(url).catch(() => null))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/* Στρατηγική: network-first για JS/CSS και σελίδες, cache-first για εικόνες.
   Τα POST και τα API δεν κρατιούνται ποτέ.

   Τα JS/CSS είναι network-first επειδή αλλάζουν με κάθε έκδοση: με
   cache-first, ένα ταμπλέτ που έχει ήδη την παλιά έκδοση στην κράχτη θα
   συνέχιζε να τρέχει παλιό κώδικα χωρίς καμία ενδείξη. Η κράχτη μένει για
   offline, απλώς προτιμάται το δίκτυο όταν υπάρχει. */
self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  /* Τα API δεν πρέπει ΠΟΤΕ να μπαίνουν στην κράχτη. Ένας αποθηκευμένος
     «έκδοση ημερολογίου» ή «διαθέσιμες ώρες» θα έδινε παλιά δεδομένα χωρίς
     καμία ενδειξη: η ζωντανή ενημέρωση δεν θα έβλεπε ποτέ αλλαγή και η φόρμα
     κράτησης θα έδειχνε ώρες που έχουν ήδη δοθεί. Πάντα κατευθείαν στο δίκτυο. */
  if (url.pathname.startsWith("/staff/api/") || url.pathname.startsWith("/api/")) {
    return;
  }

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(request, copy));
          return response;
        })
        .catch(() => caches.match(request).then((hit) => hit || caches.match("/")))
    );
    return;
  }

  /* Κώδικας και στυλ: πάντα το δίκτυο πρώτα, κράχτη μόνο αν αποτύχει. */
  /* ΤΟ ΛΟΓΟΤΥΠΟ. Δεν είναι στατικό: η ιδιοκτήτρια το αλλάζει από τη
     σελίδα ρυθμίσεων. Με τον τελευταίο κανόνα (cache-first) θα
     κρατιόταν ΜΟΝΙΜΑ — η δεύτερη αλλαγή δεν θα φαινόταν ποτέ, και το
     «αποθήκευσε το νέο λογότυπο» θα έπρεπε να ανακατεύθει. Δεν έχει
     νόημα να κρατάμε στην κράχτη κάτι που αλλάζει με κίνηση του χρήστη. */
  if (url.pathname === "/salon-logo") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => caches.match(request))
    );
    return;
  }

  if (/\.(?:js|css)$/.test(url.pathname)) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => caches.match(request))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then(
      (hit) =>
        hit ||
        fetch(request).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE).then((cache) => cache.put(request, copy));
          }
          return response;
        })
    )
  );
});
