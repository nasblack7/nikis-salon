/**
 * Ζωντανή ενημέρωση ημερολογίου.
 *
 * Ο server δίνει ένα «token» έκδοσης ανά ημέρα (αριθμός ραντεβού, μεγαλύτερο
 * id, τελευταίο updated_at). Το ρωτάμε κάθε λίγα δευτερόλεπτα και:
 *   • στη σελίδα Ημερολογίου, αν άλλαξε → ανανέωση της σελίδας
 *   • παντού, αλλάζει την κατάσταση της πράσινης κουκκίδας στο μενού
 *
 * Η κουκκίδα δεν είναι διακόσμηση: δείχνει ότι ο έλεγχος όντως γίνεται. Αν ο
 * server δεν απαντά, σβήνει — γιατί «ζωντανή» ενημέρωση που δεν ενημερώνει
 * είναι χειρότερη από καμία.
 */
(function () {
  "use strict";

  var POLL_MS = 20000;          // πόσο συχνά ρωτάμε
  var STALE_MS = POLL_MS * 3;    // μετά από πόσο θεωρούμε το token παλιό
  var dot = null;
  var date = "";
  var token = null;
  var failures = 0;
  var timer = null;
  var reloading = false;
  var lastOk = 0;

  function root() {
    return document.getElementById("liveCalendar") || null;
  }

  /* --- κατάσταση της κουκκίδας ---------------------------------------- */
  function paint(state, title) {
    if (!dot) return;
    dot.className = "live-dot live-dot--" + state;
    dot.title = title;
  }

  function setLive() {
    failures = 0;
    paint("on", "Ζωντανή ενημέρωση: ο ημερολόγιος ελέγχεται κάθε " +
          Math.round(POLL_MS / 1000) + " δευτερόλεπτα");
  }

  function setDead() {
    failures += 1;
    /* Μετά από 2 αποτυχίες θεωρούμε ότι έχει χαθεί η σύνδεση. */
    paint(failures >= 2 ? "off" : "wait",
          failures >= 2
            ? "Χωρίς σύνδεση — ο ημερολόγιος δεν ενημερώνεται αυτόματα"
            : "Ελέγχουμε τη σύνδεση…");
  }

  function check() {
    fetch("/staff/api/calendar-version?date=" + encodeURIComponent(date), {
      headers: { Accept: "application/json" },
      cache: "no-store",
    })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        setLive();
        lastOk = Date.now();
        if (token === null) {
          token = data.token;          // πρώτη μέτρηση: μόνο σημείο εκκίνησης
          return;
        }
        if (data.token === token) return;
        token = data.token;
        /* Άλλαξε κάτι. */
        if (root() && !reloading) {
          reloading = true;
          paint("sync", "Έγινε αλλαγή — ενημερώνω…");
          window.location.reload();
        } else {
          /* Αλλού: η κουκκίδα «χτυπά» μία φορά για να το δείξει. */
          paint("new", "Υπάρχουν αλλαγές στον ημερολόγιο — άνοιξε τον");
        }
      })
      .catch(setDead);
  }

  function start() {
    var cfg = root();
    if (!cfg) return;
    date = cfg.dataset.liveDate || "";
    dot = cfg.querySelector(".live-dot");
    if (timer) clearInterval(timer);
    /* Ο πρώτος έλεγχος γίνεται αμέσως, ώστε η κουκκίδα να ξεκινήσει σωστά. */
    check();
    timer = setInterval(check, POLL_MS);

    /* Οι browser περιορίζουν ή σταματούν τα timers σε κρυφές καρτέλες. Γι'
       αυτό, μόλις ο χρήστης ξαναγυρίσει στην καρτέλα, ελέγχουμε αμέσως — και
       αν πέρασε πολύ ώρα χωρίς επιτυχή απάντηση, η κουκκίδα σβήνει μόνη της
       αντί να «λέει» ότι ενημερώνεται κάτι που δεν ελέγχεται. */
    document.addEventListener("visibilitychange", function () {
      if (document.hidden) return;
      if (lastOk && Date.now() - lastOk > STALE_MS) {
        failures = 2;
        paint("off", "Χωρίς σύνδεση — ο ημερολόγιος δεν ενημερώνεται αυτόματα");
      }
      check();
    });
    window.addEventListener("offline", function () {
      failures = 2;
      paint("off", "Χωρίς σύνδεση με το δίκτυο");
    });
    window.addEventListener("online", check);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
