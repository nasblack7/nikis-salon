"""Εξαγωγή αναφορών σε Excel — Οικονομική αναφορά & στατιστικά.

Δύο ξεχωριστά αρχεία:
  • «Έσοδα – Έξοδα»  : λογαριαστική αναφορά με έσοδα, εκπτώσεις, έξοδα ανά
    κατηγορία και καθαρό εισόδημα. Μόνο για την ιδιοκτήτρια.
  • «Στατιστικά»   : κίνηση χωρίς χρηματικά ποσά, άρα και για τους βοηθούς.

Περίοδοι: ημερήσια, εβδομαδιαία, μηνιαία, ετήσια — με δυνατότητα αγκύρωσης σε
οποιαδήποτε παρελθόν ημερομηνία, ώστε να βγαίνει π.χ. ο Σεπτέμβριος του 2025.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import date as date_cls, datetime, time, timedelta

from .extensions import db
from .models import (
    OPEN_STATUSES,
    SPECIES,
    STATUS_CANCELLED,
    STATUS_COMPLETED,
    STATUS_NO_SHOW,
    WEEKDAYS,
    Appointment,
    Customer,
    Expense,
    Groomer,
    Pet,
    Service,
)
from .xlsx import Cell, Workbook

MONTHS = ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάιος", "Ιούνιος",
          "Ιούλιος", "Αυγούστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"]
MONTHS_SHORT = ["Ιαν", "Φεβ", "Μαρ", "Απρ", "Μαΐ", "Ιουν",
                "Ιουλ", "Αυγ", "Σεπ", "Οκτ", "Νοέ", "Δεκ"]

# Οι τέσσερις περίοδοι που ζητούνται από την ιδιοκτήτρια.
PERIODS = {
    "day": "Ημερήσια",
    "week": "Εβδομαδιαία",
    "month": "Μηνιαία",
    "year": "Ετήσια",
}
DEFAULT_PERIOD = "month"


# ------------------------------------------------------------------ περίοδος

def period_bounds(period: str, anchor: date_cls | None = None) -> tuple[date_cls, date_cls, str]:
    """Επιστρέφει (από, έως_αποκλειστικά, ετικέτα). Το `end` είναι αποκλειστικό."""
    period = period if period in PERIODS else DEFAULT_PERIOD
    day = anchor or date_cls.today()

    if period == "day":
        return day, day + timedelta(days=1), day.strftime("%d/%m/%Y")
    if period == "week":
        start = day - timedelta(days=day.weekday())      # Δευτέρα
        end = start + timedelta(days=7)
        return start, end, "%s – %s" % (start.strftime("%d/%m"), (end - timedelta(days=1)).strftime("%d/%m/%Y"))
    if period == "year":
        return date_cls(day.year, 1, 1), date_cls(day.year + 1, 1, 1), str(day.year)

    start = day.replace(day=1)
    end = (date_cls(day.year + 1, 1, 1) if start.month == 12
           else date_cls(day.year, start.month + 1, 1))
    return start, end, "%s %d" % (MONTHS[start.month - 1], start.year)


def _dt(day: date_cls) -> datetime:
    return datetime.combine(day, time(0, 0))


def salon_identity() -> dict:
    from .models import SalonSettings

    values = SalonSettings.as_dict()
    return {
        "name": values.get("name") or "Salon",
        "address": values.get("address") or "",
        "phone": values.get("phone") or "",
        "email": values.get("email") or "",
        "vat": values.get("vat_number") or "",
    }


def _identity_block(ws, identity: dict, subtitle: str) -> None:
    ws.title(identity["name"], subtitle, span=8)
    rows = [
        ("ΑΦΜ", identity["vat"]),
        ("Διεύθυνση", identity["address"]),
        ("Τηλέφωνο", identity["phone"]),
        ("Email", identity["email"]),
        ("Εξαγωγή", datetime.now().strftime("%d/%m/%Y %H:%M")),
    ]
    for label, value in rows:
        if value:
            ws.add([Cell(label, "label_bold"), Cell(value, "text")])
    ws.blank()


# =============================================================== οικονομικά

def _appointments(start: date_cls, end: date_cls) -> list[Appointment]:
    return (
        Appointment.query
        .filter(Appointment.start_at >= _dt(start), Appointment.start_at < _dt(end))
        .order_by(Appointment.start_at, Appointment.id)
        .all()
    )


def _expenses(start: date_cls, end: date_cls) -> list[Expense]:
    return (
        Expense.query
        .filter(Expense.spent_on >= start, Expense.spent_on < end)
        .order_by(Expense.spent_on, Expense.id)
        .all()
    )


def finance_facts(start: date_cls, end: date_cls) -> dict:
    """Μοναδικό σημείο αλήθειας για τα οικονομικά μεγέθη."""
    appts = _appointments(start, end)
    completed = [a for a in appts if a.status == STATUS_COMPLETED]
    expenses = _expenses(start, end)

    gross = sum(float(a.total_price or 0) for a in completed)
    discounts = sum(float(a.discount_amount or 0) for a in completed)
    revenue = sum(a.price_effective for a in completed)
    expense_total = sum(e.amount for e in expenses)

    by_category: dict[str, float] = defaultdict(float)
    count_category: dict[str, int] = defaultdict(int)
    for e in expenses:
        by_category[e.category_label] += e.amount
        count_category[e.category_label] += 1

    return {
        "appointments": appts,
        "completed": completed,
        "expenses": expenses,
        "gross": gross,
        "discounts": discounts,
        "revenue": revenue,
        "expense_total": expense_total,
        "net": revenue - expense_total,
        "by_category": by_category,
        "count_category": count_category,
        "cancelled": len([a for a in appts if a.status == STATUS_CANCELLED]),
        "no_shows": len([a for a in appts if a.status == STATUS_NO_SHOW]),
        "avg_ticket": (revenue / len(completed)) if completed else 0.0,
    }


def _sheet_summary(wb: Workbook, facts: dict, period_label: str, period_name: str,
                   identity: dict) -> None:
    ws = wb.add_sheet("Σύνοψη")
    ws.widths_from([46, 20, 16, 14, 12, 12, 12, 12])
    _identity_block(ws, identity, "Οικονομική αναφορά · %s · %s" % (period_name, period_label))

    ws.section("ΕΣΟΔΑ")
    ws.header_row(["Περιγραφή", "Ποσό (€)", "% επί εσόδων"])
    rows = [
        ("Ραντεβού που ολοκληρώθηκαν", facts["gross"], "money", "text"),
        ("Εκπτώσεις", -facts["discounts"], "money_neg", "text"),
    ]
    for label, value, vstyle, _ in rows:
        pct = (value / facts["revenue"]) if facts["revenue"] else 0.0
        ws.add([Cell(label, "text"), Cell(value, vstyle), Cell(pct, "pct")])
    ws.add([Cell("Σύνολο εσόδων (μετά τις εκπτώσεις)", "label_bold"),
            Cell(facts["revenue"], "money_total"), Cell(1.0 if facts["revenue"] else 0.0, "pct_bold")])
    ws.blank()

    ws.section("ΕΞΟΔΑ")
    ws.header_row(["Κατηγορία", "Ποσό (€)", "% επί εξόδων", "Καταχωρήσεις"])
    if facts["by_category"]:
        for cat, total in sorted(facts["by_category"].items(), key=lambda kv: -kv[1]):
            ws.add([Cell(cat, "text"), Cell(total, "money"),
                    Cell(total / facts["expense_total"] if facts["expense_total"] else 0.0, "pct"),
                    Cell(facts["count_category"][cat], "int")])
    else:
        ws.add([Cell("Δεν καταχωρήθηκαν έξοδα στην περίοδο.", "text_muted")])
    ws.add([Cell("Σύνολο εξόδων", "label_bold"),
            Cell(facts["expense_total"], "money_total"),
            Cell(1.0 if facts["expense_total"] else 0.0, "pct_bold"),
            Cell(len(facts["expenses"]), "int_total")])
    ws.blank()

    ws.section("ΑΠΟΤΕΛΕΣΜΑΤΑ")
    ws.add([Cell("Καθαρό εισόδημα (έσοδα − έξοδα)", "label_bold"),
            Cell(facts["net"], "money_total" if facts["net"] >= 0 else "money_neg")])
    ws.add([Cell("Μέση αξία ραντεβού", "text"), Cell(facts["avg_ticket"], "money")])
    ws.add([Cell("Ακυρώσεις", "text"), Cell(facts["cancelled"], "int")])
    ws.add([Cell("Απουσίες (no-show)", "text"), Cell(facts["no_shows"], "int")])
    ws.blank()
    ws.add([Cell("Τα έσοδα υπολογίζονται μόνο από ολοκληρωμένα ραντεβού, στην τελική "
                 "τους τιμή (δηλαδή αφαιρούμενη την έκπτωση). Τα ακυρωμένα και τα "
                 "απούσια δεν μετράννε.", "note")])


def _sheet_revenue(wb: Workbook, facts: dict, period_label: str) -> None:
    ws = wb.add_sheet("Έσοδα αναλυτικά")
    ws.widths_from([11, 9, 26, 22, 18, 40, 13, 12, 13])
    ws.title("Αναλυτικά έσοδα", "Ολοκληρωμένα ραντεβού · %s" % period_label, span=9)
    head = ws.header_row(["Ημερομηνία", "Ώρα", "Πελάτης", "Τηλέφωνο",
                          "Στυλίστρια", "Υπηρεσίες", "Αρχική τιμή",
                          "Έκπτωση", "Τελική τιμή"])
    for a in facts["completed"]:
        groomer = a.groomer.user.full_name if a.groomer and a.groomer.user else "—"
        # Χωρίς έκπτωση γράφουμε 0 και όχι -0.0, που θα έδειχνε «-0,00 €».
        discount = float(a.discount_amount or 0)
        ws.add([
            Cell(a.start_at.date(), "date"),
            Cell(a.start_at.strftime("%H:%M"), "time"),
            Cell(a.customer.name, "text"),
            Cell(a.customer.phone or "—", "text"),
            Cell(groomer, "text"),
            Cell(a.services_label, "text_wrap"),
            Cell(a.total_price, "money"),
            Cell(-discount if discount else 0.0, "money_neg" if discount else "money"),
            Cell(a.price_effective, "money_bold"),
        ])
    if not facts["completed"]:
        ws.add([Cell("Δεν υπάρχουν ολοκληρωμένα ραντεβού στην περίοδο.", "text_muted")])
    else:
        ws.add([Cell("Σύνολο", "label_bold"), Cell("", "text"), Cell("", "text"),
                Cell("", "text"), Cell("", "text"), Cell("", "text"),
                Cell(facts["gross"], "money_total"),
                Cell(-facts["discounts"], "money_total"),
                Cell(facts["revenue"], "money_total")])
    ws.freeze("A%d" % (head + 1))
    ws.filter("A%d:I%d" % (head, max(head + 1, ws.max_row - (1 if facts["completed"] else 0))))


def _sheet_expenses(wb: Workbook, facts: dict, period_label: str) -> None:
    ws = wb.add_sheet("Έξοδα αναλυτικά")
    ws.widths_from([12, 34, 24, 16, 34, 22])
    ws.title("Αναλυτικά έξοδα", "Καταχωρήσεις της περιόδου · %s" % period_label, span=6)
    head = ws.header_row(["Ημερομηνία", "Έξοδο", "Κατηγορία", "Ποσό (€)",
                          "Σημείωση", "Καταχώρισε"])
    for e in facts["expenses"]:
        who = e.created_by.full_name if e.created_by else "—"
        ws.add([
            Cell(e.spent_on, "date"),
            Cell(e.item, "text_wrap"),
            Cell(e.category_label, "text"),
            Cell(e.amount, "money"),
            Cell(e.note or "", "text_wrap"),
            Cell(who, "text"),
        ])
    if not facts["expenses"]:
        ws.add([Cell("Δεν καταχωρήθηκαν έξοδα στην περίοδο.", "text_muted")])
    else:
        ws.add([Cell("Σύνολο", "label_bold"), Cell("", "text"), Cell("", "text"),
                Cell(facts["expense_total"], "money_total"), Cell("", "text"), Cell("", "text")])
    ws.freeze("A%d" % (head + 1))
    ws.filter("A%d:F%d" % (head, max(head + 1, ws.max_row - (1 if facts["expenses"] else 0))))


def _sheet_by_day(wb: Workbook, start: date_cls, end: date_cls, facts: dict,
                  period_label: str) -> None:
    """Μηνιαία/ετήσια ανάλυση: πότε ακριβώς έγιναν έσοδα και έξοδα."""
    ws = wb.add_sheet("Ανά ημέρα")
    ws.widths_from([16, 18, 16, 14, 18, 16, 14, 14])
    ws.title("Έσοδα και έξοδα ανά ημέρα", "Περίοδος: %s" % period_label, span=8)
    ws.header_row(["Ημερομηνία", "Ημέρα", "Ραντεβού", "Έσοδα (€)",
                   "Έξοδα (€)", "Καθαρό (€)", "Ακυρώσεις", "No-show"])

    rev_by_day: dict[date_cls, float] = defaultdict(float)
    cnt_by_day: dict[date_cls, int] = defaultdict(int)
    can_by_day: dict[date_cls, int] = defaultdict(int)
    ns_by_day: dict[date_cls, int] = defaultdict(int)
    for a in facts["completed"]:
        rev_by_day[a.start_at.date()] += a.price_effective
        cnt_by_day[a.start_at.date()] += 1
    for a in facts["appointments"]:
        if a.status == STATUS_CANCELLED:
            can_by_day[a.start_at.date()] += 1
        elif a.status == STATUS_NO_SHOW:
            ns_by_day[a.start_at.date()] += 1
    exp_by_day: dict[date_cls, float] = defaultdict(float)
    for e in facts["expenses"]:
        exp_by_day[e.spent_on] += e.amount

    days = sorted(set(rev_by_day) | set(exp_by_day) | set(cnt_by_day))
    if not days:
        ws.add([Cell("Δεν υπάρχει κίνηση στην περίοδο.", "text_muted")])
        return
    for d in days:
        rev, exp = rev_by_day[d], exp_by_day[d]
        ws.add([
            Cell(d, "date"),
            Cell(WEEKDAYS[d.weekday()], "text"),
            Cell(cnt_by_day[d], "int"),
            Cell(rev, "money"),
            Cell(exp, "money"),
            Cell(rev - exp, "money_bold" if rev - exp >= 0 else "money_neg"),
            Cell(can_by_day[d], "int"),
            Cell(ns_by_day[d], "int"),
        ])
    ws.add([Cell("Σύνολο", "label_bold"), Cell("", "text"),
            Cell(len(facts["completed"]), "int_total"),
            Cell(facts["revenue"], "money_total"),
            Cell(facts["expense_total"], "money_total"),
            Cell(facts["net"], "money_total"),
            Cell(facts["cancelled"], "int_total"),
            Cell(facts["no_shows"], "int_total")])


def build_finance_workbook(period: str, anchor: date_cls | None = None) -> tuple[bytes, str, str]:
    """Επιστρέφει (bytes, όνομα_αρχείου, ετικέτα_περιόδου)."""
    start, end, label = period_bounds(period, anchor)
    period_name = PERIODS.get(period, PERIODS[DEFAULT_PERIOD])
    facts = finance_facts(start, end)
    identity = salon_identity()

    wb = Workbook(creator=identity["name"])
    _sheet_summary(wb, facts, label, period_name, identity)
    _sheet_revenue(wb, facts, label)
    _sheet_expenses(wb, facts, label)
    if period in ("month", "year", "week"):
        _sheet_by_day(wb, start, end, facts, label)

    stamp = end - timedelta(days=1)
    return wb.to_bytes(), ("%s_%s_%s" % (
        identity["name"].replace(" ", "_").replace("'", ""),
        period_name, stamp.strftime("%Y-%m-%d"))), label


# ============================================================== στατιστικά

def build_stats_workbook(period: str, anchor: date_cls | None = None) -> tuple[bytes, str, str]:
    """Στατιστική αναφορά χωρίς χρηματικά ποσά (και για τους βοηθούς)."""
    start, end, label = period_bounds(period, anchor)
    period_name = PERIODS.get(period, PERIODS[DEFAULT_PERIOD])
    appts = _appointments(start, end)
    completed = [a for a in appts if a.status == STATUS_COMPLETED]
    identity = salon_identity()

    booked = len(appts)
    cancelled = len([a for a in appts if a.status == STATUS_CANCELLED])
    no_shows = len([a for a in appts if a.status == STATUS_NO_SHOW])
    minutes = sum(int((a.end_at - a.start_at).total_seconds() // 60) for a in completed)
    new_customers = Customer.query.filter(
        Customer.created_at >= _dt(start), Customer.created_at < _dt(end)
    ).count()

    wb = Workbook(creator=identity["name"])

    # --- Σύνοψη
    ws = wb.add_sheet("Σύνοψη")
    ws.widths_from([46, 20, 16, 14, 12, 12, 12, 12])
    _identity_block(ws, identity, "Στατιστικά · %s · %s" % (period_name, label))
    ws.section("ΚΙΝΗΣΗ")
    ws.header_row(["Μέτρο", "Τιμή", "%"])
    defs = [
        ("Ραντεβού που κλείστηκαν", booked, "int"),
        ("Ολοκληρωμένα", completed and len(completed) or 0, "int"),
        ("Ακυρωμένα", cancelled, "int"),
        ("Απουσίες (no-show)", no_shows, "int"),
        ("Νέοι πελάτες", new_customers, "int"),
    ]
    for label_, value, style in defs:
        ws.add([Cell(label_, "text"), Cell(value, style),
                Cell(value / booked if booked else 0.0, "pct")])
    ws.blank()
    ws.section("ΠΟΙΟΤΗΤΑ")
    ws.header_row(["Μέτρο", "Τιμή", "Σχόλιο"])
    quality = [
        ("Ποσοστό ολοκλήρωσης", completed and len(completed) / booked if booked else 0.0, "pct",
         "ολοκληρωμένα / κλειστά"),
        ("Ποσοστό ακυρώσεων", cancelled / booked if booked else 0.0, "pct", "ακυρώσεις / κλειστά"),
        ("Ποσοστό απουσιών", no_shows / booked if booked else 0.0, "pct", "no-show / κλειστά"),
        ("Συνολικός χρόνος εργασίας (ώρες)", round(minutes / 60.0, 1), "dec2", "από τα ολοκληρωμένα"),
        ("Μέση διάρκεια ανά ραντεβού (λεπτά)",
         round(minutes / len(completed)) if completed else 0.0, "int", ""),
    ]
    for label_, value, style, note in quality:
        ws.add([Cell(label_, "text"), Cell(value, style), Cell(note, "text_muted")])

    # --- Ανά ημέρα εβδομάδας
    ws = wb.add_sheet("Ανά ημέρα εβδομάδας")
    ws.widths_from([16, 16, 12, 14, 14, 14, 14, 14])
    ws.title("Κίνηση ανά ημέρα εβδομάδας", "Περίοδος: %s" % label, span=8)
    ws.header_row(["Ημέρα", "Ολοκληρωμένα", "Ακυρωμένα", "No-show",
                   "% ολοκληρωμένων", "Συνολικός χρόνος (ώρες)", "Κατανομή %"])
    by_wd: dict[int, list] = defaultdict(list)
    for a in completed:
        by_wd[a.start_at.weekday()].append(a)
    can_wd: dict[int, int] = defaultdict(int)
    ns_wd: dict[int, int] = defaultdict(int)
    for a in appts:
        if a.status == STATUS_CANCELLED:
            can_wd[a.start_at.weekday()] += 1
        elif a.status == STATUS_NO_SHOW:
            ns_wd[a.start_at.weekday()] += 1
    peak = max((len(v) for v in by_wd.values()), default=0) or 1
    for wd in range(7):
        items = by_wd.get(wd, [])
        mins = sum(int((a.end_at - a.start_at).total_seconds() // 60) for a in items)
        booked_wd = len(items) + can_wd[wd] + ns_wd[wd]
        ws.add([
            Cell(WEEKDAYS[wd], "text"),
            Cell(len(items), "int"),
            Cell(can_wd[wd], "int"),
            Cell(ns_wd[wd], "int"),
            Cell(len(items) / booked_wd if booked_wd else 0.0, "pct"),
            Cell(round(mins / 60.0, 1), "dec2"),
            Cell(len(items) / peak, "pct"),
        ])

    # --- Ανά υπηρεσία
    ws = wb.add_sheet("Ανά υπηρεσία")
    ws.widths_from([34, 14, 14, 16, 14])
    ws.title("Δημοφιλής υπηρεσίες", "Περίοδος: %s" % label, span=5)
    ws.header_row(["Υπηρεσία", "Πλήθος", "% ραντεβού", "Μέση ποσότητα", "Κατανομή %"])
    service_stats = []
    for service in Service.query.filter_by(is_active=True).order_by(Service.sort_order).all():
        hits = [a for a in completed if any(s.id == service.id for s in a.services)]
        if not hits:
            continue
        qty = []
        for a in hits:
            for link in a.service_links:
                if link.service_id == service.id:
                    qty.append(link.quantity or 1)
        service_stats.append((service, len(hits), sum(qty) / len(qty) if qty else 0))
    service_stats.sort(key=lambda row: -row[1])
    peak = service_stats[0][1] if service_stats else 1
    for service, count, avg_qty in service_stats:
        ws.add([Cell(service.name, "text"), Cell(count, "int"),
                Cell(count / len(completed) if completed else 0.0, "pct"),
                Cell(round(avg_qty, 2), "dec2"),
                Cell(count / peak, "pct")])
    if not service_stats:
        ws.add([Cell("Δεν υπάρχουν ολοκληρωμένα ραντεβού στην περίοδο.", "text_muted")])

    # --- Ανά στυλίστρια
    ws = wb.add_sheet("Ανά στυλίστρια")
    ws.widths_from([28, 14, 14, 18, 16, 14])
    ws.title("Φόρτος ανά στυλίστρια", "Περίοδος: %s" % label, span=6)
    ws.header_row(["Στυλίστρια", "Ραντεβού", "%", "Χρόνος (ώρες)",
                   "Μέση διάρκεια (λεπτά)", "Κατανομή %"])
    rows = []
    for groomer in db.session.query(Groomer).join(Groomer.user).order_by(Groomer.sort_order).all():
        items = [a for a in completed if a.groomer_id == groomer.id]
        if not items:
            continue
        mins = sum(int((a.end_at - a.start_at).total_seconds() // 60) for a in items)
        rows.append((groomer.user.full_name, len(items), mins))
    peak = max((r[1] for r in rows), default=0) or 1
    for name, count, mins in sorted(rows, key=lambda r: -r[1]):
        ws.add([Cell(name, "text"), Cell(count, "int"),
                Cell(count / len(completed) if completed else 0.0, "pct"),
                Cell(round(mins / 60.0, 1), "dec2"),
                Cell(round(mins / count) if count else 0, "int"),
                Cell(count / peak, "pct")])
    if not rows:
        ws.add([Cell("Δεν υπάρχουν ολοκληρωμένα ραντεβού στην περίοδο.", "text_muted")])

    # --- Πελάτες
    ws = wb.add_sheet("Πελάτες")
    ws.widths_from([30, 14, 12, 16, 22, 18, 14, 14])
    ws.title("Πελάτες της περιόδου", "Ολοκληρωμένα ραντεβού · %s" % label, span=8)
    ws.header_row(["Πελάτης", "Επισκέψεις", "Τελευταία", "Κατοικίδια",
                   "Τηλέφωνο", "Σύνολο σε λεπτά", "Κατανομή %"])
    cust_rows = []
    for a in completed:
        cust_rows.append(a)
    per_customer: dict[int, list] = defaultdict(list)
    for a in completed:
        per_customer[a.customer_id].append(a)
    peak = max((len(v) for v in per_customer.values()), default=0) or 1
    for customer_id, items in per_customer.items():
        customer = db.session.get(Customer, customer_id)
        if customer is None:
            continue
        mins = sum(int((a.end_at - a.start_at).total_seconds() // 60) for a in items)
        pets = ", ".join((p.name or "χωρίς όνομα") for p in customer.pets) or "—"
        ws.add([Cell(customer.name, "text"), Cell(len(items), "int"),
                Cell(max(a.start_at for a in items).date(), "date"),
                Cell(pets, "text_wrap"), Cell(customer.phone or "—", "text"),
                Cell(mins, "int"), Cell(len(items) / peak, "pct")])

    # --- Είδη κατοικιδίων
    ws = wb.add_sheet("Είδη κατοικιδίων")
    ws.widths_from([22, 16, 16, 14, 14, 14, 14, 14])
    ws.title("Είδη κατοικιδίων", "Σύνολο κατοικιδίων που εξυπηρετήθηκαν: %s" % label, span=8)
    ws.header_row(["Είδος", "Ραντεβού", "%", "Μοναδικά κατοικίδια"])
    species_count: dict[str, int] = defaultdict(int)
    for a in completed:
        for pet in a.pets:
            species_count[pet.species] += 1
    total_pet_visits = sum(species_count.values())
    for key, label_ in SPECIES.items():
        if not species_count.get(key):
            continue
        unique = Pet.query.filter(Pet.species == key).count()
        ws.add([Cell(label_, "text"), Cell(species_count[key], "int"),
                Cell(species_count[key] / total_pet_visits if total_pet_visits else 0.0, "pct"),
                Cell(unique, "int")])
    if not species_count:
        ws.add([Cell("Δεν υπάρχουν ολοκληρωμένα ραντεβού στην περίοδο.", "text_muted")])

    stamp = end - timedelta(days=1)
    return wb.to_bytes(), ("%s_Στατιστικά_%s_%s" % (
        identity["name"].replace(" ", "_").replace("'", ""),
        period_name, stamp.strftime("%Y-%m-%d"))), label
