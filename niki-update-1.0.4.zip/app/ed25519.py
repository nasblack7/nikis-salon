"""Pure-Python Ed25519 signatures (RFC 8032 PureEdDSA) using only the stdlib.

This module implements the Ed25519 signature scheme exactly as specified in
RFC 8032 (PureEdDSA over edwards25519 with SHA-512).  It depends on nothing
beyond :mod:`hashlib` and :mod:`os`, so it works on any CPython 3.9+ install
without ``cryptography``, ``PyNaCl`` or any other third-party package.

Public API
----------
``generate_private_key()``              -> 32 random bytes
``public_key(private_key)``             -> 32 bytes
``sign(message, private_key)``          -> 64 bytes (``R || S``)
``verify(message, signature, public)``  -> bool, never raises
``signing_input(private_key, message)`` -> 96 bytes (``public || signature``)

Implementation notes
--------------------
*Points live in the twisted Edwards plane ``-x^2 + y^2 = 1 + d*x^2*y^2`` over
the prime field ``GF(2^255 - 19)``.  We keep them in **extended homogeneous
coordinates** ``(X : Y : Z : T)`` with ``x = X/Z``, ``y = Y/Z`` and
``T = X*Y/Z``.  The fourth coordinate is the whole point of the choice: the
unified addition formula for ``a = -1`` curves then costs 9 field
multiplications instead of the ~16 an affine implementation needs, and no
special cases are needed for doubling versus adding, because the curve has a
point of order 4.  The cost is one extra multiplication and one subtraction
per point, paid for many times over by the fact that the expensive step here is
the 252-bit double-and-add ladder, not the individual additions.*

Scalar multiplication uses fixed-width windowing (6-bit digits against a
precomputed table of 64 multiples of the base point, 4-bit digits for generic
points), which trades a small amount of memory for roughly 40% fewer point
additions than plain double-and-add.  A single signature or verification costs
on the order of two scalar multiplications, which is a few milliseconds in
CPython -- perfectly fine for per-request API signing, far too slow for
high-throughput bulk signing.

A deliberate caveat: this is *not* written to be constant-time.  Window table
lookups and the point additions themselves are indexed by secret-dependent
values, so a determined local attacker with precise timing visibility could in
principle recover signing key material.  Use a vetted, hardened library
(``cryptography``/libsodium) if your threat model includes such an attacker.
For everything else -- signing API requests, verifying webhook payloads,
detecting tampering -- this module is correct and dependency-free.
"""

from __future__ import annotations

import hashlib
import os

__all__ = [
    "generate_private_key",
    "public_key",
    "sign",
    "verify",
    "signing_input",
    "SEED_SIZE",
    "PUBLIC_KEY_SIZE",
    "SIGNATURE_SIZE",
]

# --------------------------------------------------------------------------- #
# Sizes
# --------------------------------------------------------------------------- #
SEED_SIZE = 32
PUBLIC_KEY_SIZE = 32
SIGNATURE_SIZE = 64

# --------------------------------------------------------------------------- #
# Field and group constants (RFC 8032 section 5.1)
# --------------------------------------------------------------------------- #
# p = 2^255 - 19, the prime field modulus.
P = 2 ** 255 - 19

# l, the order of the base point (and of the whole prime-order subgroup).
L = 2 ** 252 + 27742317777372353535851937790883648493

# The curve constant d = -121665/121666, and a square root of -1 mod p used when
# recovering an x coordinate from a y coordinate.
D = (-121665 * pow(121666, P - 2, P)) % P
SQRT_M1 = pow(2, (P - 1) // 4, P)

# The neutral element in extended coordinates is (0 : 1 : 1 : 0).
_IDENTITY = (0, 1, 1, 0)

_SHA512 = hashlib.sha512


# --------------------------------------------------------------------------- #
# Field / point helpers
# --------------------------------------------------------------------------- #
def _modp(value: int) -> int:
    """Reduce ``value`` into ``[0, P)``."""
    return value % P


def _recover_x(y: int, x_odd: int):
    """Recover the x coordinate of a curve point from ``y`` and the low bit of x.

    Returns ``None`` when no such curve point exists, i.e. when the
    corresponding ``x^2 = (y^2 - 1) / (d*y^2 + 1)`` is not a quadratic
    residue.  This is the standard RFC 8032 decoding routine.
    """
    if y >= P:
        # Rejects the non-canonical y encodings of values >= p.
        return None
    y2 = (y * y) % P
    u = (y2 - 1) % P
    v = (D * y2 + 1) % P

    if v == 0:
        # d*y^2 + 1 == 0 leaves no finite solution for x.
        return None

    # x = u/v, computed as u * v^3 * (u * v^7)^((p-5)/8) to stay inversion-free.
    # The exponentiation yields one of the two candidate square roots; the other
    # is obtained by multiplying by sqrt(-1).  Exactly one of the two satisfies
    # v*x^2 == u when u/v is a quadratic residue, and neither does when it is
    # not -- which is the on-curve test.
    v3 = (v * v % P) * v % P
    v7 = (v3 * v3 % P) * v % P
    x = (u * v3 % P) * pow((u * v7) % P, (P - 5) // 8, P) % P
    if (v * x * x - u) % P != 0:
        x = (x * SQRT_M1) % P
        if (v * x * x - u) % P != 0:
            # u/v is not a quadratic residue: not a curve point.
            return None

    if x == 0 and x_odd:
        # x = 0 has no sign bit, so it only encodes the even variant.
        return None
    if (x & 1) != x_odd:
        x = P - x
    return x


def _point_add(pt1, pt2):
    """Add two curve points in extended coordinates (add-2008-hwcd-3, a = -1)."""
    x1, y1, z1, t1 = pt1
    x2, y2, z2, t2 = pt2

    a = (y1 - x1) * (y2 - x2) % P
    b = (y1 + x1) * (y2 + x2) % P
    c = (2 * D * t1 % P) * t2 % P
    d = (2 * z1 % P) * z2 % P
    e = b - a
    f = d - c
    g = d + c
    h = b + a
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _point_double(pt):
    """Double a curve point in extended coordinates (dbl-2008-hwcd, a = -1)."""
    x1, y1, z1, _ = pt

    a = x1 * x1 % P
    b = y1 * y1 % P
    c = (2 * z1 % P) * z1 % P
    d = -a
    e = ((x1 + y1) * (x1 + y1) % P) - a - b
    g = d + b
    f = g - c
    h = d - b
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _point_negate(pt):
    """Return the inverse of ``pt`` (mirrors the point about the x axis)."""
    x, y, z, t = pt
    return (-x % P, y, z, -t % P)


def _point_equal(pt1, pt2) -> bool:
    """Compare two curve points for equality, in projective form."""
    x1, y1, z1, _ = pt1
    x2, y2, z2, _ = pt2
    return (x1 * z2 - x2 * z1) % P == 0 and (y1 * z2 - y2 * z1) % P == 0


def _point_compress(pt) -> bytes:
    """Encode a point as 32 bytes: little-endian y with the sign of x in bit 255."""
    x, y, z, _ = pt
    z_inv = pow(z, P - 2, P)
    x = x * z_inv % P
    y = y * z_inv % P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _point_decompress(data: bytes):
    """Decode 32 bytes into a curve point, or return ``None`` if malformed."""
    if len(data) != 32:
        return None
    y = int.from_bytes(data, "little")
    x_odd = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, x_odd)
    if x is None:
        return None
    return (x, y, 1, x * y % P)


# --------------------------------------------------------------------------- #
# Scalar multiplication
# --------------------------------------------------------------------------- #
_BASE_TABLE = None
_BASE_DIGIT_BITS = 6
_BASE_DIGIT_COUNT = 43  # 43 * 6 = 258 bits, comfortably above l's 253 bits.


def _base_point() -> tuple:
    """Return the Ed25519 base point ``B`` in extended coordinates.

    ``B`` is the unique point with y = 4/5 and the even (non-negative) x, so it
    is derived here rather than pasted in as a magic number.  Deriving it also
    means the constants and the decoder cannot silently disagree.
    """
    y = (4 * pow(5, P - 2, P)) % P
    x = _recover_x(y, 0)
    if x is None:  # pragma: no cover - impossible, 4/5 is a valid y
        raise ValueError("could not derive the Ed25519 base point")
    return (x, y, 1, x * y % P)


def _base_table() -> list:
    """Build (once, lazily) the table of ``0*B .. 63*B`` used for base scalarmults."""
    global _BASE_TABLE
    if _BASE_TABLE is None:
        base = _base_point()
        table = [_IDENTITY, base]
        for _ in range(2, 64):
            table.append(_point_add(table[-1], base))
        _BASE_TABLE = table
    return _BASE_TABLE


def _scalar_mult_base(k: int):
    """Compute ``[k]B`` with 6-bit fixed-window scalar multiplication."""
    table = _base_table()
    width = _BASE_DIGIT_BITS
    result = _IDENTITY
    for i in range(_BASE_DIGIT_COUNT - 1, -1, -1):
        if i != _BASE_DIGIT_COUNT - 1:
            for _ in range(width):
                result = _point_double(result)
        digit = (k >> (width * i)) & 0x3F
        result = _point_add(result, table[digit])
    return result


def _scalar_mult(k: int, point: tuple):
    """Compute ``[k]point`` with 4-bit fixed-window scalar multiplication.

    This generic (non-base-point) variant is what verification needs for the
    ``[k]A`` term, where ``A`` is the untrusted public key.
    """
    if k == 0:
        return _IDENTITY
    width = 4
    # table[i] = [i]point for i in 0..15.
    table = [_IDENTITY, point]
    for _ in range(2, 16):
        table.append(_point_add(table[-1], point))

    digits = (k.bit_length() + width - 1) // width
    result = _IDENTITY
    for i in range(digits - 1, -1, -1):
        if i != digits - 1:
            for _ in range(width):
                result = _point_double(result)
        digit = (k >> (width * i)) & 0xF
        result = _point_add(result, table[digit])
    return result


# --------------------------------------------------------------------------- #
# Key and signature primitives
# --------------------------------------------------------------------------- #
def _sha512_int(*chunks: bytes) -> int:
    """SHA-512 of the concatenated chunks, read as a little-endian integer."""
    digest = _SHA512()
    for chunk in chunks:
        digest.update(chunk)
    return int.from_bytes(digest.digest(), "little")


def _clamp(seed_hash: bytes) -> int:
    """Derive the signing scalar from the first 32 bytes of a SHA-512 digest.

    RFC 8032 section 5.1.5: clear the three lowest bits, clear the highest bit,
    set the second-highest bit.  The result is a multiple of the cofactor, so
    the public key lies in the prime-order subgroup.
    """
    scalar = int.from_bytes(seed_hash[:32], "little")
    scalar &= (1 << 254) - 8
    scalar |= 1 << 254
    return scalar


def generate_private_key() -> bytes:
    """Return a fresh 32-byte Ed25519 seed drawn from the OS CSPRNG.

    The seed is the whole secret: the signing scalar and the nonce prefix are
    both derived from it by SHA-512, so these bytes must be stored as carefully
    as a private key file.  They must also be the exact 32 bytes, not a
    passphrase -- there is no stretching here by design.
    """
    return os.urandom(SEED_SIZE)


def public_key(private_key: bytes) -> bytes:
    """Return the 32-byte public key for a 32-byte private key seed.

    ``public_key(sk) == sk[32:]`` for the keys generated by
    :func:`generate_private_key` is the one invariant that lets
    :func:`signing_input` be checked cheaply.

    Raises:
        ValueError: if ``private_key`` is not exactly 32 bytes.
    """
    if len(private_key) != SEED_SIZE:
        raise ValueError(
            "private key must be %d bytes, got %d" % (SEED_SIZE, len(private_key))
        )
    scalar = _clamp(_SHA512(private_key).digest())
    return _point_compress(_scalar_mult_base(scalar))


def sign(message: bytes, private_key: bytes) -> bytes:
    """Sign ``message`` and return the 64-byte ``R || S`` signature.

    Follows RFC 8032 section 5.1.6:

    1. Hash the seed with SHA-512; the low half becomes the clamped secret
       scalar, the high half is a nonce prefix.
    2. ``r = H(prefix || message) mod l`` and ``R = [r]B``.
    3. ``k = H(R || A || message) mod l`` and ``S = (r + k*a) mod l``.

    Raises:
        ValueError: if ``private_key`` is not exactly 32 bytes.
    """
    if len(private_key) != SEED_SIZE:
        raise ValueError(
            "private key must be %d bytes, got %d" % (SEED_SIZE, len(private_key))
        )
    if not isinstance(message, (bytes, bytearray, memoryview)):
        raise TypeError("message must be bytes-like, got %s" % type(message).__name__)
    message = bytes(message)

    seed_hash = _SHA512(private_key).digest()
    scalar = _clamp(seed_hash)
    prefix = seed_hash[32:]

    encoded_a = _point_compress(_scalar_mult_base(scalar))

    r = _sha512_int(prefix, message) % L
    encoded_r = _point_compress(_scalar_mult_base(r))

    k = _sha512_int(encoded_r, encoded_a, message) % L
    s = (r + k * scalar) % L

    return encoded_r + int.to_bytes(s, 32, "little")


def verify(message: bytes, signature: bytes, public_key: bytes) -> bool:
    """Return ``True`` if ``signature`` is a valid signature over ``message``.

    This is the RFC 8032 section 5.1.7 check, i.e. the cofactorless equation
    ``[S]B == R + [k]A`` where ``k = H(R || A || message) mod l``.

    The function is total: it returns ``False`` for every malformed input --
    wrong lengths, a non-canonical ``S`` (``S >= l``), a public key or ``R``
    that is not a valid curve point encoding, a truncated or over-long
    signature, or a signature that simply does not match.  It never raises,
    because it is typically fed bytes straight off the network.

    Note:
        As in RFC 8032 itself, this does *not* clear the cofactor, so a
        deliberately crafted small-order public key can pass verification. If
        you accept keys from an adversarial source and the signature is
        load-bearing, clear the cofactor on both sides of the comparison
        (multiply ``R``, ``[S]B`` and ``[k]A`` by 8) as libsodium does.
    """
    try:
        if not isinstance(message, (bytes, bytearray, memoryview)):
            return False
        message = bytes(message)
        signature = bytes(signature)
        public_key = bytes(public_key)

        if len(signature) != SIGNATURE_SIZE or len(public_key) != PUBLIC_KEY_SIZE:
            return False

        encoded_r = signature[:32]
        s = int.from_bytes(signature[32:], "little")
        if s >= L:
            # Rejects malleable signatures: S must be reduced mod l.
            return False

        point_a = _point_decompress(public_key)
        if point_a is None:
            return False
        point_r = _point_decompress(encoded_r)
        if point_r is None:
            return False

        k = _sha512_int(encoded_r, public_key, message) % L
        # [S]B == R + [k]A  <=>  [S]B - [k]A == R
        lhs = _scalar_mult_base(s)
        rhs = _point_add(point_r, _scalar_mult(k, point_a))
        return _point_equal(lhs, rhs)
    except Exception:
        # Defence in depth: a signature check must never take down a request.
        return False


def signing_input(private_key: bytes, message: bytes) -> bytes:
    """Return ``public_key(private_key) || sign(message, private_key)``.

    The 96-byte blob lets a verifier that only receives one opaque field
    reproduce the check with a single call::

        sig_blob == signing_input(server_private_key, message)
        verify(message, sig_blob[32:], sig_blob[:32])

    This is how the app proves a request came from this server without a
    round trip: the server signs, the client recomputes the same 96 bytes from
    its own copy of the shared secret and compares.
    """
    return public_key(private_key) + sign(message, private_key)
