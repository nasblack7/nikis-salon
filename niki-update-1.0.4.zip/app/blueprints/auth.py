"""Σύνδεση, αποσύνδεση, αλλαγή κωδικού — Niki's Grooming Salon Appointment Management."""

from datetime import datetime

from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_user, logout_user

from ..extensions import db
from ..helpers import MIN_PASSWORD_LENGTH, clean
from ..models import User
from ..password_reset import (
    NO_SMTP_MESSAGE,
    complete_reset,
    find_valid_token,
    request_reset,
)

bp = Blueprint("auth", __name__, url_prefix="/auth")


def _safe_next(target: str | None) -> str:
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return url_for("staff.dashboard")


def _announce_update() -> None:
    """Ειδοποιεί την ιδιοκτήτρια ότι υπάρχει ενημέρωση, μόλις μπει.

    ΔΙΑΒΑΖΕΙ ΑΡΧΕΙΟ, ΔΕΝ ΚΑΝΕΙ ΔΙΚΤΥΟ. Ο έλεγχος τρέχει ήδη σε φόντο και
    αποθηκεύει το αποτέλεσμα· εδώ το διαβάζουμε. Αν το κάναμε εδώ με
    δίκτυο, σε σαλόνι χωρίς internet η σύνδεση θα κόλλαγε μέχρι το
    timeout — και η ιδιοκτήτρια θα νόμιζε ότι χαλάει ο κωδικός της.

    Ο φόντος ανανέωση σηκώνεται μετά, ώστε η ΕΠΟΜΕΝΗ σύνδεση να λέει και
    αυτή πιο φρέσκο. Άρα η πρώτη μετά από μια νέα έκδοση μπορεί να μην το
    πει ακόμα — το ουσιαστικό είναι ότι λέει «τρέξε τον έλεγχο» όταν δεν
    ξέρει, όχι ότι λέει ψευδώς «όχι διαθέσιμη ενημέρωση».
    """
    from flask import current_app

    from .. import updates as U
    try:
        if not U.updates_configured() or U.unsupported_reason():
            return
        notice = U.update_notice()
        if notice:
            flash(
                f"Υπάρχει διαθέσιμη ενημέρωση: έκδοση {notice['version']} "
                f"(τρέχουσα {notice.get('current') or ''}). Ρυθμίσεις → "
                f"Ενημερώσεις για την εγκατάσταση.", "info")
            return
        if U.internet_state() is False:
            # Ξέρουμε ΌΤΙ δεν έχουμε internet. Το λέμε μία φορά, ήρεμα, και
            # ΔΕΝ ξεκινάμε έλεγχο. Χωρίς αυτό, η ιδιοκτήτρια βλέπει σιωπηλά
            # ότι η εφαρμογή δεν λέει ποτέ «υπάρχει ενημέρωση» και νομίζει
            # ότι το internet του σαλονιού είναι χαλασμένο μόνιμα.
            flash(U.offline_message(), "info")
            return
        U.refresh_check_async(current_app._get_current_object())
    except Exception:                                   # noqa: BLE001
        pass                      # ποτέ μην αποτύχει η σύνδεση γι' αυτό


@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(_safe_next(request.args.get("next")))

    # Πρώτη εγκατάσταση: δεν υπάρχει ακόμη λογαριασμός — δείχνουμε τη σωστή διαδρομή.
    from ..blueprints.setup import owner_exists
    if not owner_exists():
        return redirect(url_for("setup.first_run"))

    if request.method == "POST":
        identifier = clean(request.form.get("identifier"))
        password = request.form.get("password") or ""
        next_url = request.form.get("next")

        user = User.find_by_identifier(identifier)
        if user is None or not user.check_password(password):
            flash("Λανθασμένο όνομα χρήστη, email ή κωδικός πρόσβασης.", "error")
        elif not user.is_active:
            flash("Ο λογαριασμός σας έχει απενεργοποιηθεί. Επικοινωνήστε μαζί μας.", "error")
        else:
            user.last_login_at = datetime.now()
            db.session.commit()
            login_user(user)
            flash(f"Καλώς ήρθατε, {user.first_name}!", "success")
            _announce_update()
            return redirect(_safe_next(next_url))
    return render_template("auth/login.html", next=request.args.get("next", ""))


@bp.route("/logout")
def logout():
    if current_user.is_authenticated:
        logout_user()
        flash("Αποσυνδεθήκατε. Σας περιμένουμε ξανά!", "info")
    return redirect(url_for("auth.login"))


@bp.route("/change-password", methods=["GET", "POST"])
def change_password():
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login", next=url_for("auth.change_password")))

    if request.method == "POST":
        current = request.form.get("current_password") or ""
        new = request.form.get("new_password") or ""
        confirm = request.form.get("confirm_password") or ""

        if not current_user.check_password(current):
            flash("Ο τρέχων κωδικός είναι λανθασμένος.", "error")
        elif len(new) < MIN_PASSWORD_LENGTH:
            flash(
                f"Ο νέος κωδικός πρέπει να έχει τουλάχιστον {MIN_PASSWORD_LENGTH} χαρακτήρες.",
                "error",
            )
        elif new == current:
            flash("Ο νέος κωδικός πρέπει να διαφέρει από τον τρέχοντα.", "error")
        elif new != confirm:
            flash("Οι νέοι κωδικοί δεν ταιριάζουν.", "error")
        else:
            current_user.set_password(new)
            db.session.commit()
            flash("Ο κωδικός σας ενημερώθηκε.", "success")
            return redirect(url_for("staff.dashboard"))
    return render_template("auth/change_password.html")


# ------------------------------------------------------------ ξεχασμένος κωδικός

@bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    """Ζητά σύνδεσμο επαναφοράς.

    Η απάντηση είναι ίδια ανεξαρτήτως αν ο λογαριασμός υπάρχει — αλλιώς η
    σελίδα θα γινόταν εργαλείο εύρεσης λογαριασμών.
    """
    if request.method == "POST":
        identifier = clean(request.form.get("identifier"))
        _, message = request_reset(identifier)
        # Χωρίς flash και redirect: η ίδια σελίδα, ίδιο μήνυμα πάντα. Το flash
        # θα το έβλεπε και μετά το refresh, που δεν θέλουμε να συμβεί εδώ.
        # Το no_smtp λέει στο πρότυπο να μην προτείνει spam — εκεί το πρόβλημα
        # δεν είναι το spam, είναι ότι δεν στέλθηκε ποτέ.
        return render_template("auth/forgot_password.html", sent=True,
                               message=message,
                               no_smtp=(message == NO_SMTP_MESSAGE))
    return render_template("auth/forgot_password.html")


@bp.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    """Βάζει νέο κωδικό με το token από το email."""
    token = clean(request.form.get("token") or request.args.get("token"))
    user = find_valid_token(token)

    if user is None:
        return render_template("auth/reset_password.html", token=token,
                               invalid=True), 400

    if request.method == "POST":
        new = request.form.get("new_password") or ""
        confirm = request.form.get("confirm_password") or ""
        if len(new) < MIN_PASSWORD_LENGTH:
            flash(f"Ο νέος κωδικός πρέπει να έχει τουλάχιστον "
                  f"{MIN_PASSWORD_LENGTH} χαρακτήρες.", "error")
        elif new == user.password_hash:
            flash("Ο νέος κωδικός πρέπει να διαφέρει από τον παλιό.", "error")
        elif new != confirm:
            flash("Οι νέοι κωδικοί δεν ταιριάζουν.", "error")
        else:
            complete_reset(token, new)
            flash("Ο κωδικός ενημερώθηκε. Μπορείτε να συνδεθείτε.", "success")
            return redirect(url_for("auth.login"))

    return render_template("auth/reset_password.html", token=token,
                           user=user)
