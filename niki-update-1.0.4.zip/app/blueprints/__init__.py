"""Blueprints — Niki's Grooming Salon Appointment Management."""
