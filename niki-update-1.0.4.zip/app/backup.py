"""Αντιγράφα ασφαλείας της βάσης σε αρχείο SQL, και επαναφορά από αυτό.

Γιατί SQL και όχι απλή αντιγραφή του αρχείου .db: ένα αντίγραφο είναι
άχρηστο αν χαλάσει η βάση ή αν χρειαστεί να φέρεις δεδομένα σε άλλο server.
Το SQL είναι αναγνώσιμο, ελέγχεται με το μάτι, και ξαναφορτώνεται σε οποιαδήποτε
εγκατάσταση.

Δεν χρειάζεται καμία εξωτερική βιβλιοθήκη: το ίδιο το sqlite3 έχει iterdump().

Ασφάλεια: τα αρχεία μπαίνουν στο instance/backups/, που έχει ήδη δικαίωμα
εγγραφής η ταυτότητα του application pool. Ποτέ δεν δίνεται διαδρομή από το
browser — μόνο όνομα αρχείου, και ελέγχεται ότι το αρχείο βρίσκεται μέσα στον
φάκελο των αντιγράφων (καμία διαδρομή προς τα πάνω, καμία απόλυτη).
"""

from __future__ import annotations

import os
import re
import shutil
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path

#: Ένα αρχείο που δεν έχει το αναμενόμενο όνομα δεν το αγγίζουμε καθόλου.
BACKUP_RE = re.compile(r"^salon-\d{8}-\d{6}(-[a-z0-9-]{1,24})?\.sql$")

MAX_BYTES = 512 * 1024 * 1024      # 512 MB ανώτατο όριο αντιγράφου


class BackupError(RuntimeError):
    """Αποτυχία δημιουργίας ή επαναφοράς αντιγράφου."""


def instance_dir() -> Path:
    """Ο φάκελος instance/ — πάντα αυτός της ρίζας της εγκατάστασης."""
    try:
        from flask import current_app

        return Path(current_app.config["INSTANCE_DIR"])
    except (ImportError, RuntimeError):
        from config import INSTANCE_DIR

        return Path(INSTANCE_DIR)


def backups_dir() -> Path:
    return instance_dir() / "backups"


def database_path() -> Path:
    """Η διαδρομή του αρχείου SQLite."""
    try:
        from flask import current_app

        uri = current_app.config["SQLALCHEMY_DATABASE_URI"]
    except (ImportError, RuntimeError):
        from config import Config

        uri = Config.SQLALCHEMY_DATABASE_URI
    if not uri.startswith("sqlite"):
        raise BackupError("Η επαναφορά από SQL υποστηρίζεται μόνο σε SQLite.")
    return Path(uri.replace("sqlite:///", ""))


def safe_backup_path(name: str) -> Path:
    """Διαδρομή ενός αρχείου αντιγράφου, με προστασία από path traversal."""
    name = (name or "").strip()
    if not name or "/" in name or "\\" in name or ".." in name:
        raise BackupError("Μη έγκυρο όνομα αρχείου.")
    if not BACKUP_RE.match(name):
        raise BackupError("Το αρχείο δεν είναι αντίγραφο της εφαρμογής.")
    path = (backups_dir() / name).resolve()
    folder = backups_dir().resolve()
    if path.parent != folder:
        raise BackupError("Το αρχείο δεν βρίσκεται στον φάκελο των αντιγράφων.")
    if not path.is_file():
        raise BackupError("Το αρχείο δεν βρέθηκε.")
    return path


def list_backups() -> list[dict]:
    """Τα αντίγραφα, νεότερα πρώτα."""
    folder = backups_dir()
    if not folder.is_dir():
        return []
    out = []
    for path in folder.iterdir():
        if not path.is_file() or not BACKUP_RE.match(path.name):
            continue
        stat = path.stat()
        out.append({
            "name": path.name,
            "size": stat.st_size,
            "modified": datetime.fromtimestamp(stat.st_mtime).strftime(
                "%Y-%m-%d %H:%M"),
            "human_size": human_size(stat.st_size),
        })
    out.sort(key=lambda item: item["name"], reverse=True)
    return out


def human_size(size: int) -> str:
    if size < 1024:
        return "%d B" % size
    if size < 1024 * 1024:
        return "%.1f KB" % (size / 1024)
    return "%.1f MB" % (size / (1024 * 1024))


def _slug(text: str) -> str:
    """Καθαρό όνομα από σημείωση του χρήστη (προαιρετικό)."""
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "-", (text or "").strip().lower()).strip("-")
    return cleaned[:24]


# ---------------------------------------------------------------- δημιουργία

def create_backup(note: str = "") -> dict:
    """Γράφει τη βάση σε αρχείο SQL. Επιστρέφει πληροφορίες του αρχείου."""
    source = database_path()
    if not source.is_file():
        raise BackupError("Δεν βρέθηκε η βάση δεδομένων.")

    backups_dir().mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    name = "salon-%s%s.sql" % (stamp, ("-" + _slug(note)) if _slug(note) else "")
    target = backups_dir() / name

    # Γράφουμε πρώτα σε προσωρινό αρχείο και μετά το μεταφέρουμε, ώστε αν
    # διακοπεί, να μην μείνει μισό αρχείο να μπερδεύει την ιδιοκτήτρια.
    tmp = target.with_suffix(".sql.part")
    try:
        conn = sqlite3.connect(str(source))
        try:
            # iterdump() παράγει όλο το σχήμα και τα δεδομένα ως SQL.
            count = 0
            with tmp.open("w", encoding="utf-8", newline="\n") as out:
                out.write("-- Αντίγραφο της βάσης της εφαρμογής\n")
                out.write("-- Δημιουργήθηκε: %s\n" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                if note.strip():
                    out.write("-- Σημείωση: %s\n" % note.strip().replace("\n", " "))
                # Το iterdump() βάζει δικό του BEGIN TRANSACTION/COMMIT γύρω
                # από όλο το σχήμα και τα δεδομένα. Δεν προσθέτουμε δικό μας
                # BEGIN — δύο BEGIN στο ίδιο script είναι σφάλμα στο SQLite.
                out.write("PRAGMA foreign_keys=OFF;\n")
                for line in conn.iterdump():
                    if line.startswith(("CREATE TABLE", "INSERT INTO")):
                        count += 1
                    out.write(line + "\n")
        finally:
            conn.close()
        os.replace(tmp, target)
    except Exception as exc:
        tmp.unlink(missing_ok=True)
        raise BackupError(f"Αποτυχία δημιουργίας αντιγράφου: {exc}")

    size = target.stat().st_size
    if size == 0:
        target.unlink(missing_ok=True)
        raise BackupError("Το αντίγραφο βγήκε κενό — η βάση φαίνεται να μην έχει πίνακες.")
    if size > MAX_BYTES:
        target.unlink(missing_ok=True)
        raise BackupError("Το αντίγραφο ξεπερνά τα 512 MB.")

    return {"name": target.name, "size": size, "human_size": human_size(size),
            "statements": count}


# ---------------------------------------------------------------- επαναφορά

def peek_backup(name: str) -> dict:
    """Πληροφορίες για ένα αρχείο, χωρίς να το εφαρμόσει — για επιβεβαίωση."""
    path = safe_backup_path(name)
    text = path.read_text(encoding="utf-8", errors="replace")
    tables = len(re.findall(r"^CREATE TABLE", text, re.M))
    inserts = len(re.findall(r"^INSERT INTO", text, re.M))
    if tables == 0:
        raise BackupError("Το αρχείο δεν περιέχει κανένα CREATE TABLE· "
                          "μάλλον δεν είναι έγκυρο αντίγραφο.")
    if "COMMIT" not in text:
        raise BackupError("Το αρχείο φαίνεται ατελές (λείπει το COMMIT).")
    return {"name": path.name, "tables": tables, "rows": inserts,
            "human_size": human_size(path.stat().st_size)}


def restore_backup(name: str) -> dict:
    """Επαναφέρει τη βάση από αρχείο SQL.

    Η επαναφορά σημαίνει «η βάση γίνεται ό,τι ήταν το αντίγραφο» — όχι
    συγχώνευση. Γι' αυτό το αρχείο της βάσης αντικαθίσταται εξ ολοκλήρου, ώστε
    να μην μένουν πίνακες ή γραμμές από την παλιά έκδοση.

    Σειρά εργασίας, επίτηδες:
      1. Δοκιμαστική εφαρμογή σε πεταμένη βάση. Αν αποτύχει εκεί, η ζωντανή
         βάση δεν αγγίχτηκε καθόλου.
      2. Αντίγραφο ασφαλείας της τωρινής βάσης.
      3. Αντικατάσταση του αρχείου και εφαρμογή του script.
      4. Έλεγχος ακεραιότητας· αν αποτύχει, επιστρέφουμε το αντίγραφο ασφαλείας.
    """
    source = safe_backup_path(name)
    peek_backup(name)                    # απορρίπτει αν το αρχείο δεν μπαίνει
    script = source.read_text(encoding="utf-8", errors="replace")
    target = database_path()
    if not target.is_file():
        raise BackupError("Δεν βρέθηκε η βάση δεδομένων.")

    # 1) Δοκιμή σε πεταμένη βάση — η ζωντανή παραμένει ανέπαφη αν αποτύχει.
    probe = Path(tempfile.mkdtemp(prefix="restore-probe-")) / "probe.db"
    try:
        conn = sqlite3.connect(str(probe))
        try:
            conn.execute("PRAGMA foreign_keys=OFF")
            conn.executescript(script)
            conn.commit()
            probe_result = conn.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            conn.close()
        if probe_result != "ok":
            raise BackupError("Το αντίγραφο δεν περνά τον έλεγχο ακεραιότητας· "
                              "η βάση σας δεν άλλαξε.")
    except sqlite3.Error as exc:
        raise BackupError(
            "Το αντίγραφο δεν εφαρμόζεται (σφάλμα SQL): %s. Η βάση σας "
            "δεν άλλαξε." % exc)
    finally:
        shutil.rmtree(probe.parent, ignore_errors=True)

    # 2) Αντίγραφο ασφαλείας της υπάρχουσας βάσης.
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    safety = target.with_name("%s.pre-restore-%s%s" % (
        target.stem, stamp, "".join(target.suffixes)))
    try:
        shutil.copy2(target, safety)
    except Exception as exc:
        raise BackupError(f"Αποτυχία αντιγράφου ασφαλείας: {exc}")

    # 3) Αντικατάσταση. Κλείνουμε πρώτα τις συνδέσεις της εφαρμογής, αλλιώς
    #    κρατάει ανοιχτό handle στο παλιό αρχείο.
    _dispose_engine()
    try:
        for suffix in ("-wal", "-shm", "-journal"):
            side = target.with_name(target.name + suffix)
            if side.exists():
                side.unlink(missing_ok=True)
        target.unlink()
        conn = sqlite3.connect(str(target))
        try:
            conn.execute("PRAGMA foreign_keys=OFF")
            conn.executescript(script)
            conn.commit()
            result = conn.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            conn.close()
    except Exception as exc:
        _restore_from(safety, target)
        _dispose_engine()
        raise BackupError(
            f"Η επαναφορά απέτυχε και επαναφέρθηκε η προηγούμενη βάση: {exc}")

    if result != "ok":
        _restore_from(safety, target)
        _dispose_engine()
        raise BackupError("Η επαναφορά ολοκληρώθηκε αλλά η βάση δεν περνά τον "
                          "έλεγχο ακεραιότητας. Επαναφέρθηκε η προηγούμενη.")

    return {"name": source.name, "safety_copy": safety.name,
            "integrity": result}


def _dispose_engine() -> None:
    """Κλείνει τις συνδέσεις SQLAlchemy, ώστε να μην κρατούν το παλιό αρχείο."""
    try:
        from app.extensions import db

        db.engine.dispose()
    except Exception:
        pass


def _restore_from(backup_path: Path, target: Path) -> bool:
    """Επαναφέρει δυνατά το αρχείο βάσης από δυνατό αντίγραφο."""
    try:
        for suffix in ("-wal", "-shm", "-journal"):
            side = target.with_name(target.name + suffix)
            if side.exists():
                side.unlink(missing_ok=True)
        shutil.copy2(backup_path, target)
        return True
    except Exception:
        return False


def cleanup(keep: int = 30) -> int:
    """Κρατά τα πιο πρόσφατα `keep` αντίγραφα, σβήνει τα παλιότερα."""
    items = list_backups()
    removed = 0
    for item in items[max(0, keep):]:
        try:
            (backups_dir() / item["name"]).unlink()
            removed += 1
        except OSError:
            pass
    return removed
