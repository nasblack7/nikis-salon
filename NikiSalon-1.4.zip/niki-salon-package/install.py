#!/usr/bin/env python3
"""ΜΕ ΕΝΑ ΚΛΙΚ: εγκατάσταση, ρύθμιση και εκκίνηση της εφαρμογής στα Windows.

Το μόνο αρχείο που χρειάζεται ο χρήστης να πατήσει δύο φορές.

ΤΙ ΚΑΝΕΙ, ΜΕ ΤΗ ΣΕΙΡΑ
====================
  1. Σηκώνεται σε Administrator μόνος του (χρειάζεται για την εργασία SYSTEM)
  2. Εξασφαλίζει μια κατάλληλη Python. Αν το μηχάνημα δεν έχει, κατεβάζει
     την καθαρή έκδοση που έχουμε σταθερώσει στο runtime_python.txt, την
     ελέγχει με το επίσημο SHA-256 της και τη βάζει μέσα στον φάκελο της
     εφαρμογής. Ο πελάτης δεν εγκαθιστά τίποτα.
  3. Δημιουργεί το .venv από ΑΥΤΗ την Python και εγκαθιστά τις βιβλιοθήκες
  4. Δημιουργεί τους πίνακες της βάσης
  5. Γράφει .env με τυχαίο SECRET_KEY
  6. Δημιουργεί την εργασία Windows που ξεκινά την εφαρμογή σε κάθε
     εκκίνηση και ξαναξεκινά την αν πέσει
  7. ΕΛΕΓΧΕΙ ΟΤΙ Η ΕΦΑΡΜΟΓΗ ΑΠΑΝΤΑ — αν όχι, σταματάει και λέει ποιο είναι
     το πρόβλημα, αντί να «τελειώνει επιτυχώς» με σπασμένη εφαρμογή
  8. Εκτυπώνει τη διεύθυνση για τη δημιουργία του λογαριασμού ιδιοκτήτριας

Δεν απαιτεί IIS, HttpPlatformHandler ή οποιαδήποτε εγκατάσταση — μόνο τα
Windows. Και ούτε Python του συστήματος: αν δεν υπάρχει, φέρνουμε δική μας.
"""
from __future__ import annotations

import ast
import argparse
import os
import secrets
import subprocess
import sys
import time
from pathlib import Path

IS_WINDOWS = os.name == "nt"
APP_DIR = Path(__file__).resolve().parent
VENV = APP_DIR / ".venv"
VENV_PY = VENV / "Scripts" / "python.exe"
GREEN, YELLOW, RED, DIM, BOLD, RESET = (
    "\033[32m", "\033[33m", "\033[31m", "\033[2m", "\033[1m", "\033[0m")

_tasks: list[str] = []


def _c(text: str, colour: str) -> str:
    return f"{colour}{text}{RESET}" if sys.stdout.isatty() else text


def step(text: str) -> None:
    print()
    print(_c(f"── {text} " + "─" * max(2, 58 - len(text)), DIM))


def ok(text: str) -> None:
    print(f"  {_c('[OK]', GREEN)}  {text}")


def warn(text: str) -> None:
    print(f"  {_c('[!]', YELLOW)}   {text}")


def fail(text: str) -> None:
    print(f"  {_c('[X]', RED)}   {text}")


def info(text: str) -> None:
    print(f"       {text}")


def head(text: str) -> None:
    print()
    print(_c("=" * 64, BOLD))
    print(_c(f"  {text}", BOLD))
    print(_c("=" * 64, BOLD))


# --------------------------------------------------------------- δικαιώματα
def is_admin() -> bool:
    if not IS_WINDOWS:
        return True
    try:
        out = subprocess.run(["net", "session"], capture_output=True,
                             timeout=20)
        return out.returncode == 0
    except Exception:                                  # noqa: BLE001
        return False


def elevate() -> bool:
    """Ξαναξεκινά τον εαυτό του ως Administrator. True αν επιτύχει."""
    if not IS_WINDOWS or is_admin():
        return False
    script = (
        "Start-Process -FilePath '%s' -ArgumentList '%s' -Verb RunAs"
        % (sys.executable, " ".join('"%s"' % a for a in [str(Path(__file__).resolve())] + sys.argv[1:]))
    )
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", script], check=True)
    except Exception:                                  # noqa: BLE001
        fail("Δεν ήταν δυνατή η αύξηση δικαιωμάτων.")
        info("Κάνε δεξί κλικ → «Εκτέλεση ως διαχειριστής» στο αρχείο.")
        return False
    return True


# ------------------------------------------------------------------ Python
# Η ΕΦΑΡΜΟΓΗ ΦΕΡΕΙ ΤΗ ΔΙΚΗ ΤΗΣ PYTHON. Ο ΠΕΛΑΤΗΣ ΔΕΝ ΕΓΚΑΘΙΣΤΑ ΤΙΠΟΤΑ.
# =======================================================================
#
# Ο ΛΟΓΟΣ, ΓΙΑΤΙ ΜΕΤΑ ΑΠΟ ΑΥΤΟ ΤΟ ΑΚΟΥΣΤΕ ΞΑΝΑ:
#
#   · Σε μηχάνημα χωρίς Python, το INSTALL.bat δεν είχε τι να τρέξει και
#     έλεγε «κατέβασε την Python». Δηλαδή η εγκατάσταση ΑΠΑΙΤΟΥΣΕ το πιο
#     παράδοξο πράγμα: να δουλεύει χωρίς τη γλώσσα στην οποία γράφτηκε.
#   · Σε μηχάνημα με Python 3.9 δεν εκτελούνταν καν.
#   · Σε μηχάνημα με Python 3.14 δεν ξέρουμε τι κάνει. Δοκιμάσαμε 3.13.
#
# Η ΛΥΣΗ: κατεβάζουμε ΜΙΑ καθαρή, συγκεκριμένη έκδοση από το python.org,
# την ΕΛΕΓΧΟΥΜΕ ΜΕ ΤΟ ΕΠΙΣΗΜΟ SHA-256 ΠΡΙΝ ΤΗΝ ΕΚΤΕΛΕΣΟΥΜΕ, και τη βάζουμε
# ΜΕΣΑ ΣΤΟΝ ΦΑΚΕΛΟ ΤΗΣ ΕΦΑΡΜΟΓΗΣ (runtime/python). Το .venv χτίζεται από
# εκεί. Το runtime_python.txt είναι η ΜΙΑ πηγή αλήθειας — τη διαβάζουν και
# το INSTALL.bat και εδώ, οπότε δεν μπορούν να διαφωνήσουν για το hash.
#
# ΓΙΑΤΙ ΔΕΝ ΑΦΑΙΡΟΥΜΕ ΤΗΝ PYTHON ΤΟΥ ΠΕΛΑΤΗ
# ==========================================
# Θα μπορούσαμε. Δεν πρέπει. Το άνοιγμα μιας Python μπορεί να σπάσει λογιστικό
# που δεν μας ανήκει — λογιστικά, φορολογικά εργαλεία, σενάρια που έγραψαν
# άλλοι — και κανείς δεν μας είπε ότι υπάρχουν. Το κόστος μιας ιδιωτικής
# αντιγραφής είναι περίπου 30 MB. Το κόστος ενός σπασμένου λογισμικού στο
# μηχάνημα μιας ιδιοκτήτριας είναι αυτό που μετράει. Η ιδέα του «αφαίρεσε την
# υπάρχουσα» δεν εφαντζόταν ποτέ στον κώδικα και δεν θα μπει.
PY_MIN = (3, 10)
#: ΤΟ ΠΑΝΩ ΑΠΟ ΟΡΙΟ. Όχι «η νεότερη διαθέσιμη» — μια συγκεκριμένη, δοκιμασμένη.
#: Οι εφαρμογές σε μικρές επιχειρήσεις τρέχουν χρόνια. Μια απρόστατη «τελευταία
#: έκδοση» τρέχει μία και μετά σπάει, και κανείς δεν ξέρει γιατί.
PY_MAX = (3, 13)

#: Η έκδοση που εγκαθιστούμε. Η PY_MAX είναι το ανώτατο όριο που δεχόμαστε από
#: κάποιον άλλον· αυτή είναι η δική μας, και θέλουμε την υψιστη επιτρεπτή, ώστε
#: το .venv να μοιάζει με αυτό που δοκιμάστηκε στο εργαστήριο.
PY_PIN = PY_MAX

#: Ο ΦΑΚΕΛΟΣ ΤΗΣ ΙΔΙΩΤΙΚΗΣ PYTHON. Μέσα στον φάκελο της εφαρμογής, ώστε να
#: φεύγει μαζί της αν διαγραφεί η εφαρμογή, και να μην πειράζει τίποτα άλλο.
RUNTIME_DIR = APP_DIR / "runtime" / "python"
RUNTIME_PY = RUNTIME_DIR / "python.exe"
MANIFEST = APP_DIR / "runtime_python.txt"

#: ΟΙ ΧΑΡΑΚΤΗΡΕΣ ΠΟΥ ΣΚΑΝΟΥΝ ΤΟ cmd.exe ΜΕΣΑ ΣΕ ΜΙΑ ΓΡΑΜΜΗ ΣΧΟΛΙΟΥ ΤΟΥ
#: runtime_python.txt. Το cmd μοιράζει κάθε γραμμή στο «=» ΠΡΙΝ αποφασίσει αν
#: είναι σχόλιο, οπότε ένα εισαγωγικό ή μια παρένθεση μέσα σε σχόλιο σπάει την
#: εγκατάσταση με σφάλμα σύνταξης που δεν έχει σχέση με το θέμα.
_MANIFEST_BREAKERS = '="(),;'


def _arch() -> str:
    """AMD64 ή ARM64 — και X86 για τις 32-bit εκδόσεις των Windows 10."""
    machine = os.environ.get("PROCESSOR_ARCHITECTURE", "").upper()
    wow = os.environ.get("PROCESSOR_ARCHITEW6432", "").upper()
    if "ARM64" in (machine, wow):
        return "ARM64"
    if "AMD64" in (machine, wow):
        return "AMD64"
    return "X86"


def _read_manifest() -> dict:
    """Διαβάζει και ΕΛΕΓΧΕΙ το runtime_python.txt.

    Ο έλεγχος είναι επίμονος για έναν λόγο: το αρχείο το γράφει ένας άνθρωπος,
    τονίζει τις σημειώσεις, και ένα μόνο «»» μέσα σε μια γραμμή σχολίου κάνει το
    INSTALL.bat να σταματήσει με σφάλμα σύνταξης που δεν έχει σχέση με το θέμα.
    Καλύτερα να το πούμε εμείς, με το νούμερο της γραμμής.
    """
    if not MANIFEST.exists():
        raise SystemExit(
            "Λείπει το runtime_python.txt από τον φάκελο της εφαρμογής. "
            "Χωρίς αυτό δεν ξέρουμε ποια Python να εγκαταστήσουμε και με ποιο "
            "επίσημο hash να την εμπιστευτούμε — και δεν θα το μαντεύσουμε.")
    raw = MANIFEST.read_bytes()
    try:
        text = raw.decode("ascii")
    except UnicodeDecodeError:
        raise SystemExit(
            "Το runtime_python.txt περιέχει μη-ASCII χαρακτήρες. Το διαβάζει "
            "και το cmd.exe, οπότε πρέπει να είναι καθαρό ASCII.")

    values, offender = {}, ""
    for lineno, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        if line.startswith("#"):
            if any(ch in line for ch in _MANIFEST_BREAKERS):
                offender = "γραμμή %d: %s" % (lineno, line[:60])
            continue
        key, sep, val = line.partition("=")
        if not sep or not key.strip():
            offender = "γραμμή %d: %s" % (lineno, line[:60])
            break
        values[key.strip()] = val.strip()
    if offender:
        raise SystemExit(
            "Το runtime_python.txt είναι μη έγκυρο (%s). Το αρχείο το διαβάζει "
            "και το cmd.exe, γι' αυτό οι γραμμές σχολίων δεν πρέπει να έχουν "
            "τα χαρακτήρες: = \" ( ) , ;" % offender)

    arch = _arch()
    for key in ("VERSION", "URL_" + arch, "SHA_" + arch):
        if not values.get(key):
            raise SystemExit(
                "Το runtime_python.txt δεν έχει την τιμή %s. Το πακέτο δεν "
                "είναι ολόκληρο — κατέβασέ το ξανά." % key)
    sha = values["SHA_" + arch]
    if len(sha) != 64 or any(c not in "0123456789abcdefABCDEF" for c in sha):
        raise SystemExit(
            "Το SHA-256 στο runtime_python.txt δεν μοιάζει με SHA-256 (%d "
            "χαρακτήρες). Δεν θα κατεβάσω και δεν θα εκτελέσω τίποτα." % len(sha))
    return values


def _runs(exe, lowest=None, highest=None) -> bool:
    """Εκτελείται ΑΥΤΟΣ Ο ΔΙΚΟΣ Ο EXE; Και στην έκδοση που θέλουμε;

    Το ύπαρξη δεν αποτελεί απόδειξη. Στο System32 των Windows 10/11 υπάρχει
    πάντα python.exe και είναι το άδειο alias του Microsoft Store: το
    ανοίγει κάποιον στο Store αντί να τρέξει Python. Ένα έλεγχο «υπάρχει;»
    θα το έπαιρνε για εντάκτο και η εγκατάσταση θα σταματούσε αλλού, με
    μήνυμα που δεν έχει καμία σχέση με την αιτία.
    """
    low = PY_MIN if lowest is None else lowest
    high = PY_MAX if highest is None else highest
    try:
        result = subprocess.run(
            [str(exe), "-c",
             "import sys; print(sys.version_info[0], sys.version_info[1])"],
            capture_output=True, text=True, timeout=120)
    except Exception:                                  # noqa: BLE001
        return False
    if result.returncode != 0:
        return False
    parts = result.stdout.split()
    if len(parts) < 2 or not parts[0].isdigit() or not parts[1].isdigit():
        return False
    version = (int(parts[0]), int(parts[1]))
    return low <= version <= high


def _sha256(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(262144), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _download(url: str, target: Path) -> bool:
    """Κατεβάζει με πρόοδο. Χωρίς πρόοδο τα 30 MB μοιάζουν με κόλλημα."""
    import urllib.request

    try:
        with urllib.request.urlopen(url, timeout=90) as response:
            total = int(response.headers.get("Content-Length") or 0)
            done = 0
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("wb") as out:
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    out.write(chunk)
                    done += len(chunk)
                    if total:
                        pct = min(100, done * 100 // total)
                        sys.stdout.write("       \r  %3d%%  (%d από %d MB)   "
                                         % (pct, done // 1048576,
                                            total // 1048576))
                        sys.stdout.flush()
            if total:
                sys.stdout.write("       \r  100%%  (%d MB)               \n"
                                 % (total // 1048576))
                sys.stdout.flush()
            return True
    except Exception as exc:                          # noqa: BLE001
        sys.stdout.write("\n")
        info("Αποτυχία λήψης: %s" % exc)
        return False


def provision_python() -> str:
    """Κατεβάζει, ΕΛΕΓΧΕΙ και εγκαθιστά τη δική μας Python. Επιστρέφει το δρόμο.

    Ο έλεγχος του SHA-256 δεν είναι θεωρητική επιμέλεια. Ένα βήμα «κατέβασε
    και τρέξε» χωρίς έλεγχο ακεραιότητας είναι ακριβώς ο τρόπος με τον οποίο
    ένα μηχάνημα τρέχει τον κώδικα κάποιου άλλου — και εδώ το βήμα τρέχει με
    δικαιώματα διαχειριστή. Αν το hash δεν ταιριάζει, σταματάμε και διαγράφουμε
    το αρχείο. Δεν εκτυπώνουμε προειδοποίηση και συνεχίζουμε.
    """
    step("Εγκατάσταση ιδιωτικής Python %d.%d (%s)" % (PY_PIN[0], PY_PIN[1],
                                                    _arch()))
    values = _read_manifest()
    version, url = values["VERSION"], values["URL_" + _arch()]
    wanted = values["SHA_" + _arch()]
    info("Κατεβάζω την Python %s από το python.org (~30 MB)..." % version)

    target = APP_DIR / "runtime" / ("python-%s-installer.exe" % version)
    if not _download(url, target):
        fail("Η λήψη απέτυχε.")
        info("Ελέγξτε τη σύνδεση στο internet, ή αν κάποιο proxy ή firewall")
        info("κόβει το www.python.org. Μπορείτε να κατεβάσετε χειροκίνητα το")
        info("παρακάτω και να το αποθηκεύσετε στη θέση που λέει η εγκατάσταση,")
        info("και μετά να ξανατρέξετε το INSTALL.bat:")
        info("    %s" % url)
        info("    %s" % target)
        return ""

    info("Έλεγχος ακεραιότητας (SHA-256)...")
    if _sha256(target).lower() != wanted.lower():
        fail("Το SHA-256 ΔΕΝ ΤΑΙΡΙΖΕΙ με το επίσημο του python.org.")
        info("Αυτό σημαίνει ότι το αρχείο που κατέβηκε είναι είτε κατεστραμμένο")
        info("στη μεταφορά είτε κάτι άλλο. Δεν εκτελείται, και διαγράφεται.")
        info("ΜΗΝ ΤΟ ΤΡΕΞΕΙΣ ΧΕΙΡΟΚΙΝΑ: ένα λάθος αρχείο που εκτελείται με")
        info("δικαιώματα διαχειριστή είναι το χειρότερο που μπορεί να συμβεί σε")
        info("αυτό το μηχάνημα. Πείμονε στον προγραμματιστή.")
        try:
            target.unlink()
        except OSError:
            pass
        return ""
    ok("Το SHA-256 ταιριάζει με το επίσημο του python.org.")

    info("Εγκατάσταση στο runtime\\python (λίγα λεπτά, χωρίς παράθυρο)...")
    info("Δεν πειράζουμε καμία Python του συστήματος και δεν αλλάζουμε το PATH.")
    try:
        result = subprocess.run(
            [str(target), "/quiet", "InstallAllUsers=0",
             "TargetDir=%s" % RUNTIME_DIR, "PrependPath=0",
             "Include_launcher=0", "Include_test=0", "Include_doc=0",
             "Include_tcltk=0", "Include_tools=0", "Include_debug=0",
             "Include_symbols=0", "AssociateFiles=0", "Shortcuts=0"],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=2400)
    except Exception as exc:                          # noqa: BLE001
        fail("Η εγκατάσταση της Python απέτυχε: %s" % exc)
        return ""
    # 0 = τέλος.  3010 = τέλος, η Windows θέλει επανεκκίνηση κάποτε. Όλα ωραία.
    if result.returncode > 3010 or not _runs(RUNTIME_PY):
        fail("Η εγκατάσταση της Python απέτυχε (κωδικός %d)." % result.returncode)
        info("Συνηθισμένοι λόγοι, κατά σειρά πιθανότητας:")
        info("  1. Δεν έχει internet.")
        info("  2. Ένα antivirus ή προστασία αρχείων σταμάτησε τον installer.")
        info("  3. Δεν έχει αρκετό χώρο στον δίσκο.")
        info("")
        info("Χειροκίνητα, χωρίς κανένα αυτόματο βήμα — τρέξτε το παρακάτω,")
        info("αφήστε τα προεπιλεγμένα, και ξανατρέξετε το INSTALL.bat:")
        info("    %s" % target)
        return ""
    try:
        target.unlink()
    except OSError:
        pass
    ok("Η Python %d.%d εγκαταστάθηκε ιδιωτικά στο runtime\\python."
       % (PY_PIN[0], PY_PIN[1]))
    return str(RUNTIME_PY)


def ensure_base_python() -> str:
    """Αποφασίζει ποια Python θα χτίσει το .venv. Επιστρέφει το δρόμο ή "".

    Η σειρά προτίμησης είναι σκόπιμα αυτή:

      1. Η ΙΔΙΩΤΙΚΗ μας, αν υπάρχει ήδη — μια επανεγκατάσταση δεν κατεβάζει
         ξανά τα 30 MB.
      2. Μια Python του συστήματος που τρέχει και είναι 3.10–3.13 — δεν
         χρειάζεται να κατεβάσουμε τίποτα, αφού είναι μέσα στα όρια που
         δεχόμαστε.
      3. Διαφορετικά, κατεβάζουμε και εγκαθιστούμε τη δική μας.
    """
    step("Python %d.%d – %d.%d" % (PY_MIN[0], PY_MIN[1], PY_MAX[0], PY_MAX[1]))

    if _runs(RUNTIME_PY):
        ok("Η ιδιωτική Python της εφαρμογής (runtime\\python) είναι έτοιμη.")
        return str(RUNTIME_PY)

    if _runs(sys.executable):
        current = sys.version_info[:2]
        ok("Θα χρησιμοποιήσω την Python %d.%d που βρέθηκε στο μηχάνημα."
           % (current[0], current[1]))
        info("Είναι μέσα στα όρια που δεχόμαστε, οπότε δεν χρειάζεται να")
        info("κατεβάσουμε τίποτα. Δεν αγγίζουμε την εγκατάστασή της.")
        return str(Path(sys.executable).resolve())

    # Εδώ ή δεν υπάρχει Python, ή είναι πολύ παλιά, ή πολύ νέα, ή δεν τρέχει.
    current = sys.version_info[:2]
    warn("Η Python σε αυτό το μηχάνημα δεν μπορεί να χρησιμοποιηθεί.")
    if current >= PY_MAX:
        info("Βρέθηκε Python %d.%d, πιο νέα από τη %d.%d που έχουμε δοκιμάσει."
             % (current[0], current[1], PY_MAX[0], PY_MAX[1]))
    elif current < PY_MIN:
        info("Βρέθηκε Python %d.%d, παλιότερη από την %d.%d που χρειάζεται."
             % (current[0], current[1], PY_MIN[0], PY_MIN[1]))
    else:
        info("Βρέθηκε Python %d.%d, αλλά δεν τρέχει σωστά εδώ." % current)
    print()
    info("Θα εγκαταστήσω ΜΙΑ ΔΙΚΗ ΜΑΣ, μέσα στον φάκελο της εφαρμογής.")
    info("Δεν θα αφαιρέσω την υπάρχουσα: μπορεί να τρέχει λογιστικά,")
    info("φορολογικά εργαλεία ή σενάρια που έγραψαν άλλοι, και κανείς δεν μας")
    info("το είπε. Η δική μας μένει εδώ και φεύγει μαζί με την εφαρμογή.")
    return provision_python()


# ------------------------------------------------------------------ venv
def setup_venv(base_python: str) -> Path | None:
    r"""Δημιουργεί το .venv ΑΠΟ ΤΗΝ ΕΠΙΛΕΓΜΕΝΗ Python, όχι από τη sys.executable.

    Η αλλαγή είναι το ουσιαστικό μέρος, όχι μια μορφοποίηση. Όταν το .venv
    δημιουργείτο από το sys.executable, το venv κληρονομούσε τη διαδρομή
    της Python του ΜΗΧΑΝΗΜΑΤΟΣ. Και όχι μόνο τη διαδρομή: το pyvenv.cfg κρατά
    `home = C:\Users\...\AppData\Local\Programs\Python\Python313`. Αν ο
    πελάτης μετά καλέσει την Python (και το κάνουν όλοι, μια φορά για
    πάντα), το runtime\python μας φεύγει και το .venv μένει μισό.
    """
    step("Περιβάλλον Python (.venv)")
    if VENV_PY.exists():
        ok("Υπάρχει ήδη — δεν το αγγίχτηκε.")
        return VENV_PY
    info("Δημιουργείται από: %s" % base_python)
    info("(λίγα δευτερόλεπτα)")
    try:
        result = subprocess.run([base_python, "-m", "venv", str(VENV)],
                                capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=900)
    except Exception as exc:                          # noqa: BLE001
        fail(f"Αποτυχία: {exc}")
        return None
    if result.returncode != 0 or not VENV_PY.exists():
        fail("Το .venv δεν δημιουργήθηκε.")
        info((result.stderr or result.stdout or "").strip()[-400:])
        return None
    ok("Δημιουργήθηκε.")
    return VENV_PY


def install_deps(python: Path) -> bool:
    step("Βιβλιοθήκες")
    info("Κατέβασμα (1-3 λεπτά, μόνο την πρώτη φορά)...")
    try:
        result = subprocess.run(
            [str(python), "-m", "pip", "install", "--disable-pip-version-check",
             "--no-input", "-r", str(APP_DIR / "requirements.txt")],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=1800)
    except Exception as exc:                          # noqa: BLE001
        fail(f"Αποτυχία: {exc}")
        return False
    if result.returncode != 0:
        fail("Η εγκατάσταση απέτυχε.")
        for line in (result.stdout or result.stderr or "").splitlines()[-15:]:
            info(line.strip()[:150])
        return False
    installed = [l.strip() for l in (result.stdout or "").splitlines()
                 if l.strip().startswith("Successfully installed")]
    if installed:
        info(installed[0][:150])
    ok("Έτοιμες.")
    return True


#: Ό,τι ΠΡΕΠΕΙ να μπορεί να κάνει import το venv. Το click και το werkzeug
#: δεν τα γράφουμε στο requirements.txt — έρχονται μαζί με το Flask — αλλά
#: τα ελέγχουμε, γιατί αν δεν μπήκε το Flask δεν θα υπάρχουν ούτε αυτά.
REQUIRED_MODULES = ("flask", "dotenv", "waitress", "click", "sqlalchemy",
                    "flask_login", "flask_wtf", "werkzeug")

#: Ακόμα πιο σημαντικό: να σηκωθεί η ίδια η εφαρμογή. Ένα import που πετάει
#: σε κάποιο ασυνήθιστο σημείο (π.χ. λάθος διαδρομή) δεν φαίνεται από τον
#: έλεγχο των ονομάτων μόνων.
_PROBE = (
    "import importlib, sys\n"
    "bad = []\n"
    "for name in %r:\n"
    "    try:\n"
    "        importlib.import_module(name)\n"
    "    except Exception as exc:\n"
    "        bad.append(name + ': ' + type(exc).__name__)\n"
    "try:\n"
    "    import app\n"
    "    app.create_app()\n"
    "except Exception as exc:\n"
    "    bad.append('app: ' + type(exc).__name__ + ' ' + str(exc)[:120])\n"
    "print(chr(10).join(bad))\n"
)


def verify_env(python: Path) -> bool:
    """Αποδεικνύει ότι ΤΟ ΠΡΑΓΜΑΤΙΚΟ ΠΑΚΕΤΟ μπήκε, όχι ότι το pip είπε «οκ».

    Χωρίς αυτό τον έλεγχο, ένα αποτυχημένο κατέβασμα (κακό internet,
    proxy, απενεργοποιημένο pip) εμφανίζεται τρία βήματα αργότερα σαν
    «No module named click» — που δεν λένε τίποτα στον ιδιοκτήτρια.
    """
    step("Έλεγχος περιβάλλοντος")
    try:
        result = subprocess.run(
            [str(python), "-c", _PROBE % (REQUIRED_MODULES,)],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=300, cwd=str(APP_DIR))
    except Exception as exc:                          # noqa: BLE001
        fail(f"Δεν μπόρεσα να ελέγξω το περιβάλλον: {exc}")
        return False

    missing = [l.strip() for l in (result.stdout or "").splitlines() if l.strip()]
    if result.returncode != 0 and not missing:
        fail("Το περιβάλλον Python δεν απαντά σωστά.")
        for line in (result.stderr or "").splitlines()[-8:]:
            info(line.strip()[:150])
        return False
    if not missing:
        ok(f"Η εφαρμογή σηκώνεται· {len(REQUIRED_MODULES)} βιβλιοθήκες + η ίδια η εφαρμογή.")
        return True

    fail("Λείπουν βιβλιοθήκες — το κατέβασμα ΔΕΝ ολοκληρώθηκε.")
    for line in missing:
        info("  λείπει: " + line[:150])
    info("")
    info("Συνήθειοι λόγοι, κατά σειρά πιθανότητας:")
    info("  1. Δεν έχει internet. Το pip κατεβάζει τις βιβλιοθήκες από το")
    info("     internet κατά την εγκατάσταση· χωρίς σύνδεση δεν γίνεται.")
    info("  2. Υπάρχει proxy ή firewall που κόβει το pypi.org.")
    info("  3. Το κατέβασμα διακόπηκε (κλείσε το παράθυρο, δίκτυο).")
    info("")
    info(f"Δοκίμασε:  {VENV_PY} -m pip install -r requirements.txt")
    return False


def bootstrap_db(python: Path) -> bool:
    step("Βάση δεδομένων")
    try:
        result = subprocess.run([str(python), str(APP_DIR / "migrate.py")],
                                capture_output=True, text=True, encoding="utf-8",
                                errors="replace", timeout=600, cwd=str(APP_DIR))
    except Exception as exc:                          # noqa: BLE001
        fail(f"Αποτυχία: {exc}")
        return False
    if result.returncode != 0:
        fail("Οι πίνακες δεν δημιουργήθηκαν.")
        for line in (result.stdout or result.stderr or "").splitlines()[-12:]:
            info(line.strip()[:150])
        return False
    ok("Οι πίνακες είναι έτοιμοι.")
    return True


def _source_literals(path: Path) -> dict:
    """Συλλέγει τις ΣΤΑΘΕΡΕΣ τιμές από ένα αρχείο Python, χωρίς να το
    εκτελέσουμε. Μόνο stdlib (ast), γιατί αυτό τρέχει με το Python του
    συστήματος, χωρίς εγκατεστημένα πακέτα.

    Επιστρέφει {όνομα: τιμή} για τις αναθέσεις μονό-τιμής. Οι εκφράσεις
    που δεν είναι απλές συμβατικές (π.χ. os.environ.get(...)) δεν
    περιλαμβάνονται — τις διαβάζουμε με τη δική τους συνάρτηση.
    """
    import ast

    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError) as exc:
        raise SystemExit(f"Δεν μπόρεσα να διαβάσω το {path.name}: {exc}")

    found: dict = {}

    def walk(node):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, ast.ClassDef):
                walk(child)
            elif isinstance(child, ast.Assign):
                if not isinstance(child.value, ast.Constant):
                    continue
                if not isinstance(child.value.value, (str, int, float)):
                    continue
                for target in child.targets:
                    if isinstance(target, ast.Name):
                        found[target.id] = child.value.value

    walk(tree)
    return found


def _target_name(node) -> str:
    """Το όνομα στον αριστερό όρο μιας ανάθεσης.

    Στο config.py το UPDATE_URL είναι μέσα σε `class Config:`, άρα ο στόχος
    του AST είναι Name(id=...). Αν ποτέ γραφτεί ως `Config.UPDATE_URL = ...`
    τότε είναι Attribute(attr=...). Δεχόμαστε ΚΑΙ ΤΑ ΔΥΟ, γιατί το ποιο είναι
    σωστό εξαρτάται από το πού βρίσκεται η γραμμή — όχι από τη θέλησή μας.
    """
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return ""


def _update_url_default() -> str:
    """Η προεπιλογή του UPDATE_URL, όπως τη γράφει το config.py.

    Η γραμμή είναι `UPDATE_URL = os.environ.get("UPDATE_URL", "https://…")`
    μέσα στην class Config. Δεν κοιτάζουμε τη ΘΕΣΗ του string: το πρώτο
    όρισμα είναι το όνομα της μεταβλητής, το δεύτερο το URL. Διαλέγουμε
    εκείνο που μοιάζει διεύθυνση, ώστε η ανάγνωση να μην εξαρτάται από τη
    διάταξη της γραμμής. Η μορφοποίηση αλλάζει, η σημασία όχι.
    """
    path = APP_DIR / "config.py"
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError) as exc:
        raise SystemExit(f"Δεν μπόρεσα να διαβάσω το config.py: {exc}")

    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if not any(_target_name(t) == "UPDATE_URL" for t in node.targets):
            continue
        # Το string της διεύθυνσης μπορεί να είναι μέσα σε κλήση
        # (os.environ.get(...)) ή να είναι κατ' ευθείαν η τιμή.
        pools = ([node.value.args, node.value.keywords]
                 if isinstance(node.value, ast.Call) else [node.value])
        for pool in pools:
            for item in pool:
                if isinstance(item, ast.Constant) and isinstance(item.value, str) \
                        and "://" in item.value:
                    return item.value

    raise SystemExit(
        "Δεν βρέθηκε προεπιλογή για το UPDATE_URL στο config.py. "
        "Χωρίς αυτήν οι ενημερώσεις δεν θα ρυθμιστούν στο .env.")


def ensure_env(port: int, host: str) -> None:
    """Γράφει .env με ΤΥΧΑΙΟ κλειδί — το προεπιλεγμένο είναι δημόσιο στον
    κώδικα, οπότε θα το μπορούσε οποιοσδήποτε."""
    step("Ρυθμίσεις (.env)")
    env = APP_DIR / ".env"
    if env.exists():
        ok("Υπάρχει ήδη — δεν αγγίχτηκε.")
        return
    base = f"http://{host}:{port}" if port not in (80, 443) else f"http://{host}"
    # Διαβάζονται ΑΠΟ ΤΟΝ ΠΗΓΑΙΟ ΚΩΔΙΚΑ, χωρίς import: αυτό το αρχείο
    # τρέχει με το Python του ΣΥΣΤΗΜΑΤΟΣ, όπου δεν υπάρχουν ούτε dotenv
    # ούτε Flask. Το import του config.py σκοτώνε την εγκατάσταση στο
    # μηχάνημα του πελάτη.
    public_key = _source_literals(APP_DIR / "app" / "version.py").get(
        "UPDATE_PUBLIC_KEY", "")
    if not public_key:
        raise SystemExit(
            "Δεν βρέθηκε δημόσιο κλειδί ενημερώσεων (UPDATE_PUBLIC_KEY) "
            "στο app/version.py. Χωρίς αυτό οι ενημερώσεις δεν θα "
            "ρυθμιστούν — ξαναφτιάξτε το app/version.py.")
    update_url = _update_url_default()
    content = f"""# Niki's Grooming Salon — δημιουργήθηκε από το install.py
# Το SECRET_KEY υπογράφει τα cookies σύνδεσης. Μην το μοιράζεσαι και
# μην το αλλάξεις: η αλλαγή κόβει τις ενεργές συνδεδεμένες συνεδρίες.
SECRET_KEY={secrets.token_urlsafe(64)}

# Η διεύθυνση που βλέπει ο χρήστης. Χρησιμοποιείται στους συνδέσμους
# επαναφοράς κωδικού — αν δεν ταιριάζει, αυτοί δεν δουλεύουν.
PUBLIC_BASE_URL={base}

# Email (προαιρετικά). Χωρίς αυτά δεν στέλνονται email, και η εφαρμογή
# λειτουργεί κανονικά. Για επαναφορά κωδικού με email χρειάζεται.
MAIL_ENABLED=false

# Η θύρα στην οποία ακούει η εφαρμογή.
PORT={port}

# Αυτόματες ενημερώσεις. Το κλειδί είναι ΔΗΜΟΣΙΟ (είναι το δημόσιο μισό του
# ιδιωτικού που υπογράφει τις εκδόσεις) και βρίσκεται και στον κώδικα, στο
# app/version.py. Το γράφουμε και εδώ για να το βλέπει η ιδιοκτήτρια και να
# μπορεί να το αλλάξει αν ποτέ χρειαστεί. Χωρίς αυτά τα δύο η εφαρμογή
# ΔΕΝ προσφέρει ποτέ ενημέρωση — και δεν το λέει, μοιάζει απλώς «δεν υπάρχει
# νέα έκδοση».
UPDATE_URL={update_url}
UPDATE_PUBLIC_KEY={public_key}
"""
    env.write_text(content, encoding="utf-8")
    ok(f"Δημιουργήθηκε με τυχαίο SECRET_KEY (PUBLIC_BASE_URL={base})")


def setup_link(python: Path, base_url: str) -> str:
    """Δημιουργεί τον κωδικό πρώτης εγκατάστασης και επιστρέφει τη διεύθυνση."""
    try:
        result = subprocess.run(
            [str(python), "-m", "flask", "--app", "wsgi", "setup-token",
             "--base-url", base_url],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=180, cwd=str(APP_DIR))
    except Exception:                                  # noqa: BLE001
        return ""
    for line in (result.stdout or "").splitlines():
        if "/setup/?token=" in line:
            return line.strip()
    return ""


# ------------------------------------------------------------------ main
def main() -> int:
    head("Niki's Grooming Salon  ·  εγκατάσταση με ένα κλικ")

    if not IS_WINDOWS:
        fail("Αυτό το σενάριο στοχεύει Windows.")
        return 1
    if elevate():
        return 0                                     # ξαναξεκίνησε ως admin

    print()
    info(f"Φάκελος: {APP_DIR}")
    print()

    # Η PYTHON ΠΟΥ ΘΑ ΧΤΙΣΤΕΙ ΤΟ VENV. Πρώτα η ιδιωτική μας, μετά κάποια
    # από το μηχάνημα αν είναι μέσα στα όρια, αλλιώς τη δική μας την
    # κατεβάζουμε. Το INSTALL.bat έχει κάνει ήδη το ίδιο — εδώ επαναλαμβάνεται
    # γιατί κάποιος μπορεί να τρέξει το install.py απευθείας.
    base_python = ensure_base_python()
    if not base_python:
        pause()
        return 1

    # Προειδοποίηση ασφαλείας: μέσα στο wwwroot, το IIS σερβίρει τα πάντα.
    try:
        sys.path.insert(0, str(APP_DIR))
        import install_service
        if install_service.is_under_wwwroot() is not None:
            step("ΠΡΟΣΟΧΗ")
            fail("Η εφαρμογή είναι μέσα στο wwwroot του IIS.")
            info("Το Default Web Site του IIS θα σερβίρει τη βάση και το .env")
            info("στο δίκτυο, χωρίς κωδικό. Μεταφέρε την πριν συνεχίσεις:")
            info(f'    robocopy "{APP_DIR}" "{APP_DIR.drive}\\NikiSalon" /MOVE /E')
            pause()
            return 1
    except Exception:                                  # noqa: BLE001
        pass

    python = setup_venv(base_python)
    if not python:
        pause()
        return 1
    if not install_deps(python):
        pause()
        return 1
    # Ο ΠΡΟΕΛΓΧΟΣ ΜΕ ΤΗ ΒΑΣΗ. Χωρίς αυτό, ένα αποτυχημένο κατέβασμα
    # εκδηλώνεται εδώ σαν «No module named click» — μήνυμα που δεν λέει στον
    # ιδιοκτήτρια τι έχει πάθει.
    if not verify_env(python):
        pause()
        return 1
    if not bootstrap_db(python):
        pause()
        return 1

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--local-only", action="store_true")
    parser.add_argument("--backup-dir", default=None,
                        help="Φάκελος για το καθημερινό αυτόματο αντίγραφο.")
    known, rest = parser.parse_known_args()
    port, local_only = known.port, known.local_only
    ensure_env(port, "localhost")

    # Η εγκατάσταση της εργασίας (Task Scheduler) + ο έλεγχος υγείας.
    import install_service
    rc = install_service.do_install(port, local_only, False)
    if rc != 0:
        pause()
        return rc

    # Υπενθυμίσεις κάθε 30 λεπτά + καθημερινό αντίγραφο. Χωρίς αυτά η
    # εφαρμογή δεν θυμάται να υπενθυμίσει ραντεβού και δεν έχει αντίγραφο
    # ασφαλείας. Χωρίς αυτά η εφαρμογή δεν θυμάται να υπενθυμίσει
    # ραντεβού και δεν έχει αντίγραφο όταν πάει στραβά.
    backup_dir = Path(known.backup_dir).expanduser() if known.backup_dir \
        else APP_DIR / "backups"
    install_service.setup_automation(python, backup_dir)

    base = f"http://localhost:{port}"
    link = setup_link(python, base)
    head("ΕΤΟΙΜΟ")
    print(f"   {link or base + '/setup/'}")
    print()
    print(f"   {install_service.lan_hint(local_only, port)}")
    print()
    ok("Η εφαρμογή θα ξεκινά μόνη της σε κάθε επανεκκίνηση του υπολογιστή.")
    ok("Χειροκίνητα:  python install_service.py --status  |  --stop  |  --start")
    print()
    pause()
    return 0


def pause() -> None:
    """Κρατά το παράθυρο ανοιχτό — το .bat το καλεί και μετά κλείνει."""
    if not sys.stdin or sys.stdin.isatty():
        try:
            input(f"\n{_c('Πάτησε Enter για κλείσιμο...', DIM)}")
        except Exception:                              # noqa: BLE001
            pass


if __name__ == "__main__":
    sys.exit(main())
