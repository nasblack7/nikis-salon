@echo off
REM ===========================================================================
REM  Niki's Grooming Salon - INSTALL
REM
REM  DOUBLE-CLICK THIS FILE. Do not run it from a cmd prompt you care about.
REM
REM  THIS FILE NEEDS NO PYTHON. That is the whole point of it. It looks for a
REM  Python it can use, and if there is none it downloads the pinned one from
REM  python.org, checks it against the official SHA-256, and installs it
REM  INSIDE this folder. Only then does it run install.py.
REM
REM  The customer must never have to install software by hand in order to use
REM  a salon booking system. Every step below exists so that this file works
REM  on a machine that has never seen Python.
REM
REM  We do NOT uninstall any Python the customer already has. Removing
REM  somebodys Python can break software they depend on and never told us
REM  about - accounting packages, tax tools, scripts other people wrote.
REM  That is not ours to risk for our own convenience. Our own copy lives in
REM  runtime\python and touches nothing else on the machine.
REM ===========================================================================
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title Niki's Grooming Salon - Install

set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
set "RUNTIME=%HERE%\runtime\python"
set "MANIFEST=%HERE%\runtime_python.txt"
set "TMPDIR=%TEMP%\nikisalon-python"

echo.
echo   ==========================================================
echo     Niki's Grooming Salon - εγκατάσταση
echo   ==========================================================
echo.

REM ---------------------------------------------------------------------------
REM  Step 1. Which Python did we pin, where does it come from, and what is its
REM  official SHA-256? One manifest, read by BOTH this file and install.py, so
REM  the two can never drift apart and end up trusting different hashes.
REM ---------------------------------------------------------------------------
if not exist "%MANIFEST%" (
  echo   [X]  Λείπει το runtime_python.txt από τον φάκελο της εφαρμογής.
  echo.
  echo       Το αρχείο αυτό λέει στον εγκαταστάτη ποια Python να κατεβάσει
  echo       και ποιο είναι το επίσημο SHA-256 της. Χωρίς αυτό δεν μπορούμε
  echo       να εγκαταστήσουμε τίποτα, και δεν θα το παρακάμψουμε.
  echo.
  echo       Κατέβασε ξανά το πακέτο της εφαρμογής από τον προγραμματιστή.
  echo.
  goto :bail
)

REM  The architecture first, because it decides which URL and hash we read.
REM  Windows 11 is 64-bit only, so AMD64 or ARM64 - but a 32-bit Windows 10
REM  still exists, and a 32-bit venv is not what we want to build, so we
REM  simply bring our own 64-bit copy there instead.
set "ARCH=AMD64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=ARM64"
if /i "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "ARCH=ARM64"
if defined PROCESSOR_ARCHITEW6432 goto :arch_done
if /i not "%PROCESSOR_ARCHITECTURE%"=="AMD64" if /i not "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=X86"
:arch_done

set "PYVER="
set "PYURL="
set "PYSHA="
for /f "usebackq tokens=1,* delims==" %%A in ("%MANIFEST%") do (
  if "%%A"=="VERSION"   set "PYVER=%%B"
  if /i "%%A"=="URL_%%ARCH%%" set "PYURL=%%B"
  if /i "%%A"=="SHA_%%ARCH%%" set "PYSHA=%%B"
)

if not defined PYVER goto :bad_manifest
if not defined PYURL  goto :bad_manifest
if not defined PYSHA  goto :bad_manifest

REM ---------------------------------------------------------------------------
REM  Step 2. Is there already a Python we can use?
REM  "Use" means: it actually runs, and it is between 3.10 and 3.13. A newer
REM  one has never been tested here and an older one cannot run this code; in
REM  both cases we bring our own rather than argue with the machine.
REM ---------------------------------------------------------------------------
set "PY="
if exist "%RUNTIME%\python.exe"                set "PY=%RUNTIME%\python.exe"
if not defined PY if exist "%HERE%\.venv\Scripts\python.exe" set "PY=%HERE%\.venv\Scripts\python.exe"
if not defined PY call :probe_system

if defined PY (
  "%PY%" -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] <= (3,13) else 1)" >nul 2>&1
  if errorlevel 1 (
    echo   [!]  Η Python που βρέθηκε είναι εκτός ορίων - δεν τη χρησιμοποιούμε.
    "%PY%" -c "import sys; print('      βρέθηκε: Python %d.%d' % sys.version_info[:2])" 2>nul
    set "PY="
  )
)

if defined PY goto :have_python

REM ---------------------------------------------------------------------------
REM  Step 3. No usable Python. Fetch the pinned one, verify it, install it
REM  inside this folder.
REM ---------------------------------------------------------------------------
echo   Δεν βρέθηκε Python που να μπορεί να χρησιμοποιηθεί σε αυτό το μηχάνημα.
echo   Θα κατεβάσω μόνη μου την Python %PYVER% από το python.org
echo   και θα τη βάλω ΜΕΣΑ ΣΤΟΝ ΦΑΚΕΛΟ ΤΗΣ ΕΦΑΡΜΟΓΗΣ. Καμία Python που
echo   υπάρχει ήδη στο μηχάνημα δεν θα αγγίξει.
echo.

set "EXE=%TMPDIR%\python-%PYVER%-installer.exe"
if not exist "%TMPDIR%" mkdir "%TMPDIR%" >nul 2>&1

echo   [1/3] Κατέβασμα... ^(περίπου 30 MB^)
call :download "%PYURL%" "%EXE%"
if errorlevel 1 goto :download_failed

REM  THE INTEGRITY CHECK. A download-and-run step with no hash check is how a
REM  machine ends up running somebody elses code. If this fails we stop and we
REM  delete the file. We do not print a warning and carry on.
echo   [2/3] Έλεγχος ακεραιότητας...
set "GOT="
for /f "usebackq delims=" %%H in (`certutil -hashfile "%EXE%" SHA256 ^| findstr /r /v "hash CertUtil"`) do (
  if not defined GOT set "GOT=%%H"
)
if not defined GOT (
  echo   [X]  Το certutil δεν μπόρεσε να υπολογίσει το SHA-256.
  del "%EXE%" >nul 2>&1
  goto :bail
)
echo %GOT% | findstr /i /c:"%PYSHA%" >nul
if errorlevel 1 (
  echo.
  echo   [X]  Το SHA-256 ΔΕΝ ΤΑΙΡΙΖΕΙ με το επίσημο του python.org.
  echo.
  echo       Το αρχείο που κατέβηκε είναι είτε κατεστραμμένο στη μεταφορά
  echo       είτε κάτι άλλο. Σε ΚΑΜΙΑ περίπτωση δεν θα εκτελεστεί.
  echo.
  echo       ΜΗΝ ΤΟ ΤΡΕΞΕΙΣ ΧΕΙΡΟΚΙΝΑ. Ένα λάθος αρχείο που εκτελείται με
  echo       δικαιώματα διαχειριστή είναι το χειρότερο πράγμα που μπορεί να
  echo       συμβεί σε αυτό το μηχάνημα. Πείμονε στον προγραμματιστή.
  echo.
  del "%EXE%" >nul 2>&1
  goto :bail
)
echo         Το SHA-256 ταιριάζει με το επίσημο του python.org.

echo   [3/3] Εγκατάσταση της Python %PYVER% στον φάκελο της εφαρμογής...
echo         ^(λίγα λεπτά, δεν θα εμφανιστεί κανένα παράθυρο^)
start "" /wait "%EXE%" ^
  /quiet InstallAllUsers=0 ^
  TargetDir="%RUNTIME%" ^
  PrependPath=0 Include_launcher=0 Include_test=0 Include_doc=0 ^
  Include_tcltk=0 Include_tools=0 Include_debug=0 Include_symbols=0 ^
  AssociateFiles=0 Shortcuts=0
REM  0 = done.  3010 = done, Windows wants a restart later.  Both fine.
REM  errorlevel N means "greater or equal to N", so anything from 3011 up is
REM  a genuine failure.
if errorlevel 3011 goto :install_failed
if not exist "%RUNTIME%\python.exe" goto :install_failed
del "%EXE%" >nul 2>&1

set "PY=%RUNTIME%\python.exe"

:have_python
echo.
echo   Βρέθηκε: %PY%
for /f "usebackq delims=" %%V in (`"%PY%" --version 2^>^&1`) do echo   %%V
echo.

REM ---------------------------------------------------------------------------
REM  Step 4. The real installer.
REM ---------------------------------------------------------------------------
"%PY%" "%HERE%\install.py" %*
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo   ==========================================================
  echo     Ολοκληρώθηκε. Ανοίξτε τη διεύθυνση που εμφανίστηκε.
  echo   ==========================================================
) else (
  echo   ==========================================================
  echo     Η εγκατάσταση δεν ολοκληρώθηκε ^(κωδικός %RC%^).
  echo     Διαβάστε τα μηνύματα παραπάνω.
  echo   ==========================================================
)
echo.
pause
endlocal
exit /b %RC%

REM ===========================================================================
REM  Fallbacks
REM ===========================================================================

:probe_system
REM  Look where python.org puts itself, then ask PATH. Each candidate must
REM  actually RUN - System32\python.exe exists on every Windows 10/11 and is
REM  the Microsoft Store stub, which opens the Store rather than running
REM  Python. "It exists" is not evidence that it works.
for %%C in (
  "%ProgramFiles%\Python313\python.exe"
  "%ProgramFiles%\Python312\python.exe"
  "%ProgramFiles%\Python311\python.exe"
  "%ProgramFiles%\Python310\python.exe"
  "%LocalAppData%\Programs\Python\Python313\python.exe"
  "%LocalAppData%\Programs\Python\Python312\python.exe"
  "%LocalAppData%\Programs\Python\Python311\python.exe"
  "%LocalAppData%\Programs\Python\Python310\python.exe"
) do (
  if not defined PY (
    if exist %%C (
      %%C -c "import sys" >nul 2>&1
      if not errorlevel 1 set "PY=%%~C"
    )
  )
)
if defined PY exit /b 0
for /f "usebackq delims=" %%P in (`where python.exe 2^>nul`) do (
  if not defined PY (
    %%P -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PY=%%P"
  )
)
exit /b 0

:download
REM  curl.exe ships with Windows 10 1803 and every Windows 11. PowerShell is
REM  the fallback for machines where something removed it. A truncated
REM  download needs no extra guard here: the SHA-256 check that follows will
REM  reject it, and it says so in words the owner can act on.
curl.exe -fL --retry 3 --retry-delay 2 --connect-timeout 30 -o "%~2" "%~1"
if not errorlevel 1 if exist "%~2" exit /b 0
if exist "%~2%" del "%~2%" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ProgressPreference='SilentlyContinue';" ^
  "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
  "try { Invoke-WebRequest -Uri '%~1' -OutFile '%~2' -UseBasicParsing } catch { exit 1 }"
if not exist "%~2" exit /b 1
exit /b 0

:download_failed
echo.
echo   [X]  Η λήψη απέτυχε.
echo.
echo       Ελέγξτε τη σύνδεση στο internet, ή αν κάποιο proxy ή firewall
echo       κόβει το www.python.org. Αν θέλετε, κατεβάστε χειροκίνητα το
echo       αρχείο παρακάτω και αποθηκεύσετέ το στη θέση αυτή:
echo.
echo           %PYURL%
echo           %EXE%
echo.
echo       και ξανατρέξτε το INSTALL.bat. Θα το βρει έτοιμο και θα
echo       συνεχίσει από εκεί.
echo.
goto :bail

:install_failed
echo.
echo   [X]  Η εγκατάσταση της Python %PYVER% απέτυχε.
echo.
echo       Συνηθισμένοι λόγοι, κατά σειρά πιθανότητας:
echo         1. Δεν έχει internet.
echo         2. Ένα antivirus ή «προστασία αρχείων» σταμάτησε τον installer.
echo         3. Δεν έχει αρκετό χώρο στον δίσκο.
echo.
echo       Μπορείτε να δοκιμάσετε χειροκίνητα, χωρίς κανένα αυτόματο βήμα:
echo           "%EXE%"
echo       αφήστε τα προεπιλεγμένα και ολοκληρώστε την εγκατάσταση. ΜΕΤΑ
echo       τρέξτε ξανά το INSTALL.bat - θα βρει την Python στο runtime\python.
echo.
goto :bail

:bad_manifest
echo.
echo   [X]  Το runtime_python.txt δεν περιέχει έγκυρη έκδοση ή διεύθυνση ή
echo       SHA-256 για την αρχιτεκτονική αυτής της μηχανής ^(ARCH=%ARCH%^).
echo.
echo       Αυτό σημαίνει ότι το πακέτο δεν είναι ολόκληρο. Κατέβασέ το ξανά.
echo.
goto :bail

:bail
echo.
pause
endlocal
exit /b 1
