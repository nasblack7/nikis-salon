"""Online ενημερώσεις της εφαρμογής, με υπογραφή και δυνατότητα επιστροφής.

Διάταξη (όλα μέσα στο instance/, που το app έχει ήδη δικαίωμα εγγραφής):

    instance/
      current.txt        → ποια έκδοση τρέχει ("." για την πρώτη εγκατάσταση)
      installed.json     → έκδοση, ημερομηνία εγκατάστασης, φάκελος
      releases/<φάκελος>/ → πλήρη αντίγραφο της εφαρμογής
      updates/staging/   → λήψη και αποσυμπόληση
      updates/backup/    → αντίγραφα βάσης
      .maintenance       → σημαία «η εφαρμογή ενημερώνεται»

Ασφάλεια. Μια ενημέρωση είναι τρέξιμος κώδικας, άρα:
  1. Η λήψη γίνεται μόνο από HTTPS.
  2. Το πακέτο περιέχει manifest.json, υπογραμμένο με Ed25519 από το ιδιωτικό
     κλειδί του προγραμματιστή. Το δημόσιο κλειδί είναι μέσα στην εφαρμογή,
     όχι στον διακομιστή ενημερώσεων — αλλιώς όποιος έλεγχε τον διακομιστή
     θα είχε και την υπογραφή.
  3. Το manifest περιέχει το SHA-256 κάθε αρχείου, οπότε η υπογραφή
     καλύπτει όλο το περιεχόμενο, όχι μόνο το όνομα της έκδοσης.
  4. Η υπογραφή ελέγχεται ΜΕΤΑ τη λήψη, όχι μόνο στον έλεγχο διαθεσιμότητας.
  5. Καμία διαδρομή από το πακέτο δεν φτάνει έξω από τον φάκελο της έκδοσης
     (ποτέ ../, ποτέ απόλυτες διαδρομές) και ποτέ δεν αγγίζει instance/, τη
     βάση, το .env ή το web.config.
  6. Πριν από κάθε μετατροπή σχήματος παίρνεται αντίγραφο της βάσης.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import socket
import ssl
import subprocess

#: ΧΩΡΙΣ ΠΑΡΑΘΥΡΟ. Κάθε subprocess που ξεκινά η εφαρμογή (pip, έλεγχος
#: υγείας) είναι console application· χωρίς αυτό, κάθε ενημέρωση άνοιγε ένα
#: μαύρο παράθυρο στην οθόνη της ιδιοκτήτριας για μερικά δευτερόλεπτα. Η
#: σημαία υπάρχει μόνο στα Windows, γι' αυτό το getattr με προεπιλογή 0.
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
import sys
import threading
import time
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from . import ed25519
from .version import APP_VERSION, is_newer

# --------------------------------------------------------------------- config

MAX_FILES = 4000
MAX_TOTAL_BYTES = 200 * 1024 * 1024

#: Ποτέ δεν εγγράφονται από ένα πακέτο ενημέρωσης.
FORBIDDEN_PARTS = {"instance", "logs", "__pycache__", ".git", ".env", "web.config",
                   "node_modules", ".idea", ".vscode"}
FORBIDDEN_SUFFIX = (".db", ".sqlite", ".sqlite3", ".pyc", ".log", ".env", ".bak")

_MANIFEST_NAME = "manifest.json"
_RELEASE_RE = re.compile(r"^release-(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2})$")


class UpdateError(RuntimeError):
    """Οποιαδήποτε αποτυχία κατά τον έλεγχο ή την εγκατάσταση ενημέρωσης."""


def is_frozen() -> bool:
    """Τρέχει το exe (PyInstaller) αντί για φάκελο εγκατάστασης."""
    return bool(getattr(sys, "frozen", False))


def unsupported_reason() -> str:
    """Γιατί οι ενημερώσεις δεν τρέχουν στο exe· κενό αν τρέχουν.

    Στο onefile του PyInstaller ο κώδικας ζει σε προσωρινό φάκελο που
    διαγράφεται μόλις κλείσει το πρόγραμμα. Οι εκδόσεις θα έριχναν μέσα
    σε αυτόν τον προσωρινό φάκελο και θα χανόταν. Επιπλέον, η εγκατάσταση
    τελειώνει με os._exit(0) για να ξανασκεκαλεστεί το IIS — στο exe αυτό
    θα σήμαινε ότι το πρόγραμμα κλείνει χωρίς να ξαναανοίξει.

    Άρα στο exe η λειτουργία απενεργοποιείται ρητά, αντί να αφήσουμε ένα
    σπασμένο κουμπί. Οι ιδιοκτήτες με exe ανανεώνουν αντικαταστώντας το
    ίδιο το αρχείο .exe με το νέο.
    """
    if not is_frozen():
        return ""
    return (
        "Η έκδοση exe δεν υποστηρίζει online ενημερώσεις: λειτουργεί από "
        "προσωρινό φάκελο που διαγράφεται στο κλείσιμο. Για να ενημερωθεί, "
        "αντικαταστήστε το αρχείο NikiSalonBooking.exe με το νέο. Τα "
        "δεδομένα σας (instance/salon.db) παραμένουν ανέπαφα."
    )


@dataclass
class UpdateInfo:
    """Τι λέει ο διακομιστής ενημερώσεων (ακόμη μη επαληθευμένο)."""
    version: str
    url: str
    sha256: str
    signature: str
    #: Εναλλακτικές διευθύνσεις, κατά σειρά προσπάθειας. Το `url` είναι
    #: ΠΑΝΤΑ το πρώτο· το `urls` προστίθεται μετά, χωρίς διπλά. Καμία δεν
    #: είναι πιο αξιόπιστη από την άλλη για την υπογραφή: ισχύει το ίδιο hash
    #: σε όλες, οπότε η επιλογή είναι «ποιος host ανταποκρίνεται», όχι
    #: «ποιος έχει δικαίωμα να δώσει το πακέτο».
    urls: list[str] = field(default_factory=list)
    released_at: str = ""
    notes: str = ""
    current_version: str = APP_VERSION
    available: bool = False

    def all_urls(self) -> list[str]:
        """Όλες οι διευθύνσεις, κύρια πρώτη, χωρίς επαναλήψεις."""
        seen: list[str] = []
        for candidate in [self.url, *self.urls]:
            candidate = str(candidate or "").strip()
            if candidate and candidate not in seen:
                seen.append(candidate)
        return seen

    def as_dict(self) -> dict:
        return {
            "version": self.version,
            "released_at": self.released_at,
            "notes": self.notes,
            "current_version": self.current_version,
            "available": self.available,
        }


@dataclass
class Step:
    """Ένα βήμα της εγκατάστασης, με αποτέλεσμα για εμφάνιση στον ιδιοκτήτρια."""
    name: str
    ok: bool = False
    detail: str = ""
    output: str = ""


@dataclass
class InstallReport:
    steps: list[Step] = field(default_factory=list)
    #: Το add() τρέχει στο νήμα της εγκατάστασης, το snapshot() στο νήμα του
    #: HTTP που ρωτά για την πρόοδο. Χωρίς κλειδαριά, ο αναπτυσσόμενος
    #: κατάλογος μπορεί να διαβαστεί μισός — ή χειρότερα, να εκραγεί.
    _lock: object = field(default_factory=threading.Lock, repr=False, compare=False)

    def add(self, name: str, ok: bool, detail: str = "", output: str = "") -> Step:
        step = Step(name, ok, detail, output)
        with self._lock:
            self.steps.append(step)
        return step

    def snapshot(self) -> list[Step]:
        """Αντίγραφο των βημάτων — ασφαλές να διαβαστεί ενώ γράφονται."""
        with self._lock:
            return list(self.steps)

    @property
    def ok(self) -> bool:
        return all(s.ok for s in self.snapshot())

    def as_text(self) -> str:
        lines = []
        for s in self.snapshot():
            mark = "✓" if s.ok else "✗"
            lines.append(f"{mark} {s.name}" + (f" — {s.detail}" if s.detail else ""))
            if not s.ok and s.output:
                lines.append("    " + s.output.strip().replace("\n", "\n    ")[:4000])
        return "\n".join(lines)


# ------------------------------------------------------------------ διάδρομοι

def instance_dir() -> Path:
    """Ο φάκελος instance/ — πάντα αυτός της ρίζας της εγκατάστασης.

    Εκτός app context (εκκίνηση του server, γραμμές εντολής, δοκιμές) πέφτουμε
    στο config. Χωρίς αυτό, η εκκίνηση θα έσκαγε στο «working outside of
    application context» όταν τυπώνει ποια έκδοση τρέχει.
    """
    try:
        from flask import current_app

        return Path(current_app.config["INSTANCE_DIR"])
    except (ImportError, RuntimeError):
        from config import INSTANCE_DIR

        return Path(INSTANCE_DIR)


def releases_dir() -> Path:
    return instance_dir() / "releases"


def updates_dir() -> Path:
    return instance_dir() / "updates"


def staging_dir() -> Path:
    return updates_dir() / "staging"


def backup_dir() -> Path:
    return updates_dir() / "backup"


def pointer_file() -> Path:
    return instance_dir() / "current.txt"


def state_file() -> Path:
    return instance_dir() / "installed.json"


def maintenance_file() -> Path:
    return instance_dir() / ".maintenance"


def check_cache_file() -> Path:
    """Τι είδε ο τελευταίος έλεγχος. Μικρό αρχείο, για να το διαβάζει η
    σύνδεση χωρίς δίκτυο — βλ. update_notice()."""
    return instance_dir() / "update_check.json"


def write_check_cache(info: "UpdateInfo") -> None:
    """Αποθηκεύει το αποτέλεσμα του ελέγχου. Η αποτυχία ΔΕΝ γράφεται:
    αλλιώς ένα προσωρινό κόψιμο του internet θα έφτανε στην ιδιοκτήτρια
    ως «όχι διαθέσιμη ενημέρωση» και θα έμενε εκεί ώσπου να ξαναμπει."""
    if not getattr(info, "version", ""):
        # ΧΩΡΙΣ έκδοση ΔΕΝ ΓΡΑΦΟΥΜΕ ΤΙΠΟΤΑ. Ένας κατακερματισμένος ή λάθος
        # descriptor δεν πρέπει να σβήσει ένα καλό «υπάρχει ενημέρωση» που
        # είχαμε μάθει νωρίτερα — η ιδιοκτήτρία θα έβλεπε την ειδοποίηση να
        # χάνεται χωρίς λόγο. Το check_for_update() σήκωνει εξαίρεση σε κάθε
        # αποτυχία, άρα το κενό είναι απίθανο· το ελέγχουμε για να μην
        # εξαρτάται η σωστή συμπεριφορά από τον καλούντα.
        return
    try:
        payload = {
            "version": info.version,
            "available": bool(info.available),
            "current": APP_VERSION,
            "checked_at": datetime.now().isoformat(timespec="seconds"),
        }
        path = check_cache_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    except (OSError, ValueError):
        pass                      # η ειδοποίηση είναι ευχάριστη, όχι κρίσιμη


def read_check_cache() -> dict:
    try:
        data = json.loads(check_cache_file().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


#: Στόχοι του ελέγχου σύνδεσης. ΔΥΟ, επειδή το όνομα του update host μπορεί
#: να μην λύνεται ενώ το internet δουλεύει (ή το αντίστροφο). Θεωρούμε ότι
#: είμαστε online αν ΑΡΚΕΙ Ο ΕΝΑΣ να αποκριθεί. Port 443, γιατί αυτό χρειάζεται
#: το HTTPS που απαιτεί ο ελεγκτής ενημερώσεων (_https_only).
CONNECTIVITY_HOSTS = ("1.1.1.1", "8.8.8.8")

#: Πόσο συχνά ρωτάμε «υπάρχει internet;». Μικρή τιμή ΣΚΟΠΙΜΑ: είναι ένα TCP
#: connect στο 443 με όριο 3s, όχι λήψη αρχείου. Ο σκοπός είναι να
#: αντιληφθεί γρήγορα μια επιστροφή σύνδεσης, ώστε ο έλεγχος ενημερώσεων να
#: ξαναγίνει μόνος του — χωρίς να πειράξει τον υπολογιστή κάποιος. Με την ώρα
#: σαν ρυθμό, ένα σαλόνι που έχασε το internet θα το έμαθε μετά από ώρες.
CONNECTIVITY_SECONDS = 300


def internet_file() -> Path:
    return instance_dir() / "internet.json"


def probe_internet(timeout: float = 3.0) -> bool:
    """Υπάρχει δρόμος προς το internet; Μικρό και γρήγορο, χωρίς HTTP.

    TCP connect στο 443. Δεν στέλνουμε αίτημα στον update host εδώ: αυτός
    μπορεί να είναι εκείνος που έχει πρόβλημα, και τότε «στο internet
    είμαστε» θα ήταν ψέμα. Το _https_only απαιτεί 443, οπότε αυτό είναι
    το κατάλληλο port — όχι το 80, που θα πέρναγε ακόμα κι αν το 443 ήταν
    μπλοκαρισμένο από το router.
    """
    for host in CONNECTIVITY_HOSTS:
        try:
            with socket.create_connection((host, 443), timeout=timeout):
                return True
        except OSError:
            continue
        except Exception:                               # noqa: BLE001
            continue
    return False


def write_internet_state(online: bool) -> None:
    try:
        path = internet_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(
            {"online": bool(online),
             "checked_at": datetime.now().isoformat(timespec="seconds")},
            ensure_ascii=False), encoding="utf-8")
    except (OSError, ValueError):
        pass


def internet_state(max_age: float = 300.0) -> bool | None:
    """Είμαστε online; None = «δεν ξέρω ακόμα, μην το μάνθεις αυτή τη στιγμή».

    Το None είναι σημαντικό: η ιδιοκτήτρία δεν πρέπει να δει «εκτός
    σύνδεσης» επειδή δεν έχει γίνει έλεγχος. Ούτε και «σύνδεση OK» από
    υπόθεση. Όταν δεν ξέρουμε, οι έλεγχοι επιτρέπονται — το σωστό να
    δοκιμάσουμε παρά να αρνηθούμε.
    """
    try:
        data = json.loads(internet_file().read_text(encoding="utf-8"))
        age = datetime.now() - datetime.fromisoformat(data["checked_at"])
        if age.total_seconds() > max_age:
            return None                       # παλιό ντιγμά, δεν ξέρουμε
        return bool(data.get("online"))
    except (OSError, ValueError, KeyError, TypeError):
        return None


def pending_restart() -> dict:
    """Εγκαταστάθηκε νεότερη έκδοση από αυτή που τρέχει; {} αν όχι.

    Οι ενεργοποιημένες εκδόσεις ζουν στο instance/ και η «ενεργή» είναι ένας
    ΔΕΙΚΤΗΣ σε αρχείο. Αλλάζοντας τον δείκτη, η διεργασία που τρέχει δεν
    ξαναφορτώνει τη Python: έχει ήδη εισαγάγει τα παλιά modules. Άρα «η
    εγκατάσταση ολοκληρώθηκε» και «τρέχει η νέα έκδοση» είναι ΔΥΟ ΠΡΑΓΜΑΤΑ.

    Το ελέγχουμε με την APP_VERSION, που είναι η έκδοση του κώδικα στη μνήμη.
    """
    try:
        state = installed_state()
        if not state.get("version"):
            return {}
        if not is_newer(state["version"], APP_VERSION):
            return {}
        return {
            "installed": state["version"],
            "running": APP_VERSION,
            "installed_at": state.get("installed_at", ""),
        }
    except Exception:                                   # noqa: BLE001
        return {}


def offline_message() -> str:
    """Μήνυμα για την ιδιοκτήτρια όταν το internet δεν δουλεύει.

    Λέει ΤΙ να κάνει, όχι μόνο τι δεν πάει. Το σπιτζάκι μπορεί να είναι
    κλειστό, ή ο διακόπτης του να είναι κάτω — και κανένας έλεγχος
    ενημερώσεων δεν θα το καταλάβει.
    """
    return ("Δεν υπάρχει σύνδεση στο internet, οπότε ο έλεγχος για "
            "ενημερώσεις παραλείφθηκε. Ελέγξτε το σπιτζάκι ή τον "
            "διακόπτη του σαλονιού — η εφαρμογή λειτουργεί κανονικά, απλώς "
            "δεν μπορεί να δει τι υπάρχει νέο.")


def update_notice() -> dict:
    """Τι να πει η σύνδεση: ΥΠΑΡΧΕΙ ενημέρωση ή όχι.

    ΚΑΝΕΝΑ ΔΙΚΤΥΟ ΕΔΩ. Διαβάζει μόνο το αρχείο — βλ. την αιτία στην κορυφή.
    Επιστρέφει {} όταν δεν ξέρουμε τίποτα, ώστε ο καλούντης να μην λέει
    ψευδώς «όχι διαθέσιμη ενημέρωση» από απλή άγνοια.
    """
    data = read_check_cache()
    if not data.get("available") or not data.get("version"):
        return {}
    if not is_newer(data["version"], data.get("current") or APP_VERSION):
        return {}
    return data


def refresh_check_async(app) -> None:
    """Ξεκινά έναν έλεγχο σε φόντο, αν δεν έγινε πρόσφατα.

    Ένας νήμα, με δικό του app context: το request που το ξεκινά μπορεί να
    τελειώσει πολύ πριν ολοκληρωθεί ο έλεγχος, και χωρίς context το Flask
    θα εκραγεί.
    """
    # Η ΠΥΛΗ ΤΗΣ ΣΥΝΔΕΣΗΣ. Το None («δεν ξέρουμε») ΔΕΝ μπλοκάρει: το σωστό
    # όταν δεν ξέρουμε είναι να δοκιμάσουμε, όχι να αρνηθούμε.
    if internet_state() is False:
        return
    data = read_check_cache()
    try:
        age = datetime.now() - datetime.fromisoformat(data.get("checked_at", ""))
    except (TypeError, ValueError):
        age = None
    if age is not None and age.total_seconds() < 1800:
        return                      # ελέγχθηκε πριν από μισή ώρα

    def _go():
        try:
            with app.app_context():
                if not updates_configured():
                    return
                write_check_cache(check_for_update())
        except Exception as exc:                            # noqa: BLE001
            try:
                from .mailer import log_line
                log_line(f"Έλεγχος ενημέρωσης (σύνδεση): {exc}")
            except Exception:
                pass

    threading.Thread(target=_go, name="update-check-login", daemon=True).start()


# ------------------------------------------------------- ενεργή έκδοση/κατάσταση

#: Τι γράφεται στο current.txt για την πρώτη εγκατάσταση, όταν ο κώδικας
#: βρίσκεται ακόμη στη ρίζα του project.
ROOT_RELEASE = "."


def active_release() -> str:
    """Σχετική διαδρομή (ως προς το instance/) της έκδοσης που τρέχει.

    "." σημαίνει την πρώτη εγκατάσταση — τον ίδιο τον φάκελο του project.
    Οι ενημερώσεις αποθηκεύονται ως "releases/<φάκελος>".
    """
    try:
        value = pointer_file().read_text(encoding="utf-8").strip()
    except OSError:
        return ROOT_RELEASE
    if not value or value.startswith("/") or ".." in value:
        return ROOT_RELEASE
    return value


def release_path(name: str | None = None) -> Path:
    """Απόλυτη διαδρομή του φακέλου της ενεργής (ή ζητούμενης) έκδοσης.

    Οι ενημερώσεις ζουν μέσα στο instance/, γι' αυτό οι σχετικές διαδρομές
    μετρώνται από εκεί — όχι από τη ρίζα του project.
    """
    value = name if name is not None else active_release()
    if value == ROOT_RELEASE:
        return Path(__file__).resolve().parent.parent
    return (instance_dir() / value).resolve()


def installed_state() -> dict:
    try:
        return json.loads(state_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ensure_instance() -> None:
    """Δημιουργεί το instance/ αν λείπει. Ασφαλές να καλείται πολλές φορές.

    Το config.py το δημιουργεί στην εκκίνηση, άρα στην παραγωγή υπάρχει
    πάντα. Αλλά είναι ο ΜΟΝΟΣ γραπτός φάκελος, άρα και ο πιο πιθανός να
    λείψει — σε αντιγραφή φάκελου ή χειροκίνητη διόρθωση. Χωρίς αυτό, το
    σφάλμα έρχεται από εκεί και όχι από την αιτία που μας ενδιέφερε.
    """
    try:
        instance_dir().mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise UpdateError(f"Ο φάκελος instance/ δεν δημιουργήθηκε: {exc}") from exc


def record_install(version: str, release: str, previous: str = "") -> None:
    _ensure_instance()
    payload = {
        "version": version,
        "release": release,
        "previous_release": previous,
        "installed_at": datetime.now().isoformat(timespec="seconds"),
    }
    state_file().write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                            encoding="utf-8")


def set_active_release(name: str) -> None:
    """Ενεργοποιεί μια έκδοση. Το `name` είναι το όνομα του φακέλου, όχι
    η πλήρης διαδρομή — αυτή αποθηκεύεται σχετική, ως προς το instance/."""
    _ensure_instance()
    if name == ROOT_RELEASE:
        pointer_file().write_text(ROOT_RELEASE, encoding="utf-8")
        return
    if not _RELEASE_RE.match(name):
        raise UpdateError(f"Μη έγκυρο όνομα έκδοσης: {name!r}")
    if not (releases_dir() / name).is_dir():
        raise UpdateError(f"Ο φάκελος της έκδοσης δεν βρέθηκε: {name}")
    pointer_file().write_text(f"releases/{name}", encoding="utf-8")


def release_folder_name(value: str) -> str:
    """Από τιμή του current.txt σε όνομα φακέλου ("." ή "releases/<φάκελος>").

    Το previous_release αποθηκεύεται ΠΑΝΤΑ ως όνομα φακέλου, ώστε η επιστροφή
    να μην μπερδεύεται ανάμεσα σε "." και "releases/...".
    """
    if not value or value == ROOT_RELEASE:
        return ROOT_RELEASE
    return value.rsplit("/", 1)[-1]


def known_releases() -> list[dict]:
    """Εκδόσεις διαθέσιμες στον δίσκο, νεότερη πρώτα."""
    out = []
    root = releases_dir()
    if not root.is_dir():
        return out
    for child in sorted(root.iterdir(), reverse=True):
        if not child.is_dir() or not _RELEASE_RE.match(child.name):
            continue
        state = {}
        marker = child / "release.json"
        if marker.is_file():
            try:
                state = json.loads(marker.read_text(encoding="utf-8"))
            except ValueError:
                state = {}
        out.append({
            "name": child.name,
            "version": state.get("version", "—"),
            "installed_at": state.get("installed_at", ""),
            "active": active_release() == f"releases/{child.name}",
        })
    return out


# ------------------------------------------------------------- συντήρηση (lock)

def maintenance_on(reason: str = "") -> Path:
    """Κλειδώνει την εφαρμογή σε λειτουργία συντήρησης.

    Γράφουμε και το PID της διεργασίας. Αν αυτή πεθάνει πριν ολοκληρωθεί η
    εγκατάσταση (διακοπή ρεύματος, kill του IIS), η επόμενη εκκίνηση το
    εντοπίζει και ξεκλειδώνει την εφαρμογή — αλλιώς θα έμενε κλειστή
    για πάντα και η ιδιοκτήτριας δεν θα μπορούσε να μπει.
    """
    path = maintenance_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("%s|%d|%s" % (datetime.now().isoformat(timespec="seconds"),
                                  os.getpid(), reason),
                    encoding="utf-8")
    return path


def maintenance_off() -> None:
    try:
        maintenance_file().unlink()
    except FileNotFoundError:
        pass


def in_maintenance() -> bool:
    return maintenance_file().is_file()


def maintenance_reason() -> str:
    raw = _read_maintenance()
    if not raw:
        return ""
    # Μορφή: χρόνος|PID|αιτία. Παλιότερα αρχεία είχαν χρόνος|αιτία.
    parts = raw.split("|")
    if len(parts) >= 3 and parts[1].isdigit():
        return "|".join(parts[2:])
    return "|".join(parts[1:])


def _read_maintenance() -> str:
    try:
        return maintenance_file().read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def clear_stale_maintenance() -> bool:
    """Ξεκλειδώνει την εφαρμογή αν η σημαία έμεινε από άλλη διεργασία.

    Καλείται μία φορά κατά την εκκίνηση. Αν το PID της σημαίας είναι το
    δικό μας, κάτι τρέχει τώρα — δεν αγγίζουμε. Αν είναι άλλο, η διεργασία
    εκείνη πέθανε πριν τελειώσει, οπότε η εγκατάσταση δεν ολοκληρώθηκε και
    η εφαρμογή πρέπει να ξαναχρησιμοποιηθεί.
    """
    raw = _read_maintenance()
    if not raw:
        return False
    parts = raw.split("|")
    if len(parts) >= 2 and parts[1].isdigit() and int(parts[1]) == os.getpid():
        return False           # αυτή η διεργασία κλειδώνει τώρα
    maintenance_off()
    try:
        from .mailer import log_line

        log_line("Καθαρίστηκε παλιά σημαία συντήρησης: %s" % raw)
    except Exception:
        pass
    return True


# ------------------------------------------------------------------- βοηθητικά

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_member_path(name: str) -> Path | None:
    """Μετατρέπει ένα όνομα μέσα στο zip σε ασφαλή σχετική διαδρομή.

    Επιστρέφει None αν η διαδρομή είναι επικίνδυνη: απόλυτη, με «..», με
    symlink, ή που παραχωρεί ένα προστατευμένο αρχείο (βάση, .env, logs).
    """
    if not name or name.endswith("/"):
        return None
    name = name.replace("\\", "/")
    if name.startswith("/") or re.match(r"^[A-Za-z]:", name):
        return None
    parts = [p for p in name.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        return None
    # Καμία συνιστώσα με τελεία στην αρχή: κρύβει φακέλους όπως .ssh ή
    # .config, όχι μόνο αρχεία όπως .env. Χωρίς αυτό ένα πακέτο θα μπορούσε
    # να γράψει π.χ. .ssh/id_rsa μέσα στον server του σπα.
    if any(p.startswith(".") for p in parts):
        return None
    if any(p in FORBIDDEN_PARTS for p in parts[:-1]):
        return None
    leaf = parts[-1]
    if leaf in FORBIDDEN_PARTS or leaf.endswith(FORBIDDEN_SUFFIX):
        return None
    return Path(*parts)


def _https_only(url: str) -> None:
    if not url.lower().startswith("https://"):
        raise UpdateError("Οι ενημερώσεις κατεβάζονται μόνο από HTTPS.")


def _fetch(url: str, dest: Path, max_bytes: int, timeout: int = 30,
           what: str = "Το αρχείο") -> int:
    """Κατεβάζει ένα αρχείο με όριο μεγέθους."""
    _https_only(url)
    context = ssl.create_default_context()
    request = urllib.request.Request(url, headers={"User-Agent": "NikiSalon/1.0",
                                                   "Accept": "*/*"})
    written = 0
    # ΚΑΘΕ ΑΠΟΤΥΧΙΑ ΔΙΚΤΥΟΥ ΜΕΤΑΦΡΑΖΕΤΑΙ ΣΕ UpdateError.
    #
    # Χωρίς αυτό το πλαίσιο, οποιοδήποτε URLError / SSLError / timeout έφευγε
    # από τη _fetch ως ΜΗ ΤΥΠΟΠΟΙΗΜΕΝΗ εξαίρεση. Η διαδρομή check() πιάνει
    # μόνο UpdateError, άρα το σφάλμα έφτανε στη Flask και η ιδιοκτήτρια
    # έβλεπε «500 — Κάτι πήγε στραβά» αντί για μήνυμα που λέει τι να κάνει.
    # Το ίδιο ίσχυε και στο κατέβασμα του πακέτου, στα μισά της ενημέρωσης.
    try:
        with urllib.request.urlopen(request, timeout=timeout,
                                    context=context) as response:
            with dest.open("wb") as out:
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    written += len(chunk)
                    if written > max_bytes:
                        raise UpdateError(
                            f"Το πακέτο ξεπερνά τα "
                            f"{max_bytes // (1024 * 1024)} MB — "
                            "μάλλον δεν είναι ενημέρωση.")
                    out.write(chunk)
    except UpdateError:
        raise                              # ήδη κατανοητό μήνυμα, μην το τυλίξεις
    except urllib.error.HTTPError as exc:
        # 404 = λάθος διεύθυνση στο .env· 403/429 = το GitHub κόβει το σαλόνι·
        # 5xx = πρόβλημα του GitHub, όχι του υπολογιστή.
        # ΤΟ 404 ΔΕΝ ΕΙΝΑΙ ΠΑΝΤΑ ΤΟ ΙΔΙΟ ΠΡΑΓΜΑ, ΚΑΙ Η ΠΡΩΤΗ ΜΟΥ
        # ΕΚΔΟΧΗ ΗΤΑΝ ΛΑΘΟΣ.
        #
        # Στο αληθινό μηχάνημα (Windows, 1.0.2) το 404 ήταν στο ΑΡΧΕΙΟ, όχι
        # στη διεύθυνση: το `update.json` βρέθηκε κανονικά (γι' αυτό
        # είδαμε τις σημειώσεις της 1.0.3), αλλά το `niki-update-1.0.3.zip`
        # δεν είχε ανέβει ποτέ. Το παλιό μήνυμα έλεγε πάντα «Ελέγξε το
        # UPDATE_URL στο .env» και έτυχε ο ιδιοκτήτης να κοιτάζει ένα
        # αρχείο που ήταν τέλειο, για ένα πρόβλημα που ήταν δικό μου.
        #
        # Ο ΚΑΝΟΝΑΣ ΤΟΥ ΙΔΙΟΚΤΗΤΗ: «οι ιδιοκτήτες ενημερώνονται
        # απόμακρυς». Μέσα σε αυτόν τον κανόνα, ένα μήνυμα που χρεώνει τον
        # ιδιοκτήτη για λάθος του προγραμματιστή τον κάνει να μην
        # εμπιστεύεται τη διαδικασία. Άρα λέμε την ΑΛΗΘΕΙΑ, και τις δύο
        # περιπτώσεις χωριστά.
        is_descriptor = what == "Η περιγραφή της ενημέρωσης"
        if exc.code == 404:
            if is_descriptor:
                detail = ("Η διεύθυνση της περιγραφής δεν βρέθηκε στο "
                          "διακομιστή. Ελέγξε το UPDATE_URL στο .env.")
            else:
                detail = (
                    "Το αρχείο της ενημέρωσης δεν υπάρχει στο διακομιστή. "
                    "Αυτό ΔΕΝ είναι θέμα του υπολογιστή σου: η σελίδα "
                    "περιέχει μια ενημέρωση, αλλά το ίδιο το αρχείο δεν έχει "
                    "ανέβει ακόμα. Περιμένε λίγο ή ενημέρωσε τον "
                    "προγραμματιστή.")
        elif exc.code == 403:
            detail = "Ο διακομιστής αρνήθηκε το αίτημα."
        elif exc.code == 429:
            detail = "Υπερβολικά πολλά αιτήματα — δοκίμασε αργότερα."
        else:
            detail = "Ελέγξε τη σύνδεση με το internet."
        raise UpdateError(
            f"Ο διακομιστής ενημερώσεων απάντησε {exc.code} στο "
            f"«{what}».\n{detail}\nΔιεύθυνση: {url}"
        ) from exc
    except (socket.timeout, TimeoutError) as exc:
        raise UpdateError(
            f"Ο διακομιστής ενημερώσεων δεν απάντησε σε {timeout} δευτερόλεπτα. "
            "Μπορεί να είναι αργό το internet· δοκίμασε ξανά."
        ) from exc
    except urllib.error.URLError as exc:
        # Το πιο συχνό: δεν απαντά το DNS, ή κόβει το firewall.
        reason = getattr(exc, "reason", exc)
        raise UpdateError(
            "Δεν ήταν δυνατή η σύνδεση με τον διακομιστή ενημερώσεων "
            f"({reason})."
        ) from exc
    except ssl.SSLError as exc:
        raise UpdateError(f"Πρόβλημα ασφαλείας σύνδεσης (SSL): {exc}") from exc
    except OSError as exc:
        raise UpdateError(f"Σφάλμα δικτύου: {exc}") from exc
    return written


# ------------------------------------------------------------------ έλεγχος

def public_key_hex() -> str:
    from flask import current_app

    from .version import UPDATE_PUBLIC_KEY

    return (current_app.config.get("UPDATE_PUBLIC_KEY") or UPDATE_PUBLIC_KEY or "").strip()


def updates_configured() -> bool:
    from flask import current_app

    return bool(public_key_hex()) and bool(current_app.config.get("UPDATE_URL"))


def _verify_descriptor_signature(signature_hex: str, manifest_bytes: bytes) -> None:
    """Ελέγχει την υπογραφή Ed25519 πάνω στα bytes του manifest.

    Δέχεται την υπογραφή ως hex string, όχι ολόκληρη περιγραφή: έτσι
    δεν μπερδεύεται το dict της περιγραφής με το αντικείμενο UpdateInfo.
    """
    key_hex = public_key_hex()
    if not key_hex:
        raise UpdateError(
            "Δεν έχει ρυθμιστεί δημόσιο κλειδί ενημερώσεων (UPDATE_PUBLIC_KEY). "
            "Χωρίς κλειδί δεν γίνεται δεκτή καμία ενημέρωση.")
    try:
        key = bytes.fromhex(key_hex)
    except ValueError:
        raise UpdateError("Το δημόσιο κλειδί δεν είναι έγκυρο hex.")
    if len(key) != 32:
        raise UpdateError("Το δημόσιο κλειδί πρέπει να είναι 32 bytes (64 χαρακτήρες hex).")
    try:
        signature = bytes.fromhex((signature_hex or "").strip())
    except (ValueError, AttributeError, TypeError):
        raise UpdateError("Η υπογραφή δεν είναι έγκυρο hex.")
    if len(signature) != 64:
        raise UpdateError("Η υπογραφή πρέπει να είναι 64 bytes.")
    if not ed25519.verify(manifest_bytes, signature, key):
        raise UpdateError(
            "Η υπογραφή δεν ταιριάζει. Το πακέτο ΔΕΝ προέρχεται από εσάς — "
            "απορρίπτεται.")


def check_for_update(url: str | None = None) -> UpdateInfo:
    """Ρωτά τον διακομιστή ενημερώσεων τι υπάρχει."""
    from flask import current_app

    reason = unsupported_reason()
    if reason:
        raise UpdateError(reason)

    url = url or current_app.config.get("UPDATE_URL") or ""
    if not url:
        raise UpdateError("Δεν έχει οριστεί διεύθυνση ενημερώσεων (UPDATE_URL).")
    _https_only(url)

    raw = updates_dir() / "descriptor.json"
    raw.parent.mkdir(parents=True, exist_ok=True)
    _fetch(url, raw, 256 * 1024, timeout=20,
           what="Η περιγραφή της ενημέρωσης")
    try:
        descriptor = json.loads(raw.read_text(encoding="utf-8"))
    except ValueError:
        raise UpdateError("Η απόκριση του διακομιστή δεν είναι έγκυρο JSON.")
    for field in ("version", "url", "sha256", "signature"):
        if not descriptor.get(field):
            raise UpdateError(f"Λείπει το πεδίο «{field}» από την περιγραφή ενημέρωσης.")

    # Το `urls` είναι προαιρετικό· μπορεί να είναι ένα μόνο url ή λίστα.
    # Ό,τι και αν έρθει, η ΕΠΑΛΗΘΕΥΣΗ ΤΟΥ HTTPS γίνεται για ΚΑΘΕ διεύθυνση
    # πριν καν προσπαθήσει να κατεβάσει — μια http:// δεν περνά από το πρώτο
    # url και γίνεται δεκτή από το δεύτερο.
    extra: list[str] = []
    declared = descriptor.get("urls")
    if isinstance(declared, str):
        extra = [declared]
    elif isinstance(declared, (list, tuple)):
        extra = [str(item) for item in declared]
    for candidate in [descriptor["url"], *extra]:
        _https_only(str(candidate))

    info = UpdateInfo(
        version=str(descriptor["version"]),
        url=str(descriptor["url"]),
        urls=extra,
        sha256=str(descriptor["sha256"]).lower(),
        signature=str(descriptor["signature"]),
        released_at=str(descriptor.get("released_at", "")),
        notes=str(descriptor.get("notes", "")),
        current_version=APP_VERSION,
    )
    info.available = is_newer(info.version, APP_VERSION)
    return info


# ---------------------------------------------------------------- εγκατάσταση

def _download_and_verify(info: UpdateInfo, max_mb: int) -> tuple[Path, dict]:
    """Κατεβάζει το πακέτο και ελέγχει υπογραφή + hashes. Επιστρέφει (zip, manifest).

    ΔΟΚΙΜΑΖΕΙ ΟΛΕΣ ΤΙΣ ΔΙΕΥΘΥΝΣΕΙΣ, ΜΙΑ ΜΙΑ. Δεν είναι πολυτέλεια: στο πραγματικό
    μηχάνημα του ιδιοκτήτη, ο έλεγχος της περιγραφής πέρασε κανονικά από το
    `raw.githubusercontent.com`, ενώ το κατέβασμα του ίδιου αρχείου από το
    `github.com` έπεσε σε σφάλμα πιστοποιητικών. Με δύο διευθύνσεις, η
    εγκατάσταση τελειώνει από την πρώτη που απαντά σωστά.

    Το hash ελέγχεται ΣΕ ΚΑΘΕ ΠΡΟΣΠΑΘΕΙΑ. Άρα η εναλλακτική δεν ανοίγει πόρτα
    σε κανέναν: αν σε μια διεύθυνση υπάρχει κάτι άλλο, απορρίπτεται και
    πηγαίνουμε στην επόμενη — όχι στην εγκατάσταση.
    """
    updates_dir().mkdir(parents=True, exist_ok=True)
    archive = updates_dir() / f"update-{info.version}.zip"
    candidates = info.all_urls()
    if not candidates:
        raise UpdateError("Η περιγραφή δεν περιέχει διεύθυνση αρχείου.")

    failures: list[str] = []
    last: UpdateError | None = None
    for index, candidate in enumerate(candidates, 1):
        where = (f"({index}/{len(candidates)}) " if len(candidates) > 1 else "")
        try:
            _fetch(candidate, archive, max_mb * 1024 * 1024, timeout=120,
                   what=f"{where}Το αρχείο της ενημέρωσης")
        except UpdateError as exc:
            failures.append(f"{candidate}\n      {exc}".rstrip())
            last = exc
            continue

        actual = sha256_file(archive)
        if actual != info.sha256.lower():
            archive.unlink(missing_ok=True)
            failures.append(f"{candidate}\n      Το SHA-256 δεν ταιριάζει "
                            "— δεν είναι το πακέτο που υπογράφηκε.")
            last = UpdateError("Το SHA-256 του πακέτου δεν ταιριάζει.")
            continue

        if not zipfile.is_zipfile(archive):
            archive.unlink(missing_ok=True)
            failures.append(f"{candidate}\n      Το ληφθέν αρχείο δεν είναι "
                            "έγκυρο ZIP.")
            last = UpdateError("Το ληφθέν αρχείο δεν είναι έγκυρο ZIP.")
            continue

        # Έφτασε αληθινό πακέτο — δεν δοκιμάζουμε άλλες διευθύνσεις.
        break
    else:
        # Ο for/else τρέχει ΜΟΝΟ όταν δεν έγινε break, δηλαδή όταν απέτυχαν
        # ΟΛΕΣ. Τότε λέμε ΠΟΙΕΣ δοκιμάστηκαν και γιατί η καθεμία απέτυχε —
        # γιατί ένα «κατέβασμα απέτυχε» χωρίς διευθύνση είναι μυστήριο, και
        # τα μυστήρια κοστίζουν ώρες σε κάθε ιδιοκτήτη.
        raise UpdateError(
            "Δεν κατέβηκε το αρχείο της ενημέρωσης από ΚΑΜΙΑ διεύθυνση.\n"
            "Δοκιμάστηκαν:\n  · " + "\n  · ".join(failures)
            + "\n\nΑυτό δεν είναι θέμα αυτού του υπολογιστή. Είναι θέμα του "
              "διακομιστή που\nφιλοξενεί τα αρχεία: είτε δεν υπάρχουν εκεί, "
              "είτε το πιστοποιητικό\nτου δεν εμπιστεύεται αυτή η μηχανή. "
              "Στείλε το μήνυμα αυτό\nστον προγραμματιστή — έχει κάθε "
              "διεύθυνση και τον λόγο που\ναπέτυχε η καθεμία."
        ) from last

    with zipfile.ZipFile(archive) as zf:
        try:
            manifest_bytes = zf.read(_MANIFEST_NAME)
        except KeyError:
            raise UpdateError("Το πακέτο δεν περιέχει manifest.json.")
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise UpdateError("Το manifest.json δεν είναι έγκυρο JSON.")

    # Η υπογραφή καλύπτει το σύνολο των hashes των αρχείων.
    _verify_descriptor_signature(info.signature, manifest_bytes)
    return archive, manifest


def _extract_verified(archive: Path, manifest: dict, dest: Path) -> int:
    """Αποσυμπόληση με έλεγχο κάθε αρχείου έναντι του manifest."""
    files = manifest.get("files")
    if not isinstance(files, dict) or not files:
        raise UpdateError("Το manifest δεν περιέχει λίστα αρχείων.")
    if len(files) > MAX_FILES:
        raise UpdateError("Το πακέτο έχει πολλά αρχεία — μάλλον δεν είναι εφαρμογή.")

    if dest.exists():
        shutil.rmtree(dest, ignore_errors=True)
    dest.mkdir(parents=True, exist_ok=True)

    total = 0
    with zipfile.ZipFile(archive) as zf:
        for name in zf.namelist():
            # Το ίδιο το manifest δεν είναι αρχείο εφαρμογής: το διαβάσαμε
            # ήδη, και η υπογραφή του καλύπτει τα hashes των υπόλοιπων.
            if name == _MANIFEST_NAME:
                continue
            target = _safe_member_path(name)
            if target is None:
                continue                       # παραλείπεται, όχι αποτυχία
            expected = files.get(target.as_posix())
            if expected is None:
                raise UpdateError(
                    f"Το πακέτο περιέχει αρχείο που δεν συμφωνεί με το "
                    f"manifest: {target.as_posix()}")
            info = zf.getinfo(name)
            if info.is_dir():
                continue
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise UpdateError(f"Απαγορεύονται τα symlink: {name}")
            size = info.file_size
            if total + size > MAX_TOTAL_BYTES:
                raise UpdateError("Το πακέτο είναι υπερβολικά μεγάλο.")
            total += size
            out = dest / target
            out.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(name) as src, out.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            if sha256_file(out) != str(expected).lower():
                raise UpdateError(
                    f"Το περιεχόμενο του αρχείου {target.as_posix()} δεν "
                    "ταιριάζει με το manifest.")
    if total == 0:
        raise UpdateError("Το πακέτο δεν περιέχει αρχεία εφαρμογής.")
    return total


def _release_db_handles() -> None:
    """Κλείνει τις συνδέσεις της βάσης, ώστε να μην κρατούν το αρχείο.

    ΣΤΑ WINDOWS ΕΝΑ ΑΝΟΙΧΤΟ ΑΡΧΕΙΟ ΔΕΝ ΑΝΤΙΓΡΑΦΕΤΑΙ. Η εφαρμογή κρατάει
    ανοιχτές τις συνδέσεις SQLAlchemy όσο τρέχει, οπότε το αντίγραφο της
    βάσης κατά την εγκατάσταση έπεφτε με «the file is being used by
    another process» — ή, χειρότερο, έπαιρνε ένα ασυνεπές αντίγραφο.

    ΤΟ ΙΔΙΟ ΠΡΟΒΛΗΜΑ ΛΥΘΗΚΕ ΗΔΗ ΣΤΟ `app/backup.py` για την επαναφορά από
    αντίγραφο, με την ίδια ακριβώς λογική. Το κόβω εδώ γιατί η εγκατάσταση
    ενημέρωσης είναι το ΙΔΙΟ πρόβλημα σε ΑΛΛΟ σημείο, και το επαναλαμβάνω
    σε δύο μέρη.

    ΔΕΝ ΣΠΑΤΑΙ Η ΕΦΑΡΜΟΓΗ. Το `dispose()` κλείνει τις συνδέσεις, όχι την
    εφαρμογή· η επόμενη ερώτηση ανοίγει καινούρια σύνδεση μόνη της. Αν η
    ενημέρωση αποτύχει, η ιδιοκτήτρία συνεχίζει να δουλεύει κανονικά.
    """
    try:
        from app.extensions import db
        db.engine.dispose()
    except Exception:                                   # noqa: BLE001
        # Αν δεν κλείσουν οι συνδέσεις, το αντίγραφο θα πέσει με καθαρό
        # μήνυμα. Προτιμώτερο από το να σπάσει κάτι άλλο εδώ.
        pass


def _backup_database() -> Path:
    """Αντίγραφο της βάσης. ΣΗΚΩΝΕ UpdateError με την ΠΡΑΓΜΑΤΙΚΗ αιτία.

    Ο τρόπος του 1.0.2 επέστρεφε `None` σε κάθε αποτυχία και η
    εγκατάσταση έλεγε «Δεν ήταν δυνατό το αντίγραφο» — χωρίς διαδρομή,
    χωρίς αιτία. Στο αληθινό μηχάνημα της ιδιοκτήτριας η ενημέρωση
    σταμάτησε ακριβώς εκεί, χωρίς να λες πού έφτιαξε λάθος. Τώρα ο
    λόγος περνάει από τον migrate, που ξέρει το απόλυτο μονοπάτι και το
    συγκεκριμένο σφάλμα.

    ΧΩΡΙΣ try/except εδώ επίτηδες: το UpdateError του migrate έχει ήδη
    την πλήρη περιγραφή. Το πιάζαμε και το ξαναγράφαμε ως «Αποτυχία
    αντιγράφου της βάσης:» χωρίς τίποτα άλλο — χαμένη πληροφορία.
    """
    backup_dir().mkdir(parents=True, exist_ok=True)
    import migrate
    return migrate.backup_database()


def _run_in_release(release: Path, argv: list[str], timeout: int = 900) -> tuple[int, str]:
    """Εκτελεί μια εντολή με τον φάκελο της έκδοσης στο sys.path."""
    env = dict(os.environ)
    env["PYTHONPATH"] = str(release)
    env["PYTHONIOENCODING"] = "utf-8"
    proc = subprocess.run(
        [sys.executable] + argv,
        cwd=str(release), env=env, timeout=timeout,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        creationflags=_NO_WINDOW,
    )
    return proc.returncode, proc.stdout.decode("utf-8", "replace")


def _install_dependencies(release: Path) -> tuple[bool, str]:
    """Εγκατάσταση βιβλιοθηκών, όπως ζητήθηκε. Η έξοδος κρατιέται για διάγνωση."""
    requirements = release / "requirements.txt"
    if not requirements.is_file():
        return True, "Δεν χρειάζονται νέες βιβλιοθήκες."
    before = _installed_packages()
    # ΤΑ ΟΡΙΑ ΕΙΝΑΙ ΡΗΤΑ, ΟΧΙ ΣΤΑ ΠΡΟΕΠΙΛΟΓΑ ΤΟΥ PIP. Χωρίς --timeout και
    # --retries, το pip κρατά ό,τι έχει η έκδοσή του (15s × 5 σήμερα), άρα η
    # συμπεριφορά αλλάζει ανάμεσα σε αναβαθμίσεις. Με ρητές παραμέτρους, ένα
    # σκοτωμένο internet το καταλαβαίνει σε ~40s αντί να ξοδεύει λεπτά.
    #
    # Το όριο των 600s (10 λεπτά) είναι το εφελαδικό: η εφαρμογή είναι
    # ΚΛΕΙΣΤΗ σε συντήρηση όσο τρέχει αυτό. Με τα προηγούμενα 30 λεπτά, ένα
    # κόψιμο του internet στη μέση άφηνε το σαλόνι κλειστό μισή ώρα — και η
    # μόνη λύση ήταν να ξαναμπει ο ιδιοκτήτης.
    code, out = _run_in_release(
        release, ["-m", "pip", "install", "--disable-pip-version-check",
                  "--timeout", "20", "--retries", "2",
                  "-r", "requirements.txt"], timeout=600)
    if code != 0:
        return False, out
    after = _installed_packages()
    added = sorted(set(after) - set(before))
    detail = ("Νέες βιβλιοθήκες: " + ", ".join(added)) if added else \
             "Οι βιβλιοθήκες είναι ήδη εγκατεστημένες."
    return True, detail + "\n" + out[-1500:]


def _installed_packages() -> list[str]:
    code, out = _run_in_release(Path.cwd(), ["-m", "pip", "freeze"], timeout=120)
    if code != 0:
        return []
    return [line.strip() for line in out.splitlines() if line.strip()]


def _health_check(release: Path) -> tuple[bool, str]:
    """Ελέγχει σε ξεχωριστή διεργασία ότι η νέα έκδοση σηκώνεται και η βάση
    είναι προσβάσιμη. Έτσι αποτυχία εντοπίζεται ΠΡΙΝ την επανεκκίνηση."""
    script = (
        "import sys; sys.path.insert(0, %r)\n"
        "from app import create_app\n"
        "from app.extensions import db\n"
        "app = create_app()\n"
        "with app.app_context():\n"
        "    db.engine.connect()\n"
        "print('HEALTH_OK')\n" % str(release)
    )
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    try:
        proc = subprocess.run([sys.executable, "-c", script], cwd=str(release),
                              env=env, timeout=120,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              creationflags=_NO_WINDOW)
    except subprocess.TimeoutExpired:
        return False, "Ο έλεγχος απάντησε με καθυστέρηση — πιθανόν κάτι κολλάει."
    out = proc.stdout.decode("utf-8", "replace")
    if proc.returncode == 0 and "HEALTH_OK" in out:
        return True, out.strip().splitlines()[-1][:200]
    return False, out[-1500:]


def install_update(info: UpdateInfo, report: InstallReport | None = None) -> InstallReport:
    """Εγκαθιστά την ενημέρωση. Έως το τέλος, η παλιά έκδοση συνεχίζει να τρέχει."""
    from flask import current_app

    reason = unsupported_reason()
    if reason:
        raise UpdateError(reason)

    report = report or InstallReport()
    report.add("Έλεγχος υπογραφής", True, f"Έκδοση {info.version}")

    # Το αντίγραφο είναι το ΜΟΝΟ που κρατά τα δεδομένα της ιδιοκτήτριας.
    # Αποτυγχάνει, η εγκατάσταση σταματά — με τον πραγματικό λόγο.
    #
    # ΠΡΩΤΑ ΑΦΗΝΟΥΜΕ ΤΗ ΒΑΣΗ. Στα Windows ένα ανοιχτό αρχείο δεν
    # αντιγράφεται, και η εφαρμογή κρατάει τις συνδέσεις της ανοιχτές όσο
    # τρέχει. Αυτό ήταν το σφάλμα στο αληθινό μηχάνημα: «Δεν ήταν δυνατό το
    # αντίγραφο». Η ιδιοκτήτρια ρώτησε σωστά αν δεν έπρεπε να κλείσει η
    # εφαρμογή — και όχι μόνο δεν χρειάζεται, αλλά ούτε θα ήταν σωστό να το
    # ζητήσουμε από αυτήν. Βλ. _release_db_handles().
    _release_db_handles()
    backup = _backup_database()
    report.add("Αντίγραφο βάσης", True, str(backup.name))

    archive, manifest = _download_and_verify(info, int(current_app.config["UPDATE_MAX_MB"]))
    report.add("Λήψη και επαλήθευση υπογραφής", True, f"{archive.stat().st_size} bytes")

    staged = staging_dir()
    total = _extract_verified(archive, manifest, staged)
    report.add("Αποσυμπόληση", True, f"{len(manifest['files'])} αρχεία, {total} bytes")

    # Ο φάκελος της νέας έκδοσης: timestamped, ώστε να μένουν και οι παλιές.
    stamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    name = f"release-{stamp}"
    releases_dir().mkdir(parents=True, exist_ok=True)
    target = releases_dir() / name
    shutil.move(str(staged), str(target))
    (target / "release.json").write_text(json.dumps({
        "version": info.version,
        "installed_at": datetime.now().isoformat(timespec="seconds"),
        "notes": info.notes,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    report.add("Παρασκευή έκδοσης", True, name)

    if current_app.config.get("UPDATE_AUTO_PIP", True):
        ok, out = _install_dependencies(target)
        report.add("Εγκατάσταση βιβλιοθηκών", ok,
                   out.strip().splitlines()[-1][:160] if ok else "", out)
        if not ok:
            shutil.rmtree(target, ignore_errors=True)
            raise UpdateError("Η εγκατάσταση βιβλιοθηκών απέτυχε — η έκδοση απορρίφθηκε.")
    else:
        report.add("Εγκατάσταση βιβλιοθηκών", True, "Παρακάμφθηκε (UPDATE_AUTO_PIP=0)")

    if (target / "migrate.py").is_file():
        code, out = _run_in_release(target, ["migrate.py"])
        report.add("Μετατροπές βάσης", code == 0, "", out)
        if code != 0:
            _restore_database(backup)
            shutil.rmtree(target, ignore_errors=True)
            raise UpdateError("Οι μετατροπές βάσης απέτυχαν — επαναφέρθηκε το αντίγραφο.")
    else:
        # Πακέτο χωρίς migrate.py: δεν υπάρχει τίποτα να τρέξει, και το schema
        # μένει όπως ήταν. Τα πακέτα του build_update.py το περιέχουν πάντα·
        # αυτό αφορά μόνο ελάχιστα/χειροκίνητα πακέτα χωρίς αλλαγές στο schema.
        report.add("Μετατροπές βάσης", True, "Το πακέτο δεν περιέχει migrate.py")

    ok, detail = _health_check(target)
    report.add("Έλεγχος υγείας νέας έκδοσης", ok, "" if ok else detail[:300])
    if not ok:
        _restore_database(backup)
        shutil.rmtree(target, ignore_errors=True)
        raise UpdateError("Η νέα έκδοση δεν σηκώθηκε — επαναφέρθηκε η παλιά.")

    previous = release_folder_name(active_release())
    set_active_release(name)
    record_install(info.version, name, previous)
    report.add("Ενεργοποίηση", True, f"{previous} → releases/{name}")

    # ΤΕΛΙΚΟΣ ΚΑΘΑΡΙΣΜΟΣ. Μετά την ενεργοποίηση, όχι πριν: αν η ενημέρωση
    # αποτύχει σε οποιοδήποτε βήμα, ο φάκελος της παλιότερης έκδοσης πρέπει
    # να υπάρχει ακόμα για την επαναφορά. Εδώ η ενημέρωση έχει πετύχει και
    # το `previous` έχει ήδη καταγραφεί, οπότε κρατάμε ακριβώς αυτό και το
    # ενεργό — όσα ακριβώς χρειάζεται το rollback, και τίποτα παραπάνω.
    try:
        pruned = prune_after_install(info.version)
        freed_mb = pruned["freed"] / (1024 * 1024)
        total = pruned["releases"] + pruned["downloads"] + pruned["backups"]
        if total:
            report.add("Καθαρισμός", True,
                       f"{total} παλιά αρχεία, {freed_mb:.1f} MB ελεύθερα "
                       f"(κρατήθηκαν η τρέχουσα και η προηγούμενη έκδοση)")
    except Exception as exc:                            # noqa: BLE001
        # ΠΟΤΕ δεν κάνει την εγκατάσταση να αποτύχει ο καθαρισμός.
        report.add("Καθαρισμός", True,
                   f"παραλείφθηκε ({type(exc).__name__}) — η εγκατάσταση "
                   f"έγινε κανονικά")
    return report


def _restore_database(backup: Path) -> bool:
    """Επαναφέρει τη βάση από αντίγραφο. True αν πέτυχε.

    ΑΥΤΟ ΕΙΝΑΙ ΤΟ ΑΣΦΑΛΕΣ ΔΙΚΤΥΟ ΤΗΣ ΕΝΗΜΕΡΩΣΗΣ. Όταν κάτι πάει στραβά
    μετά το αντίγραφο, καλείται εδώ για να γυρίσουν τα δεδομένα της
    ιδιοκτήτριας πίσω. Γι' αυτό δεν μπορεί να αποτυγχάνει σιωπηλά.

    ΕΙΧΕ ΤΑ ΙΔΙΑ ΔΥΟ ΣΦΑΛΜΑΤΑ ΜΕ ΤΟ ΑΝΤΙΓΡΑΦΟ, ΚΑΙ ΣΤΑ WINDOWS ΕΠΕΦΑΝΕ:
    η χειρουργική επέμβαση στο URL έδινε μη υπαρκτό μονοπάτι χωρίς ριζικό,
    και το shutil.copy2 δεν δουλεύει σε ανοιχτό αρχείο. Μαζί με τη
    `except: return False`, μια αποτυχημένη ενημέρωση θα άφηνε τη βάση
    ασυνεπή ενώ το μήνυμα έλεγε «τα δεδομένα σου είναι ασφαλή».
    """
    try:
        import migrate
        # ΙΔΙΑ ΠΗΓΗ ΑΛΗΘΕΙΑΣ με το αντίγραφο: η SQLite λέει πού είναι το
        # πραγματικό αρχείο, όχι η αλφαβητική επεξεργασία του URL.
        found = migrate.database_file()
        if found is None or not found.is_file():
            return False
        # ΠΡΩΤΑ ΑΦΗΝΟΥΜΕ ΤΗ ΒΑΣΗ. Χωρίς αυτό, στα Windows το αντίγραφο
        # πέφτει επειδή η ίδια η εφαρμογή κρατάει το αρχείο ανοιχτό.
        _release_db_handles()
        shutil.copy2(backup, found)
        return True
    except Exception:                                   # noqa: BLE001
        return False


#: Πόσα αντίγραφα της βάσης κρατάμε. Το πιο πρόσφατο είναι πάντα το
#: «εφεδρικό» της τελευταίας εγκατάστασης· τα παλιότερα είναι ιστορικό.
BACKUPS_KEPT = 5


def _prune_releases() -> tuple[int, int]:
    """Κρατά το ενεργό και το προηγούμενο φάκελο έκδοσης. Τα υπόλοιπα φεύγουν.

    Το `rollback()` διαβάζει ΜΟΝΟ το `previous_release`. Κρατώντας και τα
    παλαιότερα δεν προσθέτουμε επιλογή — προσθέτουμε μόνο δίσκο και τον
    κίνδυνο να μπερδέψει κανείς ποια έκδοση τρέχει."""
    base = releases_dir()
    if not base.is_dir():
        return 0, 0
    state = installed_state()
    # ΤΟ ΒΑΣΙΚΟ ΜΠΟΡΙΟ ΠΟΥ ΣΚΑΒΕ Ο ΚΑΘΑΡΙΣΜΟΣ, ΚΑΙ ΤΟ ΤΕΣΤ ΤΟ ΠΙΑΣΕ.
    #
    # Το `active_release()` επιστρέφει ΣΧΕΤΙΚΗ ΔΙΑΔΡΟΜΗ: "releases/<φάκελος>".
    # Το όνομα του φακέλου όμως είναι "<φάκελος>". Άρα αν τα συγκρίνεις
    # κατευθείαν, το `child.name` ΠΟΤΕ δεν ταιριάζει με τον ενεργό — και ο
    # καθαρισμός διέγραφε τον φάκελο ΑΠΟ ΤΟΝ ΟΠΟΙΟ ΤΡΕΧΕΙ Η ΕΦΑΡΜΟΓΗ.
    #
    # Στα Windows θα έπεφτε με «το αρχείο χρησιμοποιείται», στο macOS θα το
    # έσβηνε σιωπηλά και μετά η επόμενη εκκίνηση θα δεν ξεκινούσε. Η ίδια
    # γλώσσα υπάρχει ήδη λίγες γραμμές πιο πάνω, στην εγκατάσταση:
    # `previous = release_folder_name(active_release())`. Το πρέπει να το
    # κάνει και ο καθαρισμός — μια κενή διαφορά ονόματος γίνεται διαγραφή.
    keep = {ROOT_RELEASE, release_folder_name(active_release()),
            release_folder_name(str(state.get("previous_release") or ""))}
    keep.discard("")
    freed = 0
    removed = 0
    for child in base.iterdir():
        # ΜΟΝΟ ό,τι έχει τη σωστή μορφή ονόματος. Οτιδήποτε άλλο μένει.
        if not child.is_dir() or not _RELEASE_RE.match(child.name):
            continue
        if child.name in keep:
            continue
        freed += _dir_size(child)
        shutil.rmtree(child, ignore_errors=True)
        removed += 1
    return removed, freed


def _dir_size(path: Path) -> int:
    total = 0
    try:
        for item in path.rglob("*"):
            if item.is_file():
                total += item.stat().st_size
    except OSError:
        pass
    return total


def _prune_downloads(keep_version: str) -> tuple[int, int]:
    """Κρατά το zip της τρέχουσας έκδοσης· τα παλαιότερα φεύγουν.

    Το zip της τρέχουσας δεν χρησιμεύει ούτε μετά την εγκατάσταση (έχει
    ήδη αποσυμπαστεί), αλλά το κρατάω: αν η εγκατάσταση αποτύχει μετά την
    αποσυμπόληση, χρειάζεται για να ξαναγίνει χωρίς δίκτυο. Ένας τοίχος από
    παλιά zip δεν προσθέτει τίποτα."""
    base = updates_dir()
    if not base.is_dir():
        return 0, 0
    keep = f"update-{keep_version}.zip" if keep_version else ""
    freed = removed = 0
    for child in base.glob("update-*.zip"):
        if child.name == keep:
            continue
        try:
            freed += child.stat().st_size
            child.unlink()
            removed += 1
        except OSError:
            pass
    return removed, freed


def _prune_backups(source: Path) -> tuple[int, int]:
    """Κρατά τα πιο πρόσφατα `BACKUPS_KEPT` αντίγραφα της βάσης.

    Κάθε ενημέρωση κρατά ένα. Χωρίς όριο, ένα σαλόνι με μικρή βάση αποκτά
    ένα αντίγραφο ανά μήνα για χρόνια, χωρίς λόγο. Το πιο πρόσφατο είναι
    πάντα αυτό που χρειάζεται για ανάκτηση αν κάτι πάει στραβά."""
    pattern = f"{source.stem}.bak-*{source.suffix}"
    found = sorted(source.parent.glob(pattern),
                   key=lambda p: p.stat().st_mtime, reverse=True)
    freed = removed = 0
    for old in found[BACKUPS_KEPT:]:
        try:
            freed += old.stat().st_size
            old.unlink()
            removed += 1
        except OSError:
            pass
    return removed, freed


def prune_after_install(version: str = "") -> dict:
    """Καθαρίζει ό,τι έφερε η ενημέρωση. ΠΟΤΕ δεν αποτυγχάνει την εγκατάσταση.

    Καλείται ΑΦΟΥ η ενημέρωση έχει επιτύχει. Ό,τι και αν πάει στραβά εδώ,
    καταγράφεται στο log και τελειώνει — γιατί ο σκοπός του καθαρισμού
    είναι η τάξη στον δίσκο, όχι η επιτυχία της ενημέρωσης."""
    out = {"releases": 0, "downloads": 0, "backups": 0, "freed": 0}
    try:
        from migrate import database_file
        db_path = database_file()
    except Exception:                                   # noqa: BLE001
        db_path = None
    try:
        for key, fn in (
            ("releases", _prune_releases),
            ("downloads", lambda: _prune_downloads(version)),
            ("backups", lambda: _prune_backups(db_path) if db_path
             else (0, 0)),
        ):
            removed, freed = fn()
            out[key] = removed
            out["freed"] += freed
    except Exception as exc:                            # noqa: BLE001
        try:
            from app.mailer import log_line
            log_line(f"update: ο καθαρισμός μετά την εγκατάσταση "
                     f"απέτυχε ({exc}) — δεν επηρεάζει την εγκατάσταση.")
        except Exception:
            pass
    return out


def rollback() -> str:
    """Επιστρέφει στην προηγούμενη έκδοση. Επιστρέφει το όνομα φακέλου."""
    state = installed_state()
    previous = state.get("previous_release") or ""
    if not previous or previous == ROOT_RELEASE:
        raise UpdateError("Δεν υπάρχει προηγούμενη έκδοση για επιστροφή.")
    if not (releases_dir() / previous).is_dir():
        raise UpdateError(f"Ο φάκελος της προηγούμενης έκδοσης δεν βρέθηκε: {previous}")
    current = active_release()
    set_active_release(previous)
    record_install(state.get("version", ""), previous, current)
    return previous


# ------------------------------------------------------------- επανεκκίνηση

def request_restart(delay: float = 2.0, reason: str = "") -> None:
    """Ζητά επανεκκίνηση: το run_server.cmd ξανασκεκαλεί τη διεργασία.

    Η αίτηση που το καλεί έχει ήδη απαντήσει — δεν μπορεί να σκοτώσει τη
    δική της διεργασία. Γι' αυτό φεύγει ένα νήμα με καθυστέρηση.
    """
    if is_frozen():
        # Στο exe δεν ξανασκεκαλείται κανείς: το os._exit θα το έκλεινε για
        # πάντα. Εδώ δεν φτάνει, αλλά το ασφαλίζουμε.
        maintenance_off()
        raise UpdateError(unsupported_reason() or "Δεν επιτρέπεται επανεκκίνηση.")

    def _go():
        time.sleep(delay)
        try:
            maintenance_off()
        except Exception:
            pass
        os._exit(0)                 # το IIS ξανασκεκαλεί τη διεργασία

    threading.Thread(target=_go, name="update-restart", daemon=True).start()


# ------------------------------------------------- αυτόματος έλεγχος (server)

def background_check(app, interval_hours: int) -> threading.Thread | None:
    """Ένας νήμα που ρωτά περιοδικά αν υπάρχει ενημέρωση. Ποτέ δεν σκοτώνει την
    εφαρμογή αν αποτύχει — μόνο γράφει στο αρχείο καταγραφής."""
    from flask import current_app

    if not interval_hours or interval_hours <= 0:
        return None
    if unsupported_reason():
        return None

    def _due_for_update_check() -> bool:
        """Πέρασε ο χρόνος του ελέγχου ενημερώσεων; Διαβάζεται από το
        ΑΡΧΕΙΟ, όχι από μεταβλητή μνήμης: όταν το internet κολλήσει και
        ξαναφύγει, θέλουμε να ξαναελέγξουμε, όχι να περιμένουμε 12 ώρες από
        την τελευταία επιτυχημένη προσπάθεια — γιατί αυτή ήταν και παλιά.
        """
        try:
            age = (datetime.now()
                   - datetime.fromisoformat(read_check_cache().get("checked_at", "")))
            return age.total_seconds() >= interval_hours * 3600
        except (TypeError, ValueError):
            return True                  # χωρίς έγκυρη σήμανση: έλεγξε

    def _loop():
        # Μικρή καθυστέρηση ώστε η εκκίνηση να μη δεχτεί δύο χτυπήματα.
        time.sleep(90)
        while True:
            # ---- 1. ΣΥΝΔΕΣΗ. Μία φορά κάθε CONNECTIVITY_SECONDS, ανεξάρτητα
            # από το internet — αυτό είναι το μόνο που «μετράει» στο σαλόνι
            # όταν δεν υπάρχει internet. Ένα TCP connect, όχι λήψη αρχείου.
            online = None
            try:
                online = probe_internet()
                previous = internet_state()
                write_internet_state(online)
                if online and previous is False:
                    # Ήρθε πίσω το internet. Ο έλεγχος ενημερώσεων τρέχει
                    # αμέσως από την παρακάτω, χωρίς να περιμένει τον
                    # επόμενο κύκλο των 12 ωρών — αλλιώς η ιδιοκτήτρία θα
                    # έπρεπε να χειροκινήσει «Έλεγχος τώρα» για να το μάθει.
                    try:
                        from .mailer import log_line
                        log_line("Σύνδεση internet: επανήλθε.")
                    except Exception:
                        pass
            except Exception:
                online = None           # δεν ξέρουμε· μην κλείσουμε τη door

            # ---- 2. ΕΛΕΓΧΟΣ ΕΝΗΜΕΡΩΣΗΣ, ΜΟΝΟ online και ΜΟΝΟ αν το οφείλουμε.
            # Η «ΕΚΤΟΣ ΣΥΝΔΕΣΗΣ» ΕΙΝΑΙ ΤΟ ΣΗΜΑΝΤΙΚΟ: online is False ⇒
            # καμία προσπάθεια, καμία εξαίρεση, κανένα σφάλμα στο log.
            if online is not False and _due_for_update_check():
                try:
                    with app.app_context():
                        if not updates_configured():
                            return
                        info = check_for_update()
                        # ΤΟ ΚΡΙΣΙΜΟ: χωρίς αυτό το αποτέλεσμα χανόταν. Μόνο
                        # μία γραμμή στο log — η εφαρμογή δεν ήξερε τι είδε
                        # και δεν μπορούσε να ειδοποιήσει κανέναν στη σύνδεση.
                        write_check_cache(info)
                        if info.available:
                            from .mailer import log_line
                            log_line(f"Διαθέσιμη ενημέρωση {info.version} "
                                     f"(τρέχουσα {APP_VERSION})")
                except Exception as exc:
                    try:
                        from .mailer import log_line
                        log_line(f"Έλεγχος ενημέρωσης: {exc}")
                    except Exception:
                        pass

            time.sleep(CONNECTIVITY_SECONDS)

    thread = threading.Thread(target=_loop, name="update-check", daemon=True)
    thread.start()
    return thread
