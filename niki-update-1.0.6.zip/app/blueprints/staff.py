"""Εφαρμογή προσωπικού: dashboard, ημερολόγιο, πελάτες, κατοικίδια — Niki's Grooming Salon."""

from __future__ import annotations

from collections import defaultdict
from datetime import date as date_cls, datetime, time, timedelta

from flask import (Blueprint, current_app, flash, redirect, render_template,
                   request, send_file, url_for)
from flask_login import current_user
from sqlalchemy import func
from sqlalchemy.orm import joinedload

from ..availability import (
    REASON_LABELS,
    auto_assign_groomer,
    combine,
    first_conflict,
    slot_taken,
    parse_hhmm,
    salon_hours_for,
    slot_step,
    slots_for_date,
)
from ..extensions import db
from ..helpers import (
    MIN_SEARCH_CHARS,
    active_services,
    clean,
    form_bool,
    form_float,
    form_int,
    get_or_404,
    is_searchable,
    matches,
    owner_required,
    parse_date,
    plural,
    pet_ids_from_form,
    pricing_for,
    service_ids_from_form,
    service_quantities_from_form,
    staff_required,
)
from ..importexport import (HEADERS, TEMPLATE_COLUMNS,
                            export_customers, import_customers,
                            template_bytes)
from ..version import APP_VERSION
from ..models import (
    EXPENSE_CATEGORIES,
    EXPENSE_GENERAL,
    EXPENSE_STORE,
    OPEN_STATUSES,
    SOURCE_LABELS,
    SOURCE_PHONE,
    SPECIES,
    GENDERS,
    STATUS_CANCELLED,
    STATUS_COMPLETED,
    STATUS_CONFIRMED,
    STATUS_IN_PROGRESS,
    STATUS_NO_SHOW,
    STATUS_PENDING,
    WEEKDAYS,
    Appointment,
    AppointmentService,
    AvailabilityRule,
    Customer,
    Expense,
    ExpenseItem,
    Groomer,
    Notification,
    Pet,
    Service,
    TimeOff,
    User,
    expenses_between,
    fmt_money,
)
from ..reminders import KIND_REMINDER, due_reminders, send, upcoming_for_day

bp = Blueprint("staff", __name__, url_prefix="/staff")


@bp.before_request
@staff_required
def require_staff():
    return None


# ------------------------------------------------------------------ helpers
def _view_date() -> date_cls:
    return parse_date(request.args.get("date"), date_cls.today()) or date_cls.today()


def _final_price(subtotal: float) -> float | None:
    """Η τελική τιμή μετά την έκπτωση του καταστήματος.

    Επιστρέφει None όταν δεν υπάρχει έκπτωση, ώστε το price_override να
    παραμένει κενό και το άθροισμα των υπηρεσιών να είναι το τελικό ποσό.
    """
    discount = form_float("discount", 0.0)
    if discount <= 0:
        return None
    # Δεν επιτρέπεται αρνητικό τελικό ποσό ούτε έκπτωση μεγαλύτερη από το άθροισμα.
    return max(0.0, round(subtotal - discount, 2))


def _source_from_form() -> str:
    """Η πηγή του ραντεβού, μόνο αν είναι μία από τις γνωστές.

    ΠΡΙΝ ΑΥΤΟ Η ΠΗΓΗ ΔΕΝ ΕΛΕΓΧΟΤΑΝ: οποιοσδήποτε κείμενο έμπαινε στη βάση και
    εμφανιζόταν ακριβώς όπως ήταν στην κάρτα του ραντεβού. Το dropdown προσφέρει
    μόνο τρεις τιμές, αλλά το form στέλνεται από τον browser και μπορεί να
    περιέχει οτιδήποτε. Άγνωστη τιμή => προεπιλογή (τηλεφωνικά), όχι σφάλμα:
    η ιδιοκτήτρια δεν πρέπει να μένει χωρίς ραντεβού επειδή πέταξε ένα
    ασύνημο πεδίο στη φόρμα.
    """
    value = clean(request.form.get("source"))
    return value if value in SOURCE_LABELS else SOURCE_PHONE


def _pickup_details() -> tuple[str | None, str | None]:
    """(όνομα, τηλέφωνο) του ατόμου που παραλαμβάνει το κατοικίδιο.

    Κενά => παραλαμβάνει ο ίδιος ο πελάτης. Αν υπάρχει όνομα αλλά όχι
    τηλέφωνο, επιστρέφεται (όνομα, None) και ο χρήστης ενημερώνεται —
    δεν μπλοκάρουμε την κράτηση, αλλά το τονίζουμε.
    """
    name = clean(request.form.get("pickup_name"))
    phone = clean(request.form.get("pickup_phone"))
    if not name:
        # Όνομα χωρίς άτομο δεν σημαίνει τίποτα — καθαρίζουμε και το τηλέφωνο.
        return None, None
    return name[:120], (phone[:40] or None)


def _warn_missing_pickup_phone(name: str | None, phone: str | None) -> None:
    """Υπενθύμιση (όχι σφάλμα) αν το άτομο παραλαβής δεν έχει τηλέφωνο.

    Δεν μπλοκάρουμε την κράτηση — απλώς τονίζουμε ότι το σπα χρειάζεται
    ένα νούμερρο για να επικοινωνήσει αν κάτι πάει στραβά.
    """
    if name and not phone:
        flash(
            f"Προσοχή: ο «{name}» έχει οριστεί για την παραλαβή χωρίς τηλέφωνο.",
            "warning",
        )


MONTH_LABELS = ["Ιαν", "Φεβ", "Μαρ", "Απρ", "Μαΐ", "Ιουν", "Ιουλ", "Αυγ", "Σεπ", "Οκτ", "Νοέ", "Δεκ"]


def _month_name(day: date_cls) -> str:
    return MONTH_LABELS[day.month - 1]


def _groomers() -> list[Groomer]:
    return db.session.query(Groomer).join(Groomer.user).order_by(Groomer.sort_order, Groomer.id).all()


def default_groomer_id(groomers: list[Groomer]) -> int | None:
    """Ποια στυλίστρια προτείνεται στη φόρμα κράτησης.

    Η πρώτη στη σειρά (sort_order) είναι η κύρια του Salon, οπότε επιλέγεται
    αυτόματα· αν χρειαστεί άλλη, την αλλάζει η ιδιοκτήτρια.

    Εξαίρεση: αν η πρώτη δεν έχει καθόλου διαθεσιμότητα δεν προτείνεται — η
    φόρμα θα έδειχνε μηδέν διαθέσιμες ώρες. Τότε μένει η «Αυτόματη επιλογή».
    """
    bookable = [g for g in groomers if g.is_bookable]
    if not bookable:
        return None
    if db.session.query(AvailabilityRule.id).filter_by(groomer_id=bookable[0].id).first():
        return bookable[0].id
    return None


# ----------------------------------------------------------------- dashboard
@bp.route("/")
def dashboard():
    today = date_cls.today()
    now = datetime.now()
    todays = upcoming_for_day(today)
    open_today = [a for a in todays if a.status in OPEN_STATUSES]

    week_start = today - timedelta(days=today.weekday())
    week_end = week_start + timedelta(days=6)
    week_appointments = (
        Appointment.query.filter(
            Appointment.start_at >= datetime.combine(week_start, time(0, 0)),
            Appointment.start_at < datetime.combine(week_end + timedelta(days=1), time(0, 0)),
        )
        .order_by(Appointment.start_at)
        .all()
    )

    next_up = [a for a in todays if a.is_open and a.start_at >= now][:6]
    pending_reminders = due_reminders()
    due_pets = [p for p in db.session.query(Pet).filter_by(is_active_flag=True) if p.due_for_grooming][:8]

    month_start = today.replace(day=1)
    month_count = Appointment.query.filter(
        Appointment.status == STATUS_COMPLETED,
        Appointment.start_at >= datetime.combine(month_start, time(0, 0)),
    ).count()

    no_shows = Appointment.query.filter(
        Appointment.status == STATUS_NO_SHOW,
        Appointment.start_at >= datetime.combine(month_start, time(0, 0)),
    ).count()

    # Οικονομικά: τα έξοδα τα βλέπουν όλοι (τα καταχωρούν), τα έσοδα και το
    # καθαρό εισόδημα μόνο η ιδιοκτήτρια.
    month_end = (month_start + timedelta(days=32)).replace(day=1)
    today_expenses = expenses_between(today, today + timedelta(days=1))
    month_expenses = expenses_between(month_start, month_end)

    month_revenue = month_net = 0.0
    if current_user.is_owner:
        month_completed = Appointment.query.filter(
            Appointment.status == STATUS_COMPLETED,
            Appointment.start_at >= datetime.combine(month_start, time(0, 0)),
        ).all()
        month_revenue = sum(a.price_effective for a in month_completed)
        month_net = month_revenue - month_expenses

    week_bars = []
    peak = max(
        (len([a for a in week_appointments if a.start_at.date() == week_start + timedelta(days=i)])
         for i in range(7)),
        default=0,
    ) or 1
    for i in range(7):
        day = week_start + timedelta(days=i)
        items = [a for a in week_appointments if a.start_at.date() == day]
        week_bars.append(
            {
                "date": day,
                "iso": day.isoformat(),
                "label": day.strftime("%a %d/%m"),
                "count": len(items),
                "pct": round(len(items) / peak * 100),
                "is_today": day == today,
            }
        )

    return render_template(
        "staff/dashboard.html",
        today=today,
        todays=todays,
        open_today=open_today,
        next_up=next_up,
        week_appointments=week_appointments,
        week_bars=week_bars,
        week_start=week_start,
        week_end=week_end,
        month_count=month_count,
        no_shows=no_shows,
        pending_reminders=pending_reminders,
        due_pets=due_pets,
        today_expenses=today_expenses,
        month_expenses=month_expenses,
        month_revenue=month_revenue,
        month_net=month_net,
    )


# ----------------------------------------------------------------- calendar
@bp.route("/calendar")
def calendar():
    view = request.args.get("view", "day")
    day = _view_date()

    groomers = _groomers()
    if not groomers:
        # Χωρίς στυλίστρια δεν υπάρχει ποιος να εμφανιστεί, αλλά η γραμμή
        # εργαλείων (prev/next/«Σήμερα») χρειάζεται τις ίδιες μεταβλητές με την
        # κανονική διαδρομή — αλλιώς η σελίδα σπάει με σφάλμα 500.
        return render_template(
            "staff/calendar.html",
            view=view,
            day=day,
            today=date_cls.today(),
            is_today=True,
            groomers=[],
            columns=[],
            hours=[],
            total_slots=1,
            prev_day=day - timedelta(days=1),
            next_day=day + timedelta(days=1),
            empty=True,
        )

    if view == "week":
        days = [day - timedelta(days=day.weekday()) + timedelta(days=i) for i in range(7)]
        by_day = defaultdict(list)
        for d in days:
            by_day[d] = upcoming_for_day(d)
        grid = []
        for d in days:
            grid.append(
                {
                    "date": d,
                    "is_today": d == date_cls.today(),
                    "weekday": WEEKDAYS[d.weekday()],
                    "appointments": sorted(by_day[d], key=lambda a: a.start_at),
                }
            )
        return render_template(
            "staff/calendar_week.html",
            view=view,
            day=day,
            days=grid,
            groomers=groomers,
            total=sum(len(g["appointments"]) for g in grid),
            prev_week=(days[0] - timedelta(days=7)).isoformat(),
            next_week=(days[0] + timedelta(days=7)).isoformat(),
        )

    closed, salon_open, salon_close = salon_hours_for(day)
    step = slot_step()
    if closed:
        salon_open, salon_close = 9 * 60, 18 * 60

    appointments = upcoming_for_day(day)
    by_groomer = defaultdict(list)
    for appt in appointments:
        by_groomer[appt.groomer_id].append(appt)

    hours = []
    for m in range(salon_open, salon_close + step, step):
        hours.append({"minutes": m, "label": f"{m // 60:02d}:{m % 60:02d}", "hour": m % 60 == 0})

    # Η λωρίδα του ημερολογίου έχει μία γραμμή ανά slot και ύψος len(hours) * 30px.
    # Τα top/height των μπλοκ είναι ποσοστά επί του ύψους της λωρίδας, άρα ο
    # παρονομαστής είναι τα λεπτά που καλύπτει ολόκληρη η λωρίδα.
    lane_span = salon_close - salon_open + step

    def lane_pct(minutes: float) -> float:
        """Θέση σε λεπτά μέσα στη λωρίδα, ως ποσοστό του ύψους της."""
        return round(max(0.0, min(minutes, lane_span)) / lane_span * 100, 3)

    columns = []
    for groomer in groomers:
        items = sorted(by_groomer.get(groomer.id, []), key=lambda a: a.start_at)
        blocks = []
        for appt in items:
            start_min = appt.start_at.hour * 60 + appt.start_at.minute
            end_min = appt.end_at.hour * 60 + appt.end_at.minute
            top = lane_pct(start_min - salon_open)
            height = lane_pct(end_min - salon_open) - top
            blocks.append(
                {
                    "appointment": appt,
                    "top": top,
                    # ποτέ κάτω από 2.2% ώστε να φαίνεται πάντα ο τίτλος
                    "height": round(max(height, 2.2), 3),
                }
            )
        columns.append({"groomer": groomer, "blocks": blocks, "count": len(items)})

    prev_day = day - timedelta(days=1)
    next_day = day + timedelta(days=1)

    return render_template(
        "staff/calendar.html",
        view=view,
        day=day,
        today=date_cls.today(),
        now_parts=datetime.now(),
        is_today=day == date_cls.today(),
        salon_open=salon_open,
        salon_close=salon_close,
        salon_closed=closed,
        step=step,
        columns=columns,
        hours=hours,
        total_slots=max(1, len(hours)),
        lane_span=lane_span,
        prev_day=prev_day,
        next_day=next_day,
        empty=False,
        slot_labels=REASON_LABELS,
    )


@bp.route("/new-appointment", methods=["GET", "POST"])
def new_appointment():
    groomers = [g for g in _groomers() if g.is_bookable]
    customers = (
        db.session.query(Customer).order_by(Customer.name).all()
    )
    services = active_services()

    if request.method == "POST":
        customer = db.session.get(Customer, form_int("customer_id"))
        if customer is None:
            flash("Επιλέξτε πελάτη.", "error")
            return redirect(url_for("staff.new_appointment"))

        # Ένας πελάτης μπορεί να φέρει περισσότερα από ένα κατοικίδια.
        pet_ids = pet_ids_from_form() or ([form_int("pet_id")] if form_int("pet_id") else [])
        pets = [p for p in (db.session.get(Pet, i) for i in pet_ids if i) if p is not None]
        if not pets:
            flash("Επιλέξτε τουλάχιστον ένα κατοικίδιο.", "error")
            return redirect(url_for("staff.new_appointment"))

        service_ids = service_ids_from_form()
        chosen = db.session.query(Service).filter(Service.id.in_(service_ids)).all() if service_ids else []
        if not chosen:
            flash("Επιλέξτε τουλάχιστον μία υπηρεσία.", "error")
            return redirect(request.referrer or url_for("staff.new_appointment"))

        # Στιγμιότυπο τιμής: κρατά τη λιανική τιμή, ακόμη κι αν αλλάξει ο τιμοκατάλογος.
        quantities = service_quantities_from_form()
        total_price, total_duration = pricing_for(chosen, quantities)
        final_price = _final_price(total_price)
        # Η ώρα λήξης ακολουθεί το βήμα των slots, όχι τη διάρκεια των
        # υπηρεσιών: ένα slot είναι μία «μονάδα χρόνου» του σπα.
        slot_minutes = slot_step()
        pickup_name, pickup_phone = _pickup_details()

        day = parse_date(request.form.get("date"))
        start_min = parse_hhmm(request.form.get("time"))
        if day is None or start_min is None:
            flash("Συμπληρώστε ημερομηνία και ώρα.", "error")
            return redirect(request.referrer or url_for("staff.new_appointment"))

        start_at = combine(day, start_min)
        end_at = combine(day, start_min + slot_minutes)

        # Ο χρήστης επέλεξε συγκεκριμένη στυλίστρια; την τηρούμε. Πριν
        # γινόταν σιωπηρή ανάθεση σε άλλη όταν η επιλεγμένη ήταν απασχολημένη,
        # κι έτσι το ραντεβού έμπαινε σε λάθος άτομο χωρίς προειδοποίηση.
        chosen_groomer_id = form_int("groomer_id")
        if chosen_groomer_id:
            # ΤΟ ΟΝΟΜΑ ΣΕ ΙΔΙΑ ΜΕΤΑΒΛΗΤΗ. Το παλιό `chosen = next(...)` έπεφτε
            # πάνω στη λίστα των ΥΠΗΡΕΣΙΩΝ (γραμμή 410). Δεν έβλαπτε μόνο
            # επειδή εκεί ακολουθούσε return — αλλά η προειδοποίηση για την
            # κάλυψη ώρας διαβάζει το `chosen` σε ΔΙΑΦΟΡΕΤΙΚΗ ΣΕΙΡΑ, όπου δεν
            # έχει σκιαστεί, και έδειχνε στην ιδιοκτήτρια «([<Service 1>],
            # 01/10 15:00)» αντί για όνομα. Πλέον οι δύο χρήσεις είναι
            # ξεχωριστές μεταβλητές και δεν μπορούν να συγκρούσουν.
            groomer_name = next(
                (g.name for g in groomers if g.id == chosen_groomer_id),
                "Η επιλεγμένη στυλίστρια",
            )
            conflict = first_conflict(start_at, end_at, chosen_groomer_id)
            if conflict:
                # Δείχνουμε τον ΠΡΑΓΜΑΤΙΚΟ ΛΟΓΟ. Το «είναι απασχολημένη»
                # ήταν ψευδίσμα για όλα τα υπόλοιπα: αν δεν εργάζεται εκείνη
                # τη μέρα ή η ώρα είναι εκτός ωραρίου, η ιδιοκτήτρια έψαγνε
                # λάθος πρόβλημα (να αλλάξει ώρα ενώ το πρόβλημα ήταν το
                # ωράριο).
                flash(f"{conflict} ({groomer_name}, {start_at:%d/%m %H:%M})",
                      "error")
                return redirect(request.referrer or url_for("staff.new_appointment"))
            # ΠΡΟΕΙΔΟΠΟΙΗΣΗ, ΟΧΙ ΜΠΛΟΚ. Δύο πελάτες στην ίδια ώρα είναι
            # πιθανόν (ή η ιδιοκτήτρια γράφει αναδρομικά από τη μνήμη της).
            # Πριν το μπλοκαρμε, χανόταν ΟΛΗ ΤΗΝ ΕΓΓΡΑΦΗ: η ιδιοκτήτρια
            # έβλεπε σφάλμα χωρίς να μάθει ποια ώρα, και το ραντεβού χανόταν.
            warn = slot_taken(start_at, end_at, chosen_groomer_id)
            if warn:
                flash(f"{warn} ({groomer_name}, {start_at:%d/%m %H:%M})",
                      "warning")
            groomer_id = chosen_groomer_id
        else:
            # «Αυτόματη επιλογή»: παίρνει όποια είναι ελεύθερη εκείνη την ώρα.
            groomer_id = auto_assign_groomer(start_at, end_at)
            if groomer_id is None:
                flash("Δεν βρέθηκε διαθέσιμη στυλίστρια για αυτή την ώρα.", "error")
                return redirect(request.referrer or url_for("staff.new_appointment"))

        appointment = Appointment(
            customer_id=customer.id,
            pet_id=pets[0].id,          # παλιά στήλη: το πρώτο κατοικίδιο
            groomer_id=groomer_id,
            start_at=start_at,
            end_at=end_at,
            status=clean(request.form.get("status")) or STATUS_CONFIRMED,
            # Μόνο τιμές από το allowlist: αλλιώς οποιοσδήποτε κείμενο
            # αποθηκευόταν και εμφανιζόταν στην κάρτα του ραντεβού.
            source=_source_from_form(),
            total_price=total_price,
            price_override=final_price,
            pickup_name=pickup_name,
            pickup_phone=pickup_phone,
            customer_note=clean(request.form.get("note")) or None,
            staff_note=clean(request.form.get("staff_note")) or None,
            created_by_id=current_user.id,
        )
        appointment.pets = pets
        db.session.add(appointment)
        _set_service_links(appointment, chosen, quantities)
        db.session.commit()
        who = ", ".join((p.name or "χωρίς όνομα") for p in pets)
        flash(
            f"Επιβεβαιώθηκε ραντεβού για {who} στις {start_at:%d/%m %H:%M}.",
            "success",
        )
        _warn_missing_pickup_phone(pickup_name, pickup_phone)
        return redirect(url_for("staff.appointment_detail", appointment_id=appointment.id))

    selected_customer_id = request.args.get("customer", type=int)
    selected_pet_id = request.args.get("pet", type=int)
    preselected = db.session.get(Customer, selected_customer_id) if selected_customer_id else None
    initial_customer_json = (
        {
            "id": preselected.id,
            "pets": [
                {
                    "id": p.id,
                    "name": p.name,
                    "breed": p.breed or "",
                }
                for p in preselected.active_pets
            ],
        }
        if preselected
        else None
    )
    return render_template(
        "staff/appointment_form.html",
        groomers=groomers,
        default_groomer_id=default_groomer_id(groomers),
        customers=customers,
        services=services,
        today=date_cls.today(),
        selected_customer_id=selected_customer_id,
        selected_pet_id=selected_pet_id,
        preselected=preselected,
        initial_customer_json=initial_customer_json,
    )


# --------------------------------------------------------- appointment CRUD
@bp.route("/appointments/<int:appointment_id>")
def appointment_detail(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    # Ιστορικό του πελάτη (όχι ενός κατοικιδίου): το ραντεβού μπορεί να
    # αφορά περισσότερα από ένα κατοικίδιο ή κανένα με όνομα.
    all_appointments = sorted(appointment.customer.appointments, key=lambda a: a.start_at)
    index = next((i for i, a in enumerate(all_appointments) if a.id == appointment.id), None)
    history = all_appointments[max(0, index - 4): index + 1] if index is not None else []
    return render_template(
        "staff/appointment_detail.html",
        appointment=appointment,
        history=history,
    )


@bp.route("/appointments/<int:appointment_id>/edit", methods=["GET", "POST"])
def appointment_edit(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    services = active_services()
    groomers = _groomers()

    if request.method == "POST":
        chosen_ids = service_ids_from_form()
        chosen = db.session.query(Service).filter(Service.id.in_(chosen_ids)).all() if chosen_ids else []
        if not chosen:
            flash("Επιλέξτε τουλάχιστον μία υπηρεσία.", "error")
            return redirect(request.referrer or url_for("staff.appointment_edit", appointment_id=appointment.id))

        # Κάθε αποθήκευση ξανακρατά τις τιμές της στιγμής της κράτησης.
        quantities = service_quantities_from_form()
        total_price, _total_duration = pricing_for(chosen, quantities)
        final_price = _final_price(total_price)
        pickup_name, pickup_phone = _pickup_details()

        day = parse_date(request.form.get("date")) or appointment.start_at.date()
        start_min = parse_hhmm(request.form.get("time")) or appointment.start_at.hour * 60 + appointment.start_at.minute
        start_at = combine(day, start_min)
        end_at = combine(day, start_min + slot_step())
        groomer_id = form_int("groomer_id") or appointment.groomer_id

        conflict = first_conflict(start_at, end_at, groomer_id, exclude_appointment_id=appointment.id)
        if conflict:
            flash(f"Δεν είναι δυνατή η αλλαγή: {conflict}", "error")
            return redirect(request.referrer or url_for("staff.appointment_edit", appointment_id=appointment.id))

        # Η ΙΔΙΑ ΠΡΟΕΙΔΟΠΟΙΗΣΗ ΚΑΙ ΣΤΗΝ ΑΛΛΑΓΗ, ΑΛΛΑ ΕΔΩ. Μετακινώ το
        # ραντεβού επάνω σε ώρα που έχει ήδη κάτι: συμβαίνει, είτε από
        # λάθος επιλογή είτε επειδή έχει δύο πελάτες εκείνη την ώρα.
        # Πριν το μπλοκαρμε, η αλλαγή χανόταν ολόκληρη.
        #
        # ΕΔΩ ΚΑΙ ΟΧΙ ΜΕΣΑ ΣΤΟ `if conflict:`. Μέσα, ο κώδικας είναι
        # νεκρός (ακολουθεί return) και η μεταβλητή δεν ορίζεται στην
        # κανονική πορεία — UnboundLocalError στο `if edit_warn:` και 500
        # ΣΕ ΚΑΘΕ ΕΠΙΤΥΧΗΜΕΝΗ ΑΛΛΑΓΗ, αφού το ραντεβού είχε ήδη
        # αποθηκευτεί. Η ιδιοκτήτρια έβλεπε «Κάτι πήγε στραβά» ενώ η
        # αλλαγή είχε γίνει.
        edit_warn = slot_taken(start_at, end_at, groomer_id,
                               exclude_appointment_id=appointment.id)

        pet_ids = pet_ids_from_form() or ([form_int("pet_id")] if form_int("pet_id") else [])
        new_pets = [x for x in (db.session.get(Pet, i) for i in pet_ids if i) if x is not None]
        if new_pets:
            appointment.pets = new_pets
            appointment.pet_id = new_pets[0].id
        appointment.groomer_id = groomer_id
        appointment.start_at = start_at
        appointment.end_at = end_at
        appointment.status = clean(request.form.get("status")) or appointment.status
        appointment.total_price = total_price
        appointment.price_override = final_price
        appointment.pickup_name = pickup_name
        appointment.pickup_phone = pickup_phone
        appointment.customer_note = clean(request.form.get("note")) or None
        appointment.staff_note = clean(request.form.get("staff_note")) or None
        _set_service_links(appointment, chosen, quantities)
        db.session.commit()
        flash("Το ραντεβού ενημερώθηκε.", "success")
        # Η ΠΡΟΕΙΔΟΠΟΙΗΣΗ ΜΕΤΑ ΤΗΝ ΕΠΙΤΥΧΙΑ, ώστε να μην την κρύβει
        # το μήνυμα «ενημερώθηκε». Η αλλαγή έγινε — απλώς να το ξέρει.
        if edit_warn:
            flash(edit_warn, "warning")
        _warn_missing_pickup_phone(pickup_name, pickup_phone)
        return redirect(url_for("staff.appointment_detail", appointment_id=appointment.id))

    # Ο επεξεργαστής χρειάζεται τη λίστα πελατών και το preselect JSON,
    # ώστε το form να δουλεύει και χωρίς JavaScript.
    owner_customer = appointment.customer
    initial_customer_json = {
        "id": owner_customer.id,
        "pets": [
            {
                "id": p.id,
                "name": p.name,
                "breed": p.breed or "",
            }
            for p in owner_customer.pets
        ],
    }
    return render_template(
        "staff/appointment_form.html",
        appointment=appointment,
        groomers=groomers,
        # Στην επεξεργασία κρατάμε τη στυλίστρια του ραντεβού· αν δεν υπάρχει
        # πια, προτείνεται η πρώτη.
        default_groomer_id=appointment.groomer_id or default_groomer_id(groomers),
        customers=[owner_customer],
        services=services,
        today=date_cls.today(),
        selected_customer_id=appointment.customer_id,
        selected_pet_id=appointment.pet_id,
        preselected=owner_customer,
        initial_customer_json=initial_customer_json,
    )


@bp.route("/appointments/<int:appointment_id>/status", methods=["POST"])
def appointment_status(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    status = clean(request.form.get("status")) or appointment.status
    valid = {STATUS_PENDING, STATUS_CONFIRMED, STATUS_IN_PROGRESS, STATUS_COMPLETED,
             STATUS_CANCELLED, STATUS_NO_SHOW}
    if status not in valid:
        flash("Μη έγκυρη κατάσταση.", "error")
        return redirect(request.referrer or url_for("staff.calendar"))
    appointment.status = status
    if status == STATUS_CANCELLED:
        appointment.cancel_reason = clean(request.form.get("reason")) or None
    db.session.commit()
    flash(f"Κατάσταση: {appointment.status_label}", "success")
    return redirect(request.referrer or url_for("staff.appointment_detail", appointment_id=appointment.id))


@bp.route("/appointments/<int:appointment_id>/notes", methods=["POST"])
def appointment_notes(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    appointment.staff_note = clean(request.form.get("staff_note")) or None
    db.session.commit()
    flash("Η σημείωση αποθηκεύτηκε.", "success")
    return redirect(request.referrer or url_for("staff.appointment_detail", appointment_id=appointment.id))


@bp.route("/appointments/<int:appointment_id>/remind", methods=["POST"])
def appointment_remind(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    send(KIND_REMINDER, appointment)
    db.session.commit()
    flash("Στάλθηκε υπενθύμιση στον πελάτη (βλ. logs/notifications.log).", "success")
    return redirect(request.referrer or url_for("staff.appointment_detail", appointment_id=appointment.id))


@bp.route("/appointments/<int:appointment_id>/delete", methods=["POST"])
def appointment_delete(appointment_id: int):
    appointment = get_or_404(Appointment, appointment_id, "Το ραντεβού δεν βρέθηκε.")
    label = appointment.pets_label
    db.session.delete(appointment)
    db.session.commit()
    flash(f"Το ραντεβού για {label} διαγράφηκε.", "info")
    return redirect(url_for("staff.calendar"))


# -------------------------------------------------------------- πελάτες
@bp.route("/clients")
def clients():
    search = clean(request.args.get("q"))
    # Κάτω από 3 γράμματα δεν φιλτράρουμε: δείχνουμε όλους και
    # υπενθυμίζουμε πόσα γράμματα χρειάζεται η αναζήτηση.
    filtering = is_searchable(search)
    query = db.session.query(Customer)
    if filtering:
        query = query.options(joinedload(Customer.pets))
    rows = query.order_by(Customer.name).all()

    if filtering:
        rows = [
            c for c in rows
            if matches(
                search, c.name, c.email, c.phone,
                c.address, c.notes, *[(pet.name or '') for pet in c.pets],
            )
        ]

    enriched = []
    for customer in rows:
        visits = db.session.query(func.count(Appointment.id)).filter(
            Appointment.customer_id == customer.id,
            Appointment.status == STATUS_COMPLETED,
        ).scalar()
        last = (
            db.session.query(func.max(Appointment.start_at))
            .filter(Appointment.customer_id == customer.id,
                    Appointment.status == STATUS_COMPLETED)
            .scalar()
        )
        upcoming = db.session.query(func.count(Appointment.id)).filter(
            Appointment.customer_id == customer.id,
            Appointment.status.in_(OPEN_STATUSES),
            Appointment.start_at >= datetime.now(),
        ).scalar()
        enriched.append(
            {
                "customer": customer,
                "visits": visits or 0,
                "last_visit": last,
                "upcoming": upcoming or 0,
                "pets": customer.active_pets,
            }
        )

    return render_template(
        "staff/clients.html",
        rows=enriched,
        search=search,
        filtering=filtering,
        min_chars=MIN_SEARCH_CHARS,
    )


# ──────────────────────────────────────────────── εισαγωγή / εξαγωγή Excel
# ΜΟΝΟ Η ΙΔΙΟΚΤΗΤΡΙΑ. Ο @owner_required ελέγχει τη διαδρομή στον δι��κομιστή,
# όχι μόνο το κουμπί: αλλιώς η εισαγωγή 3.000 πελατών γίνεται με ένα URL.
import io
import re


#: Όριο μεγέθους αρχείου. Το config έχει MAX_CONTENT_LENGTH στα 4 MB για
#: όλα· εδώ θέλουμε κάτι πολύ μικρότερο, γιατί ένα πρότυπο με χιλιάδες
#: πελάτες είναι 200–400 KB. Τα 4 MB θα ήταν ανεξέλεγκτα για κάτι που
#: δεν χρειάζεται ποτέ.
MAX_IMPORT_BYTES = 2 * 1024 * 1024

ALLOWED_EXT = {".xlsx", ".xlsm", ".csv", ".xls", ".txt"}


#: Ελληνικά → λατινικά, ΓΙΑ ΜΟΝΟ ΤΟ ΟΝΟΜΑ ΤΟΥ ΑΡΧΕΙΟΥ. Το περιεχόμενο
#: παραμένει ελληνικό· αλλάζει μόνο η ετικέτα στη λήψη.
#: Κτίζεται ΑΥΤΟΜΑΤΑ και για τα κεφαλαία. Με χέρι, τα «Πελάτες» έβγαιναν
#: «Πelates» — μισό ελληνικό, μισό λατινικό, και μπερδεμένα. Ο κανόνας
#: «κεφαλαίο προς κεφαλαίο, πεζό προς πεζό» δεν πρέπει να ξεχνιέται.
_GREEK_PAIRS = {
    "α": "a", "β": "v", "γ": "g", "δ": "d", "ε": "e", "ζ": "z", "η": "i",
    "θ": "th", "ι": "i", "κ": "k", "λ": "l", "μ": "m", "ν": "n", "ξ": "x",
    "ο": "o", "π": "p", "ρ": "r", "ς": "s", "σ": "s", "τ": "t", "υ": "y",
    "φ": "f", "χ": "ch", "ψ": "ps", "ω": "o",
    "ά": "a", "έ": "e", "ή": "i", "ί": "i", "ό": "o", "ύ": "y", "ώ": "o",
    "ϊ": "i", "ϋ": "y", "ΐ": "i", "ΰ": "y",
}
_GREEK_LATIN: dict[int, str] = {}
for _greek, _latin in _GREEK_PAIRS.items():
    _GREEK_LATIN[ord(_greek)] = _latin
    # Το «ΐ».upper() δίνει «Ϊ́» — δύο χαρακτήρες, τον Ϊ και έναν τονισμό
    # που έμπασε μαζί. Χωρίς το [0], ο ord() πέφτει με TypeError.
    _GREEK_LATIN[ord(_greek.upper()[0])] = _latin.capitalize()


def download_name(raw: str, fallback: str = "pelates.xlsx") -> str:
    """Καθαρίζει το όνομα αρχείου για την κεφαλίδα Content-Disposition.

    ΧΩΡΙΣ ΑΥΤΟ ΥΠΑΡΧΕΙ ΠΡΟΒΛΗΜΑ: ένα όνομα με αλλαγή γραμμής ή κωδικούς
    ελέγχου μπαίνει στην επικεφαλίδα απάντησης και σε κάποιους browsers
    κάνει header injection. Το όνομα προέρχεται από τον χρήστη, άρα το
    θεωρούμε εχθρικό.

    ΚΑΙ ΛΑΤΙΝΙΚΑ ΓΙΑΤΙ: το Werkzeug βγάζει δύο εκδόσεις — το κανονικό
    filename= και το filename*=UTF-8. Στο πρώτο κόβει ό,τι δεν είναι
    ASCII, και έτσι το «πρότυπο-πελατών-1.0.2.xlsx» έφτανε ως
    «--1.0.2.xlsx». Οι σύγχρονοι browsers χρησιμοποιούν το filename*, αλλά
    ένα αρχείο που αποθηκεύτηκε με κενό όνομα είναι μπέχα για την ιδιοκτήτρια.
    Άρα: λατινικά, ώστε να διαβάζεται και στις δύο εκδόσεις."""
    import unicodedata
    name = (raw or "").strip().split("/")[-1].split("\\")[-1]
    # Οι τόνοι φεύγουν πρώτοι· μετά η μεταγραφή σε λατινικά.
    name = "".join(c for c in unicodedata.normalize("NFD", name)
                   if not unicodedata.combining(c))
    name = name.translate(_GREEK_LATIN)
    name = "".join(ch for ch in name if ch.isalnum() or ch in " ._-()")
    name = re.sub(r"\s+", " ", name).strip(" .-")
    return name[:80] or fallback


def _send_xlsx(payload: bytes, name: str):
    return send_file(
        io.BytesIO(payload),
        mimetype="application/vnd.openxmlformats-officedocument."
                 "spreadsheetml.sheet",
        as_attachment=True,
        download_name=download_name(name),
    )


@bp.route("/clients/import", methods=["GET", "POST"])
@owner_required
def clients_import():
    """Η σελίδα εισαγωγής και η ίδια η διαδικασία — owner only."""
    if request.method == "GET":
        return render_template("staff/clients_import.html",
                               columns=TEMPLATE_COLUMNS, headers=HEADERS)

    upload = request.files.get("file")
    if upload is None or not (upload.filename or "").strip():
        flash("Δεν επιλέχθηκε αρχείο.", "error")
        return redirect(url_for("staff.clients_import"))

    filename = upload.filename or ""
    ext = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    if ext and ext not in ALLOWED_EXT:
        flash(f"Ο τύπος «{ext}» δεν υποστηρίζεται. Χρησιμοποίησε .xlsx ή .csv.",
              "error")
        return redirect(url_for("staff.clients_import"))

    # Ανάγνωση ΣΤΗ ΜΝΗΜΗ. Κανένα αρχείο δεν ακουμπά τον δίσκο.
    data = upload.read(MAX_IMPORT_BYTES + 1)
    if len(data) > MAX_IMPORT_BYTES:
        flash("Το αρχείο είναι πολύ μεγάλο (πάνω από 2 MB). "
              "Χωρίσε το σε δύο αρχεία.", "error")
        return redirect(url_for("staff.clients_import"))
    if not data.strip():
        flash("Το αρχείο είναι κενό.", "error")
        return redirect(url_for("staff.clients_import"))

    try:
        result = import_customers(data, filename)
    except ValueError as exc:
        # Μορφοποίηση/κεφαλίδες λάθος — δεν μπήκε τίποτα, δεν χρειάζεται rollback.
        flash(str(exc), "error")
        return redirect(url_for("staff.clients_import"))
    except Exception as exc:                                   # noqa: BLE001
        db.session.rollback()
        current_app.logger.exception("Αποτυχία εισαγωγής πελατών")
        flash(f"Η εισαγωγή απέτυχε ({type(exc).__name__}). "
              "Δεν μπήκε τίποτα — τα δεδομένα είναι ανέπαφα.", "error")
        return redirect(url_for("staff.clients_import"))

    if result.inserted:
        db.session.commit()
    else:
        # Κανένας επιτυχής γραμμή → δεν αφήνουμε ανοιχτή συναλλαγή.
        db.session.rollback()

    _flash_import_result(result)
    return redirect(url_for("staff.clients"))


def _flash_import_result(result) -> None:
    """Το μήνυμα της ιδιοκτήτριας: πόσοι μπήκαν, πόσοι όχι, και ΓΙΑΤΙ.
    Ο λόγος είναι το σημαντικότερο κομμάτι — χωρίς αυτόν, ένας αριθμός
    απορρίψεων είναι ανεξήγητος."""
    if result.inserted:
        flash(result.summary(), "success")
    else:
        flash("Δεν μπήκε κανένας πελάτης — διόρθωσε τα παρακάτω "
              "και δοκίμασε ξανά.", "error")

    if result.skipped_blank:
        flash(f"{result.skipped_blank} κενές γραμμές παραλείφθηκαν.", "info")

    if result.unknown_columns:
        flash("Στήλες που δεν αναγνωρίστηκαν και αγνοήθηκαν: "
              + ", ".join(result.unknown_columns[:6]) + ".", "info")

    # Μέχρι 8 λόγους. Με 200 απορρίψεις το μήνυμα γίνεται ανάγνωστο
    # δυσπαθές — λέμε πόσοι είναι και δείχνουμε τους πρώτους, με τον
    # αριθμό γραμμής ώστε να τους βρει στο αρχείο.
    for rej in result.rejected[:8]:
        flash(f"Γραμμή {rej.row_no} — {rej.name}: {rej.reason}", "error")
    if len(result.rejected) > 8:
        flash(f"…και {len(result.rejected) - 8} ακόμα απορρίψεις. "
              "Διόρθωσε τις παραπάνω και δοκίμασε ξανά.", "info")


@bp.route("/clients/export")
@owner_required
def clients_export():
    """Κατεβάζει .xlsx — owner only.

    ?template=1  → το κενό ΠΡΟΤΥΠΟ, με οδηγίες στη 2η σειρά
    ?export=1    → τους πελάτες που φιλτράρει η σελίδα (?q=…)

    ΔΥΟ ΞΕΧΩΡΙΣΤΑ ΜΠΟΥΤΟΝΙΑ, ΟΧΙ ΕΝΑ ΜΕ ΠΑΡΑΜΕΤΡΟΥΣ. Το «κατέβασε πρότυπο»
    και το «κατέβασε τους πελάτες μου» είναι διαφορετικές πράξεις με
    διαφορετικό αποτέλεσμα· το ένα γράφει, το άλλο διαβάζει. Ένα κουμπί
    που «μιλάει» ανάλογα με ένα αόρατο ?q είναι πηγή λαθών."""
    if request.args.get("template"):
        return _send_xlsx(template_bytes(),
                          f"πρότυπο-πελατών-{APP_VERSION}.xlsx")

    search = (request.args.get("q") or "").strip()
    active = is_searchable(search)
    rows = Customer.query.options(
        joinedload(Customer.pets)).order_by(Customer.name).all()
    if active:
        rows = [c for c in rows
                if matches(search, c.name, c.email, c.phone, c.address,
                           c.notes, *[(p.name or "") for p in c.pets])]
    if not rows:
        flash("Δεν βρέθηκαν πελάτες για εξαγωγή.", "info")
        return redirect(url_for("staff.clients"))
    return _send_xlsx(export_customers(rows),
                      f"πελάτες-{len(rows)}-{APP_VERSION}.xlsx")


@bp.route("/clients/new", methods=["GET", "POST"])
def client_new():
    if request.method == "POST":
        # Ονοματεπώνυμο σε ένα πεδίο. Τηλέφωνο/email/διεύθυνση προαιρετικά.
        name = clean(request.form.get("name"))
        phone = clean(request.form.get("phone"))
        email = clean(request.form.get("email"))
        address = clean(request.form.get("address"))
        notes = clean(request.form.get("notes"))

        if not name:
            flash("Συμπληρώστε το ονοματεπώνυμο.", "error")
        else:
            customer = Customer(
                name=name,
                phone=phone or None,
                email=email or None,
                address=address or None,
                notes=notes or None,
            )
            db.session.add(customer)
            db.session.commit()
            flash(f"Ο πελάτης {name} προστέθηκε.", "success")
            return redirect(url_for("staff.client_detail", customer_id=customer.id))
    return render_template("staff/client_form.html", customer=None)


@bp.route("/clients/<int:customer_id>")
def client_detail(customer_id: int):
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    now = datetime.now()
    appointments = sorted(customer.appointments, key=lambda a: a.start_at, reverse=True)
    completed = [a for a in appointments if a.status == STATUS_COMPLETED]
    return render_template(
        "staff/client_detail.html",
        customer=customer,
        appointments=appointments,
        upcoming=[a for a in appointments if a.is_upcoming],
        completed_count=len(completed),
        no_shows=len([a for a in appointments if a.status == STATUS_NO_SHOW]),
        last_visit=completed[0] if completed else None,
        today=now.date(),
    )


@bp.route("/clients/<int:customer_id>/edit", methods=["GET", "POST"])
def client_edit(customer_id: int):
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    if request.method == "POST":
        name = clean(request.form.get("name"))
        if not name:
            flash("Συμπληρώστε το ονοματεπώνυμο.", "error")
        else:
            customer.name = name
            customer.phone = clean(request.form.get("phone")) or None
            customer.email = clean(request.form.get("email")) or None
            customer.address = clean(request.form.get("address")) or None
            customer.notes = clean(request.form.get("notes")) or None
            db.session.commit()
            flash("Τα στοιχεία ενημερώθηκαν.", "success")
            return redirect(url_for("staff.client_detail", customer_id=customer.id))
    return render_template("staff/client_form.html", customer=customer)


@bp.route("/clients/<int:customer_id>/notes", methods=["POST"])
def client_notes(customer_id: int):
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    customer.notes = clean(request.form.get("notes")) or None
    db.session.commit()
    flash("Η σημείωση αποθηκεύτηκε.", "success")
    return redirect(url_for("staff.client_detail", customer_id=customer.id))


# -------------------------------------------------------- κατοικίδια
@bp.route("/clients/<int:customer_id>/pets/new", methods=["GET", "POST"])
def pet_new(customer_id: int):
    customer = get_or_404(Customer, customer_id, "Ο πελάτης δεν βρέθηκε.")
    if request.method == "POST":
        # Το όνομα είναι προαιρετικό· χωρίς όνομα εμφανίζεται «χωρίς όνομα».
        name = clean(request.form.get("name")) or None
        birth = parse_date(request.form.get("birth_date"))
        if request.form.get("birth_date") and birth is None:
            flash("Ημερομηνία γέννησης μη έγκυρη (μορφή ΗΗ/ΜΜ/ΕΕΕΕ).", "error")
        elif birth and birth > date_cls.today():
            flash("Η ημερομηνία γέννησης δεν μπορεί να είναι στο μέλλον.", "error")
        else:
            pet = Pet(
                customer_id=customer.id,
                # Το όνομα παραμένει προαιρετικό· χωρίς όνομα εμφανίζεται
                # ως «χωρίς όνομα» στο ραντεβού.
                name=name,
                species=clean(request.form.get("species")) or "dog",
                breed=clean(request.form.get("breed")) or None,
                gender=clean(request.form.get("gender")) or "unknown",
                birth_date=birth,
                weight_kg=form_float("weight_kg") or None,
                is_neutered=form_bool("is_neutered"),
                allergies=clean(request.form.get("allergies")) or None,
                temperament=clean(request.form.get("temperament")) or None,
                health_notes=clean(request.form.get("health_notes")) or None,
                coat_notes=clean(request.form.get("coat_notes")) or None,
            )
            db.session.add(pet)
            db.session.commit()
            flash(f"Το κατοικίδιο «{name or 'χωρίς όνομα'}» προστέθηκε!", "success")
            return redirect(url_for("staff.client_detail", customer_id=customer.id))
    return render_template("staff/pet_form.html", customer=customer, pet=None,
                       species=SPECIES, genders=GENDERS)


@bp.route("/pets/<int:pet_id>/edit", methods=["GET", "POST"])
def pet_edit(pet_id: int):
    pet = get_or_404(Pet, pet_id, "Το κατοικίδιο δεν βρέθηκε.")
    customer = pet.customer
    if request.method == "POST":
        # Το όνομα είναι προαιρετικό.
        name = clean(request.form.get("name")) or None
        birth = parse_date(request.form.get("birth_date"))
        pet.name = name
        pet.species = clean(request.form.get("species")) or "dog"
        pet.breed = clean(request.form.get("breed")) or None
        pet.gender = clean(request.form.get("gender")) or "unknown"
        pet.birth_date = birth
        pet.weight_kg = form_float("weight_kg") or None
        pet.is_neutered = form_bool("is_neutered")
        pet.allergies = clean(request.form.get("allergies")) or None
        pet.temperament = clean(request.form.get("temperament")) or None
        pet.health_notes = clean(request.form.get("health_notes")) or None
        pet.coat_notes = clean(request.form.get("coat_notes")) or None
        db.session.commit()
        flash("Τα στοιχεία ενημερώθηκαν.", "success")
        return redirect(url_for("staff.client_detail", customer_id=customer.id))
    return render_template("staff/pet_form.html", customer=customer, pet=pet,
                           species=SPECIES, genders=GENDERS)


@bp.route("/pets/<int:pet_id>/delete", methods=["POST"])
def pet_delete(pet_id: int):
    pet = get_or_404(Pet, pet_id, "Το κατοικίδιο δεν βρέθηκε.")
    customer_id = pet.customer_id
    # ΟΛΑ ΤΑ ΡΑΝΤΕΒΟΥ, όχι μόνο αυτά που το έχει ως κύριο. Με το
    # pet.appointments, ένα δεύτερο κατοικίδιο σε ραντεβού με δύο
    # κατοικίδια δεν έβλεπε το επερχόμενο — και η διαγραφή του θα έσπαγε
    # το ραντεβού.
    has_future = any(a.is_upcoming for a in pet.appointments_including_shared())
    if has_future:
        flash("Δεν είναι δυνατή η διαγραφή — υπάρχουν επερχόμενα ραντεβού.", "error")
        return redirect(url_for("staff.client_detail", customer_id=customer_id))
    name = pet.name
    db.session.delete(pet)
    db.session.commit()
    flash(f"Το κατοικίδιο «{name or 'χωρίς όνομα'}» διαγράφηκε.", "info")
    return redirect(url_for("staff.client_detail", customer_id=customer_id))


@bp.route("/pets")
def all_pets():
    pets = (
        db.session.query(Pet)
        .join(Pet.customer)
        .order_by(Customer.name, Pet.name)
        .all()
    )
    show_due_only = request.args.get("due") == "1"
    search = clean(request.args.get("q"))
    filtering = is_searchable(search)

    if show_due_only:
        pets = [p for p in pets if p.due_for_grooming]

    if filtering:
        pets = [
            pet for pet in pets
            if matches(
                search, pet.name, pet.breed, pet.color, pet.species,
                pet.allergies, pet.temperament, pet.health_notes, pet.coat_notes,
                pet.customer.name,
                pet.customer.phone, pet.customer.email,
            )
        ]

    # ΟΙ ΕΠΙΣΚΕΨΕΙΣ, ΜΙΑ ΦΟΡΑ ΓΙΑ ΟΛΗ ΤΗ ΛΙΣΤΑ. Ένα ερώτημα ενώνει το
    # κύριο κατοικίδιο με τους συμμετέχοντες — αλλιώς το δεύτερο
    # κατοικίδιο σε ραντεβού με δύο κατοικίδια έμενε μηδέν επισκέψεις.
    visits_by_pet: dict[int, int] = {}
    for _pid, _appts in Pet.appointments_for([x.id for x in pets]).items():
        visits_by_pet[_pid] = sum(
            1 for a in _appts if a.status == STATUS_COMPLETED)


    return render_template(

        "staff/pets.html",

        pets=pets,
        visits_by_pet=visits_by_pet,
        show_due_only=show_due_only,
        search=search,
        filtering=filtering,
        min_chars=MIN_SEARCH_CHARS,
    )


# ------------------------------------------------------------ ειδοποιήσεις
@bp.route("/notifications")
def notifications():
    rows = (
        Notification.query.order_by(Notification.created_at.desc()).limit(120).all()
    )
    return render_template("staff/notifications.html", rows=rows,
                           pending=due_reminders())


@bp.route("/api/calendar-version")
def api_calendar_version():
    """«Έκδοση» του ημερολογίου μιας μέρας, για έλεγχο αλλαγών.

    Πολύ ελαφρύ endpoint: μία συγκέντρωση πάνω σε χρονικό διάστημα. Ο
    πελάτης το ζητά κάθε λίγα δευτερόλεπτα και ανανεώνεται μόνο όταν αλλάξει
    το token — δηλαδή όταν μπήκε, διεγράφη ή άλλαξε κάτι.

    Το token πιάνει και τις τρεις περιπτώσεις: νέα κράση (μεγαλύτερο id),
    αλλαγή ώρας/κατάστασης (μεγαλύτερο updated_at) και διαγραφή (πλήθος).
    """
    from flask import jsonify

    day = parse_date(request.args.get("date")) or date_cls.today()
    start_dt = datetime.combine(day, time(0, 0))
    end_dt = datetime.combine(day + timedelta(days=1), time(0, 0))
    row = (
        db.session.query(
            func.count(Appointment.id),
            func.max(Appointment.id),
            func.max(Appointment.updated_at),
        )
        .filter(Appointment.start_at >= start_dt, Appointment.start_at < end_dt)
        .one()
    )
    count, max_id, updated = row
    token = "%s|%s|%s" % (count or 0, max_id or 0, updated or "")
    return jsonify({
        "date": day.isoformat(),
        "token": token,
        "count": int(count or 0),
        "updated_at": updated.isoformat() if updated else None,
    })


@bp.route("/notifications/send-reminders", methods=["POST"])
def send_pending_reminders():
    items = due_reminders()
    for appointment in items:
        send(KIND_REMINDER, appointment)
    db.session.commit()
    flash(plural(len(items), "υπενθύμιση", "υπενθυμίσεις") + " στάλθηκαν.", "success")
    return redirect(url_for("staff.notifications"))


# ------------------------------------------------------- API για JS φόρμες
@bp.route("/api/customers")
def api_customers():
    from flask import jsonify

    results = []
    for customer in db.session.query(Customer).order_by(Customer.name).all():
        results.append(
            {
                "id": customer.id,
                "name": customer.name,
                "phone": customer.phone or "",
                "email": customer.email or "",
                "pets": [
                    {"id": p.id, "name": p.name,
                     "breed": p.breed or ""}
                    for p in customer.active_pets
                ],
            }
        )
    return jsonify(results)


@bp.route("/api/slots")
def api_slots():
    from flask import jsonify

    day = parse_date(request.args.get("date")) or date_cls.today()
    duration = int(request.args.get("duration", 60) or 60)
    groomer_id = request.args.get("groomer_id", type=int)
    exclude = request.args.get("exclude", type=int)
    slots = slots_for_date(day, duration, groomer_id, exclude_appointment_id=exclude)
    return jsonify(
        {
            "date": day.isoformat(),
            "closed": bool(slots) and slots[0]["start"] == "—",
            "duration": duration,
            "slots": [
                {"start": s["start"], "end": s["end"], "available": s["available"],
                 "reason": s["reason"], "label": s["label"], "groomer_id": s["groomer_id"]}
                for s in slots
            ],
        }
    )


def _set_service_links(appointment, services, quantities) -> None:
    """Γράφει τις γραμμές υπηρεσιών με ποσότητα και στιγμιότυπο διάρκειας."""
    appointment.service_links = [
        AppointmentService(
            service_id=service.id,
            quantity=max(1, int(quantities.get(service.id, 1))),
            duration=int(service.duration_minutes or 0),
        )
        for service in services
    ]


# ------------------------------------------------------------------ expenses
@bp.route("/expenses", methods=["GET", "POST"])
def expenses():
    """Καταγραφή εξόδων υλικών (π.χ. σαμπουάν, μάσκες) από την ιδιοκτήτρια ή τους βοηθούς."""
    today = date_cls.today()

    if request.method == "POST":
        action = request.form.get("action") or "create"
        if action == "create":
            item = clean(request.form.get("item"))
            if not item:
                flash("Συμπληρώστε τι αγοράστηκε, χρησιμοποιήθηκε ή πληρώθηκε.", "error")
                return redirect(url_for("staff.expenses"))
            amount = form_float("amount", 0.0)
            if amount <= 0:
                flash("Το ποσό πρέπει να είναι μεγαλύτερο από μηδέν.", "error")
                return redirect(url_for("staff.expenses"))
            spent_on = parse_date(request.form.get("spent_on"), default=today) or today
            db.session.add(
                Expense(
                    item=item[:160],
                    category=clean(request.form.get("category"))[:60] or EXPENSE_GENERAL,
                    amount=round(amount, 2),
                    spent_on=spent_on,
                    note=clean(request.form.get("note"))[:200] or None,
                    created_by_id=current_user.id,
                )
            )
            db.session.commit()
            flash(f"Καταχωρίστηκαν έξοδα: {item} — {fmt_money(amount)}.", "success")
        elif action == "delete":
            expense = db.session.get(Expense, form_int("expense_id"))
            if expense is None:
                flash("Δεν βρέθηκε αυτή η καταχώρηση.", "error")
            else:
                item = expense.item
                db.session.delete(expense)
                db.session.commit()
                flash(f"Τα έξοδα «{item}» διαγράφηκαν.", "info")
        return redirect(url_for("staff.expenses"))

    # Παράμετροι περιόδου (προεπιλογή: τρέχων μήνας)
    today = date_cls.today()
    month_start = today.replace(day=1)
    next_month = (month_start + timedelta(days=32)).replace(day=1)
    view_month = request.args.get("month", "")  # YYYY-MM

    if view_month:
        try:
            year_s, month_s = view_month.split("-")
            view_start = date_cls(int(year_s), int(month_s), 1)
        except (ValueError, TypeError):
            view_month = ""
            view_start = month_start
    if not view_month:
        view_start = month_start
    view_end = (view_start + timedelta(days=32)).replace(day=1)

    rows = (
        Expense.query.filter(Expense.spent_on >= view_start, Expense.spent_on < view_end)
        .order_by(Expense.spent_on.desc(), Expense.id.desc())
        .all()
    )

    day_totals: dict = {}
    for row in rows:
        day_totals.setdefault(row.spent_on, 0.0)
        day_totals[row.spent_on] += row.amount

    month_expenses = sum(r.amount for r in rows)

    # Τα οικονομικά του καταστήματος (έσοδα/καθαρό εισόδημα) είναι για την
    # ιδιοκτήτρια μόνο. Οι βοηθοί βλέπουν έξοδα — που καταχωρούν — όχι έσοδα.
    show_financials = current_user.is_owner
    revenue = revenue_gross = discounts = net = 0.0
    if show_financials:
        window = (
            Appointment.status == STATUS_COMPLETED,
            Appointment.start_at >= datetime.combine(view_start, time(0, 0)),
            Appointment.start_at < datetime.combine(view_end, time(0, 0)),
        )
        # ΜΙΑ ΕΡΩΤΗΣΗ ΓΙΑ ΟΛΑ ΤΑ ΠΟΣΑ, ΟΧΙ ΔΥΟ.
        #
        # ΤΙ ΖΗΤΗΣΕ Η ΙΔΙΟΚΤΗΤΡΙΑ ΚΑΙ ΤΙ ΕΔΕΙΧΝΕ Η ΟΘΟΝΗ. Έδειχνε 168,00 € και
        # από κάτω «−18,00 € εκπτώσεις». Δηλαδή το ΜΕΓΑΛΟ ΝΟΜΙΣΜΑ ήταν αυτό
        # που δεν μπήκε στο ταμείο. Τα πραγματικά χρήματα ήταν 150,00 €, και
        # αυτό είναι που θέλει να βλέπει πρώτο.
        #
        # Δεν το άλλαξα μόνο στην οθόνη: άλλαξα το ίδιο το ΜΕΤΡΗΜΑ, ώστε ο
        # αριθμός στην οθόνη και αυτός στο Excel να είναι το ίδιο πράγμα.
        # Μια επιφάνεια που διαφωνεί με την αναφορά είναι χειρότερη από το
        # παλιό.
        row = db.session.query(
            func.coalesce(func.sum(Appointment.total_price), 0.0),
            func.coalesce(
                func.sum(
                    func.coalesce(Appointment.price_override, Appointment.total_price)
                ), 0.0),
        ).filter(*window).one()
        revenue_gross = float(row[0] or 0.0)
        revenue = float(row[1] or 0.0)
        discounts = revenue_gross - revenue
        net = revenue - month_expenses

    categories = sorted({r.category_label for r in rows} | set(EXPENSE_CATEGORIES))

    # Ανάλυση ανά κατηγορία, ώστε να φαίνεται πόσα ήταν τα έξοδα του
    # καταστήματος (ρεύμα, νερό…) από τα υλικά που καταναλώθηκαν.
    by_category: dict = {}
    for row in rows:
        by_category.setdefault(row.category_label, 0.0)
        by_category[row.category_label] += row.amount
    category_totals = sorted(by_category.items(), key=lambda kv: -kv[1])
    store_total = by_category.get(EXPENSE_STORE, 0.0)

    # Ο κατάλογος των σταθερών εξόδων, για γρήγορη καταχώριση.
    store_items = (
        ExpenseItem.query.filter_by(is_active=True)
        .order_by(ExpenseItem.sort_order, ExpenseItem.label)
        .all()
    )

    return render_template(
        "staff/expenses.html",
        rows=rows,
        day_totals=day_totals,
        month_expenses=month_expenses,
        revenue=revenue,
        revenue_gross=revenue_gross,
        discounts=discounts,
        net=net,
        view_start=view_start,
        view_end=view_end,
        view_label=f"{_month_name(view_start)} {view_start.year}",
        today=today,
        categories=categories,
        category_totals=category_totals,
        store_total=store_total,
        store_items=store_items,
        show_financials=show_financials,
    )
