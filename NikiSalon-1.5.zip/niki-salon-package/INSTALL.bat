@echo off
REM ===========================================================================
REM  Niki's Grooming Salon - INSTALL
REM
REM  DOUBLE-CLICK THIS FILE. Do not run it from a cmd prompt you care about.
REM
REM  THIS FILE NEEDS NO PYTHON. That is the whole point of it. It looks for a
REM  Python it can use, and if there is none it downloads the pinned one from
REM  python.org, checks it against the official SHA-256, and installs it
REM  INSIDE this folder. Only then does it run install.py.
REM
REM  The customer must never have to install software by hand in order to use
REM  a salon booking system. Every step below exists so that this file works
REM  on a machine that has never seen Python.
REM
REM  We do NOT uninstall any Python the customer already has. Removing
REM  somebody's Python can break software they depend on and never told us
REM  about - accounting packages, tax tools, scripts other people wrote.
REM  That is not ours to risk for our own convenience. Our own copy lives in
REM  runtime\python and touches nothing else on the machine.
REM
REM  ---------------------------------------------------------------------------
REM  THE FOUR RULES OF THIS FILE. THEY ARE NOT STYLE. BREAKING ANY OF THEM
REM  IS WHAT MADE THE PREVIOUS VERSION PRINT
REM      'lue_test' is not recognized as an internal or external command
REM  on a customer's machine, with no other symptom and no way to guess.
REM
REM  1. THIS FILE IS PURE ASCII. No Greek, no accents, nothing. cmd.exe reads
REM     a batch file in the console's own code page, and when a multi-byte
REM     character lands in the wrong one the parser loses its place - the
REM     "echo" in front of a line stops being a command and the rest of the
REM     line is EXECUTED. Every message below is therefore English. As soon
REM     as a Python exists, install.py takes over and speaks Greek.
REM
REM  2. THIS FILE USES CRLF LINE ENDINGS. A batch file saved with Unix line
REM     endings is read by cmd.exe at its own risk, and the failures are
REM     silent and confusing.
REM
REM  3. THERE ARE NO PARENTHESIS BLOCKS ANYWHERE IN THIS FILE. Not "if (",
REM     not "for ... do (". cmd.exe finds the end of such a block by counting
REM     parentheses, and it counts the ones inside double-quoted strings too.
REM     A quoted Python expression full of brackets and comparison signs
REM     therefore ends the block early, and the rest of the line then runs
REM     as a command.
REM     Control
REM     flow uses labels and goto instead. This costs a few extra lines and
REM     removes an entire class of "works on my machine".
REM
REM  4. NO PERCENT SIGN INSIDE A QUOTED PYTHON ARGUMENT. The percent sign
REM     is batch's own variable character, so a percent format inside a
REM     quoted print call is a landmine. Print sys.version instead.
REM
REM  Also: the "start" invocation below is ONE line, not a caret continuation.
REM  ===========================================================================
chcp 65001 >nul 2>&1
setlocal EnableExtensions
cd /d "%~dp0"
title Niki's Grooming Salon - Install

set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
set "RUNTIME=%HERE%\runtime\python"
set "MANIFEST=%HERE%\runtime_python.txt"
set "TMPDIR=%TEMP%\nikisalon-python"
set "HASHFILE=%TMPDIR%\hash.txt"

echo.
echo   ==========================================================
echo     Niki's Grooming Salon - installation
echo   ==========================================================
echo.

REM ---------------------------------------------------------------------------
REM  Step 1. Which Python did we pin, where does it come from, and what is its
REM  official SHA-256? One manifest, read by BOTH this file and install.py, so
REM  the two can never drift apart and end up trusting different hashes.
REM ---------------------------------------------------------------------------
if not exist "%MANIFEST%" goto :no_manifest

REM  The architecture first, because it decides which URL and hash we read.
REM  Windows 11 is 64-bit only, so AMD64 or ARM64 - but a 32-bit Windows 10
REM  still exists, and a 32-bit venv is not what we want to build, so we
REM  simply bring our own 64-bit copy there instead.
set "ARCH=AMD64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=ARM64"
if /i "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "ARCH=ARM64"
if defined PROCESSOR_ARCHITEW6432 goto :arch_done
if /i "%PROCESSOR_ARCHITECTURE%"=="AMD64" goto :arch_done
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" goto :arch_done
set "ARCH=X86"
:arch_done

REM  One loop per key. A single loop would need a block body, and rule 3 says
REM  no blocks. Three loops over a seven-line file cost nothing.
set "PYVER="
for /f "usebackq tokens=1,* delims==" %%A in ("%MANIFEST%") do if "%%A"=="VERSION" set "PYVER=%%B"
set "PYURL="
for /f "usebackq tokens=1,* delims==" %%A in ("%MANIFEST%") do if /i "%%A"=="URL_%%ARCH%%" set "PYURL=%%B"
set "PYSHA="
for /f "usebackq tokens=1,* delims==" %%A in ("%MANIFEST%") do if /i "%%A"=="SHA_%%ARCH%%" set "PYSHA=%%B"

if not defined PYVER goto :bad_manifest
if not defined PYURL  goto :bad_manifest
if not defined PYSHA  goto :bad_manifest

REM ---------------------------------------------------------------------------
REM  Step 2. Is there already a Python we can use?
REM  "Use" means: it actually runs, and it is 3.10 to 3.13. A newer one has
REM  never been tested here and an older one cannot run this code; in both
REM  cases we bring our own rather than argue with the machine.
REM ---------------------------------------------------------------------------
set "PY="
if exist "%RUNTIME%\python.exe" set "PY=%RUNTIME%\python.exe"
if not defined PY call :probe_system
if not defined PY goto :need_python

:check_usable
REM  Quoted parentheses are safe HERE because this line is not inside a block.
"%PY%" -c "import sys;sys.exit(0 if sys.version_info.major==3 and 10<=sys.version_info.minor<=13 else 1)" >nul 2>&1
if not errorlevel 1 goto :have_python
echo.
echo   [!]  The Python found is out of range - it will not be used.
"%PY%" -c "import sys;print(sys.version)" 2>nul
set "PY="

REM ---------------------------------------------------------------------------
REM  Step 3. No usable Python. Fetch the pinned one, verify it, install it
REM  inside this folder.
REM ---------------------------------------------------------------------------
:need_python
echo.
echo   No usable Python was found on this machine.
echo   Downloading Python %PYVER% from python.org and putting it INSIDE this
echo   folder. Any Python already on the machine is left completely alone.
echo.
set "EXE=%TMPDIR%\python-%PYVER%-installer.exe"
if exist "%TMPDIR%" goto :tmp_ready
mkdir "%TMPDIR%" >nul 2>&1
:tmp_ready

echo   [1/3] Downloading, about 30 MB...
call :download "%PYURL%" "%EXE%"
if errorlevel 1 goto :download_failed

REM  THE INTEGRITY CHECK. A download-and-run step with no hash check is how a
REM  machine ends up running somebody else's code. If this fails we stop and
REM  we delete the file. We do not print a warning and carry on.
echo   [2/3] Verifying the SHA-256...
set "GOT="
certutil -hashfile "%EXE%" SHA256 > "%HASHFILE%" 2>nul
for /f "usebackq delims=" %%H in (`findstr /r /c:"^[0-9a-fA-F][0-9a-fA-F]*$" "%HASHFILE%"`) do if not defined GOT set "GOT=%%H"
if not defined GOT goto :hash_failed
echo %GOT% | findstr /i /c:"%PYSHA%" >nul
if errorlevel 1 goto :hash_mismatch
echo         SHA-256 matches the official python.org value.

echo   [3/3] Installing Python %PYVER% into this folder...
echo         A few minutes. No window will appear.
REM  ONE LINE ON PURPOSE. A caret-continued "start" is how the previous
REM  version lost its place and executed "Include_test" as a command.
start "" /wait "%EXE%" /quiet InstallAllUsers=0 TargetDir="%RUNTIME%" PrependPath=0 Include_launcher=0 Include_test=0 Include_doc=0 Include_tcltk=0 Include_tools=0 Include_debug=0 Include_symbols=0 AssociateFiles=0 Shortcuts=0

REM  0 = done.  3010 = done, Windows wants a restart later.  Both fine.
REM  errorlevel N means "greater or equal to N", so anything from 3011 up is
REM  a genuine failure.
if errorlevel 3011 goto :install_failed
if not exist "%RUNTIME%\python.exe" goto :install_failed
del "%EXE%" >nul 2>&1
set "PY=%RUNTIME%\python.exe"

:have_python
echo.
echo   Python: "%PY%"
"%PY%" --version
echo.

REM ---------------------------------------------------------------------------
REM  Step 4. The real installer, in Greek.
REM ---------------------------------------------------------------------------
"%PY%" "%HERE%\install.py" %*
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" goto :finished_ok
echo   ==========================================================
echo     Installation did not finish. Exit code %RC%.
echo     Read the messages above.
echo   ==========================================================
echo.
pause
endlocal
exit /b %RC%

:finished_ok
echo   ==========================================================
echo     Finished. Open the address that appeared above.
echo   ==========================================================
echo.
pause
endlocal
exit /b 0

REM ===========================================================================
REM  Fallbacks
REM ===========================================================================

REM  Look where python.org puts itself, then ask PATH. Each candidate must
REM  actually RUN - System32\python.exe exists on every Windows 10/11 and is
REM  the Microsoft Store stub, which opens the Store rather than running
REM  Python. "It exists" is not evidence that it works.
:probe_system
call :try_py "%ProgramFiles%\Python313\python.exe"
if defined PY exit /b 0
call :try_py "%ProgramFiles%\Python312\python.exe"
if defined PY exit /b 0
call :try_py "%ProgramFiles%\Python311\python.exe"
if defined PY exit /b 0
call :try_py "%ProgramFiles%\Python310\python.exe"
if defined PY exit /b 0
call :try_py "%LocalAppData%\Programs\Python\Python313\python.exe"
if defined PY exit /b 0
call :try_py "%LocalAppData%\Programs\Python\Python312\python.exe"
if defined PY exit /b 0
call :try_py "%LocalAppData%\Programs\Python\Python311\python.exe"
if defined PY exit /b 0
call :try_py "%LocalAppData%\Programs\Python\Python310\python.exe"
if defined PY exit /b 0
for /f "usebackq delims=" %%P in (`where python.exe 2^>nul`) do call :try_py "%%P"
exit /b 0

:try_py
if defined PY exit /b 0
if not exist "%~1" exit /b 0
"%~1" -c "import sys" >nul 2>&1
if errorlevel 1 exit /b 0
set "PY=%~1"
exit /b 0

REM  curl.exe ships with Windows 10 1803 and every Windows 11. PowerShell is
REM  the fallback for machines where something removed it. A truncated
REM  download needs no extra guard here: the SHA-256 check that follows will
REM  reject it, and it says so in words the owner can act on.
:download
curl.exe -fL --retry 3 --retry-delay 2 --connect-timeout 30 -o "%~2" "%~1"
if not errorlevel 1 if exist "%~2" exit /b 0
if exist "%~2" del "%~2" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue';[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;try { Invoke-WebRequest -Uri '%~1' -OutFile '%~2' -UseBasicParsing } catch { exit 1 }"
if not exist "%~2" exit /b 1
exit /b 0

:no_manifest
echo.
echo   [X]  runtime_python.txt is missing from the application folder.
echo.
echo       That file says which Python to download and what its official
echo       SHA-256 is. Without it we cannot install anything, and we are
echo       not going to guess.
echo.
echo       Download the application package again from the developer.
echo.
goto :bail

:bad_manifest
echo.
echo   [X]  runtime_python.txt has no version, URL or SHA-256 for this
echo       machine's architecture. Detected ARCH = %ARCH%.
echo.
echo       That means the package is incomplete. Download it again.
echo.
goto :bail

:download_failed
echo.
echo   [X]  The download failed.
echo.
echo       Check the internet connection, and whether a proxy or firewall
echo       is blocking www.python.org. To do it by hand, download the file
echo       to this exact location:
echo.
echo           "%PYURL%"
echo           "%EXE%"
echo.
echo       then run INSTALL.bat again. It will find it and carry on.
echo.
goto :bail

:hash_failed
del "%EXE%" >nul 2>&1
echo.
echo   [X]  certutil could not calculate the SHA-256 of the download.
echo.
echo       The file was deleted. Download it again, or ask the developer.
echo.
goto :bail

:hash_mismatch
echo.
echo   [X]  The SHA-256 DOES NOT MATCH the official python.org value.
echo.
echo       The downloaded file is either damaged in transit or something
echo       else. In NO case will it be executed.
echo.
echo       DO NOT RUN IT BY HAND. A wrong file that runs with administrator
echo       rights is the worst thing that can happen to this machine. Tell
echo       the developer.
echo.
del "%EXE%" >nul 2>&1
goto :bail

:install_failed
echo.
echo   [X]  The installation of Python %PYVER% failed.
echo.
echo       Usual reasons, in order of likelihood:
echo         1. No internet.
echo         2. An antivirus or file-blocking tool stopped the installer.
echo         3. Not enough free space on the disk.
echo.
echo       You can do it by hand instead of any automatic step:
echo           "%EXE%"
echo       leave every option at its default and finish the installation.
echo       THEN run INSTALL.bat again - it will find the Python in
echo       runtime\python and continue from there.
echo.
goto :bail

:bail
echo.
pause
endlocal
exit /b 1
