"""Βοηθητικές συναρτήσεις — σύστημα διαχείρισης ραντεβού σαλονιού."""

from __future__ import annotations

import unicodedata
from datetime import date as date_cls, datetime, time, timedelta
from functools import wraps

from flask import abort, flash, redirect, request, url_for
from flask_login import current_user
from sqlalchemy.exc import OperationalError

from .extensions import db
from .models import (
    ADMIN_ROLES,
    Groomer,
    Pet,
    Service,
    STAFF_ROLES,
    SalonSettings,
)


# ------------------------------------------------------------------ decorators
def roles_required(*roles):
    """Επιτρέπει πρόσβαση μόνο σε συγκεκριμένους ρόλους."""
    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for("auth.login", next=request.path))
            if roles and current_user.role not in roles:
                flash("Δεν έχετε πρόσβαση σε αυτή τη σελίδα.", "error")
                return redirect(url_for("staff.dashboard"))
            return view(*args, **kwargs)
        return wrapper
    return decorator


staff_required = roles_required(*STAFF_ROLES)
# ΔΙΟΙΚΗΣΗ = ΙΔΙΟΚΤΗΤΗΣ Ή ΥΠΕΥΘΥΝΟΣ. Το παλιό `owner_required` έλεγχε το
# αληθινό string "owner" και έκοβε τον υπεύθυνο απ’ όλα τα δικαιώματα.
admin_required = roles_required(*ADMIN_ROLES)


# ------------------------------------------------------------------ αναζήτηση
# Οι χρήστες πληκτρολογούν συχνά χωρίς τόνους ("Παπαδοπουλου" αντί για
# "Παπαδοπούλου") και τα τηλέφωνα με/χωρίς κενά. Ο κανονικοποιητής
# αντιμετωπίζει και τα δύο, ώστε η αναζήτηση να "δουλεύει πάντα".
MIN_SEARCH_CHARS = 3


def fold(value: str | None) -> str:
    """Κείμενο έτοιμο για σύγκριση: χωρίς τόνους, πεζά, χωρίς τελικό ζ."""
    if not value:
        return ""
    decomposed = unicodedata.normalize("NFD", str(value))
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return " ".join(stripped.lower().replace("ς", "σ").split())


def digits_only(value: str | None) -> str:
    """Μόνο ψηφία — για να βρίσκει «210985» το «210 985 0000»."""
    return "".join(ch for ch in str(value or "") if ch.isdigit())


def search_tokens(term: str | None) -> list[str]:
    """Διαχωρισμός του όρου αναζήτησης σε λέξεις."""
    return fold(term).split()


def matches(term: str | None, *fields) -> bool:
    """True αν ΟΛΕΣ οι λέξεις του όρου βρίσκονται στα δεδομένα.

    Κάθε πεδίο προστίθεται και με τα ψηφία του, ώστε η αναζήτηση
    τηλεφώνου να δουλεύει ανεξάρτητα από τα κενά."""
    tokens = search_tokens(term)
    if not tokens:
        return True
    parts = []
    for field in fields:
        parts.append(fold(field))
        parts.append(digits_only(field))
    haystack = " ".join(part for part in parts if part)
    return all(token in haystack for token in tokens)


def plural(count, singular: str, many: str) -> str:
    """Ελληνική πληθυντική: 1 → ενικός, 2+ → πληθυντικός.

    Χρησιμοποιείται στα πρότυπα ώστε να μην εμφανίζεται
    «1 κατοικίδια» ή «1 πελάτες»."""
    n = int(count or 0)
    return f"{n} {singular if n == 1 else many}"


def is_searchable(term: str | None) -> bool:
    """True όταν ο όρος έχει αρκετά γράμματα για να φιλτραριστεί η λίστα."""
    return len(fold(term)) >= MIN_SEARCH_CHARS


# ------------------------------------------------------------------- parsing
def parse_date(value, default=None) -> date_cls | None:
    if not value:
        return default
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(value.strip(), fmt).date()
        except ValueError:
            continue
    return default


def parse_time(value) -> time | None:
    if not value:
        return None
    try:
        return datetime.strptime(value.strip(), "%H:%M").time()
    except ValueError:
        return None


def form_date(name: str, default: date_cls | None = None) -> date_cls | None:
    return parse_date(request.form.get(name), default)


def form_int(name: str, default: int = 0) -> int:
    try:
        return int(request.form.get(name, default))
    except (TypeError, ValueError):
        return default


def form_float(name: str, default: float = 0.0) -> float:
    try:
        return float(request.form.get(name, default))
    except (TypeError, ValueError):
        return default


def form_bool(name: str) -> bool:
    return bool(request.form.get(name))


def form_str(name: str, default: str = "", allowed: tuple | None = None) -> str:
    value = clean(request.form.get(name)) or default
    if allowed and value not in allowed:
        return default
    return value


def form_time(name: str):
    return parse_time(request.form.get(name))


def form_datetime(name: str) -> datetime | None:
    raw = clean(request.form.get(name))
    if not raw:
        return None
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(raw, fmt)
        except ValueError:
            continue
    return None


# Ελάχιστο μήκος κωδικού. Ένας ορισμός για όλο το app, ώστε η σελίδα
# πρώτης εγκατάστασης, η δημιουργία χρήστη και η αλλαγή κωδικού να
# λένε όλα το ίδιο πράγμα.
MIN_PASSWORD_LENGTH = 8


#: ΛΕΞΕΣ ΠΟΥ ΣΗΜΑΙΝΟΥΝ «ΚΕΝΟ» ΟΤΑΝ ΓΡΑΦΤΗΚΑΝ ΩΣ ΚΕΙΜΕΝΟ. Ένας αντιγραφέας
#: που διαβάζει μια κενή στήλη από xlsx/CSV παίρνει το αντικείμενο None και
#: το κάνει str() → η βάση αποθηκεύει το ΚΕΙΜΕΝΟ "None", και το πρότυπο το
#: δείχνει ως «Τηλέφωνο: None» στον πελάτη. Ήταν αυτό που έβλεψε η ιδιοκτήτρια
#: στο δικό της σαλόνι: πελάτης χωρίς τηλέφωνο, και στη σελίδα του ραντεβού
#: έγραφε «None» αντί για «—».
#:
#: Το `or '—'` του προτύπου ΔΕΝ το σώζει: μια μη κενή συμβολοειρά είναι αληθινή
#: στην Python. Άρα το φροντίζουμε ΕΔΩ, στη μία είσοδο που περνά από όλα τα
#: πεδία, ώστε το κακό κείμενο να μην εισάγεται ποτέ. Το ίδιο και η μετατροπή
#: στο migrate.py, για τα δεδομένα που έχουν ήδη μπει.
NULLISH = {"none", "null", "nan", "n/a"}


def clean(value: str | None) -> str:
    text = (value or "").strip()
    # ΜΟΝΟ όταν είναι ακριβώς αυτή η λέξη. Ένα πραγματικό «None» μέσα σε
    # σύνθετο κείμενο («None Street») πρέπει να περάσει ανέπαφο.
    return "" if text.lower() in NULLISH else text


def get_or_404(model, object_id, message="Η εγγραφή δεν βρέθηκε."):
    obj = db.session.get(model, object_id)
    if obj is None:
        abort(404, description=message)
    return obj


# ------------------------------------------------------------------ services
def active_services() -> list[Service]:
    return Service.query.filter_by(is_active=True).order_by(
        Service.category, Service.sort_order, Service.name
    ).all()


def services_grouped() -> dict:
    grouped: dict[str, list[Service]] = {}
    for service in active_services():
        grouped.setdefault(service.category or "Λοιπά", []).append(service)
    return grouped


def service_ids_from_form() -> list[int]:
    raw = request.form.getlist("service_ids")
    ids = []
    for value in raw:
        try:
            ids.append(int(value))
        except (TypeError, ValueError):
            continue
    return ids


MAX_SERVICE_QUANTITY = 20


def service_pets_from_form() -> dict[int, int]:
    """{service_id: pet_id} — σε ΠΟΙΟ κατοικίδιο ισχύει η υπηρεσία.

    ΑΠΟΥΣΙΑ ΤΟ ΠΕΔΙΟ = ΟΛΑ ΤΑ ΚΑΤΟΙΚΙΔΙΑ ΤΟΥ ΡΑΝΤΕΒΟΥ. Είναι η συνηθισμένη
    περίπτωση και η ΠΡΟΕΠΙΛΟΓΗ: η ιδιοκτήτρια δεν πληκτρολογεί τίποτα για τις
    περισσότερες κλήσεις, όπως ζητήθηκε («να μην πρέπει να γράφει»).

    Το πεδίο υπάρχει μόνο όταν η ίδια θέλει μια υπηρεσία για ΕΝΑ κατοικίδιο
    (π.χ. ο ένας πλυντρείται, η άλλη κουρεμένη) — και τότε είναι μία και μόνη
    επιλογή για τη γραμμή, όχι μια στήλη που γεμίζει.

    ΤΟ ΠΕΔΙΟ ΠΙΑΝΕ ΤΑ ΠΕΔΙΑ `pet_<id>` ΚΑΙ ΤΑ `svc_pet` ΜΕ ΤΗ ΜΟΡΦΗ
    `<id>:<κατοικίδιο>` — τα δεύτερα έχουν ήδη χρησιμοποιηθεί σε αποθηκευμένες
    φόρμες, και ένα αγνοημένο όνομα σημαίνει χαμένη επιλογή χωρίς ειδοποίηση.
    """
    out: dict[int, int] = {}
    for raw in request.form.getlist("svc_pet"):
        sid, _, pid = str(raw).partition(":")
        try:
            out[int(sid)] = int(pid)
        except (TypeError, ValueError):
            continue
    for key, raw in request.form.items():
        if not key.startswith("pet_"):
            continue
        try:
            sid, pid = int(key[4:]), int(raw)
        except (TypeError, ValueError):
            continue
        if pid > 0:
            out[sid] = pid
    return out


def service_quantities_from_form() -> dict[int, int]:
    """{service_id: ποσότητα} από τη φόρμα ραντεβού.

    Αποδέχεται και τις δύο μορφές πεδίου ώστε να δουλεύει και με το
    κλασικό <input name="qty_3">, αλλά και με το νέο "service_id:qty".
    """
    quantities: dict[int, int] = {}
    for value in request.form.getlist("qty"):
        service_id, _, qty = str(value).partition(":")
        try:
            sid, count = int(service_id), int(qty)
        except (TypeError, ValueError):
            continue
        quantities[sid] = min(MAX_SERVICE_QUANTITY, max(1, count))
    for key, raw in request.form.items():
        if not key.startswith("qty_"):
            continue
        try:
            sid = int(key[4:])
        except ValueError:
            continue
        try:
            quantities[sid] = min(MAX_SERVICE_QUANTITY, max(1, int(raw)))
        except (TypeError, ValueError):
            continue
    return quantities


def pet_ids_from_form() -> list[int]:
    """Κατοικίδια επιλεγμένα στη φόρμα — μπορεί να είναι περισσότερα από ένα."""
    ids: list[int] = []
    for value in request.form.getlist("pet_ids"):
        try:
            pet_id = int(value)
        except (TypeError, ValueError):
            continue
        if pet_id not in ids:
            ids.append(pet_id)
    return ids


def pricing_for(
    services: list[Service],
    quantities: dict[int, int] | None = None,
    pets: dict[int, int] | None = None,
) -> tuple[float, int]:
    """Επιστρέφει (σύνολο τιμής, συνολική διάρκεια εκτίμησης).

    Η τιμή πολλαπλασιάζεται επί την ποσότητα κάθε υπηρεσίας. Η διάρκεια
    είναι ΕΝΔΕΙΚΤΙΚΗ: δεν καθορίζει τα slots, απλώς εμφανίζεται.

    ΤΟ «ΜΟΝΟ ΓΙΑ…» ΣΗΜΑΙΝΕΙ ΜΙΑ ΦΟΡΑ. Οταν η ιδιοκτήτρια έχει πει σε
    ποια κατοικίδιο αφορά η υπηρεσία, η ποσότητα δεν είναι «όσα
    κατοικίδια έχει το ραντεβού» αλλά ΟΧΙ. Χωρίς αυτόν τον κανόνα, το
    κόστος εμφανιζόταν ×2 για υπηρεσία που ισχύει σε ΕΝΑ ζώο, κι η
    ιδιοκτήτρια το έβλεπε χωρίς να μπορεί να το διορθώσει: το πεδίο
    «×» ξαναγραφόταν από τον αριθμό των κατοικιδίων σε κάθε αλλαγή.

    Ο ΚΑΝΟΝΑΣ ΕΙΝΑΙ ΕΝΑΣ, Ο ΙΔΙΟΣ ΠΑΝΤΟΥ: εδώ στον server, στο
    booking.js για την οθόνη, και στη _set_service_links για τη βάση.
    Αν οι τρεις διαφωνούν, το άθροισμα δεν ταιριάζει με το ραντεβού.
    """
    quantities = quantities or {}
    pets = pets or {}
    total_price = 0.0
    total_duration = 0
    for service in services:
        qty = max(1, int(quantities.get(service.id, 1)))
        if pets.get(service.id):
            qty = 1
        total_price += float(service.price or 0.0) * qty
        total_duration += int(service.duration_minutes or 0)
    return round(total_price, 2), total_duration


# ---------------------------------------------------------------- context
def salon_context() -> dict:
    """Οι ρυθμίσεις του σπα για τα πρότυπα.

    Σε καθαρή εγκατάσταση ο πίνακας μπορεί να μην υπάρχει ακόμη. Τότε
    δίνουμε τις προεπιλογές, ώστε η σελίδα πρώτης εγκατάστασης να
    ανοίγει αντί να πέσει με 500.
    """
    try:
        settings = SalonSettings.as_dict()
    except OperationalError:
        db.session.rollback()
        settings = dict(SalonSettings.DEFAULTS)
    return {
        "salon": settings,
    }


# ------------------------------------------------------------------- dates
def day_bounds(day: date_cls) -> tuple[datetime, datetime]:
    start = datetime.combine(day, time(0, 0))
    return start, start + timedelta(days=1)


def week_start(day: date_cls) -> date_cls:
    return day - timedelta(days=day.weekday())


def build_calendar_days(from_day: date_cls, days: int) -> list[date_cls]:
    return [from_day + timedelta(days=i) for i in range(days)]


def resolve_groomer(groomer_id: int | None) -> Groomer | None:
    if not groomer_id:
        return None
    return db.session.get(Groomer, groomer_id)
