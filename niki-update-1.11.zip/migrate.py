"""Μετατροπές βάσης δεδομένων — σύστημα διαχείρισης ραντεβού σαλονιού.

Χρήση:

    python migrate.py               # προσθέτει users.username + τιμές/έσοδα αν λείπουν
    python migrate.py --purge-demo  # καθαρίζει ΠΕΛΑΤΕΣ/ΚΑΤΟΙΚΙΔΙΑ/ΡΑΝΤΕΒΟΥ
                                    # και αφαιρεί τους λογαριασμούς βοηθών
                                    # (κρατά μόνο την ιδιοκτήτρια)

Το σενάριο είναι ασφαλές να εκτελείται πολλές φορές (idempotent).
Πριν αλλάξει κάτι, κάνει αντίγραφο ασφαλείας του instance/salon.db.
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from datetime import datetime, time as time_cls
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from app import create_app  # noqa: E402
from sqlalchemy import text as sa_text  # noqa: E402
from sqlalchemy.exc import SQLAlchemyError  # noqa: E402
from app.helpers import plural  # noqa: E402
from app.extensions import db  # noqa: E402

# ΟΥΔΕΤΡΟ. Παλαιότερα ο βοηθητικός λογαριασμός που δημιουργούσε εδώ
# έφερνε τα στοικεία ενός συγκεκριμένου ανθρώπου — όνομα, email, επώνυμο —
# και τυπώνονταν όλα μαζί στην οθόνη.
OWNER_USERNAME = "admin"
OWNER_EMAIL = "admin@example.com"
OWNER_PASSWORD = "salon1234"
OWNER_FIRST_NAME = "Test"
OWNER_LAST_NAME = "Owner"


# --------------------------------------------------------------------- βοηθητικά
def database_file() -> Path | None:
    """Το ΠΡΑΓΜΑΤΙΚΟ αρχείο SQLite που χρησιμοποιεί η εφαρμογή.

    ΡΩΤΑΜΕ ΤΗΝ SQLITE, ΔΕΝ ΔΙΑΒΑΖΟΥΜΕ ΤΟ URL. Το παλιό `url.replace(
    "sqlite:///", "")` ήταν χειρουργική επέμβαση σε αλφαβητικά: στα
    Windows έβριζε `C:/NikiSalon/instance/salon.db` χωρίς ριζικό και
    χωρίς πρόγραμμα οδήγησης, δηλαδή μη υπαρκτό μονοπάτι. Η
    `PRAGMA database_list` δίνει το απόλυτο, επιλυμένο αρχείο που
    ανοίγει η ίδια η SQLite — ακόμα κι όταν συνδεθήκαμε με σχετική
    διαδρομή. Κενό μόνο αν δεν είναι SQLite.
    """
    if not db.engine.dialect.name == "sqlite":
        return None
    with db.engine.connect() as conn:
        rows = conn.exec_driver_sql("PRAGMA database_list").fetchall()
    for row in rows:
        # (seq, name, file) — το 'main' είναι η βάση μας. Οι άλλες
        # (ATTACH) μπορεί να είναι κενές, γι' αυτό τις παρακάμπτω.
        if len(row) >= 3 and row[1] == "main" and row[2]:
            return Path(row[2])
    return None


#: Πόσα αντίγραφα της βάσης κρατάμε. Το πιο πρόσφατο είναι πάντα αυτό
#: που χρειάζεται για ανάκτηση αν κάτι πάει στραβά. Ο ΚΑΝΟΝΑΣ ΤΟΥ
#: ΙΔΙΟΚΤΗΤΗ: «η βάση + ΕΝΑ αντίγραφο, τα υπόλοιπα να σβήνουν».
BACKUPS_KEPT = 1


def backup_database() -> Path:
    """Αντίγραφο της βάσης, με χρονοσήμανση στο όνομα.

    ΧΡΗΣΙΜΟΠΟΙΕΙ ΤΟ ONLINE BACKUP API ΤΗΣ SQLITE, ΟΧΙ shutil.copy2. Η
    ενημέρωση τρέχει ενώ η εφαρμογή κρατάει τη βάση ανοιχτή: στα Windows
    το απλό copy πέφτει με «being used by another process», κι ακόμα
    κι πέτυχε δεν θα ήταν συνεπές στιγμιότυπο. Το `Connection.backup()`
    είναι το επίσημο API, μέσα στη βιβλιοθήκη της Python — χωρίς
    εξάρτηση — και δουλεύει με το αρχείο ανοιχτό.

    ΣΕ ΑΠΟΤΥΧΙΑ ΕΝΑΙΣΧΝΕΙ ΠΟΤΕ. Κάθε λόγος περιέχει τη διαδρομή και
    την αιτία: ένα αντίγραφο που δεν έγινε χωρίς εξήγηση σταματά την
    εγκατάσταση σε ένα βήμα που φαίνεται ασήμαντο.
    """
    import sqlite3

    source = database_file()
    if source is None:
        raise RuntimeError(
            "Η βάση δεν είναι SQLite — δεν ξέρω πώς να την αντιγράψω. "
            "Το όνομα του αρχείου είναι στο DATABASE_URL."
        )
    if not source.is_file():
        raise RuntimeError(
            "Δεν βρέθηκε το αρχείο της βάσης: %s\n"
            "Ελέγξε αν το instance\\ υπάρχει και αν έχεις δικαίωμα "
            "εγγραφής." % source
        )

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    target = source.with_name(f"{source.stem}.bak-{stamp}{source.suffix}")

    # ΤΑ ΑΝΟΙΓΜΑΤΑ ΕΙΝΑΙ ΜΕΣΑ ΣΤΟ try. Πριν ήταν έξω, και αν το αρχείο
    # δεν άνοιγε καθόλου (δικαιώματα, κλειδωμένο) η εξαίρεση έφευγε από
    # το ίδιο το connect — με το μήνυμα «unable to open database file»,
    # χωρίς διαδρομή. Δηλαδή ακριβώς το άχρηστο μήνυμα που διορθώνω.
    src = None
    dst = None
    try:
        src = sqlite3.connect(f"file:{source}?mode=ro", uri=True)
        dst = sqlite3.connect(target)
        src.backup(dst)
    except sqlite3.Error as exc:
        for handle in (dst, src):
            if handle is not None:
                try:
                    handle.close()
                except sqlite3.Error:
                    pass
        try:
            target.unlink()
        except OSError:
            pass
        raise RuntimeError(
            "Αποτυχία αντιγράφου της βάσης: %s\nΑρχείο: %s" % (exc, source)
        ) from exc
    finally:
        for handle in (dst, src):
            if handle is not None:
                try:
                    handle.close()
                except sqlite3.Error:
                    pass

    # ΕΛΕΓΧΟΣ ΤΟΥ ΑΝΤΙΓΡΑΦΟΥ. Ένα αντίγραφο που δεν ανοίγει δεν είναι
    # αντίγραφο· αν δεν το δούμε εδώ, το μαθαίνουμε στη ΧΕΙΡΟΤΕΡΗ ΣΤΙΓΜΗ,
    # όταν δεν θα ανοίγει η βάση μετά την ενημέρωση.
    try:
        with sqlite3.connect(f"file:{target}?mode=ro", uri=True) as probe:
            probe.execute("PRAGMA quick_check").fetchone()
    except sqlite3.Error as exc:
        try:
            target.unlink()
        except OSError:
            pass
        raise RuntimeError(
            "Το αντίγραφο δεν μπορεί να διαβαστεί: %s\n"
            "Αντίγραφο: %s" % (exc, target)
        ) from exc

    # ΜΕΤΑ ΤΟ ΠΡΩΤΟ ΑΝΤΙΓΡΑΦΟ ΚΑΘΑΡΙΖΟΥΜΕ ΤΑ ΠΑΛΙΑ, ΕΔΩ. Ο ΚΑΝΟΝΑΣ ΤΟΥ
    # ΙΔΙΟΚΤΗΤΗ: «η βάση + ΕΝΑ αντίγραφο». Ο καθαρισμός υπήρχε, αλλά
    # κρυφός στο prune_after_install() — δηλαδή μόνο μετά από εγκατάσταση
    # ενημέρωσης. Οι υπόλοιπες διαδρομές που κάνουν αντίγραφο (το `migrate`
    # με το χέρι, το update_now.py, οι παλιές εκδόσεις) ΔΕΝ καθάριζαν
    # ποτέ, και η ιδιοκτήτρια βρήκε τρία salon.bak-*.db στο instance/ και
    # ρώτησε τι είναι τα δύο παλιά.
    #
    # ΤΟ ΚΑΝΟΥΜΕ ΕΔΩ ΓΙΑΤΙ ΕΔΩ ΕΙΝΑΙ Η ΜΟΝΗ ΣΗΜΕΙΑ ΠΟΥ ΞΕΡΕΙ ΟΤΙ
    # ΔΗΜΙΟΥΡΓΗΘΗΚΕ ΝΕΟ ΑΝΤΙΓΡΑΦΟ. Όποιος και να 'ναι ο καλών, το αντίγραφο
    # που μόλις έγινε είναι το πιο πρόσφατο· τα παλιά δεν χρειάζονται.
    # Το ίδιο αποτέλεσμα έχει και το startup prune — εδώ όμως ισχύει
    # ΑΜΕΣΑ, χωρίς να περάσει από εγκατάσταση ή επανεκκίνηση.
    #
    # ΠΟΤΕ ΔΕΝ ΣΗΚΩΝΕΙ. Η βάση μόλις αντιγράφηκε επιτυχώς· αν το
    # σβήσιμο των παλιών αποτύγει, το νέο αντίγραφο υπάρχει και το μόνο
    # που χάνεται είναι χώρος στον δίσκο.
    try:
        prune_database_backups(source, keep=BACKUPS_KEPT)
    except OSError:
        pass

    return target


def prune_database_backups(source: Path, keep: int = BACKUPS_KEPT) -> int:
    """Κρατά τα `keep` πιο πρόσφατα `salon.bak-*.db` και σβήνει τα υπόλοιπα.

    Ξεχωριστή συνάρτηση — και όχι μέσα στη backup_database() — για να
    μπορεί να καλείται και χωρίς να δημιουργείται αντίγραφο (στην εκκίνηση
    της εφαρμογής, όπου το instance/ μπορεί να έχει μαζευτεί από
    εγκαταστάσεις που κόπηκαν στη μέση).
    """
    pattern = f"{source.stem}.bak-*{source.suffix}"
    found = sorted(source.parent.glob(pattern),
                   key=lambda p: p.stat().st_mtime, reverse=True)
    removed = 0
    for old in found[max(1, keep):]:
        try:
            old.unlink()
            removed += 1
        except OSError:
            pass
    return removed


def table_columns(table: str) -> set[str]:
    inspector = db.inspect(db.engine)
    if table not in inspector.get_table_names():
        return set()
    return {col["name"] for col in inspector.get_columns(table)}


def username_from(email: str | None, first_name: str | None) -> str:
    """Παράγει ένα μοναδικό όνομα χρήστη από υπάρχοντα στοιχεία."""
    base = ""
    if email and "@" in email:
        base = email.split("@", 1)[0]
    if not base:
        base = first_name or "user"
    base = re.sub(r"[^A-Za-z0-9_.-]+", "", base).strip("._-") or "user"
    return base


# ----------------------------------------------------- 1. στήλη users.username
def add_username_column() -> bool:
    """Προσθέτει το users.username και κάνει το email προαιρετικό."""
    if "username" in table_columns("users"):
        print("· Το users.username υπάρχει ήδη — δεν χρειάζεται αλλαγή.")
        return False

    print("· Προστίθεται η στήλη users.username και το email γίνεται προαιρετικό.")

    columns = table_columns("users")
    if not columns:
        print("✗ Δεν βρέθηκε ο πίνακας users. Εκτέλεσε πρώτα: python server.py --init-db")
        return False

    select_fields = [c for c in columns if c != "username"]
    quoted = ", ".join(f'"{c}"' for c in select_fields)
    rows = db.session.execute(db.text(f"SELECT {quoted} FROM users")).mappings().all()

    db.session.execute(db.text("DROP TABLE IF EXISTS users__new"))
    db.session.execute(
        db.text(
            """
            CREATE TABLE users__new (
                id INTEGER NOT NULL,
                username VARCHAR(80) NOT NULL,
                email VARCHAR(180),
                password_hash VARCHAR(255) NOT NULL,
                role VARCHAR(20) NOT NULL,
                first_name VARCHAR(80) NOT NULL,
                last_name VARCHAR(80) NOT NULL,
                phone VARCHAR(40),
                is_active_flag BOOLEAN NOT NULL,
                created_at DATETIME NOT NULL,
                last_login_at DATETIME,
                PRIMARY KEY (id),
                UNIQUE (username),
                UNIQUE (email)
            )
            """
        )
    )

    used: set[str] = set()
    for row in rows:
        candidate = username_from(row.get("email"), row.get("first_name"))
        username, suffix = candidate, 2
        while username.lower() in used:
            username = f"{candidate}{suffix}"
            suffix += 1
        used.add(username.lower())

        values = dict(row)
        values["username"] = username
        columns_sql = ", ".join(f'"{c}"' for c in ("username", *select_fields))
        placeholders = ", ".join(f":{c}" for c in ("username", *select_fields))
        db.session.execute(
            db.text(f"INSERT INTO users__new ({columns_sql}) VALUES ({placeholders})"),
            values,
        )

    db.session.execute(db.text("DROP TABLE users"))
    db.session.execute(db.text("ALTER TABLE users__new RENAME TO users"))
    db.session.execute(db.text("CREATE INDEX IF NOT EXISTS ix_users_username ON users (username)"))
    db.session.execute(db.text("CREATE INDEX IF NOT EXISTS ix_users_email ON users (email)"))
    db.session.execute(db.text("CREATE INDEX IF NOT EXISTS ix_users_role ON users (role)"))
    db.session.commit()

    print(f"✓ Ενημερώθηκαν: {plural(len(rows), 'χρήστης', 'χρήστες')}")
    return True


# ------------------------------------------------- 2. τιμές υπηρεσιών & έσοδα
# Κανονικές τιμές (μικρό/μεσαίο/μεγάλο/γιγάντιο), ίδιες με το έργο «niki salon».
PRICE_TABLE: list[tuple[str, list[float]]] = [
    ("Μπάνιο", [18, 24, 32, 40]),
    ("Κούρεμα με μηχανή", [22, 28, 36, 44]),
    ("Κούρεμα με ψαλίδι", [28, 36, 46, 56]),
    ("Κούρεμα φυλής", [34, 42, 54, 66]),
    ("Stripping", [30, 38, 48, 58]),
    ("Μείωση υπερβολικού μαδήματος", [10, 12, 15, 18]),
    ("Ξεκόμπιασμο & αφαίρεση τζίβας", [12, 15, 20, 25]),
    ("Κόψιμο νυχιών", [6, 8, 10, 12]),
    ("Καθάρισμα αυτιών", [6, 8, 10, 12]),
    ("Πατουσάκια & πισινός", [8, 10, 12, 14]),
]
# Διαρκειες ανά υπηρεσια (λεπτα) για καθαρη εγκατασταση. Σε παλια βαση
# παιρνονται αποτις παλιες στηλες dur_* (δει collapse_size_prices).
DURATION_TABLE: dict[str, int] = {
    "Μπάνιο & Στέγνωμα": 50,
    "Κούρεμα με μηχανή": 45,
    "Κούρεμα με ψαλίδι": 60,
    "Κούρεμα φυλής": 70,
    "Stripping": 65,
    "Μείωση υπερβολικού μαδήματος": 25,
    "Ξεκόμπιασμο & αφαίρεση τζίβας": 40,
    "Κόψιμο νυχιών": 20,
    "Καθάρισμα αυτιών": 15,
    "Πατουσάκια & πισινός": 15,
}

# Μία τιμή ανά υπηρεσία. Παλιά ήταν τέσσερες (ανά μέγεθος)· κρατάμε τη
# «large» (τρίτη θέση) όπως ζητήθηκε.
SINGLE_PRICE_INDEX = 2
PRICE_SIZES = ("small", "medium", "large", "giant")  # legacy, για παλιές βάσεις


def add_column(table: str, column: str, ddl: str) -> bool:
    """ALTER TABLE ADD COLUMN, ανοστεκδιάστατο."""
    if not table_columns(table):
        print(f"✗ Δεν βρέθηκε ο πίνακας {table}.")
        return False
    if column in table_columns(table):
        return False
    db.session.execute(db.text(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}"))
    return True


def add_archive_columns() -> bool:
    """Προσθέτει τις σημαίες αρχειοθέτησης σε χρήστες και κατοικίδια.

    ΟΙ ΔΥΟ ΑΥΤΕΣ ΣΤΗΛΕΣ ΥΠΗΡΧΑΝ ΣΤΑ ΜΟΝΤΕΛΑ ΑΠΟ ΤΗΝ 1.2, ΧΩΡΙΣ ΜΕΤΑΤΡΟΠΗ ΠΟΥ
    ΝΑ ΤΙΣ ΠΡΟΣΘΕΤΕΙ ΣΕ ΥΠΑΡΧΟΝΤΑ ΒΑΣΗ. Το create_all() φτιάχνει ΠΙΝΑΚΕΣ που
    λείπουν, όχι ΣΤΗΛΕΣ που λείπουν — άρα μια ΦΡΕΣΚΑ εγκατάσταση τις έπαιρνε
    κανονικά και έτσι το λάθος δεν φάνηκε. Μια ΕΝΗΜΕΡΩΣΗ όμως κρατά τη βάση
    του πελάτη, και εκεί λείπαν.

    ΤΟ ΑΠΟΤΕΛΕΣΜΑ ΗΤΑΝ ΘΑΝΑΣΙΜΟ ΚΑΙ ΣΙΩΠΗΛΟ: με το «Μετατροπές βάσης
    απέτυχαν — επαναφέρθηκε το αντίγραφο» η ενημέρωση ΔΕΝ εγκαταστάθηκε ποτέ,
    και το ίδιο θα γινόταν σε κάθε επόμενη. Χειρότερο: στην 1.2 το
    `Pet.active_pets` διάβαζε ήδη το `is_archived`, οπότε κάθε εγκατάσταση που
    είχε ενημερωθεί (και όχι εγκατασταθεί από το μηδέν) έπαθε σφάλμα στο
    πρώτο ερώτημα που αγγίζει κατοικίδιο.

    ΤΟ ΙΔΙΟ ΜΟΤΙΒΟ ΤΟ ΕΙΧΕ ΛΥΣΕΙ Η add_customer_archive_column() για τους
    πελάτες — και το σχόλιό της το προειδοποιούσε ρητά. Εδώ το παραλήφθηκε.
    """
    added = add_column("users", "is_archived", "BOOLEAN NOT NULL DEFAULT 0")
    added |= add_column("pets", "is_archived", "BOOLEAN NOT NULL DEFAULT 0")
    return added


def add_pricing_columns() -> bool:
    """Προσθέτει τιμές στις υπηρεσίες και σύνολο/έκπτωση στα ραντεβού."""
    if not table_columns("services"):
        print("✗ Δεν βρέθηκε ο πίνακας services. Εκτέλεσε πρώτα: python server.py --init-db")
        return False

    added = False
    for size in PRICE_SIZES:
        added |= add_column("services", f"price_{size}", "FLOAT")
    # Νέο μοντέλο: μία τιμή / μία διάρκεια για όλα τα κατοικίδια.
    added |= add_column("services", "price", "FLOAT NOT NULL DEFAULT 0")
    added |= add_column("services", "duration_minutes", "INTEGER NOT NULL DEFAULT 30")

    # Το άθροισμα τιμών κρατάμε πάντα, για να μην εξαρτάται από τον τιμοκατάλογο.
    if add_column("appointments", "total_price", "FLOAT NOT NULL DEFAULT 0.0"):
        added = True
    if add_column("appointments", "price_override", "FLOAT"):
        added = True

    # Παραλαβή από άλλο άτομο (όνομα + τηλέφωνο).
    if add_column("appointments", "pickup_name", "VARCHAR(120)"):
        added = True
    if add_column("appointments", "pickup_phone", "VARCHAR(40)"):
        added = True

    if not added:
        print("· Οι στήλες τιμών υπάρχουν ήδη — δεν χρειάζεται αλλαγή.")
    else:
        print("· Προστέθηκαν οι στήλες τιμών & παραλαβής "
              "(services.price_*, appointments.total_price/price_override/pickup_*).")
    backfill_service_prices()
    return backfill_appointment_prices()


# Τιμή/διάρκεια ανά υπηρεσία: μία για όλα τα κατοικίδια. Κρατάμε τη μεγάλη
# (παλιά "large") τιμή, όπως ζητήθηκε.
COLLAPSE_SIZE_TO = "large"


def collapse_size_prices() -> bool:
    """Κάνει τις 4 τιμές/διάρκειες ανά μέγεθος μία τιμή/διάρκεια.

    Οι παλιές στήλες (price_small…price_giant) μένουν στη βάση αλλαγμένες —
    δεν διαβάζονται πουθενά. Οι νέες στήλες γεμίζουν από την price_large/dur_large.
    """
    from app.models import Service

    cols = table_columns("services")
    changed = False
    if "price" not in cols:
        add_column("services", "price", "REAL NOT NULL DEFAULT 0")
        changed = True
    if "duration_minutes" not in cols:
        add_column("services", "duration_minutes", "INTEGER NOT NULL DEFAULT 30")
        changed = True
    db.session.commit()
    if not changed:
        return False

    source = f"price_{COLLAPSE_SIZE_TO}"
    if source not in table_columns("services"):
        return True
    rows = db.session.execute(
        db.text(f"SELECT id, {source} FROM services")
    ).fetchall()
    for service_id, value in rows:
        db.session.execute(
            db.text("UPDATE services SET price = :p WHERE id = :i"),
            {"p": float(value or 0), "i": service_id},
        )
    # Διάρκεια: παίρνουμε τη μεγάλη· αλλιώς όποια υπάρχει· αλλιώς 30.
    dur_cols = [c for c in ("dur_large", "dur_giant", "dur_medium", "dur_small")
                if c in table_columns("services")]
    if dur_cols:
        for service_id, *values in db.session.execute(
            db.text("SELECT id, " + ", ".join(dur_cols) + " FROM services")
        ).fetchall():
            pick = next((v for v in values if v), 30)
            db.session.execute(
                db.text("UPDATE services SET duration_minutes = :d WHERE id = :i"),
                {"d": int(pick), "i": service_id},
            )
    db.session.commit()
    return True


def add_quantity_to_services() -> bool:
    """Προσθέτει quantity/duration στον σύνδεσμο appointment_services."""
    cols = table_columns("appointment_services")
    changed = False
    if "quantity" not in cols:
        add_column("appointment_services", "quantity", "INTEGER NOT NULL DEFAULT 1")
        changed = True
    if "duration" not in cols:
        add_column("appointment_services", "duration", "INTEGER NOT NULL DEFAULT 30")
        changed = True
    if changed:
        db.session.commit()
    return changed


def add_pet_to_appointment_services() -> bool:
    """Προσθέτει το «ποιο κατοικίδιο παίρνει την υπηρεσία».

    ΚΕΝΟ ΣΤΗ ΣΤΗΛΗ = ΟΛΑ ΤΑ ΚΑΤΟΙΚΙΔΙΑ ΤΟΥ ΡΑΝΤΕΒΟΥ. Άρα τα 40 παλιά
    ραντεβού παραμένουν έγκυρα και συμπεριφέρονται όπως συμπεριφέρονταν:
    οι υπηρεσίες τους αφορούν όλα τα κατοικίδια τους.

    ΤΟ ΓΙΑΤΙ ΚΕΝΟ, ΚΑΙ ΟΧΙ «κάποιο συγκεκριμένο»: τα παλιά δεν έχουν
    ΠΛΗΡΟΦΟΡΙΑ. Βάζοντας ένα κατοικίδιο σε κάθε παλιά γραμμή θα πλάσαμε
    πληροφορία που δεν υπάρχει — και η ιδιοκτήτρια θα έβλεπε «ο Σκύλος
    πλυντρείται» σε ένα ραντεβού που ίσως ήταν εντελώς διαφορετικό. Το κενό
    λέει την αλήθεια· η οθόνη το εμφανίζει ως «όλα τα κατοικίδια» ή «δεν έχει
    καταχωριστεί», ανάλογα με το αν προκύπτει από τα δεδομένα.
    """
    return add_column(
        "appointment_services", "pet_id",
        "INTEGER REFERENCES pets(id) ON DELETE SET NULL",
    )


def backfill_service_durations() -> bool:
    """Γεμίζει το duration των γραμμών από την υπηρεσία (για παλιές εγγραφές)."""
    result = db.session.execute(db.text(
        "UPDATE appointment_services SET duration = ("
        "  SELECT duration_minutes FROM services WHERE services.id = appointment_services.service_id"
        ") WHERE duration IS NULL OR duration = 0"
    ))
    db.session.commit()
    return bool(result.rowcount)


def add_customer_fullname() -> bool:
    """Ενώνει first/last name σε ένα πεδίο name."""
    cols = table_columns("customers")
    if "name" not in cols:
        add_column("customers", "name", "TEXT")
        db.session.commit()
        cols = table_columns("customers")
    # Σε κενή εγκατάσταση ο create_all() δημιουργεί ήδη το `name` και δεν
    # υπάρχουν first_name/last_name — δεν υπάρχει τίποτα να ενώσει.
    if "first_name" not in cols or "last_name" not in cols:
        return False
    result = db.session.execute(db.text(
        "UPDATE customers SET name = TRIM("
        "  COALESCE(first_name,'') || ' ' || COALESCE(last_name,'')"
        ") WHERE name IS NULL OR TRIM(name) = ''"
    ))
    db.session.commit()
    # True μόνο αν ενώθηκαν πραγματικά γραμμές, αλλιώς το μήνυμα εμφανίζεται
    # σε κάθε εκτέλεση χωρίς να γίνεται τίποτα.
    return bool(result.rowcount)


def add_appointment_pets() -> bool:
    """Πίνακας πολλών κατοικιδίων ανά ραντεβού + μεταφορά από το pet_id.

    Επιστρέφει True μόνο αν μπήκαν πραγματικά γραμμές, ώστε το μήνυμα της
    εγκατάστασης να μην εμφανίζεται σε κάθε εκτέλεση.
    """
    from app.models import appointment_pets

    db.create_all()
    cols = table_columns("appointments")
    if "pet_id" not in cols:
        return False
    result = db.session.execute(db.text(
        "INSERT OR IGNORE INTO appointment_pets (appointment_id, pet_id) "
        "SELECT id, pet_id FROM appointments WHERE pet_id IS NOT NULL"
    ))
    db.session.commit()
    return bool(result.rowcount)


def drop_not_null(table: str, columns: list[str]) -> bool:
    """Αφαιρεί το NOT NULL από στήλες. Ο SQLite το αλλάζει μόνο με
    αναδιαμορφωσμό ολόκληρου πίνακα (νέος → αντιγραφή → drop → rename).

    Επιστρέφει True αν άλλαξε κάτι. Οι παλιές στήλες first_name/last_name
    κρατούνται για ασφάλεια αλλά γίνονται προαιρετικές, ώστε το app να
    γράφει μόνο το `name`.
    """
    db.session.commit()
    info = db.session.execute(db.text(f"PRAGMA table_info({table})")).fetchall()
    if not info:
        return False
    present = {r[1] for r in info}
    targets = [c for c in columns if c in present]
    if not targets:
        return False
    still_required = [
        r[1] for r in info
        if r[1] in targets and r[3] and r[4] is None
    ]
    if not still_required:
        return False   # ήδη προαιρετικές

    db.session.execute(db.text("PRAGMA foreign_keys=OFF"))
    all_cols = [r[1] for r in info]
    defs = []
    for r in info:
        ddl = f'"{r[1]}" {r[2] or ""}'
        if r[1] in targets:
            ddl = f'"{r[1]}" {r[2] or "TEXT"}'      # χωρίς NOT NULL
        elif r[3]:
            ddl += " NOT NULL"
        if r[4] is not None:
            ddl += f" DEFAULT {r[4]}"
        if r[5]:
            ddl += " PRIMARY KEY"
        defs.append(ddl)
    quoted = ", ".join(f'"{c}"' for c in all_cols)
    tmp = f"{table}__nn"
    db.session.execute(db.text(f"DROP TABLE IF EXISTS {tmp}"))
    db.session.execute(db.text(f"CREATE TABLE {tmp} ({', '.join(defs)})"))
    db.session.execute(db.text(
        f"INSERT INTO {tmp} ({quoted}) SELECT {quoted} FROM {table}"
    ))
    db.session.execute(db.text(f"DROP TABLE {table}"))
    db.session.execute(db.text(f"ALTER TABLE {tmp} RENAME TO {table}"))
    db.session.commit()
    db.session.execute(db.text("PRAGMA foreign_keys=ON"))
    return True


def relax_optional_fields() -> None:
    """Ονοματεπώνυμο σε ένα πεδίο + προαιρετικό όνομα κατοικιδίου."""
    # Το size καταργήθηκε από το μοντέλο· η παλιά στήλη μένει αχρησίμητη,
    # αλλά πρέπει να γίνει προαιρετική αλλιώς το INSERT χωρίς size αποτυγχάνει.
    drop_not_null("customers", ["first_name", "last_name", "name"])
    drop_not_null("pets", ["name", "size"])


# Προτυπικά έξοδα καταστήματος. Μπαίνουν μία φορά ώστε η ιδιοκτήτρια να έχει
# έτοιμα κουμπιά (ρεύμα, νερό, ενοικίαση…) και να μην τα πληκτρολογεί κάθε φορά.
# Αλλάζονται/διαγράφονται ελεύθερα από τις Ρυθμίσεις.
DEFAULT_STORE_EXPENSES = (
    # (ετικέτα, τυπικό ποσό)
    ("Ρεύμα (ΔΕΗ)", 0.0),
    ("Νερό", 0.0),
    ("Ενοικίαση", 0.0),
    ("Αναψυκτικά & καφές για τους πελάτες", 0.0),
    ("Καθαριστικά καταστήματος", 0.0),
    ("Internet & τηλέφωνο", 0.0),
    ("Προγράμμα ραντεβού (συνδρομή)", 0.0),
    ("Συντήρηση εξοπλισμού", 0.0),
    ("Διαφήμιση & προώθηση", 0.0),
    ("Λογαριασμοί τραπέζης (τράπεζα)", 0.0),
    ("Άλλα έξοδα καταστήματος", 0.0),
)


def backfill_store_expenses() -> int:
    """Προσθέτει τα προκαθορισμένα είδη ΠΟΥ ΛΕΙΠΟΥΝ — χωρίς να πειράξει όσα υπάρχουν.

    ΤΟ ΠΡΟΒΛΗΜΑ ΣΤΟ ΜΗΧΑΝΗΜΑ ΤΟΥ ΣΑΛΟΝΙΟΥ: η `seed_store_expenses()` κάνει
    «αν υπάρχει ΕΝΑ είδος, μη κάνεις τίποτα». Άρα σε εγκατάσταση που είχε ήδη
    ΜΙΑ-ΔΥΟ καταχωρήσεις, ΚΑΘΕ ΝΕΑ ΠΡΟΣΘΕΤΗ ΕΙΔΗ ΠΟΥ ΠΡΟΣΤΕΘΗΤΕ ΠΟΤΕ
    ΔΕΝ ΜΠΗΚΕ ΠΟΤΕ. Η ιδιοκτήτρια έβλεπε τη λίστα να μην έχει «καφές»,
    «νερό», «ενοίκιο», «internet» — και να νομίζει ότι η εφαρμογή τα έχει
    σβήσει. Δεν τα έχει σβήσει: ΠΟΤΕ ΔΕΝ ΜΠΗΚΑΝ.

    ΕΔΩ ΓΡΑΦΟΥΜΕ Ο,ΤΙ ΛΕΙΠΕΙ ΜΟΝΟ. ΤΙΣ ΕΤΙΚΕΤΕΣ ΠΟΥ Η ΙΔΙΑ ΕΧΕΙ ΓΡΑΨΕΙ
    ΔΕΝ ΤΙΣ ΑΓΓΙΖΟΥΜΕ — είναι δικά της δεδομένα, όχι προτάσεις μας.
    """
    from app.models import EXPENSE_STORE, ExpenseItem

    have = {(r.label or "").strip() for r in ExpenseItem.query.all()}
    missing = [(label, amount) for label, amount in DEFAULT_STORE_EXPENSES
               if label not in have]
    if not missing:
        return 0
    start = ExpenseItem.query.count()
    for order, (label, amount) in enumerate(missing):
        db.session.add(ExpenseItem(label=label, category=EXPENSE_STORE,
                                   default_amount=amount,
                                   sort_order=start + order))
    db.session.commit()
    return len(missing)


def seed_store_expenses() -> int:
    """Δημιουργεί τον κατάλογο εξόδων καταστήματος, αν είναι κενός."""
    from app.models import EXPENSE_STORE, ExpenseItem

    if ExpenseItem.query.first():
        return 0
    for order, (label, amount) in enumerate(DEFAULT_STORE_EXPENSES):
        db.session.add(ExpenseItem(
            label=label,
            category=EXPENSE_STORE,
            default_amount=amount,
            sort_order=order,
        ))
    db.session.commit()
    return len(DEFAULT_STORE_EXPENSES)


def add_customer_archive_column() -> bool:
    """Προσθέτει τη σήμα αρχειοθέτησης στον πίνακα πελατών.

    Χωρίς αυτή τη στήλη μια εγκατάσταση που είχε ήδη βάση θα ξεκινούσε με
    επισκοπήσεις που δεν βρίσκουν το πεδίο. Με NOT NULL DEFAULT 1 οι υπάρχοντες
    πελάτες παραμένουν ενεργοί — η αρχειοθέτηση είναι πράξη της ιδιοκτήτριας,
    όχι αναδιαμόρφωση του ιστορικού."""
    added = add_column("customers", "is_active_flag", "BOOLEAN NOT NULL DEFAULT 1")
    # Η ΗΜΕΡΟΜΗΝΙΑ ΕΙΝΑΙ ΜΙΑ ΣΤΗΛΗ, ΟΧΙ ΜΙΑ ΕΠΙΛΟΓΗ. Χωρίς αυτήν την
    # κλήση, μια παλιά βάση θα πάρει μόνο το is_active_flag και η εφαρμογή
    # θα σπάσει αμέσως μετά την εγκατάσταση, όταν διαβάσει το archived_at —
    # δηλαδή ΘΑ ΤΟ ΣΠΑΣΕΙ Ο ΙΔΙΟΣ Ο ΜΗΧΑΝΙΣΜΟΣ ΜΕΤΑΤΡΟΠΩΝ.
    added |= add_column("customers", "archived_at", "DATETIME")
    return added


def add_expenses_table(already_present: bool = False) -> bool:
    """Εξασφαλίζει ότι υπάρχει ο πίνακας εξόδων (έξοδα υλικών)."""
    if already_present:
        print("· Ο πίνακας expenses υπάρχει ήδη — δεν χρειάζεται αλλαγή.")
        return False
    db.create_all()
    print("✓ Δημιουργήθηκε ο πίνακας expenses (έξοδα υλικών).")
    return True


def _find_service(name: str):
    """Βρίσκει την υπηρεσία με ακριβή ή μοναδικό prefix ταιριάσμα.

    Το όνομα μπορεί να διαφέρει ελαφρώς από το «niki salon»
    (π.χ. «Μπάνιο» εκεί, «Μπάνιο & Στέγνωμα» εδώ)."""
    from app.models import Service

    service = Service.query.filter(Service.name == name).first()
    if service is not None:
        return service
    matches = Service.query.filter(Service.name.like(f"{name}%")).all()
    return matches[0] if len(matches) == 1 else None


def backfill_appointment_prices() -> bool:
    """Γεμίζει το total_price των υπαρκόντων ραντεβού από τις υπηρεσίες τους.

    Τα παλιά ραντεβού δημιουργήθηκαν όταν δεν υπήρχαν τιμές, άρα έχουν 0.
    Το price_override μένει άδειο — καμία έκπτωση δεν δίνεται «φαντασιακά».
    """
    from app.helpers import pricing_for
    from app.models import Appointment, AppointmentService

    patched = 0
    for appointment in Appointment.query.all():
        if float(appointment.total_price or 0) > 0:
            continue
        if not appointment.service_links:
            continue
        # Οι παλιές γραμμές έχουν quantity=1· οι νέες το διαβάζουν.
        quantities = {link.service_id: max(1, int(link.quantity or 1))
                      for link in appointment.service_links}
        price, _duration = pricing_for(appointment.services, quantities)
        if price > 0:
            appointment.total_price = round(price, 2)
            patched += 1

    # Παλιές γραμμές χωρίς διάρκεια: παίρνουν τη διάρκεια της υπηρεσίας.
    for link in db.session.query(AppointmentService).filter(
        db.or_(AppointmentService.duration.is_(None), AppointmentService.duration == 0)
    ).all():
        if link.service is not None:
            link.duration = int(link.service.duration_minutes or 30)

    if patched:
        db.session.commit()
        print(f"✓ Τιμές: {plural(patched, 'ραντεβού', 'ραντεβού')} με υπολογισμένο σύνολο.")
    else:
        print("· Τα υπάρχοντα ραντεβού έχουν ήδη τιμή ή δεν έχουν υπηρεσίες.")
    return bool(patched)


def backfill_service_prices() -> bool:
    """Γράφει τις κανονικές τιμές στις υπηρεσίες που δεν έχουν ήδη τιμή."""
    from app.models import Service

    updated = 0
    for name, prices in PRICE_TABLE:
        service = _find_service(name)
        if service is None:
            continue
        # Δεν γράφουμε ποτέ πάνω από τιμή που έχει ήδη οριστεί.
        if float(service.price or 0) > 0:
            continue
        service.price = float(prices[SINGLE_PRICE_INDEX])
        service.duration_minutes = int(
            DURATION_TABLE.get(name, service.duration_minutes or 30)
        )
        updated += 1

    if updated:
        db.session.commit()
        print(f"✓ Τιμοκατάλογος: {plural(updated, 'υπηρεσία', 'υπηρεσίες')} με τιμές.")
    else:
        print("· Οι τιμές υπηρεσιών είναι ήδη σωστές.")
    return bool(updated)


# ------------------------------------------------------------ 3. καθαρισμός demo
def purge_demo_data() -> None:
    """Καθαρίζει πελάτες, κατοικίδια, ραντεβού, ειδοποιήσεις & λογαριασμούς βοηθών."""
    from app.models import (ROLE_OWNER, ROLE_STAFF, Appointment, Customer,
                            Notification, Pet, User)

    appts = db.session.execute(db.text("SELECT COUNT(*) FROM appointments")).scalar() or 0
    customers = db.session.execute(db.text("SELECT COUNT(*) FROM customers")).scalar() or 0
    pets = db.session.execute(db.text("SELECT COUNT(*) FROM pets")).scalar() or 0
    # ΜΟΝΟ ΟΙ ΒΟΗΘΟΙ. Ο υπεύθυνος είναι λογαριασμός επιπέδου ιδιοκτήτη και
    # δεν είναι δεδομένο επίδειξης — δεν σβήνεται μαζί με τα υπόλοιπα.
    staff = User.query.filter_by(role=ROLE_STAFF).count()

    print(
        f"· Θα διαγραφούν: {plural(customers, 'πελάτης', 'πελάτες')}, "
        f"{plural(pets, 'κατοικίδιο', 'κατοικίδια')}, "
        f"{plural(appts, 'ραντεβού', 'ραντεβού')}, "
        f"{plural(staff, 'λογαριασμός βοηθού', 'λογαριασμοί βοηθών')}."
    )

    db.session.execute(db.text("DELETE FROM appointment_services"))
    db.session.execute(db.text("DELETE FROM notifications"))
    db.session.query(Appointment).delete()
    db.session.query(Pet).delete()
    db.session.query(Customer).delete()

    for user in User.query.filter_by(role=ROLE_STAFF).all():
        # Οι στυλίστρες των βοηθών διαγράφονται μαζί με τον χρήστη.
        if user.groomer is not None:
            db.session.delete(user.groomer)
        db.session.delete(user)

    db.session.commit()
    print("✓ Η βάση καθαρίστηκε. Κρατήθηκαν υπηρεσίες, ώρες λειτουργίας & ρυθμίσεις Salon.")


# ----------------------------------------------------------------- 4. ιδιοκτήτρια
# Πραγματικές ώρες του σπα. Χρησιμοποιούνται ΜΟΝΟ όταν ο πίνακας
# salon_day_settings είναι άδειος, δηλαδή σε καθαρή εγκατάσταση.
def seed_salon_settings() -> int:
    """Γράφει στη βάση τις ρυθμίσεις σπα που λείπουν. Επιστρέφει πόσες μπήκαν.

    Έτσι το σλόγκαν και οι υπόλοιπες προεπιλογές του σπα υπάρχουν ως σειρές και
    εμφανίζονται στη φόρμα Ρυθμίσεων, ώστε η ιδιοκτήτρια να μπορεί να τις
    αλλάξει. Δεν αντικαθιστά ποτέ υπάρχον τιμή, άρα σε εγκαταστάσεις με άλλο
    σπα δεν πειράζει τίποτα.
    """
    from app.models import SalonSettings

    existing = {row.key for row in SalonSettings.query.all()}
    added = 0
    for key, value in SalonSettings.DEFAULTS.items():
        if key not in existing:
            SalonSettings.set(key, value)
            added += 1
    if added:
        db.session.commit()
    return added


DEFAULT_SALON_HOURS = (
    # (weekday, is_closed, open, close)
    (0, True,  None,   None),   # Δευτέρα
    (1, False, "12:00", "21:00"),
    (2, False, "09:00", "17:00"),
    (3, False, "12:00", "21:00"),
    (4, False, "09:00", "17:00"),
    (5, False, "09:00", "15:00"),
    (6, True,  None,   None),   # Κυριακή
)


#: ΤΑ ΑΡΧΕΙΑ ΕΚΚΙΝΗΣΗΣ. Μένουν στη ρίζα του installer για πάντα — το Task
#: Scheduler και το run_server.cmd έχουν αυτή τη διαδρομή στις ρυθμίσεις τους.
LAUNCHERS = ("server.py", "wsgi.py")


def _installer_root() -> Path:
    """Ο φάκελος του INSTALLER — όχι αυτός της έκδοσης.

    ΔΕΝ ξαναγράφω το ίδιο «ανέβα τρία επίπεδα» που έχει ήδη το
    `config._install_root()`. Ένας δεύτερος τρόπος να υπολογιστεί η ίδια
    διαδρομή είναι δεύτερη ευκαιρία να γίνει λάθος — και λάθος εδώ σημαίνει
    «έγραψα τα αρχεία εκκίνησης μέσα στο instance/», όπου δεν τα κοινάει
    κανένας. Οι δοκιμές του config.py καλύπτουν ήδη τη δική του εκδοχή.
    """
    from config import BASE_DIR as ROOT

    return ROOT


def sync_launchers() -> list[str]:
    """Αντιγράφει server.py/wsgi.py από την έκδοση στη ρίζα του installer.

    ΓΙΑΤΙ ΕΔΩ ΚΑΙ ΟΧΙ ΣΤΟ install_update(): το βήμα εγκατάστασης τρέχει ο
    ΚΩΔΙΚΑΣ ΠΟΥ ΤΡΕΧΕΙ ΤΩΡΑ. Ο ιδιοκτήτης στο 1.7 εγκαθιστά το 1.8, άρα το
    βήμα το τρέχει το 1.7 — που φυσικά δεν έχει αυτή τη διόρθωση μέσα του.
    Το `migrate.py` όμως εκτελείται ΑΠΟ ΤΗ ΝΕΑ ΕΚΔΟΣΗ (ο εγκαταστέας το
    καλεί με τον φάκελό της στο PYTHONPATH), άρα το 1.8 μπορεί να
    διορθώσει τον εαυτό του τη στιγμή που εγκαθίσταται. Χωρίς αυτό, η
    διόρθωση θα έπαιρνε μία ΕΚΔΟΣΗ καθυστέρηση — και τα ρολόγια θα έστελναν
    παλιά υπενθύμιση για ακόμα μία περίοδο.

    ΤΟ ΙΔΙΟ ΜΠΛΟΚΟ ΥΠΗΡΧΕ ΉΔΗ ΣΤΟ app/updates.py (`_sync_launchers`). Μένει
    και εκεί για τις επόμενες ενημερώσεις, όπου εκείνο το βήμα θα τρέχει
    ήδη με τον καινούριο κώδικα. Το migrate.py είναι το δίχτυ ασφαλείας για
    τη ΜΕΤΑΒΑΣΗ, όχι δύο τρόποι να κάνουν το ίδιο πράγμα.

    ΠΟΤΕ ΔΕΝ ΚΑΝΕ ΛΑΘΟΣ: σε φρέσκα εγκατάσταση η ρίζα ΕΙΝΑΙ η έκδοση, οπότε
    πηγή και προορισμός είναι το ίδιο αρχείο. Και αν κάτι αποτύχει, το
    migrate.py δεν πρέπει να ρίξει την εγκατάσταση — μια ρίζα που δεν
    γράφτηκε είναι προτιμότερη από εγκατάσταση που κολλάει.
    """
    root = _installer_root()
    written: list[str] = []
    for name in LAUNCHERS:
        src, dst = BASE_DIR / name, root / name
        try:
            if not src.is_file() or not dst.parent.is_dir():
                continue
            if src.resolve() == dst.resolve():
                continue                      # φρέσκα εγκατάσταση
            if dst.is_file() and dst.read_bytes() == src.read_bytes():
                continue                      # ήδη σωστά
            dst.write_bytes(src.read_bytes())
            written.append(name)
        except OSError as exc:
            print(f"· Τα αρχεία εκκίνησης δεν ενημερώθηκαν ({exc}).")
            break
    return written


def purge_literal_nulls() -> int:
    """Καθαρίζει το ΚΕΙΜΕΝΟ «None» από τα πεδία που γράφτηκαν από εισαγωγή.

    Ένας αντιγραφέας που διαβάζει κενή στήλη από xlsx/CSV παίρνει το αντικείμενο
    None και το κάνει str(): η βάση αποθηκεύει ΤΟ ΚΕΙΜΕΝΟ «None», και το
    πρότυπο το δείχνει στον πελάτη ως «Τηλέφωνο: None». Το `or '—'` του
    προτύπου δεν το σώζει, γιατί μια μη κενή συμβολοειρά είναι αληθινή.

    Δεν πειράζουμε το schema — μόνο τιμές. Και μόνο όπου το κείμενο είναι
    ΑΚΡΙΒΩΣ «None»· ένα αληθινό «None Street» είναι νόμιμο όνομα δρόμου.
    """
    targets = [
        ("customers", ("phone", "address", "email")),
        ("pets", ("name", "breed", "notes")),
        ("appointments", ("pickup_name", "pickup_phone")),
        ("users", ("phone",)),
        ("services", ("name", "description")),
    ]
    cleared = 0
    for table, columns in targets:
        existing = table_columns(table)
        for column in columns:
            if column not in existing:
                continue
            try:
                result = db.session.execute(
                    sa_text(f"UPDATE {table} SET {column} = NULL "
                            f"WHERE lower(trim({column})) IN ('none','null','nan','n/a')")
                )
                cleared += result.rowcount or 0
            except SQLAlchemyError:
                db.session.rollback()
    if cleared:
        db.session.commit()
    return cleared


def _clock(value: str | None):
    """'HH:MM' -> datetime.time (None περνά απευθείας)."""
    if not value:
        return None
    hour, _, minute = value.partition(":")
    return time_cls(int(hour), int(minute))


def seed_salon_hours() -> int:
    """Δημιουργεί τις ώρες λειτουργίας, αν δεν υπάρχουν. Επιστρέφει πόσες μπήκαν.

    Χωρίς αυτές η νέα εγκατάσταση ξεκινά χωρίς ώρες: το σπα φαίνεται
    κλειστό, ο πίνακας δείχνει «μέρα ελεύθερη» παντού και δεν κλείνονται
    ραντεβού. Οι διαθεσιμότητες της ιδιοκτήτριας παίρνουν τις ώρες από εδώ.
    """
    from app.models import SalonDaySettings

    if SalonDaySettings.query.first():
        return 0

    for weekday, is_closed, open_h, close_h in DEFAULT_SALON_HOURS:
        db.session.add(SalonDaySettings(
            weekday=weekday,
            is_closed=is_closed,
            open_time=_clock(open_h),
            close_time=_clock(close_h),
        ))
    db.session.commit()
    return len(DEFAULT_SALON_HOURS)


def ensure_owner(create: bool = False) -> None:
    """Εξασφαλίζει ότι υπάρχει λογαριασμός ιδιοκτήτριας.

    ΠΟΤΕ δεν γράφει πάνω από υπάρχοντα ιδιοκτήτη: αν έχεις ήδη δικό σου
    λογαριασμό, το όνομα χρήστη και το email του παραμένουν αυτά που έβαλες.

    Δημιουργεί προσωρινό λογαριασμό μόνο μετά από ρητό --create-owner,
    ώστε μια καθαρή εγκατάσταση να μην ξεκινά με δημόσιο κωδικό.
    """
    from app.models import ROLE_OWNER, Groomer, User

    owner = User.query.filter_by(role=ROLE_OWNER).first()
    if owner is not None:
        if owner.groomer is None:
            db.session.add(Groomer(user_id=owner.id, sort_order=owner.id, color="#B0567A"))
            db.session.commit()
            print(f"✓ Δημιουργήθηκε λογαριασμός στυλίστριας για τον «{owner.username}».")
        else:
            print(f"· Υπάρχει ήδη ιδιοκτήτρια: «{owner.username}» (αφήθηκε ανέπαφη).")
        return

    if not create:
        print("· Δεν υπάρχει ιδιοκτήτρια — δεν δημιουργήθηκε αυτόματα.")
        print("  Δημιούργησέ την από τη σελίδα πρώτης εγκατάστασης:")
        print("    flask --app wsgi setup-token")
        print("  (Θα τυπώσει τη διεύθυνση /setup?token=… που ανοίγεις στον browser.)")
        print("  Εναλλακτικά, χωρίς browser:")
        print("    flask --app wsgi create-user <ΟΝΟΜΑ> <ΚΩΔΙΚΟΣ> --role owner \\")
        print("        --first-name \"Όνομα\" --last-name \"Επώνυμο\" --email you@example.com")
        return

    owner = User(
        username=OWNER_USERNAME,
        email=OWNER_EMAIL,
        role=ROLE_OWNER,
        first_name=OWNER_FIRST_NAME,
        last_name=OWNER_LAST_NAME,
    )
    owner.set_password(OWNER_PASSWORD)
    db.session.add(owner)
    db.session.flush()
    db.session.add(Groomer(user_id=owner.id, sort_order=1, color="#B0567A"))
    db.session.commit()
    print(f"✓ Δημιουργήθηκε προσωρινή ιδιοκτήτρια: «{OWNER_USERNAME}» / {OWNER_PASSWORD}")
    print("  ΑΛΛΑΞΕ ΤΟΝ ΚΩΔΙΚΟ Ή ΔΗΜΙΟΥΡΓΗΣΕ ΔΙΚΟ ΣΟΥ ΛΟΓΑΡΙΑΣΜΟ.")


# ------------------------------------------------------------------------ main
def main() -> None:
    parser = argparse.ArgumentParser(description="Μετατροπές βάσης δεδομένων")
    parser.add_argument(
        "--create-owner",
        action="store_true",
        help="Δημιουργεί προσωρινό λογαριασμό ιδιοκτήτρια με ΓΝΩΣΤΟ κωδικό "
             "(Niki/salon1234) αν δεν υπάρχει. Για δοκιμή μόνο — διέγραψέ τον μετά.",
    )
    parser.add_argument(
        "--purge-demo",
        action="store_true",
        help="Καθαρίζει πελάτες, κατοικίδια, ραντεβού και τους λογαριασμούς βοηθών.",
    )
    args = parser.parse_args()

    app = create_app()
    with app.app_context():
        # Ο έλεγχος για τον πίνακα εξόδων γίνεται πριν το create_all(),
        # αλλιώς θα αναφέρει πάντα «υπάρχει ήδη».
        had_expenses = "expenses" in db.inspect(db.engine).get_table_names()
        db.create_all()
        backup = backup_database()
        # Χωρίς `if`: το backup_database() ΣΗΚΩΝΕ αν αποτύχει, με την
        # αιτία. Ο παλιός έλεγχος `if backup:` κρύβε το απροσδόκητο None.

        add_username_column()

        # ---- ΠΡΩΤΑ ΟΙ ΣΗΜΑΙΕΣ ΑΡΧΕΙΟΘΕΤΗΣΗΣ, ΓΙΑΤΙ ΤΟ ΥΠΟΛΟΙΠΟ ΤΙΣ ΔΙΑΒΑΖΕΙ.
        # Οποιοσδήποτε ερώτημα που αγγίζει Pet ή User επιλέγει όλες τις στήλες
        # τους, άρα μια παλιά βάση χωρίς αυτές σκάζει στο ΠΡΩΤΟ βήμα — και
        # η εγκατάσταση γυρίζει πίσω, χωρίς να προλάβει να προσθέσει τίποτα.
        if add_archive_columns():
            print("· Προστέθηκαν οι σημαίες αρχειοθέτησης "
                  "(χρήστες, κατοικίδια).")

        # ---- Μετατροπή μοντέλου. Η σειρά είναι σημαντική: κάθε βήμα
        # προσθέτει στήλες ΠΡΙΝ από το επόμενο, γιατί το ORM χρειάζεται όλες.
        #
        # 1) ποσότητα/διάρκεια στον σύνδεσμο υπηρεσιών
        if add_quantity_to_services():
            print("· Προστέθηκε ποσότητα ανά υπηρεσία στο ραντεβού.")
        # 2) πολλά κατοικίδια ανά ραντεβού (ο πίνακας είναι ήδη έτοιμος από create_all)
        if add_appointment_pets():
            print("· Τα ραντεβού συνδέθηκαν με τα κατοικίδιά τους.")
        # 3) ονοματεπώνυμο πελάτη σε ένα πεδίο
        if add_customer_fullname():
            print("· Το ονοματεπώνυμο πελάτη ενώθηκε σε ένα πεδίο.")
        # 3β) ποιο κατοικίδιο παίρνει κάθε υπηρεσία. ΚΕΝΟ = όλα τα
        # κατοικίδια του ραντεβού, άρα τα παλιά ραντεβού μένουν όπως
        # ήταν — δεν πλάζουμε κατοικίδιο εκεί που δεν το ξέρουμε.
        if add_pet_to_appointment_services():
            print("· Κάθε υπηρεσία μπορεί να δηλώνει για ποιο κατοικίδιο "
                  "ισχύει.")
        # 3γ) ΤΑ ΠΡΟΚΑΘΟΡΙΣΜΕΝΑ ΕΙΔΗ ΕΞΟΔΩΝ ΠΟΥ ΛΕΙΠΟΥΝ. Η παλιά σπορά
        # σταματούσε μόλις βρισκόταν ΕΝΑ είδος, άρα σε υπάρχουσα εγκατάσταση
        # κανένα νέο είδος δεν μπήκε ποτέ (καφές, νερό, ενοίκιο, internet).
        added = backfill_store_expenses()
        if added:
            print("· Προστέθηκαν %d προκαθορισμένα είδη εξόδων που "
                  "έλειπαν." % added)
        # 4) μία τιμή / μία διάρκεια: οι παλιές στήλες γεμίζουν τις νέες
        if collapse_size_prices():
            print("· Οι τιμές/διάρκειες υπηρεσιών συγχωνίστηκαν σε μία "
                  "(τιμή & διάρκεια μεγάλου μεγέθους).")
        # 5) το όνομα του κατοικιδίου γίνεται προαιρετικό
        relax_optional_fields()
        print("· Ονοματεπώνυμο σε ένα πεδίο· όνομα κατοικιδίου προαιρετικό.")
        # 5) μία τιμή / μία διάρκεια ανά υπηρεσία (πρέπει μετά τα παραπάνω,
        #    γιατί το add_pricing_columns καλεί backfill που διαβάζει τα ποσά)


        add_pricing_columns()
        add_expenses_table(already_present=had_expenses)
        add_customer_archive_column()

        # ΤΟ ΚΕΙΜΕΝΟ «None» ΣΤΑ ΠΕΔΙΑ. Έφτασε από εισαγωγή από αρχείο και
        # εμφανιζόταν στον πελάτη ως «Τηλέφωνο: None». Βλ. purge_literal_nulls().
        cleared = purge_literal_nulls()
        if cleared:
            print("· Καθαρίστηκαν %d πεδία που είχαν το κείμενο «None»." % cleared)

        # ΤΑ ΑΡΧΕΙΑ ΕΚΚΙΝΗΣΗΣ ΣΤΗ ΡΙΖΑ. Χωρίς αυτό το βήμα, ο scheduler
        # των υπενθυμίσεων συνεχίζει να τρέχει τον αρχικό κώδικα για πάντα και
        # στέλνει τα ΠΑΛΙΑ πρότυπα email — βλ. sync_launchers() για την ιστορία.
        if sync_launchers():
            print("· Αντιγράφηκαν τα αρχεία εκκίνησης στη ρίζα "
                  "(server.py, wsgi.py).")

        if args.purge_demo:
            purge_demo_data()
        else:
            print("· Παράλειψη καθαρισμού (χρησιμοποιήστε --purge-demo για αυτό).")

        store_items = seed_store_expenses()
        if store_items:
            print(f"· Δημιουργήθηκε ο κατάλογος εξόδων καταστήματος ({store_items} εγγραφές).")

        settings_added = seed_salon_settings()
        if settings_added:
            print(f"· Προστέθηκαν ρυθμίσεις Salon ({settings_added}).")

        hours = seed_salon_hours()
        if hours:
            print(f"· Δημιουργήθηκαν οι ώρες λειτουργίας του Salon ({hours} ημέρες).")

        # Ο κατάλογος υπηρεσιών: χωρίς αυτόν δεν κλείνεται τίποτα.
        try:
            from seed import seed_services

            created_services = seed_services()
            if created_services:
                print(f"· Δημιουργήθηκε ο κατάλογος υπηρεσιών ({created_services}).")
        except Exception as exc:  # ποτέ να μην κρυφτεί
            print(f"  Προσοχή: ο κατάλογος υπηρεσιών δεν δημιουργήθηκε ({exc}).")

        ensure_owner(create=args.create_owner)

        print("✓ Οι μετατροπές ολοκληρώθηκαν.")


if __name__ == "__main__":
    main()
